# 📦 SafwaanBuddy - Complete Installation Guide

## Professional Installation for All Editions

---

## 🎯 Overview

This guide will help you install and configure all four editions of SafwaanBuddy:
- ⭐ Standard Edition
- 🔥 ULTIMATE Edition
- 💎 PRO MAX Edition
- 🏆 MASTER Edition

**Time Required**: 15-20 minutes
**Difficulty**: Easy
**Prerequisites**: Windows 11/10, Internet connection

---

## ✅ Pre-Installation Checklist

Before starting, ensure you have:
- [ ] Windows 11 or Windows 10
- [ ] Administrator access
- [ ] Internet connection (for downloads)
- [ ] Working microphone
- [ ] Speakers or headphones
- [ ] At least 2GB free disk space
- [ ] 4GB RAM minimum (8GB recommended)

---

## 📥 Step-by-Step Installation

### Step 1: Install Python 3.11+

#### Download Python
1. Visit [python.org/downloads](https://www.python.org/downloads/)
2. Click "Download Python 3.11.x" (or newer)
3. Save the installer

#### Install Python
1. Run the downloaded installer
2. ⚠️ **CRITICAL**: Check ✅ "Add Python to PATH"
3. Click "Install Now"
4. Wait for installation (2-3 minutes)
5. Click "Close"
6. **Restart your computer**

#### Verify Installation
1. Open Command Prompt (Win + R, type `cmd`, Enter)
2. Type: `python --version`
3. Should show: `Python 3.11.x` or higher
4. Type: `pip --version`
5. Should show pip version

**Troubleshooting**:
- If "python not recognized": Restart computer
- If still not working: Reinstall with "Add to PATH" checked
- If PATH issues: Add manually in System Environment Variables

---

### Step 2: Download SafwaanBuddy

1. **Download the SafwaanBuddy folder**
2. **Extract to a location** like:
   - `C:\SafwaanBuddy`
   - `C:\Users\YourName\SafwaanBuddy`
   - Desktop\SafwaanBuddy

3. **Open folder** in File Explorer

---

### Step 3: Install Dependencies

#### Method 1: Automated (Recommended)
1. **Double-click**: `install.bat`
2. Wait for installation (5-10 minutes)
3. Watch for "Installation Complete!" message

#### Method 2: Manual
1. Open Command Prompt in SafwaanBuddy folder
   - Hold Shift + Right-click in folder
   - Select "Open PowerShell window here"
2. Run:
   ```bash
   pip install -r requirements.txt
   ```
3. Wait for completion

#### What Gets Installed
- PyQt6 (User Interface)
- SpeechRecognition (Voice Input)
- edge-tts (Voice Output)
- google-generativeai (AI Brain)
- pygame (Audio)
- pyautogui (Automation)
- psutil (System Monitoring)
- And 20+ more packages...

**Troubleshooting**:
- If PyAudio fails on Windows:
  ```bash
  pip install pipwin
  pipwin install pyaudio
  ```
- If installation hangs: Close and restart
- If specific package fails: Install separately

---

### Step 4: Get Gemini API Key (FREE)

#### Create API Key
1. **Visit**: https://makersuite.google.com/app/apikey
2. **Sign in** with your Google account
3. **Click**: "Create API Key"
4. **Select**: "Create API key in new project"
5. **Copy** the generated key (starts with "AIza...")
6. **Save** it somewhere safe

**Important Notes**:
- API key is FREE
- Generous free tier (60 requests/minute)
- No credit card required
- Keep key private and secure

---

### Step 5: Configure SafwaanBuddy

#### Create .env File
1. In SafwaanBuddy folder, find `.env.template`
2. **Copy** it and rename to `.env`

**Windows Command**:
```bash
copy .env.template .env
```

#### Edit .env File
1. **Open** `.env` with Notepad
2. **Find** this line:
   ```
   GEMINI_API_KEY=your_gemini_api_key_here
   ```
3. **Replace** with your actual key:
   ```
   GEMINI_API_KEY=AIzaSyABC123def456GHI789jkl012MNO345pqr
   ```
4. **Save** and close

**Example .env**:
```
GEMINI_API_KEY=AIzaSyABC123def456GHI789jkl012MNO345pqr
WAKE_WORDS=safwaan,buddy,hey safwaan,computer
DEFAULT_VOICE=en-US-JennyNeural
ENABLE_LEARNING=true
```

---

### Step 6: Verify Installation (Recommended)

#### Run Verification
1. **Double-click**: `verify_setup.bat`
2. **Review** the checklist
3. **Ensure** all checks pass ✅

#### What It Checks
- ✅ Python version (3.11+)
- ✅ All dependencies installed
- ✅ API key configured
- ✅ Project files present
- ✅ Microphone available
- ✅ Audio output working

**If Any Check Fails**:
- Follow the error message instructions
- Review previous steps
- Check troubleshooting section

---

### Step 7: Test Microphone

#### Windows Microphone Setup
1. **Open Settings** (Win + I)
2. Go to **System** > **Sound**
3. Under **Input**, select your microphone
4. **Speak** and watch volume bar move
5. **Set as default** input device

#### Grant Permissions
1. Settings > **Privacy & Security** > **Microphone**
2. Enable "**Microphone access**"
3. Enable for "**Desktop apps**"

#### Test in Windows
1. Right-click speaker icon in taskbar
2. Select "**Sound settings**"
3. Click "**Test your microphone**"
4. Speak and verify it works

---

### Step 8: Choose Your Edition

#### Decision Guide

**Choose Standard If**:
- You're new to voice assistants
- You want basic functionality
- You have 2-4GB RAM
- You prefer simplicity

**Choose ULTIMATE If**:
- You want realistic voice
- You need automation
- You have 4-8GB RAM
- You're a power user

**Choose PRO MAX If**:
- You need vision AI
- You want focus mode
- You have 8GB+ RAM
- You're a professional

**Choose MASTER If**:
- You want premium UI
- You need maximum power
- You have 8GB+ RAM
- You want enterprise grade

**Recommendation**: Start with ULTIMATE, upgrade to MASTER later

---

### Step 9: First Launch

#### Launch Your Chosen Edition

**Standard**:
```bash
# Double-click:
run.bat

# Or:
python main.py
```

**ULTIMATE**:
```bash
# Double-click:
run_ultimate.bat

# Or:
python safwaan_ultimate.py
```

**PRO MAX**:
```bash
# Double-click:
run_pro_max.bat

# Or:
python safwaan_pro_max.py
```

**MASTER**:
```bash
# Double-click:
run_master.bat

# Or:
python safwaan_master.py
```

#### What to Expect
1. **Console window** opens with initialization messages
2. **Hologram UI** appears at top of screen
3. **Welcome message**: "Hello! I'm Safwaan..."
4. **Microphone adjustment**: 2 seconds
5. **Ready message**: "Listening started..."

---

### Step 10: First Commands

#### Test Basic Commands
```
"Safwaan, what time is it?"
"Safwaan, tell me a joke"
"Safwaan, what's the weather?"
```

#### Test Conversation Mode
```
You: "Safwaan"
Safwaan: "Hello! How can I help you?"
You: "What time is it?"
Safwaan: "The current time is 3:45 PM"
You: "Thanks!"
Safwaan: "You're welcome!"
```

#### Test Advanced Features (PRO MAX/MASTER)
```
"Safwaan, demonstrate your personalities"
"Safwaan, demonstrate your emotions"
"Safwaan, start focus mode for 25 minutes"
"Safwaan, show productivity stats"
```

---

## ⚙️ Configuration & Customization

### Edit config.json

#### Change Wake Words
```json
{
  "wake_words": ["safwaan", "buddy", "assistant", "computer"]
}
```

#### Change UI Size
```json
{
  "ui": {
    "hologram_size": 500,
    "animation_fps": 60
  }
}
```

#### Enable/Disable Features
```json
{
  "features": {
    "enable_learning": true,
    "enable_proactive": true,
    "enable_conversation_mode": true
  }
}
```

### Edit .env

#### Change Default Voice
```
DEFAULT_VOICE=en-GB-RyanNeural
```

#### Change Speech Settings
```
SPEECH_RATE=+10%
SPEECH_VOLUME=+20%
```

---

## 🔧 Advanced Configuration

### Multiple API Keys

#### Add OpenAI (Optional)
```
OPENAI_API_KEY=sk-...
```

#### Custom Wake Words
```
WAKE_WORDS=safwaan,buddy,jarvis,friday,computer
```

### Performance Tuning

#### For Low-End PCs
```json
{
  "performance": {
    "max_concurrent_threads": 2,
    "cache_size": 50
  },
  "ui": {
    "animation_fps": 30
  }
}
```

#### For High-End PCs
```json
{
  "performance": {
    "max_concurrent_threads": 8,
    "cache_size": 200
  },
  "ui": {
    "animation_fps": 60
  }
}
```

---

## 🐛 Troubleshooting

### Common Issues & Solutions

#### Issue: "Python not recognized"
**Cause**: Python not in PATH
**Solution**:
1. Reinstall Python with "Add to PATH" checked
2. Restart computer
3. Try again

#### Issue: "No module named 'PyQt6'"
**Cause**: Dependencies not installed
**Solution**:
```bash
pip install -r requirements.txt
```

#### Issue: "Microphone not working"
**Cause**: Permissions or settings
**Solution**:
1. Check Windows microphone permissions
2. Set as default device
3. Test in Windows Sound settings
4. Restart SafwaanBuddy

#### Issue: "No voice output"
**Cause**: Audio system issue
**Solution**:
1. Check speaker/headphone connection
2. Verify system volume
3. Test with other audio
4. Restart SafwaanBuddy

#### Issue: "API key error"
**Cause**: Invalid or missing key
**Solution**:
1. Verify key in .env file
2. Check for extra spaces
3. Ensure internet connection
4. Try generating new key

#### Issue: "High CPU usage"
**Cause**: Too many features enabled
**Solution**:
1. Use Standard or ULTIMATE edition
2. Reduce animation FPS in config
3. Disable proactive monitoring
4. Close other applications

#### Issue: "Hologram not showing"
**Cause**: UI initialization issue
**Solution**:
1. Check if running in background
2. Look for system tray icon
3. Right-click tray > Show/Hide
4. Restart application

---

## 📊 Post-Installation

### Verify Everything Works

#### Checklist
- [ ] Python installed and in PATH
- [ ] All dependencies installed
- [ ] API key configured in .env
- [ ] Microphone working
- [ ] Audio output working
- [ ] Hologram UI appears
- [ ] Voice recognition works
- [ ] Voice output works
- [ ] Commands execute correctly

#### Test Commands
```
✅ "Safwaan, what time is it?"
✅ "Safwaan, tell me a joke"
✅ "Safwaan, search for Python"
✅ "Safwaan, take a screenshot"
✅ "Safwaan, system info"
```

### Customize Your Experience

#### 1. Choose Personality
Edit config.json or say:
```
"Safwaan, switch to professional voice"
"Safwaan, use friendly voice"
```

#### 2. Set Preferences
- Adjust wake words
- Change UI size
- Enable/disable features
- Set default voice

#### 3. Explore Features
- Try all commands
- Test conversation mode
- Explore automation (PRO MAX/MASTER)
- Use focus mode (PRO MAX/MASTER)

---

## 🎓 Learning Path

### Week 1: Basics (Standard)
- Install and configure
- Learn wake words
- Try basic commands (time, jokes, search)
- Practice conversation mode
- Explore UI

### Week 2: Intermediate (ULTIMATE)
- Upgrade to ULTIMATE
- Experience realistic voice
- Try screen control
- Use proactive features
- Customize settings

### Week 3: Advanced (PRO MAX)
- Upgrade to PRO MAX
- Use vision AI
- Try focus mode
- Create workflows
- Track productivity

### Week 4: Master (MASTER)
- Upgrade to MASTER
- Experience premium UI
- Use all features
- Optimize workflows
- Master the system

---

## 🚀 Quick Start Commands

### First 10 Commands to Try

1. **"Safwaan, what time is it?"**
   - Tests basic functionality

2. **"Safwaan, tell me a joke"**
   - Tests entertainment

3. **"Safwaan, what's the weather?"**
   - Tests web integration

4. **"Safwaan, play some music"**
   - Tests YouTube integration

5. **"Safwaan, search for Python tutorials"**
   - Tests web search

6. **"Safwaan, take a screenshot"**
   - Tests system control

7. **"Safwaan, what's my system info?"**
   - Tests system monitoring

8. **"Safwaan, open email"**
   - Tests application control

9. **"Safwaan, calculate 25 times 4"**
   - Tests calculator

10. **"Safwaan, what can you do?"**
    - Tests help system

---

## 💡 Pro Tips

### Installation Tips
1. **Use install.bat**: Easiest method
2. **Verify setup**: Run verify_setup.bat
3. **Check logs**: Review safwaan*.log files
4. **Test incrementally**: Test after each step
5. **Keep backups**: Save working .env file

### Usage Tips
1. **Start simple**: Begin with Standard
2. **Learn gradually**: Master basics first
3. **Upgrade progressively**: Standard → ULTIMATE → PRO MAX → MASTER
4. **Customize**: Make it yours
5. **Explore**: Try all features

### Performance Tips
1. **Close unused apps**: Free up resources
2. **Use appropriate edition**: Match your PC specs
3. **Adjust FPS**: Lower if laggy
4. **Disable features**: Turn off unused features
5. **Regular restarts**: Restart occasionally

---

## 📞 Getting Help

### Documentation Files
- **START_HERE.md** - Quick start
- **QUICKSTART.md** - 5-minute guide
- **SETUP_GUIDE.md** - Detailed setup
- **USER_MANUAL.md** - Command reference
- **MASTER_EDITION.md** - MASTER features
- **ALL_EDITIONS_COMPARISON.md** - Compare editions

### Log Files
- `safwaan.log` - Standard edition logs
- `safwaan_ultimate.log` - ULTIMATE logs
- `safwaan_pro_max.log` - PRO MAX logs
- `safwaan_master.log` - MASTER logs

### Verification
- Run `verify_setup.bat` anytime
- Check all components
- Verify configuration

---

## 🎊 Installation Complete!

### You Now Have:
✅ Python 3.11+ installed
✅ All dependencies installed
✅ API key configured
✅ Four complete editions ready
✅ Comprehensive documentation
✅ All tools and utilities

### Next Steps:
1. **Choose edition** (recommend ULTIMATE or MASTER)
2. **Launch** your chosen edition
3. **Say** "Safwaan" to activate
4. **Try** basic commands
5. **Explore** all features
6. **Customize** to your preferences
7. **Enjoy** your AI assistant!

---

## 🌟 Welcome to SafwaanBuddy!

Your advanced AI voice assistant is ready!

**Launch now**:
```bash
run_master.bat  # Premium experience
```

**Say**:
```
"Safwaan, hello! Let's get started!"
```

---

**Installation Guide Version**: 1.0
**Last Updated**: December 2024
**Status**: ✅ Complete
**Support**: See documentation files

**Enjoy your AI companion!** 🤖✨