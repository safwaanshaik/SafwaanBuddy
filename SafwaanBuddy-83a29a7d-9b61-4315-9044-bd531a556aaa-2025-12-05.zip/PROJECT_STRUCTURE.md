# 📁 SafwaanBuddy Project Structure

Complete overview of the project architecture and file organization.

---

## 🗂️ Directory Structure

```
SafwaanBuddy/
├── main.py                      # Main application entry point
├── requirements.txt             # Python dependencies
├── config.json                  # Application configuration
├── .env.template               # Environment variables template
├── .env                        # Your API keys (create from template)
│
├── src/                        # Source code directory
│   ├── __init__.py            # Package initializer
│   ├── config_manager.py      # Configuration management
│   ├── database_manager.py    # SQLite database operations
│   ├── voice_system.py        # Text-to-speech system
│   ├── listener.py            # Speech recognition
│   ├── ai_brain.py            # AI processing with Gemini
│   ├── hologram_ui.py         # PyQt6 GUI interface
│   │
│   └── skills/                # Skills and tools
│       ├── __init__.py
│       ├── basic_skills.py    # Basic commands
│       └── advanced_skills.py # System automation
│
├── temp_audio/                # Temporary audio files (auto-created)
├── safwaan_data.db           # SQLite database (auto-created)
├── safwaan.log               # Application logs (auto-created)
│
├── README.md                  # Project overview
├── SETUP_GUIDE.md            # Installation instructions
├── USER_MANUAL.md            # Complete user guide
├── QUICKSTART.md             # Quick start guide
├── PROJECT_STRUCTURE.md      # This file
│
├── run.bat                    # Windows launcher script
└── install.bat               # Windows installation script
```

---

## 📄 File Descriptions

### Core Files

#### `main.py`
**Purpose**: Application entry point and orchestration
- Initializes all components
- Manages Qt application lifecycle
- Handles voice command routing
- Coordinates between modules

**Key Classes**:
- `SafwaanBuddy`: Main application class

**Key Functions**:
- `start()`: Launch application
- `_on_command()`: Process voice commands
- `_execute_tool()`: Execute detected tools
- `shutdown()`: Clean shutdown

---

#### `requirements.txt`
**Purpose**: Python package dependencies
- Lists all required packages
- Specifies versions for compatibility
- Used by pip for installation

**Key Dependencies**:
- PyQt6: GUI framework
- SpeechRecognition: Voice input
- edge-tts: Text-to-speech
- google-generativeai: AI brain
- pygame: Audio playback
- psutil: System monitoring

---

#### `config.json`
**Purpose**: Application configuration
- Voice personalities
- Wake words
- Feature toggles
- UI settings
- Performance parameters

**Customizable Settings**:
```json
{
  "voice_personalities": {...},
  "wake_words": [...],
  "features": {...},
  "ui": {...}
}
```

---

#### `.env.template` / `.env`
**Purpose**: Environment variables and API keys
- Gemini API key
- OpenAI API key (optional)
- Wake words override
- Voice settings
- Log level

**Security**: `.env` should never be committed to version control

---

### Source Code (`src/`)

#### `config_manager.py`
**Purpose**: Configuration management system

**Key Class**: `ConfigManager`
- Loads config.json
- Reads .env file
- Provides configuration access
- Saves configuration changes

**Key Methods**:
- `get(key, default)`: Get config value
- `set(key, value)`: Set config value
- `get_api_key(service)`: Get API key
- `get_wake_words()`: Get wake words
- `save_config()`: Save to file

---

#### `database_manager.py`
**Purpose**: SQLite database operations

**Key Class**: `DatabaseManager`
- Manages SQLite connection
- Creates and maintains tables
- Stores conversations
- Manages memories
- Tracks metrics

**Database Tables**:
1. **conversations**: All user interactions
2. **memories**: Important information
3. **user_preferences**: User settings
4. **system_metrics**: Performance data

**Key Methods**:
- `store_conversation()`: Save interaction
- `get_conversation_history()`: Retrieve history
- `store_memory()`: Save memory
- `get_relevant_memories()`: Retrieve memories
- `get_statistics()`: Get stats

---

#### `voice_system.py`
**Purpose**: Text-to-speech with edge-tts

**Key Classes**:
- `VoiceSystem`: Main TTS system
- `VoiceCloner`: Voice cloning (placeholder)

**Features**:
- Multiple voice personalities
- Emotion-based modulation
- Async audio generation
- Interruption support
- Queue management

**Key Methods**:
- `speak()`: Speak text
- `stop_speaking()`: Interrupt
- `set_personality()`: Change voice
- `cleanup()`: Clean temp files

**Voice Personalities**:
- Professional: en-GB-RyanNeural
- Friendly: en-US-JennyNeural
- Energetic: en-US-GuyNeural
- Calm: en-US-AriaNeural

---

#### `listener.py`
**Purpose**: Speech recognition and wake word detection

**Key Class**: `VoiceListener`
- Continuous listening
- Wake word detection
- Conversation mode
- Microphone management

**Features**:
- Dynamic energy threshold
- Ambient noise adjustment
- Conversation timeout
- Multiple wake words

**Key Methods**:
- `listen_continuous()`: Start listening
- `stop_listening()`: Stop listening
- `enable_conversation_mode()`: Activate mode
- `disable_conversation_mode()`: Deactivate mode

**Wake Word Detection**:
- Checks for wake words in speech
- Extracts command after wake word
- Activates conversation mode

---

#### `ai_brain.py`
**Purpose**: AI processing with Google Gemini

**Key Class**: `AIBrain`
- Gemini API integration
- Context management
- Tool detection
- Emotion detection
- Memory integration

**Features**:
- Conversation history
- Context-aware responses
- Fallback responses
- Performance metrics

**Key Methods**:
- `think()`: Process user input
- `_generate_gemini_response()`: AI response
- `_detect_tool()`: Identify tool
- `_detect_emotion()`: Detect emotion
- `get_stats()`: Get statistics

**Tool Detection**:
- TIME, DATE, JOKE
- MUSIC, SEARCH, WEBSITE
- SCREENSHOT, WEATHER, NEWS
- EMAIL, CALENDAR, CALCULATOR
- And many more...

---

#### `hologram_ui.py`
**Purpose**: PyQt6 holographic interface

**Key Class**: `HologramUI`
- Animated hologram display
- State visualization
- Emotion display
- System tray integration

**Features**:
- Frameless window
- Always on top
- Draggable
- Particle effects
- State-based animations

**States**:
- IDLE: Waiting
- LISTENING: Active listening
- THINKING: Processing
- SPEAKING: Responding
- ERROR: Problem occurred

**Key Methods**:
- `animate()`: Update animation
- `paintEvent()`: Draw hologram
- `set_state()`: Change state
- `set_emotion()`: Update emotion
- `toggle_visibility()`: Show/hide

---

### Skills (`src/skills/`)

#### `basic_skills.py`
**Purpose**: Basic command implementations

**Key Class**: `BasicSkills`

**Implemented Skills**:
- `get_time()`: Current time
- `get_date()`: Current date
- `tell_joke()`: Random joke
- `search_web()`: Google search
- `play_music()`: YouTube music
- `open_website()`: Open URL
- `take_screenshot()`: Screen capture
- `get_weather()`: Weather info
- `get_news()`: Latest news
- `open_email()`: Gmail
- `open_calendar()`: Google Calendar
- `calculate()`: Math operations
- `take_note()`: Save note
- `translate()`: Google Translate

---

#### `advanced_skills.py`
**Purpose**: System automation and advanced features

**Key Class**: `AdvancedSkills`

**Implemented Skills**:
- `get_system_info()`: PC specs
- `set_volume()`: Volume control
- `close_window()`: Close active window
- `minimize_window()`: Minimize window
- `maximize_window()`: Maximize window
- `lock_computer()`: Lock PC
- `shutdown_computer()`: Shutdown
- `restart_computer()`: Restart
- `cancel_shutdown()`: Cancel shutdown
- `get_battery_status()`: Battery info
- `get_network_info()`: Network info
- `open_task_manager()`: Task Manager
- `open_control_panel()`: Control Panel

---

## 🔄 Data Flow

### Voice Command Flow

```
1. User speaks → Microphone
2. Listener captures audio
3. Speech Recognition converts to text
4. Wake word detection
5. AI Brain processes command
6. Tool detection
7. Skill execution
8. Response generation
9. Voice System speaks response
10. Database stores interaction
```

### Component Interaction

```
main.py
  ├─→ ConfigManager (config)
  ├─→ DatabaseManager (data storage)
  ├─→ VoiceSystem (TTS)
  ├─→ VoiceListener (STT)
  ├─→ AIBrain (processing)
  │     ├─→ Gemini API
  │     ├─→ DatabaseManager (memories)
  │     └─→ Tool Detection
  ├─→ HologramUI (display)
  └─→ Skills (execution)
        ├─→ BasicSkills
        └─→ AdvancedSkills
```

---

## 💾 Database Schema

### conversations
```sql
CREATE TABLE conversations (
    id INTEGER PRIMARY KEY,
    session_id TEXT,
    user_input TEXT,
    ai_response TEXT,
    emotion TEXT,
    tool_used TEXT,
    confidence REAL,
    response_time REAL,
    timestamp TIMESTAMP
)
```

### memories
```sql
CREATE TABLE memories (
    id INTEGER PRIMARY KEY,
    content TEXT,
    category TEXT,
    importance REAL,
    access_count INTEGER,
    last_accessed TIMESTAMP,
    created_at TIMESTAMP
)
```

### user_preferences
```sql
CREATE TABLE user_preferences (
    id INTEGER PRIMARY KEY,
    key TEXT UNIQUE,
    value TEXT,
    updated_at TIMESTAMP
)
```

### system_metrics
```sql
CREATE TABLE system_metrics (
    id INTEGER PRIMARY KEY,
    metric_type TEXT,
    metric_value REAL,
    metadata TEXT,
    timestamp TIMESTAMP
)
```

---

## 🔧 Configuration Files

### config.json Structure
```json
{
  "version": "1.0.0",
  "app_name": "SafwaanBuddy",
  "voice_personalities": {
    "professional": "voice-id",
    "friendly": "voice-id",
    "energetic": "voice-id",
    "calm": "voice-id"
  },
  "wake_words": ["safwaan", "buddy"],
  "features": {
    "enable_learning": true,
    "enable_conversation_mode": true
  },
  "performance": {
    "max_concurrent_threads": 4,
    "cache_size": 100,
    "response_timeout": 30.0
  },
  "ui": {
    "hologram_size": 300,
    "animation_fps": 30,
    "show_on_startup": true
  }
}
```

### .env Structure
```
GEMINI_API_KEY=your_key
OPENAI_API_KEY=optional
WAKE_WORDS=safwaan,buddy
DEFAULT_VOICE=en-US-JennyNeural
SPEECH_RATE=+0%
SPEECH_VOLUME=+0%
LOG_LEVEL=INFO
```

---

## 📊 Logging System

### Log Files
- **safwaan.log**: Main application log
- **Console**: Real-time output

### Log Levels
- **INFO**: Normal operations
- **WARNING**: Non-critical issues
- **ERROR**: Problems requiring attention
- **DEBUG**: Detailed information

### Log Format
```
YYYY-MM-DD HH:MM:SS - Module - Level - Message
```

---

## 🔐 Security Considerations

### API Keys
- Stored in .env file
- Never committed to version control
- Loaded at runtime only

### Database
- Local SQLite storage
- No external transmission
- Optional encryption support

### Privacy
- All processing local except AI
- No telemetry or tracking
- User data stays on device

---

## 🚀 Performance

### Memory Usage
- Typical: 200-400 MB
- Peak: 500-600 MB
- Depends on features enabled

### CPU Usage
- Idle: <1%
- Listening: 2-5%
- Processing: 10-20%
- Speaking: 5-10%

### Disk Usage
- Application: ~50 MB
- Dependencies: ~200 MB
- Database: Grows with usage
- Temp files: Auto-cleaned

---

## 🔮 Extension Points

### Adding New Skills
1. Add method to BasicSkills or AdvancedSkills
2. Add tool detection in ai_brain.py
3. Add execution in main.py

### Adding New Voice Personalities
1. Add to config.json
2. Use edge-tts voice ID

### Custom Wake Words
1. Edit .env or config.json
2. Add to wake_words list

### Database Extensions
1. Add table in database_manager.py
2. Create methods for CRUD operations

---

## 📚 Dependencies Overview

### Core Dependencies
- **PyQt6**: GUI framework
- **SpeechRecognition**: Voice input
- **edge-tts**: Text-to-speech
- **google-generativeai**: AI brain
- **pygame**: Audio playback

### System Dependencies
- **psutil**: System monitoring
- **pyautogui**: Automation
- **pygetwindow**: Window management
- **pywin32**: Windows API

### Utility Dependencies
- **python-dotenv**: Environment variables
- **requests**: HTTP requests
- **logging**: Application logging

---

## 🎯 Module Responsibilities

| Module | Responsibility |
|--------|---------------|
| main.py | Orchestration & coordination |
| config_manager.py | Configuration management |
| database_manager.py | Data persistence |
| voice_system.py | Audio output |
| listener.py | Audio input |
| ai_brain.py | Intelligence & processing |
| hologram_ui.py | User interface |
| basic_skills.py | Basic commands |
| advanced_skills.py | System automation |

---

## 🔄 Lifecycle

### Startup
1. Load configuration
2. Initialize database
3. Setup voice system
4. Initialize AI brain
5. Create GUI
6. Start listener
7. Enter event loop

### Runtime
1. Listen for wake word
2. Capture command
3. Process with AI
4. Execute tool
5. Speak response
6. Store in database
7. Update UI

### Shutdown
1. Stop listener
2. Cleanup voice system
3. Close database
4. Save configuration
5. Generate statistics
6. Exit gracefully

---

## 📖 Documentation Files

- **README.md**: Project overview and features
- **SETUP_GUIDE.md**: Installation instructions
- **USER_MANUAL.md**: Complete usage guide
- **QUICKSTART.md**: Quick start guide
- **PROJECT_STRUCTURE.md**: This file

---

**Version**: 1.0.0  
**Last Updated**: December 2024  
**Architecture**: Modular, event-driven, extensible