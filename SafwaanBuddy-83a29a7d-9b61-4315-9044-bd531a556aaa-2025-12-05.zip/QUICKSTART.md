# ⚡ SafwaanBuddy Quick Start

Get up and running in 5 minutes!

---

## 🚀 Super Quick Setup

### 1️⃣ Install Python (if not installed)
- Download from [python.org](https://www.python.org/downloads/)
- ✅ Check "Add Python to PATH"
- Install

### 2️⃣ Install Dependencies
```bash
# Double-click install.bat
# OR run in Command Prompt:
pip install -r requirements.txt
```

### 3️⃣ Get API Key
1. Visit [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Create API Key
3. Copy it

### 4️⃣ Configure
```bash
# Copy template
copy .env.template .env

# Edit .env and paste your API key
GEMINI_API_KEY=your_key_here
```

### 5️⃣ Run
```bash
# Double-click run.bat
# OR run:
python main.py
```

---

## 🎤 First Commands

Try these immediately:

```
"Safwaan, what time is it?"
"Safwaan, tell me a joke"
"Safwaan, search for Python tutorials"
"Safwaan, play some music"
```

---

## 🎯 Essential Commands

| Say This | Get This |
|----------|----------|
| "Safwaan" | Activate assistant |
| "What time is it?" | Current time |
| "Tell me a joke" | Random joke |
| "Play [song]" | YouTube music |
| "Search for [topic]" | Google search |
| "Take a screenshot" | Screen capture |
| "What's the weather?" | Weather info |
| "Open email" | Gmail |
| "System info" | PC specs |
| "Goodbye" | Exit conversation |

---

## 💡 Pro Tips

1. **Conversation Mode**: Say just "Safwaan" to start chatting
2. **Natural Language**: Speak normally, no special phrases needed
3. **Interruption**: Say wake word while it's speaking
4. **System Tray**: Minimize to tray, right-click for menu
5. **Drag UI**: Click and drag hologram to move it

---

## 🔧 Troubleshooting

### Microphone Not Working?
- Check Windows microphone permissions
- Set as default device
- Test in Windows Sound settings

### No Voice Output?
- Check speaker connection
- Verify system volume
- Restart SafwaanBuddy

### API Key Error?
- Verify key in .env file
- Check for extra spaces
- Ensure internet connection

---

## 📚 Learn More

- **README.md**: Full feature list
- **SETUP_GUIDE.md**: Detailed installation
- **USER_MANUAL.md**: Complete command reference

---

## 🎉 You're Ready!

Just say "Safwaan" and start chatting!

**Enjoy your AI assistant!** 🤖✨