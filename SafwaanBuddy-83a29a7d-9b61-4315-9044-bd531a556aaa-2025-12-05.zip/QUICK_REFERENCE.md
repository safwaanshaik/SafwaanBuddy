# ⚡ SafwaanBuddy - Quick Reference Card

## Everything You Need on One Page

---

## 🚀 HOW TO RUN (Choose ONE)

### 🎯 **Easiest Way** (First Time)
```
Double-click: SETUP_EVERYTHING.bat
(Does everything automatically!)
```

### 🎮 **Menu Way** (After Setup)
```
Double-click: LAUNCHER.bat
(Choose your edition from menu)
```

### ⚡ **Direct Launch** (After Setup)
```
run.bat              → Standard ⭐
run_ultimate.bat     → ULTIMATE 🔥
run_pro_max.bat      → PRO MAX 💎
run_master.bat       → MASTER 🏆 (Recommended!)
```

---

## 🎤 VOICE COMMANDS CHEAT SHEET

### 🔊 Wake Words (Say These to Activate)
- "Safwaan"
- "Buddy"
- "Hey Safwaan"
- "Computer"

### ⏰ Time & Date
```
"What time is it?"
"What's the date?"
"What day is it?"
```

### 😂 Entertainment
```
"Tell me a joke"
"Play [song name]"
"Play some music"
```

### 🔍 Web & Search
```
"Search for [topic]"
"Open [website]"
"Open YouTube"
"Open Gmail"
```

### 📸 System
```
"Take a screenshot"
"System info"
"Battery status"
"What's the weather?"
```

### 🪟 Window Control
```
"Close window"
"Minimize window"
"Maximize window"
```

### 🔊 Volume
```
"Set volume to [0-100]"
"Increase volume"
"Decrease volume"
```

### 💻 Applications
```
"Open task manager"
"Open control panel"
"Lock computer"
```

### 🎯 MASTER Edition Only
```
"Start focus mode"
"Analyze my screen"
"Show my goals"
"Daily briefing"
"Demonstrate personalities"
"Demonstrate emotions"
```

---

## 🗣️ CONVERSATION MODE

### Start Conversation
```
You: "Safwaan"
Safwaan: "Hello! How can I help?"
You: "What time is it?"
Safwaan: "It's 3:45 PM"
You: "And the date?"
Safwaan: "Today is Thursday, December 5, 2024"
```

### Exit Conversation
```
Say: "Goodbye" or "Stop listening" or "Exit"
Or: Wait 30 seconds
```

---

## 🎭 VOICE PERSONALITIES

### Available Personalities
1. **Friendly** (Default) - Warm, approachable
2. **Professional** - Confident, business-like
3. **Energetic** - Enthusiastic, motivating
4. **Calm** - Soothing, peaceful
5. **Sophisticated** - Elegant, refined
6. **Caring** - Empathetic, supportive

### Change Personality
```
"Switch to professional personality"
"Use calm voice"
"Be more energetic"
```

---

## 😊 EMOTIONS

Safwaan understands and expresses:
- Happy 😊
- Sad 😢
- Excited 🤩
- Calm 😌
- Angry 😠
- Confused 😕
- Neutral 😐
- Thinking 🤔
- Confident 💪
- Empathetic 🤗

---

## 🔧 TROUBLESHOOTING

### Problem: Python not found
```
Solution:
1. Install Python 3.11+ from python.org
2. ✅ Check "Add Python to PATH"
3. Restart computer
```

### Problem: Dependencies won't install
```
Solution:
1. Open Command Prompt as Admin
2. Run: pip install --upgrade pip
3. Run: pip install -r requirements.txt
```

### Problem: No API key
```
Solution:
1. Visit: https://makersuite.google.com/app/apikey
2. Create FREE API key
3. Double-click: auto_configure.py
4. Paste your key
```

### Problem: Microphone not working
```
Solution:
1. Check Windows microphone permissions
2. Set as default device
3. Test in Windows Sound settings
4. Restart SafwaanBuddy
```

### Problem: No voice output
```
Solution:
1. Check speaker connection
2. Verify system volume
3. Check Windows sound settings
4. Restart SafwaanBuddy
```

---

## 📁 KEY FILES

### To Run
- `SETUP_EVERYTHING.bat` - Complete auto-setup
- `LAUNCHER.bat` - Edition menu
- `run_master.bat` - Launch MASTER (best!)

### To Configure
- `auto_configure.py` - Configure API key
- `.env` - Your settings
- `config.json` - App settings

### To Verify
- `verify_setup.bat` - Check installation
- `verify_setup.py` - Detailed check

### To Learn
- `HOW_TO_RUN.md` - This guide
- `START_HERE.md` - Begin here
- `USER_MANUAL.md` - All commands

---

## 🎯 RECOMMENDED WORKFLOW

### First Time User:
```
1. Double-click: SETUP_EVERYTHING.bat
2. Follow prompts (10-15 minutes)
3. Choose MASTER edition
4. Say: "Safwaan, what time is it?"
5. Explore commands!
```

### Daily Use:
```
1. Double-click: run_master.bat
2. Wait for "I'm ready"
3. Say: "Safwaan"
4. Start talking!
```

---

## 💡 PRO TIPS

1. **Speak Clearly**: Normal speaking voice works best
2. **Wait for Green**: Hologram turns green when listening
3. **Natural Language**: Speak normally, no special phrases
4. **Conversation Mode**: Say just "Safwaan" to chat
5. **Interrupt**: Say wake word while it's speaking
6. **Drag UI**: Click and drag hologram to move it
7. **System Tray**: Minimize to tray, right-click for menu

---

## 🎊 YOU'RE READY!

### Quick Start:
```
1. Double-click: SETUP_EVERYTHING.bat
2. Wait 10-15 minutes
3. Say: "Safwaan, hello!"
```

**Enjoy your AI assistant!** 🤖✨

---

## 📞 NEED HELP?

- Read: `START_HERE.md`
- Read: `USER_MANUAL.md`
- Run: `verify_setup.bat`
- Check: `safwaan_master.log` for errors