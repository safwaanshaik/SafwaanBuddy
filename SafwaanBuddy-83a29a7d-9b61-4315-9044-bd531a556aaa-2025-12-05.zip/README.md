# 🌟 SafwaanBuddy - Advanced AI Voice Assistant

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![Python](https://img.shields.io/badge/python-3.11+-green)
![License](https://img.shields.io/badge/license-MIT-orange)

**SafwaanBuddy** is a powerful, feature-rich AI voice assistant for Windows 11 with advanced capabilities including voice recognition, AI-powered responses, holographic UI, and system automation.

---

## ✨ Features

### 🎤 Voice Recognition
- **Wake Word Detection**: Activate with "Safwaan", "Buddy", "Hey Safwaan", or "Computer"
- **Conversation Mode**: Natural back-and-forth conversations
- **Continuous Listening**: Always ready to help
- **Multi-Engine Support**: Google Speech Recognition with fallbacks

### 🧠 AI Intelligence
- **Google Gemini Integration**: Advanced AI responses with Gemini Pro
- **Context Awareness**: Remembers conversation history
- **Memory System**: Stores and retrieves relevant information
- **Emotion Detection**: Understands user emotions and adapts responses
- **Smart Tool Detection**: Automatically identifies user intent

### 🗣️ Voice System
- **Multiple Personalities**: Professional, Friendly, Energetic, Calm
- **Emotion-Based Modulation**: Voice changes based on emotion
- **Edge-TTS Integration**: High-quality text-to-speech
- **Natural Speech**: Human-like voice output

### 🎨 Holographic UI
- **Animated Interface**: Beautiful holographic display
- **State Indicators**: Visual feedback for listening, thinking, speaking
- **Emotion Display**: Shows detected emotions
- **System Tray Integration**: Minimize to tray
- **Draggable Window**: Position anywhere on screen

### 🛠️ Skills & Tools

#### Basic Skills
- ⏰ **Time & Date**: Get current time and date
- 😂 **Jokes**: Tell random jokes
- 🎵 **Music**: Play music on YouTube
- 🔍 **Web Search**: Search Google
- 🌐 **Website**: Open any website
- 📸 **Screenshot**: Capture screen
- ☁️ **Weather**: Check weather
- 📰 **News**: Get latest news
- 📧 **Email**: Open Gmail
- 📅 **Calendar**: Open Google Calendar
- 🧮 **Calculator**: Perform calculations
- 📝 **Notes**: Take quick notes
- 🌍 **Translate**: Translate text

#### Advanced Skills
- 💻 **System Info**: Get CPU, memory, disk usage
- 🔊 **Volume Control**: Adjust system volume
- 🪟 **Window Management**: Close, minimize, maximize windows
- 🔒 **Lock Computer**: Lock your PC
- 🔌 **Shutdown/Restart**: Power management
- 🔋 **Battery Status**: Check battery level
- 🌐 **Network Info**: Get IP and hostname
- 📊 **Task Manager**: Open Task Manager
- ⚙️ **Control Panel**: Open Control Panel

### 💾 Data Management
- **SQLite Database**: Stores conversations, memories, preferences
- **Conversation History**: Track all interactions
- **Memory System**: Context-aware responses
- **Statistics**: Performance metrics and analytics

---

## 📋 Requirements

### System Requirements
- **OS**: Windows 11 (or Windows 10)
- **Python**: 3.11 or higher
- **RAM**: 4GB minimum (8GB recommended)
- **Microphone**: Required for voice input
- **Internet**: Required for AI features

### Python Dependencies
See `requirements.txt` for full list. Key dependencies:
- PyQt6 (GUI)
- SpeechRecognition (Voice input)
- edge-tts (Text-to-speech)
- google-generativeai (AI brain)
- pygame (Audio playback)
- pyautogui (System automation)
- psutil (System monitoring)

---

## 🚀 Installation

### Step 1: Clone or Download
```bash
# Download the SafwaanBuddy folder to your computer
cd SafwaanBuddy
```

### Step 2: Install Python
1. Download Python 3.11+ from [python.org](https://www.python.org/downloads/)
2. **Important**: Check "Add Python to PATH" during installation
3. Verify installation:
```bash
python --version
```

### Step 3: Install Dependencies
```bash
# Install all required packages
pip install -r requirements.txt
```

**Note**: If you encounter issues with PyAudio on Windows:
```bash
pip install pipwin
pipwin install pyaudio
```

### Step 4: Configure API Keys
1. Copy `.env.template` to `.env`:
```bash
copy .env.template .env
```

2. Edit `.env` and add your Gemini API key:
```
GEMINI_API_KEY=your_actual_api_key_here
```

**Get Gemini API Key**:
- Visit [Google AI Studio](https://makersuite.google.com/app/apikey)
- Sign in with Google account
- Click "Create API Key"
- Copy and paste into `.env` file

### Step 5: Run SafwaanBuddy
```bash
python main.py
```

---

## 🎯 Usage

### Starting the Assistant
1. Run `python main.py`
2. Wait for "I'm ready to help you" message
3. The holographic UI will appear at the top of your screen

### Activating Voice Commands
Say one of the wake words:
- "Safwaan"
- "Buddy"
- "Hey Safwaan"
- "Computer"

### Conversation Mode
Once activated, you can have natural conversations:
```
You: "Safwaan, what time is it?"
Safwaan: "The current time is 3:45 PM"

You: "Tell me a joke"
Safwaan: "Why don't programmers like nature? It has too many bugs!"

You: "Play some relaxing music"
Safwaan: "Playing relaxing music on YouTube"
```

### Example Commands

#### Time & Information
- "What time is it?"
- "What's today's date?"
- "What's the weather like?"
- "Show me the latest news"

#### Entertainment
- "Tell me a joke"
- "Play [song name]"
- "Search for [topic]"

#### Productivity
- "Take a screenshot"
- "Open Gmail"
- "Open my calendar"
- "Calculate 25 times 4"
- "Take a note: [your note]"

#### System Control
- "What's my system info?"
- "Close this window"
- "Minimize window"
- "Lock my computer"

### Exiting Conversation Mode
Say:
- "Stop listening"
- "Exit"
- "Goodbye"
- "Bye"

Or wait 30 seconds of inactivity

### System Tray
- **Right-click tray icon**: Show menu
- **Show/Hide**: Toggle window visibility
- **Quit**: Close application

---

## ⚙️ Configuration

### config.json
Edit `config.json` to customize:

```json
{
  "voice_personalities": {
    "professional": "en-GB-RyanNeural",
    "friendly": "en-US-JennyNeural",
    "energetic": "en-US-GuyNeural",
    "calm": "en-US-AriaNeural"
  },
  "wake_words": ["safwaan", "buddy", "hey safwaan", "computer"],
  "features": {
    "enable_learning": true,
    "enable_conversation_mode": true
  },
  "ui": {
    "hologram_size": 300,
    "animation_fps": 30,
    "show_on_startup": true
  }
}
```

### .env File
Configure environment variables:
```
GEMINI_API_KEY=your_key_here
WAKE_WORDS=safwaan,buddy,hey safwaan
DEFAULT_VOICE=en-US-JennyNeural
SPEECH_RATE=+0%
LOG_LEVEL=INFO
```

---

## 🎨 UI Controls

### Hologram Window
- **Drag**: Click and drag to move
- **Close**: Minimizes to system tray
- **States**:
  - 🔵 **IDLE**: Waiting for wake word
  - 🟢 **LISTENING**: Actively listening
  - 🟣 **THINKING**: Processing command
  - 🔴 **SPEAKING**: Responding to you

### Colors by Emotion
- **Happy**: Bright, warm colors
- **Sad**: Cool, muted colors
- **Excited**: Vibrant, energetic colors
- **Calm**: Soft, peaceful colors
- **Neutral**: Standard blue

---

## 📊 Database

SafwaanBuddy stores data in `safwaan_data.db`:

### Tables
- **conversations**: All interactions
- **memories**: Important information
- **user_preferences**: Your settings
- **system_metrics**: Performance data

### Viewing Data
Use any SQLite browser or:
```bash
sqlite3 safwaan_data.db
.tables
SELECT * FROM conversations LIMIT 10;
```

---

## 🔧 Troubleshooting

### Microphone Not Working
1. Check Windows microphone permissions
2. Test microphone in Windows settings
3. Try different microphone index in code
4. Ensure microphone is default device

### No Voice Output
1. Check speaker/headphone connection
2. Verify pygame mixer initialization
3. Check system volume
4. Try different audio device

### API Key Errors
1. Verify Gemini API key is correct
2. Check internet connection
3. Ensure API key has proper permissions
4. Check API quota limits

### Import Errors
```bash
# Reinstall dependencies
pip install -r requirements.txt --force-reinstall
```

### PyAudio Installation Issues (Windows)
```bash
pip install pipwin
pipwin install pyaudio
```

### High CPU Usage
1. Reduce animation FPS in config.json
2. Disable unused features
3. Close other applications

---

## 📝 Logs

Logs are saved to:
- `safwaan.log`: Main application log
- Console output: Real-time logging

View logs:
```bash
# Windows
type safwaan.log

# Or open in text editor
notepad safwaan.log
```

---

## 🔐 Privacy & Security

- **Local Processing**: Most processing happens locally
- **API Calls**: Only AI responses use Gemini API
- **Data Storage**: All data stored locally in SQLite
- **No Telemetry**: No data sent to third parties
- **Encryption**: Optional encryption for sensitive data

---

## 🚧 Known Limitations

1. **Windows Only**: Currently supports Windows 11/10 only
2. **Internet Required**: AI features need internet connection
3. **English Only**: Primary language is English
4. **Microphone Required**: Voice input needs working microphone
5. **API Limits**: Gemini API has rate limits

---

## 🔮 Future Enhancements

- [ ] Multi-language support
- [ ] Voice cloning
- [ ] Custom wake words
- [ ] Plugin system
- [ ] Mobile app integration
- [ ] Smart home control
- [ ] Calendar integration
- [ ] Email automation
- [ ] Advanced emotion detection
- [ ] Face recognition

---

## 🤝 Contributing

Contributions are welcome! Areas for improvement:
- Additional skills and tools
- UI enhancements
- Performance optimizations
- Bug fixes
- Documentation improvements

---

## 📄 License

MIT License - See LICENSE file for details

---

## 👨‍💻 Author

**Safwaan**
- Created with ❤️ for Windows 11
- Powered by Google Gemini AI

---

## 🙏 Acknowledgments

- **Google Gemini**: AI brain
- **Edge-TTS**: Voice synthesis
- **PyQt6**: Beautiful UI
- **SpeechRecognition**: Voice input
- **Python Community**: Amazing libraries

---

## 📞 Support

For issues, questions, or suggestions:
1. Check troubleshooting section
2. Review logs in `safwaan.log`
3. Ensure all dependencies are installed
4. Verify API keys are configured

---

## 🎉 Enjoy SafwaanBuddy!

Your personal AI assistant is ready to help. Just say the wake word and start chatting!

**Remember**: Be patient during first run as it initializes all components.

---

**Version**: 1.0.0  
**Last Updated**: December 2024  
**Status**: ✅ Production Ready