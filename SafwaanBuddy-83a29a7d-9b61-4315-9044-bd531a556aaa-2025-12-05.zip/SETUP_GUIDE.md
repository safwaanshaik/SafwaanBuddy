# 🚀 SafwaanBuddy Setup Guide

Complete step-by-step guide to get SafwaanBuddy running on your Windows 11 PC.

---

## 📋 Pre-Installation Checklist

Before starting, ensure you have:
- [ ] Windows 11 (or Windows 10)
- [ ] Administrator access
- [ ] Internet connection
- [ ] Working microphone
- [ ] Speakers or headphones
- [ ] At least 2GB free disk space

---

## 🔧 Step-by-Step Installation

### Step 1: Install Python

1. **Download Python**
   - Go to [python.org/downloads](https://www.python.org/downloads/)
   - Download Python 3.11 or newer
   - Choose "Windows installer (64-bit)"

2. **Install Python**
   - Run the downloaded installer
   - ⚠️ **IMPORTANT**: Check "Add Python to PATH"
   - Click "Install Now"
   - Wait for installation to complete
   - Click "Close"

3. **Verify Installation**
   - Open Command Prompt (Win + R, type `cmd`, press Enter)
   - Type: `python --version`
   - Should show: `Python 3.11.x` or higher
   - Type: `pip --version`
   - Should show pip version

**Troubleshooting**:
- If "python not recognized": Restart computer and try again
- If still not working: Reinstall Python with "Add to PATH" checked

---

### Step 2: Download SafwaanBuddy

1. **Download the Project**
   - Download the SafwaanBuddy folder
   - Extract to a location like `C:\SafwaanBuddy`

2. **Open Command Prompt in Project Folder**
   - Navigate to SafwaanBuddy folder
   - Hold Shift + Right-click in folder
   - Select "Open PowerShell window here" or "Open Command Prompt here"

---

### Step 3: Install Dependencies

1. **Install Required Packages**
   ```bash
   pip install -r requirements.txt
   ```
   
   This will install:
   - PyQt6 (User Interface)
   - SpeechRecognition (Voice Input)
   - edge-tts (Voice Output)
   - google-generativeai (AI Brain)
   - pygame (Audio)
   - And many more...

2. **Wait for Installation**
   - This may take 5-10 minutes
   - Don't close the window
   - You'll see packages being downloaded and installed

3. **Handle PyAudio Issues (if any)**
   
   If PyAudio fails to install:
   ```bash
   pip install pipwin
   pipwin install pyaudio
   ```

**Troubleshooting**:
- If "pip not recognized": Restart Command Prompt
- If installation fails: Try `pip install --upgrade pip` first
- If specific package fails: Install it separately with `pip install package-name`

---

### Step 4: Get Gemini API Key

SafwaanBuddy uses Google Gemini for AI responses.

1. **Visit Google AI Studio**
   - Go to [makersuite.google.com/app/apikey](https://makersuite.google.com/app/apikey)
   - Sign in with your Google account

2. **Create API Key**
   - Click "Create API Key"
   - Select "Create API key in new project"
   - Copy the generated key

3. **Save API Key**
   - Keep this key safe
   - You'll need it in the next step

**Note**: Gemini API is free with generous limits!

---

### Step 5: Configure SafwaanBuddy

1. **Create .env File**
   - In SafwaanBuddy folder, find `.env.template`
   - Copy it and rename to `.env`
   
   Or in Command Prompt:
   ```bash
   copy .env.template .env
   ```

2. **Edit .env File**
   - Open `.env` with Notepad
   - Find line: `GEMINI_API_KEY=your_gemini_api_key_here`
   - Replace `your_gemini_api_key_here` with your actual API key
   - Save and close

   Example:
   ```
   GEMINI_API_KEY=AIzaSyABC123def456GHI789jkl012MNO345pqr
   ```

3. **Optional: Customize Settings**
   - Edit other settings in `.env` if desired
   - Change wake words, voice, etc.

---

### Step 6: Test Microphone

1. **Check Windows Microphone**
   - Open Settings (Win + I)
   - Go to System > Sound
   - Under Input, select your microphone
   - Speak and watch the volume bar move

2. **Set as Default**
   - Right-click speaker icon in taskbar
   - Select "Sound settings"
   - Choose your microphone as default input device

3. **Grant Permissions**
   - Settings > Privacy & Security > Microphone
   - Enable "Microphone access"
   - Enable for desktop apps

---

### Step 7: First Run

1. **Launch SafwaanBuddy**
   ```bash
   python main.py
   ```

2. **What to Expect**
   - Console will show initialization messages
   - Holographic UI will appear at top of screen
   - You'll hear: "Hello! I'm Safwaan, your AI assistant..."
   - Microphone will adjust for ambient noise (2 seconds)
   - You'll see: "Listening started. Say wake word to activate."

3. **Test Voice Command**
   - Say: "Safwaan"
   - Wait for response
   - Say: "What time is it?"
   - Safwaan should respond with current time

**Success!** 🎉 SafwaanBuddy is now running!

---

## 🎯 Quick Start Commands

Try these commands to test SafwaanBuddy:

### Basic Commands
```
"Safwaan, what time is it?"
"Safwaan, tell me a joke"
"Safwaan, what's today's date?"
```

### Web & Search
```
"Safwaan, search for Python tutorials"
"Safwaan, play some music"
"Safwaan, open YouTube"
```

### System Commands
```
"Safwaan, take a screenshot"
"Safwaan, what's my system info?"
"Safwaan, open my email"
```

---

## ⚙️ Configuration Tips

### Change Voice Personality

Edit `config.json`:
```json
{
  "voice_personalities": {
    "friendly": "en-US-JennyNeural",
    "professional": "en-GB-RyanNeural",
    "energetic": "en-US-GuyNeural"
  }
}
```

### Change Wake Words

Edit `.env`:
```
WAKE_WORDS=safwaan,buddy,hey safwaan,computer,assistant
```

### Adjust UI Size

Edit `config.json`:
```json
{
  "ui": {
    "hologram_size": 400,
    "animation_fps": 30
  }
}
```

---

## 🔧 Common Issues & Solutions

### Issue: "Python not recognized"
**Solution**:
1. Reinstall Python with "Add to PATH" checked
2. Restart computer
3. Try again

### Issue: "No module named 'PyQt6'"
**Solution**:
```bash
pip install PyQt6
```

### Issue: "Microphone not working"
**Solution**:
1. Check Windows microphone permissions
2. Set microphone as default device
3. Test in Windows Sound settings
4. Restart SafwaanBuddy

### Issue: "API key error"
**Solution**:
1. Verify API key is correct in `.env`
2. Check for extra spaces
3. Ensure internet connection
4. Try generating new API key

### Issue: "No sound output"
**Solution**:
1. Check speaker/headphone connection
2. Verify system volume
3. Test with other audio
4. Restart SafwaanBuddy

### Issue: "High CPU usage"
**Solution**:
1. Reduce animation FPS in config.json
2. Close other applications
3. Restart computer

---

## 🎨 Customization

### Change Hologram Colors

Edit `src/hologram_ui.py` to customize colors:
```python
state_colors = {
    "IDLE": QColor(0, 200, 255),  # Cyan
    "LISTENING": QColor(0, 255, 100),  # Green
    "THINKING": QColor(100, 100, 255),  # Purple
    "SPEAKING": QColor(255, 100, 150),  # Pink
}
```

### Add Custom Wake Words

Edit `.env`:
```
WAKE_WORDS=safwaan,buddy,jarvis,friday,computer
```

### Adjust Speech Speed

Edit `.env`:
```
SPEECH_RATE=+20%  # Faster
SPEECH_RATE=-20%  # Slower
```

---

## 📊 Performance Optimization

### For Low-End PCs
1. Reduce animation FPS to 15
2. Disable unused features
3. Use lighter voice model
4. Reduce hologram size

Edit `config.json`:
```json
{
  "ui": {
    "hologram_size": 200,
    "animation_fps": 15
  }
}
```

### For High-End PCs
1. Increase animation FPS to 60
2. Enable all features
3. Increase hologram size

---

## 🔄 Updating SafwaanBuddy

1. **Backup Your Data**
   ```bash
   copy safwaan_data.db safwaan_data_backup.db
   copy .env .env.backup
   ```

2. **Update Dependencies**
   ```bash
   pip install -r requirements.txt --upgrade
   ```

3. **Restart SafwaanBuddy**
   ```bash
   python main.py
   ```

---

## 🗑️ Uninstallation

1. **Stop SafwaanBuddy**
   - Close the application
   - Check system tray and quit

2. **Remove Files**
   - Delete SafwaanBuddy folder
   - Delete any shortcuts

3. **Optional: Remove Python**
   - Only if not used by other programs
   - Uninstall from Windows Settings

---

## 📞 Getting Help

### Check Logs
```bash
type safwaan.log
```

### Common Log Messages
- "✅" = Success
- "⚠️" = Warning (non-critical)
- "❌" = Error (needs attention)

### Debug Mode
Edit `.env`:
```
LOG_LEVEL=DEBUG
```

---

## 🎓 Learning Resources

### Python Basics
- [Python.org Tutorial](https://docs.python.org/3/tutorial/)
- [W3Schools Python](https://www.w3schools.com/python/)

### Voice Recognition
- [SpeechRecognition Docs](https://pypi.org/project/SpeechRecognition/)

### AI & Gemini
- [Google AI Studio](https://ai.google.dev/)
- [Gemini API Docs](https://ai.google.dev/docs)

---

## ✅ Setup Complete!

You're all set! SafwaanBuddy is ready to be your AI assistant.

**Next Steps**:
1. Try different voice commands
2. Explore all features
3. Customize to your preferences
4. Read the User Manual for advanced features

**Enjoy your new AI assistant!** 🎉

---

**Need Help?** Check the troubleshooting section or review logs in `safwaan.log`