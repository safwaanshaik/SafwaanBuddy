"""
Test All Imports - Verify all modules load correctly
Version: 3.0 HYPER ULTIMATE
"""
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

print("=" * 80)
print("[TEST] TESTING ALL IMPORTS - SafwaanBuddy HYPER ULTIMATE")
print("=" * 80)
print()

# Test counter
tests_passed = 0
tests_failed = 0

def test_import(module_name, description):
    """Test importing a module"""
    global tests_passed, tests_failed
    try:
        __import__(module_name)
        print(f"[OK] {description}")
        tests_passed += 1
        return True
    except Exception as e:
        print(f"[ERROR] {description}")
        print(f"   Error: {e}")
        tests_failed += 1
        return False

print("Testing Core Modules...")
print("-" * 80)
test_import("src.config_manager", "ConfigManager")
test_import("src.database_manager", "DatabaseManager")
test_import("src.voice_system", "VoiceSystem")
test_import("src.listener", "VoiceListener")
test_import("src.ai_brain", "AIBrain")
test_import("src.hologram_ui", "HologramUI")
print()

print("Testing Advanced Modules...")
print("-" * 80)
test_import("src.advanced_brain", "AdvancedAIBrain")
test_import("src.realistic_voice", "RealisticVoiceSystem")
test_import("src.screen_control", "ScreenControl")
test_import("src.proactive_assistant", "ProactiveAssistant")
print()

print("Testing NEW HYPER ULTIMATE Modules...")
print("-" * 80)
test_import("src.local_ai_brain", "LocalAIBrain")
test_import("src.neural_memory_system", "NeuralMemorySystem")
test_import("src.voice_cloning_system", "VoiceCloningSystem")
test_import("src.plugin_system", "PluginSystem")
test_import("src.workflow_automation_engine", "WorkflowAutomationEngine")
test_import("src.smart_home_integration", "SmartHomeIntegration")
test_import("src.computer_vision_system", "ComputerVisionSystem")
print()

print("Testing Skills Modules...")
print("-" * 80)
test_import("src.skills.basic_skills", "BasicSkills")
test_import("src.skills.advanced_skills", "AdvancedSkills")
print()

print("Testing UI Modules...")
print("-" * 80)
test_import("src.enhanced_ui", "Enhanced3DHologram")
test_import("src.premium_hologram", "PremiumHologram")
print()

print("Testing Automation Modules...")
print("-" * 80)
test_import("src.smart_automation", "SmartAutomation")
test_import("src.smart_features", "SmartFeatures")
print()

print("=" * 80)
print(f"[BAR_CHART] TEST RESULTS")
print("=" * 80)
print(f"[OK] Tests Passed: {tests_passed}")
print(f"[ERROR] Tests Failed: {tests_failed}")
print(f"[TRENDING_UP] Success Rate: {(tests_passed / (tests_passed + tests_failed) * 100):.1f}%")
print("=" * 80)

if tests_failed == 0:
    print()
    print("[CELEBRATE] ALL TESTS PASSED! SafwaanBuddy is ready to use!")
    print()
else:
    print()
    print("[WARNING] Some tests failed. Please check the errors above.")
    print()

input("Press Enter to exit...")