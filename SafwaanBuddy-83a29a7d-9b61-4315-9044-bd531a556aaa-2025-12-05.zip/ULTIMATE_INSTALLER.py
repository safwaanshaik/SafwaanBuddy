"""
SafwaanBuddy ULTIMATE INSTALLER
Intelligent automated installer that handles EVERYTHING
No matter what - this will get SafwaanBuddy working!
"""
import os
import sys
import subprocess
import platform
import urllib.request
import webbrowser
import time
import json
from pathlib import Path

# ANSI Colors for terminal
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    END = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

class UltimateInstaller:
    """Intelligent installer that fixes everything automatically"""
    
    def __init__(self):
        self.system = platform.system()
        self.is_windows = self.system == "Windows"
        self.python_cmd = self._find_python()
        self.errors = []
        self.warnings = []
        
    def _find_python(self):
        """Find Python command"""
        for cmd in ['python', 'python3', 'py']:
            try:
                result = subprocess.run(
                    [cmd, '--version'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if result.returncode == 0:
                    return cmd
            except:
                continue
        return None
    
    def print_banner(self):
        """Print installation banner"""
        print(f"\n{Colors.CYAN}{'='*80}")
        print(f"{Colors.BOLD}")
        print("  ███████╗ █████╗ ███████╗██╗    ██╗ █████╗  █████╗ ███╗   ██╗")
        print("  ██╔════╝██╔══██╗██╔════╝██║    ██║██╔══██╗██╔══██╗████╗  ██║")
        print("  ███████╗███████║█████╗  ██║ █╗ ██║███████║███████║██╔██╗ ██║")
        print("  ╚════██║██╔══██║██╔══╝  ██║███╗██║██╔══██║██╔══██║██║╚██╗██║")
        print("  ███████║██║  ██║██║     ╚███╔███╔╝██║  ██║██║  ██║██║ ╚████║")
        print("  ╚══════╝╚═╝  ╚═╝╚═╝      ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝")
        print(f"{Colors.END}")
        print(f"{Colors.CYAN}                 ULTIMATE AUTOMATED INSTALLER")
        print(f"{'='*80}{Colors.END}\n")
    
    def log(self, message, level="INFO"):
        """Log message with color"""
        timestamp = time.strftime("%H:%M:%S")
        
        if level == "INFO":
            print(f"{Colors.BLUE}[{timestamp}] [INFO]{Colors.END} {message}")
        elif level == "SUCCESS":
            print(f"{Colors.GREEN}[{timestamp}] [OK]{Colors.END} {message}")
        elif level == "WARNING":
            print(f"{Colors.YELLOW}[{timestamp}] [!]{Colors.END} {message}")
            self.warnings.append(message)
        elif level == "ERROR":
            print(f"{Colors.RED}[{timestamp}] [X]{Colors.END} {message}")
            self.errors.append(message)
    
    def progress_bar(self, current, total, description=""):
        """Show progress bar"""
        percent = int((current / total) * 100)
        bar_length = 50
        filled = int(bar_length * current / total)
        bar = '█' * filled + '░' * (bar_length - filled)
        
        print(f"\r{Colors.CYAN}[{bar}] {percent}% {Colors.END}{description}", end='', flush=True)
        
        if current == total:
            print()  # New line when complete
    
    def run_command(self, command, check=True, capture=True, timeout=300):
        """Run command with error handling"""
        try:
            if capture:
                result = subprocess.run(
                    command,
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=timeout
                )
                
                if check and result.returncode != 0:
                    return False, result.stderr
                
                return True, result.stdout
            else:
                result = subprocess.run(
                    command,
                    shell=True,
                    timeout=timeout
                )
                return result.returncode == 0, ""
        
        except subprocess.TimeoutExpired:
            return False, "Command timed out"
        except Exception as e:
            return False, str(e)
    
    def check_python(self):
        """Check and install Python if needed"""
        self.log("Checking Python installation...")
        
        if self.python_cmd:
            success, output = self.run_command(f"{self.python_cmd} --version")
            if success:
                version = output.strip()
                self.log(f"Python found: {version}", "SUCCESS")
                
                # Check version
                try:
                    version_parts = version.split()[1].split('.')
                    major, minor = int(version_parts[0]), int(version_parts[1])
                    
                    if major >= 3 and minor >= 11:
                        self.log("Python version is compatible", "SUCCESS")
                        return True
                    else:
                        self.log(f"Python {major}.{minor} found, but 3.11+ required", "WARNING")
                except:
                    pass
        
        # Python not found or incompatible
        self.log("Python 3.11+ not found", "ERROR")
        
        if self.is_windows:
            self.log("Opening Python download page...", "INFO")
            webbrowser.open("https://www.python.org/downloads/")
            
            print(f"\n{Colors.YELLOW}{'='*80}")
            print("  PYTHON INSTALLATION REQUIRED")
            print(f"{'='*80}{Colors.END}\n")
            print("Please:")
            print("  1. Download Python 3.11 or newer from the opened browser")
            print("  2. Run the installer")
            print(f"  3. {Colors.RED}IMPORTANT:{Colors.END} Check 'Add Python to PATH'")
            print("  4. Complete installation")
            print("  5. Restart your computer")
            print("  6. Run this installer again\n")
            
            input("Press Enter after installing Python...")
            return False
        else:
            print(f"\n{Colors.YELLOW}Please install Python 3.11+ using your package manager:{Colors.END}")
            print("  Ubuntu/Debian: sudo apt install python3 python3-pip")
            print("  macOS: brew install python3")
            return False
    
    def upgrade_pip(self):
        """Upgrade pip to latest version"""
        self.log("Upgrading pip...")
        
        success, output = self.run_command(
            f"{self.python_cmd} -m pip install --upgrade pip",
            check=False
        )
        
        if success:
            self.log("pip upgraded successfully", "SUCCESS")
        else:
            self.log("pip upgrade failed (continuing anyway)", "WARNING")
        
        return True
    
    def install_dependencies(self):
        """Install all dependencies with intelligent error handling"""
        self.log("Installing dependencies...")
        
        if not os.path.exists('requirements.txt'):
            self.log("requirements.txt not found!", "ERROR")
            return False
        
        # Read requirements
        with open('requirements.txt', 'r') as f:
            requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]
        
        total = len(requirements)
        installed = 0
        failed = []
        
        print(f"\n{Colors.CYAN}Installing {total} packages...{Colors.END}\n")
        
        for i, package in enumerate(requirements, 1):
            self.progress_bar(i, total, f"Installing {package}")
            
            # Try to install package
            success, output = self.run_command(
                f"{self.python_cmd} -m pip install {package}",
                check=False,
                timeout=180
            )
            
            if success:
                installed += 1
            else:
                failed.append(package)
                
                # Try alternative installation methods
                if 'pyaudio' in package.lower() and self.is_windows:
                    self.log(f"Trying alternative PyAudio installation...", "INFO")
                    
                    # Try pipwin
                    self.run_command(f"{self.python_cmd} -m pip install pipwin", check=False)
                    success, _ = self.run_command("pipwin install pyaudio", check=False)
                    
                    if success:
                        failed.remove(package)
                        installed += 1
        
        print()  # New line after progress bar
        
        if installed == total:
            self.log(f"All {total} packages installed successfully!", "SUCCESS")
            return True
        else:
            self.log(f"Installed {installed}/{total} packages", "WARNING")
            if failed:
                self.log(f"Failed packages: {', '.join(failed)}", "WARNING")
            return installed > (total * 0.8)  # 80% success rate acceptable
    
    def configure_api_key(self):
        """Interactive API key configuration"""
        self.log("Configuring API key...")
        
        # Check if already configured
        if os.path.exists('.env'):
            with open('.env', 'r') as f:
                content = f.read()
            
            if 'GEMINI_API_KEY=' in content and 'your_gemini_api_key_here' not in content:
                self.log("API key already configured!", "SUCCESS")
                
                print(f"\n{Colors.YELLOW}API key is already set.{Colors.END}")
                choice = input("Update it? (y/n): ").lower()
                
                if choice != 'y':
                    return True
        
        # Create .env from template if needed
        if not os.path.exists('.env'):
            if os.path.exists('.env.template'):
                with open('.env.template', 'r') as f:
                    template = f.read()
                with open('.env', 'w') as f:
                    f.write(template)
                self.log("Created .env file", "SUCCESS")
            else:
                # Create basic .env
                with open('.env', 'w') as f:
                    f.write("GEMINI_API_KEY=your_gemini_api_key_here\n")
        
        # Guide user to get API key
        print(f"\n{Colors.CYAN}{'='*80}")
        print("  API KEY CONFIGURATION")
        print(f"{'='*80}{Colors.END}\n")
        print("SafwaanBuddy needs a FREE Google Gemini API key.\n")
        print("Steps to get your key:")
        print("  1. Visit: https://makersuite.google.com/app/apikey")
        print("  2. Sign in with your Google account")
        print("  3. Click 'Create API Key'")
        print("  4. Copy the generated key\n")
        
        choice = input("Open the website now? (y/n): ").lower()
        if choice == 'y':
            webbrowser.open('https://makersuite.google.com/app/apikey')
            self.log("Browser opened! Get your API key and return here.", "INFO")
            print()
        
        # Get API key from user
        print(f"{Colors.YELLOW}{'='*80}{Colors.END}")
        api_key = input("Paste your Gemini API key here: ").strip()
        
        if not api_key or len(api_key) < 20:
            self.log("Invalid API key!", "ERROR")
            return False
        
        # Save API key
        try:
            with open('.env', 'r') as f:
                lines = f.readlines()
            
            with open('.env', 'w') as f:
                for line in lines:
                    if line.startswith('GEMINI_API_KEY='):
                        f.write(f'GEMINI_API_KEY={api_key}\n')
                    else:
                        f.write(line)
            
            self.log("API key configured successfully!", "SUCCESS")
            return True
        
        except Exception as e:
            self.log(f"Error saving API key: {e}", "ERROR")
            return False
    
    def verify_installation(self):
        """Verify everything is installed correctly"""
        self.log("Verifying installation...")
        
        checks = {
            'Python': False,
            'Dependencies': False,
            'API Key': False,
            'Files': False
        }
        
        # Check Python
        if self.python_cmd:
            checks['Python'] = True
        
        # Check key dependencies
        key_packages = ['PyQt6', 'speech_recognition', 'edge_tts', 'google.generativeai', 'pygame']
        installed_count = 0
        
        for package in key_packages:
            try:
                __import__(package.replace('-', '_').lower())
                installed_count += 1
            except:
                pass
        
        checks['Dependencies'] = installed_count >= 3  # At least 3 key packages
        
        # Check API key
        if os.path.exists('.env'):
            with open('.env', 'r') as f:
                content = f.read()
            checks['API Key'] = 'GEMINI_API_KEY=' in content and 'your_gemini_api_key_here' not in content
        
        # Check files
        required_files = ['main.py', 'safwaan_master.py', 'config.json']
        checks['Files'] = all(os.path.exists(f) for f in required_files)
        
        # Print results
        print(f"\n{Colors.CYAN}{'='*80}")
        print("  VERIFICATION RESULTS")
        print(f"{'='*80}{Colors.END}\n")
        
        for check, status in checks.items():
            if status:
                print(f"  {Colors.GREEN}[OK]{Colors.END} {check}")
            else:
                print(f"  {Colors.RED}[X]{Colors.END} {check}")
        
        all_passed = all(checks.values())
        
        if all_passed:
            print(f"\n{Colors.GREEN}{'='*80}")
            print("  ALL CHECKS PASSED - READY TO RUN!")
            print(f"{'='*80}{Colors.END}\n")
        else:
            print(f"\n{Colors.YELLOW}{'='*80}")
            print("  SOME CHECKS FAILED - MAY HAVE ISSUES")
            print(f"{'='*80}{Colors.END}\n")
        
        return all_passed
    
    def select_edition(self):
        """Let user select which edition to launch"""
        print(f"\n{Colors.CYAN}{'='*80}")
        print("  SELECT EDITION")
        print(f"{'='*80}{Colors.END}\n")
        print("  [1] Standard Edition      - Basic features, good for beginners")
        print("  [2] ULTIMATE Edition      - Advanced features, realistic voice")
        print("  [3] PRO MAX Edition       - Maximum features, vision AI")
        print("  [4] MASTER Edition        - Enterprise-grade, premium UI (RECOMMENDED!)")
        print("  [5] Skip launch\n")
        
        while True:
            try:
                choice = input("Enter your choice (1-5): ").strip()
                
                if choice in ['1', '2', '3', '4', '5']:
                    return int(choice)
                else:
                    print(f"{Colors.RED}Invalid choice. Please enter 1-5.{Colors.END}")
            except:
                print(f"{Colors.RED}Invalid input. Please enter a number.{Colors.END}")
    
    def launch_edition(self, edition):
        """Launch selected edition"""
        editions = {
            1: ('main.py', 'Standard'),
            2: ('safwaan_ultimate.py', 'ULTIMATE'),
            3: ('safwaan_pro_max.py', 'PRO MAX'),
            4: ('safwaan_master.py', 'MASTER')
        }
        
        if edition == 5:
            self.log("Skipping launch", "INFO")
            return True
        
        if edition not in editions:
            return False
        
        file, name = editions[edition]
        
        if not os.path.exists(file):
            self.log(f"{file} not found!", "ERROR")
            return False
        
        print(f"\n{Colors.GREEN}{'='*80}")
        print(f"  LAUNCHING {name} EDITION")
        print(f"{'='*80}{Colors.END}\n")
        
        self.log(f"Starting {name} edition...", "INFO")
        time.sleep(2)
        
        # Launch
        try:
            subprocess.run([self.python_cmd, file])
            return True
        except KeyboardInterrupt:
            self.log("Interrupted by user", "WARNING")
            return True
        except Exception as e:
            self.log(f"Launch error: {e}", "ERROR")
            return False
    
    def run(self):
        """Run complete installation process"""
        self.print_banner()
        
        print(f"{Colors.BOLD}This installer will set up EVERYTHING automatically!{Colors.END}\n")
        print("It will:")
        print("  • Check Python installation")
        print("  • Install all dependencies")
        print("  • Configure API keys")
        print("  • Verify setup")
        print("  • Launch SafwaanBuddy\n")
        
        input("Press Enter to start...")
        
        # Step 1: Check Python
        print(f"\n{Colors.CYAN}{'='*80}")
        print("  STEP 1/5: Python Check")
        print(f"{'='*80}{Colors.END}\n")
        
        if not self.check_python():
            return False
        
        # Step 2: Upgrade pip
        print(f"\n{Colors.CYAN}{'='*80}")
        print("  STEP 2/5: Upgrade pip")
        print(f"{'='*80}{Colors.END}\n")
        
        self.upgrade_pip()
        
        # Step 3: Install dependencies
        print(f"\n{Colors.CYAN}{'='*80}")
        print("  STEP 3/5: Install Dependencies")
        print(f"{'='*80}{Colors.END}\n")
        
        if not self.install_dependencies():
            self.log("Dependency installation had issues", "WARNING")
            choice = input("\nContinue anyway? (y/n): ").lower()
            if choice != 'y':
                return False
        
        # Step 4: Configure API key
        print(f"\n{Colors.CYAN}{'='*80}")
        print("  STEP 4/5: Configure API Key")
        print(f"{'='*80}{Colors.END}\n")
        
        if not self.configure_api_key():
            self.log("API key configuration failed", "WARNING")
            choice = input("\nContinue anyway? (y/n): ").lower()
            if choice != 'y':
                return False
        
        # Step 5: Verify
        print(f"\n{Colors.CYAN}{'='*80}")
        print("  STEP 5/5: Verification")
        print(f"{'='*80}{Colors.END}\n")
        
        self.verify_installation()
        
        # Launch
        edition = self.select_edition()
        self.launch_edition(edition)
        
        # Summary
        print(f"\n{Colors.GREEN}{'='*80}")
        print("  INSTALLATION COMPLETE!")
        print(f"{'='*80}{Colors.END}\n")
        
        if self.warnings:
            print(f"{Colors.YELLOW}Warnings: {len(self.warnings)}{Colors.END}")
        if self.errors:
            print(f"{Colors.RED}Errors: {len(self.errors)}{Colors.END}")
        
        print(f"\n{Colors.BOLD}SafwaanBuddy is ready to use!{Colors.END}")
        print(f"Say: {Colors.CYAN}'Safwaan, what time is it?'{Colors.END} to test\n")
        
        return True


if __name__ == "__main__":
    try:
        installer = UltimateInstaller()
        installer.run()
    except KeyboardInterrupt:
        print(f"\n\n{Colors.YELLOW}Installation cancelled by user.{Colors.END}\n")
    except Exception as e:
        print(f"\n\n{Colors.RED}Installation error: {e}{Colors.END}\n")
    
    input("\nPress Enter to exit...")