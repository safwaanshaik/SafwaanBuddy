"""
SafwaanBuddy HYPER ULTIMATE - Master Installer
Automated installation and setup system
Version: 3.0 HYPER ULTIMATE
"""
import os
import sys
import subprocess
import platform
import shutil
from pathlib import Path
import urllib.request
import zipfile

# Colors for terminal output
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'


def print_banner():
    """Print installation banner"""
    banner = f"""
{Colors.CYAN}╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║     ███████╗ █████╗ ███████╗██╗    ██╗ █████╗  █████╗ ███╗   ██╗   ║
║     ██╔════╝██╔══██╗██╔════╝██║    ██║██╔══██╗██╔══██╗████╗  ██║   ║
║     ███████╗███████║█████╗  ██║ █╗ ██║███████║███████║██╔██╗ ██║   ║
║     ╚════██║██╔══██║██╔══╝  ██║███╗██║██╔══██║██╔══██║██║╚██╗██║   ║
║     ███████║██║  ██║██║     ╚███╔███╔╝██║  ██║██║  ██║██║ ╚████║   ║
║     ╚══════╝╚═╝  ╚═╝╚═╝      ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝   ║
║                                                                      ║
║                    HYPER ULTIMATE MASTER INSTALLER                  ║
║                         Version 3.0 HYPER                           ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝{Colors.ENDC}

{Colors.BOLD}[LAUNCH] Welcome to SafwaanBuddy HYPER ULTIMATE Installation!{Colors.ENDC}

This installer will:
  [OK] Check system requirements
  [OK] Install Python (if needed)
  [OK] Install all dependencies
  [OK] Configure the system
  [OK] Set up the environment
  [OK] Create shortcuts
  [OK] Verify installation

{Colors.YELLOW}[WARNING]  This may take 10-15 minutes depending on your internet speed.{Colors.ENDC}
"""
    print(banner)


def check_python():
    """Check if Python is installed"""
    print(f"\n{Colors.BLUE}[1/8] Checking Python installation...{Colors.ENDC}")
    
    try:
        version = sys.version_info
        if version.major >= 3 and version.minor >= 11:
            print(f"{Colors.GREEN}[OK] Python {version.major}.{version.minor}.{version.micro} detected{Colors.ENDC}")
            return True
        else:
            print(f"{Colors.RED}[ERROR] Python 3.11+ required (found {version.major}.{version.minor}){Colors.ENDC}")
            return False
    except:
        print(f"{Colors.RED}[ERROR] Python not found{Colors.ENDC}")
        return False


def install_python():
    """Guide user to install Python"""
    print(f"\n{Colors.YELLOW}📥 Python Installation Required{Colors.ENDC}")
    print("\nPlease install Python 3.11 or higher:")
    print("1. Visit: https://www.python.org/downloads/")
    print("2. Download Python 3.11 or higher")
    print("3. Run installer")
    print(f"{Colors.BOLD}4. [WARNING]  IMPORTANT: Check 'Add Python to PATH'{Colors.ENDC}")
    print("5. Complete installation")
    print("6. Restart this installer")
    
    input("\nPress Enter to exit...")
    sys.exit(1)


def check_pip():
    """Check if pip is available"""
    print(f"\n{Colors.BLUE}[2/8] Checking pip...{Colors.ENDC}")
    
    try:
        subprocess.run([sys.executable, "-m", "pip", "--version"], 
                      check=True, capture_output=True)
        print(f"{Colors.GREEN}[OK] pip is available{Colors.ENDC}")
        return True
    except:
        print(f"{Colors.RED}[ERROR] pip not found{Colors.ENDC}")
        return False


def upgrade_pip():
    """Upgrade pip to latest version"""
    print(f"\n{Colors.BLUE}[3/8] Upgrading pip...{Colors.ENDC}")
    
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pip"],
                      check=True, capture_output=True)
        print(f"{Colors.GREEN}[OK] pip upgraded{Colors.ENDC}")
        return True
    except Exception as e:
        print(f"{Colors.YELLOW}[WARNING]  Could not upgrade pip: {e}{Colors.ENDC}")
        return False


def install_dependencies():
    """Install all required dependencies"""
    print(f"\n{Colors.BLUE}[4/8] Installing dependencies...{Colors.ENDC}")
    print(f"{Colors.YELLOW}[HOURGLASS] This may take 5-10 minutes...{Colors.ENDC}\n")
    
    requirements_file = "requirements_production.txt"
    if not Path(requirements_file).exists():
        requirements_file = "requirements.txt"
    
    try:
        # Install dependencies
        process = subprocess.Popen(
            [sys.executable, "-m", "pip", "install", "-r", requirements_file],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True
        )
        
        # Show progress
        for line in process.stdout:
            if "Collecting" in line or "Installing" in line:
                print(f"  {line.strip()}")
        
        process.wait()
        
        if process.returncode == 0:
            print(f"\n{Colors.GREEN}[OK] All dependencies installed successfully{Colors.ENDC}")
            return True
        else:
            print(f"\n{Colors.RED}[ERROR] Some dependencies failed to install{Colors.ENDC}")
            return False
            
    except Exception as e:
        print(f"\n{Colors.RED}[ERROR] Error installing dependencies: {e}{Colors.ENDC}")
        return False


def create_directories():
    """Create necessary directories"""
    print(f"\n{Colors.BLUE}[5/8] Creating directories...{Colors.ENDC}")
    
    directories = [
        'data',
        'logs',
        'plugins',
        'workflows',
        'screenshots',
        'config',
        'web_control_panel',
        'src/core',
        'src/ui',
        'src/skills',
        'src/automation',
        'src/vision'
    ]
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
    
    print(f"{Colors.GREEN}[OK] Directories created{Colors.ENDC}")


def setup_configuration():
    """Set up configuration files"""
    print(f"\n{Colors.BLUE}[6/8] Setting up configuration...{Colors.ENDC}")
    
    # Copy .env template if .env doesn't exist
    if not Path('.env').exists():
        if Path('.env.template').exists():
            shutil.copy('.env.template', '.env')
            print(f"{Colors.GREEN}[OK] Created .env file{Colors.ENDC}")
        else:
            print(f"{Colors.YELLOW}[WARNING]  .env.template not found{Colors.ENDC}")
    else:
        print(f"{Colors.GREEN}[OK] .env file already exists{Colors.ENDC}")
    
    # Create default config.json if it doesn't exist
    if not Path('config.json').exists():
        default_config = {
            "voice_personalities": {
                "professional": "en-GB-RyanNeural",
                "friendly": "en-US-JennyNeural",
                "energetic": "en-US-GuyNeural",
                "calm": "en-US-AriaNeural"
            },
            "wake_words": ["safwaan", "buddy", "hey safwaan", "computer"],
            "features": {
                "enable_learning": True,
                "enable_conversation_mode": True,
                "enable_proactive": True,
                "enable_neural_memory": True,
                "enable_voice_cloning": True,
                "enable_plugins": True
            },
            "ui": {
                "hologram_size": 300,
                "animation_fps": 30,
                "show_on_startup": True
            }
        }
        
        import json
        with open('config.json', 'w') as f:
            json.dump(default_config, f, indent=2)
        
        print(f"{Colors.GREEN}[OK] Created config.json{Colors.ENDC}")
    else:
        print(f"{Colors.GREEN}[OK] config.json already exists{Colors.ENDC}")


def verify_installation():
    """Verify installation is complete"""
    print(f"\n{Colors.BLUE}[7/8] Verifying installation...{Colors.ENDC}")
    
    # Check critical imports
    critical_modules = [
        'PyQt6',
        'speech_recognition',
        'edge_tts',
        'pygame',
        'numpy',
        'cv2',
        'PIL',
        'flask'
    ]
    
    failed = []
    for module in critical_modules:
        try:
            __import__(module)
            print(f"{Colors.GREEN}  [OK] {module}{Colors.ENDC}")
        except ImportError:
            print(f"{Colors.RED}  [ERROR] {module}{Colors.ENDC}")
            failed.append(module)
    
    if failed:
        print(f"\n{Colors.RED}[ERROR] Some modules failed to import: {', '.join(failed)}{Colors.ENDC}")
        print(f"{Colors.YELLOW}Try installing them manually:{Colors.ENDC}")
        for module in failed:
            print(f"  pip install {module}")
        return False
    
    print(f"\n{Colors.GREEN}[OK] All critical modules verified{Colors.ENDC}")
    return True


def create_shortcuts():
    """Create desktop shortcuts"""
    print(f"\n{Colors.BLUE}[8/8] Creating shortcuts...{Colors.ENDC}")
    
    if platform.system() == 'Windows':
        # Create batch file launcher
        launcher_content = f"""@echo off
cd /d "%~dp0"
python safwaan_hyper_ultimate.py
pause
"""
        with open('Launch_SafwaanBuddy.bat', 'w') as f:
            f.write(launcher_content)
        
        print(f"{Colors.GREEN}[OK] Created Launch_SafwaanBuddy.bat{Colors.ENDC}")
    
    print(f"{Colors.GREEN}[OK] Shortcuts created{Colors.ENDC}")


def print_completion():
    """Print completion message"""
    print(f"""
{Colors.GREEN}╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║                    [CELEBRATE] INSTALLATION COMPLETE! [CELEBRATE]                      ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝{Colors.ENDC}

{Colors.BOLD}SafwaanBuddy HYPER ULTIMATE is now installed!{Colors.ENDC}

{Colors.CYAN}[LAUNCH] To start SafwaanBuddy:{Colors.ENDC}

  Windows:
    • Double-click: RUN_HYPER_ULTIMATE.bat
    • Or run: python safwaan_hyper_ultimate.py

  Linux/Mac:
    • Run: python3 safwaan_hyper_ultimate.py

{Colors.CYAN}[WEB] Web Control Panel:{Colors.ENDC}
  • Will be available at: http://localhost:8080
  • Opens automatically when SafwaanBuddy starts

{Colors.CYAN}[MIC] Voice Commands:{Colors.ENDC}
  • Say "Safwaan" or "Hey Safwaan" to activate
  • Then give your command
  • Example: "What time is it?"

{Colors.CYAN}[BOOKS] Documentation:{Colors.ENDC}
  • README_HYPER_ULTIMATE.md - Overview
  • HYPER_ULTIMATE_INSTALLATION_GUIDE.md - Setup guide
  • HYPER_ULTIMATE_FEATURES.md - Features guide

{Colors.CYAN}[IDEA] Tips:{Colors.ENDC}
  • Edit .env for API keys (optional)
  • Edit config.json for preferences
  • Check logs in safwaan_hyper_ultimate.log
  • Visit web panel for real-time monitoring

{Colors.GREEN}[SPARKLE] Enjoy your HYPER ULTIMATE AI Assistant! [SPARKLE]{Colors.ENDC}
""")


def main():
    """Main installation process"""
    print_banner()
    
    # Confirm installation
    response = input(f"\n{Colors.BOLD}Continue with installation? (y/n): {Colors.ENDC}").lower()
    if response != 'y':
        print(f"{Colors.YELLOW}Installation cancelled.{Colors.ENDC}")
        sys.exit(0)
    
    # Check Python
    if not check_python():
        install_python()
        return
    
    # Check pip
    if not check_pip():
        print(f"{Colors.RED}[ERROR] pip not found. Please reinstall Python.{Colors.ENDC}")
        sys.exit(1)
    
    # Upgrade pip
    upgrade_pip()
    
    # Install dependencies
    if not install_dependencies():
        print(f"\n{Colors.RED}[ERROR] Installation failed. Please check errors above.{Colors.ENDC}")
        sys.exit(1)
    
    # Create directories
    create_directories()
    
    # Setup configuration
    setup_configuration()
    
    # Verify installation
    if not verify_installation():
        print(f"\n{Colors.YELLOW}[WARNING]  Installation completed with warnings.{Colors.ENDC}")
        print(f"{Colors.YELLOW}Some features may not work correctly.{Colors.ENDC}")
    
    # Create shortcuts
    create_shortcuts()
    
    # Print completion message
    print_completion()
    
    # Ask to launch
    response = input(f"\n{Colors.BOLD}Launch SafwaanBuddy now? (y/n): {Colors.ENDC}").lower()
    if response == 'y':
        print(f"\n{Colors.GREEN}[LAUNCH] Launching SafwaanBuddy HYPER ULTIMATE...{Colors.ENDC}\n")
        
        if platform.system() == 'Windows':
            subprocess.Popen(['python', 'safwaan_hyper_ultimate.py'])
        else:
            subprocess.Popen(['python3', 'safwaan_hyper_ultimate.py'])


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{Colors.YELLOW}[WARNING]  Installation interrupted by user{Colors.ENDC}")
        sys.exit(0)
    except Exception as e:
        print(f"\n{Colors.RED}[ERROR] Fatal error: {e}{Colors.ENDC}")
        sys.exit(1)