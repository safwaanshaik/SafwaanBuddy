# 📖 SafwaanBuddy User Manual

Complete guide to using all features of SafwaanBuddy AI Voice Assistant.

---

## 📑 Table of Contents

1. [Getting Started](#getting-started)
2. [Voice Commands](#voice-commands)
3. [Conversation Mode](#conversation-mode)
4. [Skills & Features](#skills--features)
5. [User Interface](#user-interface)
6. [Advanced Features](#advanced-features)
7. [Tips & Tricks](#tips--tricks)
8. [FAQ](#faq)

---

## 🚀 Getting Started

### Launching SafwaanBuddy

1. Open Command Prompt in SafwaanBuddy folder
2. Run: `python main.py`
3. Wait for initialization (5-10 seconds)
4. Listen for welcome message
5. Hologram appears at top of screen

### First Interaction

1. **Say the wake word**: "Safwaan" or "Buddy"
2. **Wait for acknowledgment**: Hologram turns green
3. **Give your command**: "What time is it?"
4. **Listen to response**: Safwaan will answer
5. **Continue conversation**: Ask follow-up questions

---

## 🎤 Voice Commands

### Wake Words

Activate SafwaanBuddy with any of these:
- "Safwaan"
- "Buddy"
- "Hey Safwaan"
- "Computer"

**Example**:
```
You: "Safwaan, what time is it?"
Safwaan: "The current time is 3:45 PM"
```

### Command Structure

**Basic Pattern**:
```
[Wake Word] + [Command]
```

**Examples**:
- "Safwaan, tell me a joke"
- "Buddy, what's the weather?"
- "Hey Safwaan, play some music"

### Natural Language

SafwaanBuddy understands natural language:
- "What time is it?"
- "Can you tell me the time?"
- "What's the current time?"
- "Time please"

All work the same way!

---

## 💬 Conversation Mode

### Activating Conversation Mode

Say the wake word without a command:
```
You: "Safwaan"
Safwaan: "Hello! How can I help you today?"
You: "What time is it?"
Safwaan: "The current time is 3:45 PM"
You: "And what's the date?"
Safwaan: "Today is Thursday, December 5, 2024"
```

### In Conversation Mode

- **No wake word needed**: Just speak naturally
- **Context awareness**: Remembers previous messages
- **Natural flow**: Like talking to a person
- **Auto-timeout**: Ends after 30 seconds of silence

### Exiting Conversation Mode

Say any of these:
- "Stop listening"
- "Exit"
- "Goodbye"
- "Bye"
- "That's all"

Or wait 30 seconds without speaking.

---

## 🛠️ Skills & Features

### ⏰ Time & Date

**Commands**:
- "What time is it?"
- "Tell me the time"
- "What's today's date?"
- "What day is it?"

**Response**:
- Time in 12-hour format (3:45 PM)
- Full date (Thursday, December 5, 2024)

---

### 😂 Entertainment

#### Jokes
**Commands**:
- "Tell me a joke"
- "Make me laugh"
- "Say something funny"

**Example**:
```
You: "Tell me a joke"
Safwaan: "Why don't programmers like nature? It has too many bugs!"
```

#### Music
**Commands**:
- "Play [song name]"
- "Play some music"
- "Play relaxing music"

**What happens**:
- Opens YouTube with search results
- You can choose which video to play

**Examples**:
- "Play Bohemian Rhapsody"
- "Play jazz music"
- "Play workout music"

---

### 🔍 Web & Search

#### Web Search
**Commands**:
- "Search for [topic]"
- "Google [topic]"
- "Find [topic]"
- "Look up [topic]"

**Examples**:
- "Search for Python tutorials"
- "Google best restaurants near me"
- "Find weather forecast"

#### Open Websites
**Commands**:
- "Open [website]"
- "Go to [website]"
- "Visit [website]"

**Examples**:
- "Open YouTube"
- "Go to Gmail"
- "Visit reddit.com"

---

### 📸 Screenshots

**Commands**:
- "Take a screenshot"
- "Capture screen"
- "Screenshot"

**What happens**:
- Captures entire screen
- Saves as `screenshot_YYYYMMDD_HHMMSS.png`
- Saved in SafwaanBuddy folder

---

### ☁️ Weather & News

#### Weather
**Commands**:
- "What's the weather?"
- "Check weather"
- "Weather forecast"

**What happens**:
- Opens weather.com
- Shows current weather and forecast

#### News
**Commands**:
- "What's the news?"
- "Latest news"
- "Show me headlines"

**What happens**:
- Opens Google News
- Shows latest headlines

---

### 📧 Productivity

#### Email
**Commands**:
- "Open email"
- "Check my email"
- "Open Gmail"

**What happens**:
- Opens Gmail in browser

#### Calendar
**Commands**:
- "Open calendar"
- "Show my calendar"
- "Check my schedule"

**What happens**:
- Opens Google Calendar

---

### 🧮 Calculator

**Commands**:
- "Calculate [expression]"
- "What is [math problem]"
- "Compute [expression]"

**Examples**:
- "Calculate 25 times 4"
- "What is 100 divided by 5"
- "Compute 15 plus 30"

**Supported Operations**:
- Addition: +, plus
- Subtraction: -, minus
- Multiplication: *, times, x
- Division: /, divided by

---

### 📝 Notes

**Commands**:
- "Take a note: [content]"
- "Remember: [content]"
- "Write down: [content]"

**Examples**:
- "Take a note: Buy milk tomorrow"
- "Remember: Meeting at 3 PM"

**What happens**:
- Creates text file: `note_YYYYMMDD_HHMMSS.txt`
- Saves in SafwaanBuddy folder

---

### 🌍 Translation

**Commands**:
- "Translate [text]"
- "How do you say [text] in [language]"

**Examples**:
- "Translate hello in Spanish"
- "Translate thank you in French"

**What happens**:
- Opens Google Translate
- Shows translation

---

### 💻 System Commands

#### System Information
**Commands**:
- "System info"
- "Computer specs"
- "Show system information"

**Shows**:
- Operating system
- Processor
- CPU usage
- Memory usage
- Disk usage

#### Window Management
**Commands**:
- "Close window" / "Close this"
- "Minimize window"
- "Maximize window"

**What happens**:
- Closes current active window (Alt+F4)
- Minimizes current window
- Maximizes current window

#### Volume Control
**Commands**:
- "Set volume to [number]"
- "Volume [number]"

**Examples**:
- "Set volume to 50"
- "Volume 75"

**Note**: Windows only

#### Lock Computer
**Commands**:
- "Lock computer"
- "Lock my PC"

**What happens**:
- Locks Windows (Win+L)
- Requires password to unlock

---

## 🎨 User Interface

### Hologram Display

#### States & Colors

**IDLE** (Blue)
- Waiting for wake word
- Gentle pulsing animation
- Ready to listen

**LISTENING** (Green)
- Actively listening to you
- Scanning animation
- Processing your voice

**THINKING** (Purple)
- Processing your command
- Spinning animation
- Analyzing with AI

**SPEAKING** (Pink/Red)
- Responding to you
- Rhythmic pulsing
- Playing audio

**ERROR** (Red)
- Something went wrong
- Check logs for details

#### Emotion Display

Bottom right shows detected emotion:
- Happy 😊
- Sad 😢
- Excited 🎉
- Calm 😌
- Angry 😠
- Neutral 😐

### Moving the Hologram

1. Click and hold on hologram
2. Drag to desired position
3. Release to place

### Minimizing to Tray

- Click X button (minimizes to tray)
- Right-click tray icon for menu
- Select "Show/Hide" to restore

### System Tray Menu

Right-click tray icon:
- **Show/Hide**: Toggle window
- **Quit**: Close application

---

## 🔧 Advanced Features

### Memory System

SafwaanBuddy remembers:
- Previous conversations
- Your preferences
- Important information
- Context from earlier

**Example**:
```
You: "My favorite color is blue"
Safwaan: "I'll remember that!"

[Later...]
You: "What's my favorite color?"
Safwaan: "Your favorite color is blue"
```

### Context Awareness

Understands conversation flow:
```
You: "Tell me about Python"
Safwaan: "Python is a programming language..."

You: "Is it easy to learn?"
Safwaan: "Yes, Python is known for being beginner-friendly..."
```

### Emotion Detection

Adapts responses based on your emotion:

**Happy**:
```
You: "I'm so happy today!"
Safwaan: [Enthusiastic voice] "That's wonderful! I'm glad to hear that!"
```

**Sad**:
```
You: "I'm feeling down"
Safwaan: [Gentle voice] "I'm sorry to hear that. Is there anything I can do to help?"
```

### Voice Personalities

Change personality in `config.json`:
- **Friendly**: Warm and casual (default)
- **Professional**: Formal and business-like
- **Energetic**: Upbeat and enthusiastic
- **Calm**: Soothing and peaceful

---

## 💡 Tips & Tricks

### Best Practices

1. **Speak Clearly**: Enunciate words
2. **Normal Volume**: Not too loud or soft
3. **Reduce Background Noise**: For better recognition
4. **Wait for Response**: Let Safwaan finish speaking
5. **Use Natural Language**: Speak normally

### Improving Recognition

1. **Adjust Microphone**:
   - Position 6-12 inches from mouth
   - Reduce background noise
   - Use quality microphone

2. **Speak Naturally**:
   - Don't shout
   - Don't whisper
   - Normal conversation tone

3. **Clear Commands**:
   - "Play music" ✅
   - "Uh, can you maybe play some music?" ❌

### Power User Tips

1. **Quick Commands**: Skip wake word in conversation mode
2. **Batch Tasks**: Give multiple commands in sequence
3. **Shortcuts**: Learn common command patterns
4. **Customize**: Edit config for your preferences

### Keyboard Shortcuts

While hologram is focused:
- **Drag**: Move window
- **Click X**: Minimize to tray
- **Right-click tray**: Show menu

---

## ❓ FAQ

### General Questions

**Q: Does SafwaanBuddy work offline?**
A: Partially. Voice recognition works offline, but AI responses need internet.

**Q: Can I change the wake word?**
A: Yes! Edit `.env` file and add your custom wake words.

**Q: How much data does it use?**
A: Minimal. Only AI responses use internet (~1-5 KB per request).

**Q: Is my data private?**
A: Yes. All data stored locally. Only AI queries sent to Gemini API.

**Q: Can I use it on Mac or Linux?**
A: Currently Windows only. Mac/Linux support planned.

### Voice Commands

**Q: Why doesn't it understand me?**
A: Check microphone settings, reduce background noise, speak clearly.

**Q: Can I interrupt Safwaan?**
A: Yes! Say the wake word while it's speaking.

**Q: How long can I talk?**
A: Up to 10 seconds per command. For longer, break into parts.

**Q: What languages are supported?**
A: Currently English only. More languages planned.

### Technical Questions

**Q: How much RAM does it use?**
A: Typically 200-400 MB. Depends on features enabled.

**Q: Can I run it on startup?**
A: Yes! Create a shortcut in Windows Startup folder.

**Q: Where is data stored?**
A: In `safwaan_data.db` (SQLite database) in project folder.

**Q: Can I delete conversation history?**
A: Yes. Delete `safwaan_data.db` or use database tools.

### Troubleshooting

**Q: No response to wake word?**
A: Check microphone permissions, test in Windows settings.

**Q: No voice output?**
A: Check speaker connection, system volume, audio device.

**Q: High CPU usage?**
A: Reduce animation FPS in config.json, close other apps.

**Q: API errors?**
A: Verify Gemini API key, check internet connection.

---

## 📊 Understanding Logs

### Log Levels

- **INFO**: Normal operation (✅)
- **WARNING**: Non-critical issues (⚠️)
- **ERROR**: Problems that need attention (❌)
- **DEBUG**: Detailed information

### Common Log Messages

```
✅ Voice System initialized
✅ AI Brain initialized
✅ Listening started
🎤 Heard: [your command]
📝 Command received: [command]
🗣️ Speaking: [response]
✅ Response: [response]
```

### Reading Logs

```bash
# View entire log
type safwaan.log

# View last 20 lines
powershell Get-Content safwaan.log -Tail 20

# Search for errors
findstr "ERROR" safwaan.log
```

---

## 🎯 Command Reference

### Quick Reference Table

| Category | Command Example | What It Does |
|----------|----------------|--------------|
| Time | "What time is it?" | Shows current time |
| Date | "What's the date?" | Shows current date |
| Joke | "Tell me a joke" | Tells random joke |
| Music | "Play [song]" | Opens YouTube |
| Search | "Search for [topic]" | Opens Google |
| Website | "Open [site]" | Opens website |
| Screenshot | "Take a screenshot" | Captures screen |
| Weather | "What's the weather?" | Opens weather.com |
| News | "Latest news" | Opens Google News |
| Email | "Open email" | Opens Gmail |
| Calendar | "Open calendar" | Opens Google Calendar |
| Calculate | "Calculate 5 + 3" | Performs math |
| Note | "Take a note: [text]" | Saves text file |
| Translate | "Translate [text]" | Opens translator |
| System Info | "System info" | Shows PC specs |
| Close Window | "Close window" | Closes active window |
| Lock PC | "Lock computer" | Locks Windows |

---

## 🎓 Learning More

### Explore Features

Try these to discover capabilities:
- "What can you do?"
- "Help me"
- "Show me your features"

### Experiment

- Try different phrasings
- Combine commands
- Use conversation mode
- Test edge cases

### Customize

- Edit config.json
- Modify .env settings
- Adjust UI preferences
- Add custom wake words

---

## 📞 Getting Help

### Self-Help

1. Check this manual
2. Review logs
3. Check troubleshooting section
4. Verify configuration

### Resources

- README.md: Overview and features
- SETUP_GUIDE.md: Installation help
- safwaan.log: Detailed logs

---

## 🎉 Enjoy SafwaanBuddy!

You now know how to use all features of SafwaanBuddy. Experiment, explore, and enjoy your AI assistant!

**Remember**: The more you use it, the better it gets at understanding you!

---

**Version**: 1.0.0  
**Last Updated**: December 2024  
**Happy Assisting!** 🤖✨