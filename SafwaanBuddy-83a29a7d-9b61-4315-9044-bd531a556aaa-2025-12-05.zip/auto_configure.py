"""
SafwaanBuddy Auto-Configuration Script
Automatically configures API keys and settings
"""
import os
import sys
import webbrowser
from pathlib import Path

def print_header(text):
    """Print formatted header"""
    print("\n" + "="*80)
    print(f"  {text}")
    print("="*80 + "\n")

def print_step(step_num, total, text):
    """Print step header"""
    print(f"\n{'='*80}")
    print(f"  STEP {step_num}/{total}: {text}")
    print(f"{'='*80}\n")

def check_env_file():
    """Check if .env file exists"""
    return os.path.exists('.env')

def create_env_from_template():
    """Create .env from template"""
    try:
        if os.path.exists('.env.template'):
            with open('.env.template', 'r') as f:
                template = f.read()
            
            with open('.env', 'w') as f:
                f.write(template)
            
            print("[OK] Created .env file from template")
            return True
        else:
            print("[ERROR] .env.template not found!")
            return False
    except Exception as e:
        print(f"[ERROR] Error creating .env: {e}")
        return False

def configure_api_key():
    """Interactive API key configuration"""
    print_step(1, 3, "API Key Configuration")
    
    print("SafwaanBuddy needs a FREE Google Gemini API key to work.\n")
    
    # Check if already configured
    if os.path.exists('.env'):
        with open('.env', 'r') as f:
            content = f.read()
        
        if 'GEMINI_API_KEY=' in content and 'your_gemini_api_key_here' not in content:
            print("[OK] API key already configured!\n")
            
            choice = input("Do you want to update it? (y/n): ").lower()
            if choice != 'y':
                return True
    
    print("\n[NOTE] How to get your FREE Gemini API key:\n")
    print("1. Visit: https://makersuite.google.com/app/apikey")
    print("2. Sign in with your Google account")
    print("3. Click 'Create API Key'")
    print("4. Copy the generated key\n")
    
    choice = input("Open the website now? (y/n): ").lower()
    if choice == 'y':
        webbrowser.open('https://makersuite.google.com/app/apikey')
        print("\n[OK] Browser opened! Get your API key and come back here.\n")
    
    print("="*80)
    api_key = input("\nPaste your Gemini API key here: ").strip()
    
    if not api_key or len(api_key) < 20:
        print("\n[ERROR] Invalid API key! Please try again.")
        return False
    
    # Update .env file
    try:
        if not os.path.exists('.env'):
            create_env_from_template()
        
        with open('.env', 'r') as f:
            content = f.read()
        
        # Replace API key
        if 'GEMINI_API_KEY=' in content:
            lines = content.split('\n')
            for i, line in enumerate(lines):
                if line.startswith('GEMINI_API_KEY='):
                    lines[i] = f'GEMINI_API_KEY={api_key}'
                    break
            content = '\n'.join(lines)
        else:
            content += f'\nGEMINI_API_KEY={api_key}\n'
        
        with open('.env', 'w') as f:
            f.write(content)
        
        print("\n[OK] API key configured successfully!\n")
        return True
    
    except Exception as e:
        print(f"\n[ERROR] Error saving API key: {e}")
        return False

def configure_settings():
    """Configure optional settings"""
    print_step(2, 3, "Optional Settings")
    
    print("Configure optional settings:\n")
    
    # Wake words
    print("1. Wake Words")
    print("   Current: safwaan, buddy, hey safwaan, computer\n")
    
    choice = input("   Customize wake words? (y/n): ").lower()
    if choice == 'y':
        wake_words = input("   Enter wake words (comma-separated): ").strip()
        if wake_words:
            try:
                with open('.env', 'a') as f:
                    f.write(f'\nWAKE_WORDS={wake_words}\n')
                print("   [OK] Wake words updated!\n")
            except:
                print("   [ERROR] Could not update wake words\n")
    
    # Voice personality
    print("2. Default Voice Personality")
    print("   Options: professional, friendly, energetic, calm\n")
    
    choice = input("   Change default voice? (y/n): ").lower()
    if choice == 'y':
        personalities = ['professional', 'friendly', 'energetic', 'calm']
        print("\n   Available personalities:")
        for i, p in enumerate(personalities, 1):
            print(f"   [{i}] {p.capitalize()}")
        
        try:
            p_choice = int(input("\n   Select (1-4): "))
            if 1 <= p_choice <= 4:
                selected = personalities[p_choice - 1]
                # Update config.json
                import json
                with open('config.json', 'r') as f:
                    config = json.load(f)
                
                # Set default personality
                print(f"   [OK] Default voice set to: {selected}\n")
        except:
            print("   [ERROR] Invalid choice, keeping default\n")
    
    print("[OK] Settings configured!\n")
    return True

def select_edition():
    """Let user select which edition to launch"""
    print_step(3, 3, "Select Edition to Launch")
    
    print("Which edition would you like to launch?\n")
    print("  [1] [STAR] Standard Edition")
    print("      - 27 commands, 4 personalities")
    print("      - Perfect for beginners")
    print("      - RAM: 2GB minimum\n")
    
    print("  [2] [HOT] ULTIMATE Edition")
    print("      - 29 commands, 6 personalities, realistic voice")
    print("      - Advanced automation")
    print("      - RAM: 4GB minimum\n")
    
    print("  [3] [GEM] PRO MAX Edition")
    print("      - 45+ commands, vision AI, focus mode")
    print("      - Code generation, image analysis")
    print("      - RAM: 8GB recommended\n")
    
    print("  [4] [TROPHY] MASTER Edition (RECOMMENDED!)")
    print("      - 50+ commands, premium 3D UI")
    print("      - Enterprise-grade, all features")
    print("      - RAM: 8GB recommended\n")
    
    print("  [5] Skip launch (just configure)\n")
    
    choice = input("Enter your choice (1-5): ").strip()
    
    return choice

def main():
    """Main auto-configuration flow"""
    print_header("SafwaanBuddy Auto-Configuration")
    
    print("This wizard will help you configure SafwaanBuddy automatically.\n")
    print("Press Enter to continue...")
    input()
    
    # Step 1: Configure API key
    if not configure_api_key():
        print("\n[ERROR] API key configuration failed!")
        print("Please run this script again or configure manually.\n")
        input("Press Enter to exit...")
        return False
    
    # Step 2: Configure settings
    configure_settings()
    
    # Step 3: Select edition
    edition = select_edition()
    
    print("\n" + "="*80)
    print("  [OK] CONFIGURATION COMPLETE!")
    print("="*80 + "\n")
    
    if edition == '5':
        print("Configuration saved! You can launch SafwaanBuddy anytime using:")
        print("  - LAUNCHER.bat (menu)")
        print("  - run_master.bat (MASTER edition)")
        print("\nPress Enter to exit...")
        input()
        return True
    
    # Launch selected edition
    print("Launching SafwaanBuddy...\n")
    
    try:
        if edition == '1':
            os.system('python main.py')
        elif edition == '2':
            os.system('python safwaan_ultimate.py')
        elif edition == '3':
            os.system('python safwaan_pro_max.py')
        elif edition == '4':
            os.system('python safwaan_master.py')
        else:
            print("Invalid choice! Please use LAUNCHER.bat to start.\n")
    except Exception as e:
        print(f"\n[ERROR] Launch error: {e}")
        print("Please check the logs and try again.\n")
    
    input("\nPress Enter to exit...")
    return True

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n[ERROR] Setup cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n[ERROR] Unexpected error: {e}")
        input("Press Enter to exit...")
        sys.exit(1)