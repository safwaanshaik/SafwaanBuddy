"""
Unicode Emoji Fixer for SafwaanBuddy
Replaces all Unicode emojis with ASCII-safe alternatives
"""
import os
import re
from pathlib import Path

# Emoji to ASCII mapping
EMOJI_MAP = {
    '[OK]': '[OK]',
    '[ERROR]': '[X]',
    '[WARNING]': '[!]',
    '[MIC]': '[MIC]',
    '[SPEAK]': '[SPEAK]',
    '[TOOL]': '[TOOL]',
    '[IDEA]': '[IDEA]',
    '[BAR_CHART]': '[STATS]',
    '[TARGET]': '[TARGET]',
    '🔮': '[PREDICT]',
    '[LAUNCH]': '[LAUNCH]',
    '[STAR]': '[STAR]',
    '[GEM]': '[PREMIUM]',
    '[HOT]': '[HOT]',
    '[STAR]': '[STAR]',
    '[TROPHY]': '[TROPHY]',
    '[CELEBRATE]': '[PARTY]',
    '[PARTY]': '[CELEBRATE]',
    '[EMOTION]': '[EMOTION]',
    '[AI]': '[BRAIN]',
    '[VISION]': '[EYE]',
    '[LISTEN]': '[EAR]',
    '[CHAT]': '[CHAT]',
    '[NOTE]': '[NOTE]',
    '[CLIPBOARD]': '[CLIPBOARD]',
    '[FOLDER]': '[FOLDER]',
    '[DESKTOP]': '[SYSTEM]',
    '[KEYBOARD]': '[KEYBOARD]',
    '[MOUSE]': '[MOUSE]',
    '[AUDIO]': '[VOLUME]',
    '[SILENT]': '[MUTE]',
    '🌤️': '[WEATHER]',
    '[HOME]': '[HOME]',
    '[ALARM]': '[ALARM]',
    '[CALENDAR]': '[CALENDAR]',
    '[NOTIFICATION]': '[BELL]',
    '[SYSTEM]': '[LAPTOP]',
    '[MOBILE]': '[PHONE]',
    '[MUSIC]': '[MUSIC]',
    '[NOTES]': '[NOTES]',
    '[CAMERA]': '[CAMERA]',
    '[PHOTO]': '[PHOTO]',
    '[VIDEO]': '[VIDEO]',
    '[SEARCH]': '[SEARCH]',
    '[WEB]': '[WEB]',
    '[EMAIL]': '[EMAIL]',
    '[SAVE]': '[SAVE]',
    '[TRASH]': '[TRASH]',
    '[FAST]': '[BOLT]',
    '[LOCKED]': '[LOCK]',
    '[UNLOCKED]': '[UNLOCK]',
    '[TOOLS]': '[TOOLS]',
    '[SETTINGS]': '[SETTINGS]',
    '[TRENDING_UP]': '[BAR_CHART]',
    '[TRENDING_DOWN]': '[DOWN]',
    '[DESIGN]': '[DESIGN]',
    '[FRAME]': '[FRAME]',
    '[FOLDER]': '[FILES]',
    '[PACKAGE]': '[PACKAGE]',
    '[LINK]': '[LINK]',
    '[COLOR]': '[RAINBOW]',
    '[STRONG]': '[STRONG]',
    '[THUMBS_UP]': '[THUMBS_UP]',
    '👎': '[THUMBS_DOWN]',
    '[HEART]': '[HEART]',
    '💚': '[GREEN_HEART]',
    '💙': '[BLUE_HEART]',
    '🧡': '[ORANGE_HEART]',
    '💛': '[YELLOW_HEART]',
    '💜': '[PURPLE_HEART]',
}

def fix_file(file_path):
    """Fix Unicode emojis in a file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        original_content = content
        
        # Replace all emojis
        for emoji, ascii_rep in EMOJI_MAP.items():
            content = content.replace(emoji, ascii_rep)
        
        # Only write if changes were made
        if content != original_content:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"[OK] Fixed: {file_path}")
            return True
        else:
            print(f"[SKIP] No emojis: {file_path}")
            return False
            
    except Exception as e:
        print(f"[ERROR] {file_path}: {e}")
        return False

def main():
    """Fix all Python files"""
    print("="*80)
    print("  SafwaanBuddy Unicode Emoji Fixer")
    print("="*80)
    print()
    
    # Find all Python files
    src_dir = Path("src")
    py_files = list(src_dir.rglob("*.py"))
    
    # Add main files
    main_files = [
        "main.py",
        "safwaan_ultimate.py",
        "safwaan_pro_max.py",
        "safwaan_master.py",
        "safwaan_complete.py"
    ]
    
    for f in main_files:
        if Path(f).exists():
            py_files.append(Path(f))
    
    print(f"Found {len(py_files)} Python files to check\n")
    
    fixed_count = 0
    for py_file in py_files:
        if fix_file(py_file):
            fixed_count += 1
    
    print()
    print("="*80)
    print(f"  Fixed {fixed_count} files")
    print("="*80)
    print()
    print("[OK] All Unicode emojis replaced with ASCII-safe alternatives!")
    print()

if __name__ == "__main__":
    main()