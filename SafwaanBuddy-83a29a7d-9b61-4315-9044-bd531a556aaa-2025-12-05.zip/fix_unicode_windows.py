"""
Fix Unicode Issues for Windows 11
Removes all emoji characters from Python files
"""
import os
import re
from pathlib import Path

def remove_emojis_from_file(file_path):
    """Remove emojis from a single file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Simple replacements for common emojis
        replacements = {
            '[OK]': '[OK]',
            '[ERROR]': '[ERROR]',
            '[WARNING]': '[WARNING]',
            '[MIC]': '[MIC]',
            '[AI]': '[AI]',
            '[AUDIO]': '[AUDIO]',
            '[VISION]': '[VISION]',
            '[HOME]': '[HOME]',
            '[PACKAGE]': '[PACKAGE]',
            '[LAUNCH]': '[LAUNCH]',
            '[TARGET]': '[TARGET]',
            '[BAR_CHART]': '[STATS]',
            '[SYSTEM]': '[SYSTEM]',
            '[STAR]': '[STAR]',
            '[FAST]': '[FAST]',
            '[HOT]': '[HOT]',
            '[IDEA]': '[IDEA]',
            '[DESIGN]': '[DESIGN]',
            '[WEB]': '[WEB]',
            '[PLUGIN]': '[PLUGIN]',
            '[EMOTION]': '[EMOTION]',
            '[MUSIC]': '[MUSIC]',
            '[TRENDING_UP]': '[BAR_CHART]',
            '[SEARCH]': '[SEARCH]',
            '[CHAT]': '[CHAT]',
            '[VIDEO]': '[VIDEO]',
            '[PHOTO]': '[PHOTO]',
            '[SPEAK]': '[SPEAK]',
            '[LISTEN]': '[LISTEN]',
            '[BOT]': '[BOT]',
            '[COLOR]': '[COLOR]',
            '[STAR]': '[STAR]',
            '[NOTIFICATION]': '[BELL]',
            '[NOTE]': '[NOTE]',
            '[GIFT]': '[GIFT]',
            '[TROPHY]': '[TROPHY]',
            '[STRONG]': '[STRONG]',
            '[CELEBRATE]': '[CELEBRATE]',
            '[THUMBS_UP]': '[THUMBS_UP]',
            '[HEART]': '[HEART]',
            '[SECURE]': '[SECURE]',
            '[TOOLS]': '[TOOLS]',
            '[BOOKS]': '[BOOKS]',
            '[EDUCATION]': '[EDUCATION]',
            '[GLOBE]': '[GLOBE]',
            '[NOTIFICATION]': '[NOTIFICATION]',
            '[MOBILE]': '[MOBILE]',
            '[SAVE]': '[SAVE]',
            '[FOLDER]': '[FOLDER]',
            '[CLIPBOARD]': '[CLIPBOARD]',
            '[DESKTOP]': '[DESKTOP]',
            '[KEYBOARD]': '[KEYBOARD]',
            '[MOUSE]': '[MOUSE]',
            '[GAME]': '[GAME]',
            '[BATTERY]': '[BATTERY]',
            '[SIGNAL]': '[SIGNAL]',
            '[TEMP]': '[TEMP]',
            '[ALARM]': '[ALARM]',
            '[TIMER]': '[TIMER]',
            '[CALENDAR]': '[CALENDAR]',
            '[CALENDAR_SPIRAL]': '[SCHEDULE]',
            '[PIN]': '[PIN]',
            '[BOOKMARK]': '[BOOKMARK]',
            '[TAG]': '[TAG]',
            '[EDIT]': '[EDIT]',
            '[CUT]': '[CUT]',
            '[ATTACH]': '[ATTACH]',
            '[LINK]': '[LINK]',
            '[EMAIL]': '[EMAIL]',
            '[MAILBOX]': '[MAILBOX]',
            '[POSTBOX]': '[POSTBOX]',
            '[BALLOT]': '[BALLOT]',
            '[ENVELOPE]': '[ENVELOPE]',
            '[PAGE]': '[PAGE]',
            '[DOCUMENT]': '[DOCUMENT]',
            '[BOOKMARK_TABS]': '[BOOKMARK_TABS]',
            '[RECEIPT]': '[RECEIPT]',
            '[BAR_CHART]': '[BAR_CHART]',
            '[TRENDING_UP]': '[TRENDING_UP]',
            '[TRENDING_DOWN]': '[TRENDING_DOWN]',
            '[NOTEPAD]': '[NOTEPAD]',
            '[CALENDAR_SPIRAL]': '[CALENDAR_SPIRAL]',
        }
        
        # Apply replacements
        for emoji, replacement in replacements.items():
            content = content.replace(emoji, replacement)
        
        # Write back
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return True
    except Exception as e:
        print(f"Error processing {file_path}: {e}")
        return False


def main():
    """Fix all Python files"""
    print("=" * 80)
    print("FIXING UNICODE ISSUES FOR WINDOWS 11")
    print("=" * 80)
    print()
    
    # Get all Python files
    python_files = list(Path('.').rglob('*.py'))
    
    fixed_count = 0
    for file_path in python_files:
        if '__pycache__' in str(file_path):
            continue
        
        print(f"Processing: {file_path}")
        if remove_emojis_from_file(file_path):
            fixed_count += 1
    
    print()
    print("=" * 80)
    print(f"FIXED {fixed_count} FILES")
    print("=" * 80)
    print()
    print("All emoji characters have been replaced with [TEXT] equivalents")
    print("Your application should now work perfectly on Windows 11!")


if __name__ == '__main__':
    main()