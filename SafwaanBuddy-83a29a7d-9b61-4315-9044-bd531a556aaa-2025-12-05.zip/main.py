"""
SafwaanBuddy - Advanced AI Voice Assistant
Main application entry point
Version: 1.0 STANDARD - Windows 11 Optimized
"""
import sys
import os
import logging
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional, Any

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

# Setup Windows 11 compatible logging FIRST
from src.windows_logger import setup_windows_logging
setup_windows_logging('safwaan.log', logging.INFO)

from PyQt6.QtWidgets import QApplication, QMessageBox
from PyQt6.QtGui import QPalette, QColor
from PyQt6.QtCore import Qt

from src.config_manager import ConfigManager
from src.database_manager import DatabaseManager
from src.voice_system import VoiceSystem
from src.listener import VoiceListener
from src.ai_brain import AIBrain
from src.hologram_ui import HologramUI
from src.skills.basic_skills import BasicSkills
from src.skills.advanced_skills import AdvancedSkills

logger = logging.getLogger('SafwaanBuddy')


class SafwaanBuddy:
    """Main SafwaanBuddy application"""
    
    def __init__(self):
        logger.info("=" * 80)
        logger.info("SAFWAANBUDDY - ADVANCED AI VOICE ASSISTANT")
        logger.info("=" * 80)
        logger.info("Initializing SafwaanBuddy Standard Edition...")
        
        try:
            # Initialize core components
            logger.info("[1/8] Initializing configuration...")
            self.config = ConfigManager()
            
            logger.info("[2/8] Initializing database...")
            self.db = DatabaseManager()
            
            logger.info("[3/8] Initializing voice system...")
            self.voice = VoiceSystem(self.config)
            
            logger.info("[4/8] Initializing AI brain...")
            self.brain = AIBrain(self.config, self.db)
            
            logger.info("[5/8] Initializing voice listener...")
            self.listener = VoiceListener(self.config)
            
            logger.info("[6/8] Initializing skills...")
            # FIX: BasicSkills doesn't take arguments
            self.basic_skills = BasicSkills()
            self.advanced_skills = AdvancedSkills()
            
            logger.info("[7/8] Initializing holographic UI...")
            self.ui = HologramUI()
            
            logger.info("[8/8] Setting up callbacks...")
            self.listener.set_callback(
                on_command_callback=self.process_command,
                is_speaking_callback=self.voice.is_speaking
            )
            
            # Connect UI signals
            self.ui.command_signal.connect(self.process_command)
            
            logger.info("[OK] SafwaanBuddy initialized successfully")
            logger.info("=" * 80)
            
        except Exception as e:
            logger.error(f"[ERROR] Initialization failed: {e}")
            raise
    
    def process_command(self, command: str):
        """Process voice command"""
        try:
            logger.info(f"[COMMAND] Processing: {command}")
            
            # Update UI state
            self.ui.set_state('thinking')
            
            # Get AI response
            response = self.brain.process(command)
            
            # Speak response
            self.ui.set_state('speaking')
            self.voice.speak(response)
            
            # Return to idle
            self.ui.set_state('idle')
            
            logger.info(f"[RESPONSE] {response}")
            
        except Exception as e:
            logger.error(f"[ERROR] Command processing failed: {e}")
            self.ui.set_state('idle')
    
    def start(self):
        """Start the assistant"""
        try:
            logger.info("[START] Starting SafwaanBuddy...")
            
            # Show UI
            self.ui.show()
            
            # Start listening
            self.listener.start_listening()
            
            # Welcome message
            self.voice.speak("Hello! I am Safwaan, your AI voice assistant. How can I help you today?")
            
            logger.info("[OK] SafwaanBuddy is now running")
            logger.info("[INFO] Say 'Safwaan' to activate me")
            
        except Exception as e:
            logger.error(f"[ERROR] Start failed: {e}")
            raise
    
    def stop(self):
        """Stop the assistant"""
        try:
            logger.info("[STOP] Shutting down SafwaanBuddy...")
            
            # Stop listening
            if hasattr(self, 'listener'):
                self.listener.stop_listening()
            
            # Stop voice
            if hasattr(self, 'voice'):
                self.voice.stop()
            
            # Close UI
            if hasattr(self, 'ui'):
                self.ui.close()
            
            logger.info("[OK] SafwaanBuddy stopped successfully")
            
        except Exception as e:
            logger.error(f"[ERROR] Shutdown failed: {e}")


def main():
    """Main entry point"""
    try:
        # Create Qt application
        app = QApplication(sys.argv)
        app.setApplicationName("SafwaanBuddy")
        
        # Set dark theme
        app.setStyle('Fusion')
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(53, 53, 53))
        palette.setColor(QPalette.ColorRole.WindowText, Qt.GlobalColor.white)
        app.setPalette(palette)
        
        # Create and start SafwaanBuddy
        safwaan = SafwaanBuddy()
        safwaan.start()
        
        # Run application
        sys.exit(app.exec())
        
    except KeyboardInterrupt:
        logger.info("[INFO] Interrupted by user")
        if 'safwaan' in locals():
            safwaan.stop()
    except Exception as e:
        logger.error(f"[FATAL] Application error: {e}")
        QMessageBox.critical(None, "Error", f"Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()