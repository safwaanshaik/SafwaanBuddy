"""
Remove ALL Emojis from Python Files
Windows 11 Compatibility Fix
"""
import os
import sys

def remove_emojis_from_file(filepath):
    """Remove emojis from a single file"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Count original emojis
        original_emojis = sum(1 for c in content if ord(c) > 127 and ord(c) not in range(128, 256))
        
        if original_emojis == 0:
            return 0
        
        # Replace emojis with text equivalents
        replacements = [
            (r'[OK]', '[OK]'),
            (r'[ERROR]', '[ERROR]'),
            (r'[WARNING]', '[WARNING]'),
            (r'[MIC]', '[MIC]'),
            (r'[AI]', '[AI]'),
            (r'[AUDIO]', '[AUDIO]'),
            (r'[VISION]', '[VISION]'),
            (r'[HOME]', '[HOME]'),
            (r'[PACKAGE]', '[PACKAGE]'),
            (r'[LAUNCH]', '[LAUNCH]'),
            (r'[TARGET]', '[TARGET]'),
            (r'[FIRE]', '[FIRE]'),
            (r'[FAST]', '[FAST]'),
            (r'[STAR]', '[STAR]'),
            (r'[IDEA]', '[IDEA]'),
            (r'[TOOL]', '[TOOL]'),
            (r'[CHART]', '[CHART]'),
            (r'[GRAPH]', '[GRAPH]'),
            (r'[DOWN]', '[DOWN]'),
            (r'[COMPUTER]', '[COMPUTER]'),
            (r'[DESKTOP]', '[DESKTOP]'),
            (r'[PHONE]', '[PHONE]'),
            (r'[WATCH]', '[WATCH]'),
            (r'[BELL]', '[BELL]'),
            (r'[MUTE]', '[MUTE]'),
            (r'[SILENT]', '[SILENT]'),
            (r'[VOLUME]', '[VOLUME]'),
            (r'[VOLUME_UP]', '[VOLUME_UP]'),
            (r'[SPEAK]', '[SPEAK]'),
            (r'[LISTEN]', '[LISTEN]'),
            (r'[MUSIC]', '[MUSIC]'),
            (r'[NOTES]', '[NOTES]'),
            (r'[HEADPHONES]', '[HEADPHONES]'),
            (r'[RADIO]', '[RADIO]'),
            (r'[MOVIE]', '[MOVIE]'),
            (r'[TV]', '[TV]'),
            (r'[CAMERA]', '[CAMERA]'),
            (r'[PHOTO]', '[PHOTO]'),
            (r'[PICTURE]', '[PICTURE]'),
            (r'[MAP]', '[MAP]'),
            (r'[COMPASS]', '[COMPASS]'),
            (r'[ALARM]', '[ALARM]'),
            (r'[TIMER]', '[TIMER]'),
            (r'[CLOCK]', '[CLOCK]'),
            (r'[TIME]', '[TIME]'),
            (r'[CALENDAR]', '[CALENDAR]'),
            (r'[DATE]', '[DATE]'),
            (r'[NOTE]', '[NOTE]'),
            (r'[DOCUMENT]', '[DOCUMENT]'),
            (r'[PAGE]', '[PAGE]'),
            (r'[CLIPBOARD]', '[CLIPBOARD]'),
            (r'[FOLDER]', '[FOLDER]'),
            (r'[OPEN_FOLDER]', '[OPEN_FOLDER]'),
            (r'[FILES]', '[FILES]'),
            (r'[ARCHIVE]', '[ARCHIVE]'),
            (r'[CABINET]', '[CABINET]'),
            (r'[SAVE]', '[SAVE]'),
            (r'[DISC]', '[DISC]'),
            (r'[DVD]', '[DVD]'),
            (r'[PRINTER]', '[PRINTER]'),
            (r'[KEYBOARD]', '[KEYBOARD]'),
            (r'[MOUSE]', '[MOUSE]'),
            (r'[TRACKBALL]', '[TRACKBALL]'),
            (r'[DISK]', '[DISK]'),
            (r'[PLUG]', '[PLUG]'),
            (r'[BATTERY]', '[BATTERY]'),
            (r'[SEARCH]', '[SEARCH]'),
            (r'[ZOOM]', '[ZOOM]'),
            (r'[MICROSCOPE]', '[MICROSCOPE]'),
            (r'[TELESCOPE]', '[TELESCOPE]'),
            (r'[SATELLITE]', '[SATELLITE]'),
            (r'[SPACE]', '[SPACE]'),
            (r'[GLOBE]', '[GLOBE]'),
            (r'[EARTH]', '[EARTH]'),
            (r'[AMERICAS]', '[AMERICAS]'),
            (r'[ASIA]', '[ASIA]'),
            (r'[MAP]', '[WORLD_MAP]'),
            (r'[PUZZLE]', '[PUZZLE]'),
            (r'[GAME]', '[GAME]'),
            (r'[JOYSTICK]', '[JOYSTICK]'),
            (r'[DICE]', '[DICE]'),
            (r'[SPADE]', '[SPADE]'),
            (r'[HEART]', '[HEART]'),
            (r'[DIAMOND]', '[DIAMOND]'),
            (r'[CLUB]', '[CLUB]'),
            (r'[JOKER]', '[JOKER]'),
            (r'[MAHJONG]', '[MAHJONG]'),
            (r'[CARDS]', '[CARDS]'),
            (r'[THEATER]', '[THEATER]'),
            (r'[PICTURE]', '[FRAME]'),
            (r'[ART]', '[ART]'),
            (r'[THREAD]', '[THREAD]'),
            (r'[YARN]', '[YARN]'),
            (r'[GLASSES]', '[GLASSES]'),
            (r'[SUNGLASSES]', '[SUNGLASSES]'),
            (r'[GOGGLES]', '[GOGGLES]'),
            (r'[LAB_COAT]', '[LAB_COAT]'),
            (r'[VEST]', '[VEST]'),
            (r'[TIE]', '[TIE]'),
            (r'[SHIRT]', '[SHIRT]'),
            (r'[JEANS]', '[JEANS]'),
            (r'[SCARF]', '[SCARF]'),
            (r'[GLOVES]', '[GLOVES]'),
            (r'[COAT]', '[COAT]'),
            (r'[SOCKS]', '[SOCKS]'),
            (r'[DRESS]', '[DRESS]'),
            (r'[KIMONO]', '[KIMONO]'),
            (r'[SARI]', '[SARI]'),
            (r'[SWIMSUIT]', '[SWIMSUIT]'),
            (r'[BRIEFS]', '[BRIEFS]'),
            (r'[SHORTS]', '[SHORTS]'),
            (r'[BIKINI]', '[BIKINI]'),
            (r'[WOMANS_CLOTHES]', '[WOMANS_CLOTHES]'),
            (r'[PURSE]', '[PURSE]'),
            (r'[HANDBAG]', '[HANDBAG]'),
            (r'[CLUTCH]', '[CLUTCH]'),
            (r'[SHOPPING]', '[SHOPPING]'),
            (r'[BACKPACK]', '[BACKPACK]'),
            (r'[SANDAL]', '[SANDAL]'),
            (r'[SHOE]', '[SHOE]'),
            (r'[SNEAKER]', '[SNEAKER]'),
            (r'[BOOT]', '[BOOT]'),
            (r'[FLAT_SHOE]', '[FLAT_SHOE]'),
            (r'[HEEL]', '[HEEL]'),
            (r'[SANDAL]', '[SANDAL]'),
            (r'[BALLET]', '[BALLET]'),
            (r'[BOOTS]', '[BOOTS]'),
            (r'[CROWN]', '[CROWN]'),
            (r'[HAT]', '[HAT]'),
            (r'[TOP_HAT]', '[TOP_HAT]'),
            (r'[GRADUATION]', '[GRADUATION]'),
            (r'[CAP]', '[CAP]'),
            (r'[HELMET]', '[HELMET]'),
            (r'[RESCUE]', '[RESCUE]'),
            (r'[LIPSTICK]', '[LIPSTICK]'),
            (r'[RING]', '[RING]'),
            (r'[GEM]', '[GEM]'),
        ]
        
        # Apply replacements
        for emoji, text in replacements:
            content = content.replace(emoji, text)
        
        # Write back
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return original_emojis
        
    except Exception as e:
        print(f"Error processing {filepath}: {e}")
        return 0


def main():
    """Main function"""
    print("=" * 80)
    print("REMOVING ALL EMOJIS FOR WINDOWS 11 COMPATIBILITY")
    print("=" * 80)
    print()
    
    total_files = 0
    total_emojis = 0
    
    # Process all Python files
    for root, dirs, files in os.walk('.'):
        # Skip venv and __pycache__
        if 'venv' in root or '__pycache__' in root:
            continue
            
        for file in files:
            if file.endswith('.py'):
                filepath = os.path.join(root, file)
                emojis_removed = remove_emojis_from_file(filepath)
                if emojis_removed > 0:
                    total_files += 1
                    total_emojis += emojis_removed
                    print(f"Fixed: {filepath} ({emojis_removed} emojis)")
    
    print()
    print("=" * 80)
    print(f"COMPLETE! Fixed {total_files} files, removed {total_emojis} emojis")
    print("=" * 80)


if __name__ == "__main__":
    main()