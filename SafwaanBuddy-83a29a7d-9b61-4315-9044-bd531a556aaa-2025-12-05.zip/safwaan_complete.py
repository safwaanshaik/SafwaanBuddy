"""
SafwaanBuddy COMPLETE EDITION
Full system control, OCR, automation, and AI
Version: 5.0 COMPLETE
"""
import sys
import os
import logging
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional, Any

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

from PyQt6.QtWidgets import QApplication, QMessageBox
from PyQt6.QtGui import QPalette, QColor
from PyQt6.QtCore import Qt

from src.config_manager import ConfigManager
from src.database_manager import DatabaseManager
from src.realistic_voice import RealisticVoiceSystem
from src.listener import VoiceListener
from src.advanced_brain import AdvancedAIBrain
from src.multimodal_ai import MultiModalAI
from src.premium_hologram import PremiumHologram
from src.complete_screen_control import CompleteScreenControl
from src.system_controller import SystemController
from src.ocr_system import OCRSystem
from src.application_controller import ApplicationController
from src.proactive_assistant import ProactiveAssistant
from src.smart_automation import SmartAutomation
from src.smart_features import SmartFeatures
from src.ultimate_skills import UltimateSkills

# Configure logging with ASCII-safe format
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('safwaan_complete.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger('SafwaanBuddyComplete')


class SafwaanBuddyComplete:
    """Complete SafwaanBuddy with FULL system control"""
    
    def __init__(self):
        self._print_banner()
        logger.info(">>> Initializing COMPLETE system...")
        
        # Core components
        self.config = ConfigManager()
        self.db = DatabaseManager()
        self.voice = RealisticVoiceSystem(self.config)
        self.listener = VoiceListener(self.config)
        
        # AI systems
        self.brain = AdvancedAIBrain(self.config, self.db)
        self.multimodal = MultiModalAI(self.config)
        
        # Control systems
        self.screen = CompleteScreenControl()
        self.system = SystemController()
        self.ocr = OCRSystem()
        self.apps = ApplicationController()
        
        # Advanced features
        self.proactive = ProactiveAssistant(self.config, self.voice, self.db)
        self.automation = SmartAutomation(self.config, self.db, self.voice)
        self.smart = SmartFeatures(self.config, self.voice, self.db, self.brain)
        
        # Skills
        self.skills = UltimateSkills(self.screen, self.multimodal)
        
        # UI (initialized in Qt context)
        self.hologram = None
        
        # State
        self.is_running = True
        self.conversation_mode = False
        
        logger.info("[OK] All components initialized")
        logger.info("[OK] COMPLETE Edition ready!")
    
    def _print_banner(self):
        """Print startup banner"""
        print("\n" + "="*80)
        print("  SAFWAANBUDDY COMPLETE EDITION")
        print("  Full System Control + OCR + Complete Automation")
        print("  Version 5.0")
        print("="*80 + "\n")
    
    def initialize_ui(self, app):
        """Initialize UI in Qt context"""
        try:
            self.hologram = PremiumHologram(self.config)
            self.hologram.show()
            logger.info("[OK] Premium Hologram UI initialized")
        except Exception as e:
            logger.error(f"[ERROR] UI initialization failed: {e}")
    
    def start(self):
        """Start all systems"""
        logger.info(">>> Starting all systems...")
        
        # Start proactive assistant
        self.proactive.start_monitoring()
        
        # Start automation engine
        self.automation.start()
        
        # Welcome message
        self.voice.speak(
            "SafwaanBuddy Complete Edition activated. I have full control over your system. "
            "I can see your screen, control applications, manage settings, and automate anything. "
            "How can I help you today?",
            personality='professional'
        )
        
        # Start listening
        self.listener.start_listening()
        
        logger.info("[OK] All systems started")
    
    def _on_command(self, command: str):
        """Handle voice command with full system control"""
        logger.info(f"[CMD] Command: {command}")
        
        # Update UI
        if self.hologram:
            self.hologram.update_signal.emit("THINKING")
        
        # Check for system control commands
        response = self._handle_system_command(command)
        
        if not response:
            # Use AI brain
            ai_response = self.brain.think(command)
            response = ai_response['response']
            
            # Update emotion
            if self.hologram:
                self.hologram.emotion_signal.emit(ai_response['emotion'])
        
        # Speak response
        if self.hologram:
            self.hologram.update_signal.emit("SPEAKING")
        
        self.voice.speak(response, personality='friendly')
        
        # Back to listening
        if self.hologram:
            self.hologram.update_signal.emit("LISTENING")
    
    def _handle_system_command(self, command: str) -> Optional[str]:
        """Handle system control commands"""
        cmd_lower = command.lower()
        
        # Screen control commands
        if 'click' in cmd_lower:
            if 'center' in cmd_lower:
                self.screen.click_center()
                return "Clicked center of screen"
            elif 'button' in cmd_lower:
                # Extract button text
                words = command.split()
                button_text = ' '.join(words[words.index('button')+1:]) if 'button' in words else None
                if button_text and self.screen.click_button(button_text):
                    return f"Clicked {button_text} button"
        
        # OCR commands
        if 'read screen' in cmd_lower or 'what do you see' in cmd_lower:
            text = self.ocr.read_screen()
            return f"I can see: {text[:200]}..." if text else "I couldn't read any text"
        
        # Window management
        if 'close window' in cmd_lower:
            self.apps.close_active_window()
            return "Window closed"
        
        if 'minimize' in cmd_lower:
            self.apps.minimize_active_window()
            return "Window minimized"
        
        if 'maximize' in cmd_lower:
            self.apps.maximize_active_window()
            return "Window maximized"
        
        # Application launching
        if 'open' in cmd_lower:
            app_name = cmd_lower.replace('open', '').strip()
            if self.apps.launch_application(app_name):
                return f"Opening {app_name}"
        
        # System settings
        if 'brightness' in cmd_lower:
            try:
                level = int(''.join(filter(str.isdigit, command)))
                if self.system.set_brightness(level):
                    return f"Brightness set to {level}%"
            except:
                pass
        
        if 'volume' in cmd_lower:
            try:
                level = int(''.join(filter(str.isdigit, command)))
                if self.system.set_volume(level):
                    return f"Volume set to {level}%"
            except:
                pass
        
        # Screenshot
        if 'screenshot' in cmd_lower or 'capture screen' in cmd_lower:
            filename = self.screen.take_screenshot()
            return f"Screenshot saved as {filename}"
        
        # Type text
        if 'type' in cmd_lower:
            text = command.replace('type', '').strip()
            self.screen.type_text(text)
            return f"Typed: {text}"
        
        return None
    
    def stop(self):
        """Stop all systems"""
        logger.info(">>> Stopping all systems...")
        
        self.is_running = False
        self.listener.stop_listening()
        self.proactive.stop()
        self.automation.stop()
        
        if self.hologram:
            self.hologram.close()
        
        logger.info("[OK] All systems stopped")


def main():
    """Main entry point"""
    try:
        # Create Qt application
        app = QApplication(sys.argv)
        
        # Set dark theme
        app.setStyle('Fusion')
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(30, 30, 30))
        palette.setColor(QPalette.ColorRole.WindowText, Qt.GlobalColor.white)
        app.setPalette(palette)
        
        # Create SafwaanBuddy
        safwaan = SafwaanBuddyComplete()
        
        # Initialize UI
        safwaan.initialize_ui(app)
        
        # Start systems
        safwaan.start()
        
        # Run application
        sys.exit(app.exec())
        
    except KeyboardInterrupt:
        logger.info("\n[OK] Shutting down...")
        safwaan.stop()
    except Exception as e:
        logger.error(f"[ERROR] Fatal error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()