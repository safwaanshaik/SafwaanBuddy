"""
Advanced AI Brain for SafwaanBuddy
Enhanced intelligence with multi-model support, learning, and advanced reasoning
"""
import google.generativeai as genai
import logging
import time
import uuid
import json
from typing import Dict, Tuple, Optional, List
from collections import deque, defaultdict
import random

logger = logging.getLogger('SafwaanBuddy.AdvancedBrain')


class AdvancedAIBrain:
    """Advanced AI brain with enhanced capabilities"""
    
    def __init__(self, config_manager, db_manager):
        self.config = config_manager
        self.db = db_manager
        
        # Initialize AI models
        self.gemini_model = None
        self.gemini_flash = None
        self._initialize_models()
        
        # Session management
        self.session_id = str(uuid.uuid4())
        self.conversation_history = deque(maxlen=50)
        self.user_profile = self._load_user_profile()
        
        # Advanced features
        self.personality_traits = {
            'helpfulness': 0.9,
            'friendliness': 0.9,
            'professionalism': 0.7,
            'humor': 0.6,
            'empathy': 0.8
        }
        
        # Learning system
        self.learned_patterns = defaultdict(int)
        self.user_preferences = defaultdict(float)
        self.command_success_rate = defaultdict(lambda: {'success': 0, 'total': 0})
        
        # Context awareness
        self.current_context = {
            'topic': None,
            'mood': 'neutral',
            'task_in_progress': None,
            'last_tool_used': None
        }
        
        # Performance metrics
        self.metrics = {
            'total_requests': 0,
            'successful_responses': 0,
            'average_response_time': 0.0,
            'cache_hits': 0,
            'cache_misses': 0,
            'learning_events': 0
        }
        
        # Response cache
        self.response_cache = {}
        self.cache_ttl = 300  # 5 minutes
        
        logger.info("[OK] Advanced AI Brain initialized")
    
    def _initialize_models(self):
        """Initialize multiple AI models"""
        try:
            api_key = self.config.get_api_key('gemini')
            
            if not api_key or api_key == 'your_gemini_api_key_here':
                logger.warning("[WARNING] Gemini API key not configured. Using enhanced fallback.")
                return
            
            genai.configure(api_key=api_key)
            
            # Initialize Gemini Pro for complex reasoning
            self.gemini_model = genai.GenerativeModel('gemini-pro')
            logger.info("[OK] Gemini Pro initialized")
            
            # Initialize Gemini Flash for quick responses
            try:
                self.gemini_flash = genai.GenerativeModel('gemini-1.5-flash-latest')
                logger.info("[OK] Gemini Flash initialized")
            except:
                logger.info("Gemini Flash not available, using Pro only")
            
        except Exception as e:
            logger.error(f"Model initialization error: {e}")
    
    def _load_user_profile(self) -> Dict:
        """Load user profile from database"""
        profile = self.db.get_preference('user_profile', {
            'name': 'User',
            'preferences': {},
            'interaction_style': 'friendly',
            'expertise_level': 'intermediate'
        })
        return profile
    
    def think(self, user_input: str, multimodal_data: Dict = None) -> Dict:
        """
        Advanced thinking process with learning and adaptation
        """
        start_time = time.time()
        self.metrics['total_requests'] += 1
        
        try:
            # Check cache first
            cache_key = self._generate_cache_key(user_input)
            cached = self._get_cached_response(cache_key)
            if cached:
                self.metrics['cache_hits'] += 1
                return cached
            
            self.metrics['cache_misses'] += 1
            
            # Analyze user input deeply
            analysis = self._analyze_input(user_input)
            
            # Detect tool and intent
            tool, tool_value = self._detect_tool_advanced(user_input, analysis)
            
            # Get relevant memories with scoring
            memories = self.db.get_relevant_memories(user_input, limit=5)
            
            # Build rich context
            context = self._build_rich_context(user_input, analysis, memories)
            
            # Determine response strategy
            strategy = self._determine_response_strategy(analysis, tool)
            
            # Generate response based on strategy
            if strategy == 'quick' and self.gemini_flash:
                response_text = self._generate_quick_response(user_input, context)
            elif strategy == 'detailed' and self.gemini_model:
                response_text = self._generate_detailed_response(user_input, context)
            else:
                response_text = self._generate_intelligent_fallback(user_input, analysis, tool)
            
            # Enhance response with personality
            response_text = self._apply_personality(response_text, analysis['emotion'])
            
            # Detect emotion from response
            response_emotion = self._detect_response_emotion(response_text, analysis['emotion'])
            
            # Calculate confidence
            confidence = self._calculate_confidence(analysis, tool, response_text)
            
            # Create response object
            response = {
                'response': response_text,
                'tool': tool,
                'tool_value': tool_value,
                'emotion': response_emotion,
                'confidence': confidence,
                'response_time': time.time() - start_time,
                'strategy': strategy,
                'analysis': analysis
            }
            
            # Learn from interaction
            self._learn_from_interaction(user_input, response)
            
            # Store in database
            self.db.store_conversation(
                self.session_id,
                user_input,
                response_text,
                response_emotion,
                tool,
                confidence,
                response['response_time']
            )
            
            # Store important interactions in memory
            if confidence > 0.7 or tool != 'NONE':
                importance = self._calculate_importance(response)
                self.db.store_memory(
                    f"User: {user_input}\nAssistant: {response_text}",
                    category="conversation",
                    importance=importance
                )
            
            # Update conversation history
            self.conversation_history.append({
                'user': user_input,
                'assistant': response_text,
                'tool': tool,
                'emotion': response_emotion,
                'timestamp': time.time()
            })
            
            # Update context
            self._update_context(user_input, response)
            
            # Cache response
            self._cache_response(cache_key, response)
            
            # Update metrics
            self.metrics['successful_responses'] += 1
            self._update_average_response_time(response['response_time'])
            
            return response
            
        except Exception as e:
            logger.error(f"Advanced thinking error: {e}")
            return self._create_error_response(user_input, str(e), time.time() - start_time)
    
    def _analyze_input(self, text: str) -> Dict:
        """Deep analysis of user input"""
        analysis = {
            'text': text,
            'length': len(text),
            'word_count': len(text.split()),
            'emotion': self._detect_emotion_advanced(text),
            'intent': self._detect_intent(text),
            'urgency': self._detect_urgency(text),
            'complexity': self._assess_complexity(text),
            'keywords': self._extract_keywords(text),
            'entities': self._extract_entities(text)
        }
        
        return analysis
    
    def _detect_emotion_advanced(self, text: str) -> str:
        """Advanced emotion detection with nuance"""
        text_lower = text.lower()
        
        # Emotion scoring
        emotion_scores = {
            'happy': 0.0, 'sad': 0.0, 'angry': 0.0, 'excited': 0.0,
            'calm': 0.0, 'confused': 0.0, 'grateful': 0.0, 'frustrated': 0.0
        }
        
        # Enhanced emotion keywords with weights
        emotion_patterns = {
            'happy': [('happy', 1.0), ('great', 0.8), ('wonderful', 0.9), ('love', 0.8), 
                     ('awesome', 0.9), ('excellent', 0.8), ('fantastic', 0.9)],
            'sad': [('sad', 1.0), ('unhappy', 0.9), ('depressed', 1.0), ('down', 0.7),
                   ('upset', 0.8), ('disappointed', 0.8)],
            'angry': [('angry', 1.0), ('mad', 0.9), ('furious', 1.0), ('annoyed', 0.7),
                     ('frustrated', 0.8), ('irritated', 0.7)],
            'excited': [('excited', 1.0), ('amazing', 0.8), ('incredible', 0.9), 
                       ('wow', 0.7), ('awesome', 0.8)],
            'calm': [('calm', 1.0), ('peaceful', 0.9), ('relaxed', 0.9), ('serene', 0.8)],
            'confused': [('confused', 1.0), ('don\'t understand', 0.9), ('what', 0.5),
                        ('huh', 0.8), ('unclear', 0.7)],
            'grateful': [('thank', 1.0), ('thanks', 1.0), ('appreciate', 0.9),
                        ('grateful', 1.0)],
            'frustrated': [('frustrated', 1.0), ('annoying', 0.8), ('difficult', 0.6),
                          ('hard', 0.5)]
        }
        
        # Score emotions
        for emotion, patterns in emotion_patterns.items():
            for keyword, weight in patterns:
                if keyword in text_lower:
                    emotion_scores[emotion] += weight
        
        # Punctuation analysis
        if '!' in text:
            emotion_scores['excited'] += 0.3
        if '?' in text and text.count('?') > 1:
            emotion_scores['confused'] += 0.2
        
        # Get dominant emotion
        max_score = max(emotion_scores.values())
        if max_score > 0.5:
            return max(emotion_scores, key=emotion_scores.get)
        
        return 'neutral'
    
    def _detect_intent(self, text: str) -> str:
        """Detect user intent"""
        text_lower = text.lower()
        
        intents = {
            'question': ['what', 'when', 'where', 'who', 'why', 'how', '?'],
            'command': ['open', 'close', 'start', 'stop', 'play', 'search', 'find'],
            'request': ['can you', 'could you', 'would you', 'please'],
            'statement': ['i am', 'i have', 'i think', 'i feel'],
            'greeting': ['hello', 'hi', 'hey', 'good morning', 'good evening'],
            'farewell': ['bye', 'goodbye', 'see you', 'exit']
        }
        
        for intent, keywords in intents.items():
            if any(keyword in text_lower for keyword in keywords):
                return intent
        
        return 'unknown'
    
    def _detect_urgency(self, text: str) -> str:
        """Detect urgency level"""
        text_lower = text.lower()
        
        urgent_keywords = ['urgent', 'asap', 'immediately', 'now', 'quick', 'hurry', 'emergency']
        high_keywords = ['soon', 'important', 'need', 'must']
        
        if any(keyword in text_lower for keyword in urgent_keywords):
            return 'urgent'
        elif any(keyword in text_lower for keyword in high_keywords):
            return 'high'
        
        return 'normal'
    
    def _assess_complexity(self, text: str) -> str:
        """Assess query complexity"""
        word_count = len(text.split())
        
        if word_count < 5:
            return 'simple'
        elif word_count < 15:
            return 'moderate'
        else:
            return 'complex'
    
    def _extract_keywords(self, text: str) -> List[str]:
        """Extract important keywords"""
        # Simple keyword extraction
        words = text.lower().split()
        
        # Remove common stop words
        stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
                     'of', 'with', 'by', 'from', 'is', 'are', 'was', 'were', 'be', 'been'}
        
        keywords = [word for word in words if word not in stop_words and len(word) > 2]
        
        return keywords[:5]  # Top 5 keywords
    
    def _extract_entities(self, text: str) -> Dict:
        """Extract named entities (simplified)"""
        entities = {
            'numbers': [],
            'dates': [],
            'urls': [],
            'emails': []
        }
        
        import re
        
        # Extract numbers
        entities['numbers'] = re.findall(r'\b\d+\b', text)
        
        # Extract URLs
        entities['urls'] = re.findall(r'https?://\S+', text)
        
        # Extract emails
        entities['emails'] = re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text)
        
        return entities
    
    def _build_rich_context(self, user_input: str, analysis: Dict, memories: List) -> str:
        """Build rich context for AI"""
        context_parts = []
        
        # User profile
        context_parts.append(f"USER PROFILE: {self.user_profile.get('name', 'User')}")
        context_parts.append(f"INTERACTION STYLE: {self.user_profile.get('interaction_style', 'friendly')}")
        
        # Current context
        if self.current_context['topic']:
            context_parts.append(f"CURRENT TOPIC: {self.current_context['topic']}")
        
        # User emotion and intent
        context_parts.append(f"USER EMOTION: {analysis['emotion']}")
        context_parts.append(f"USER INTENT: {analysis['intent']}")
        context_parts.append(f"URGENCY: {analysis['urgency']}")
        
        # Recent conversation
        if self.conversation_history:
            context_parts.append("\nRECENT CONVERSATION:")
            for conv in list(self.conversation_history)[-3:]:
                context_parts.append(f"User: {conv['user']}")
                context_parts.append(f"Assistant: {conv['assistant']}")
        
        # Relevant memories
        if memories:
            context_parts.append("\nRELEVANT MEMORIES:")
            for mem in memories[:3]:
                context_parts.append(f"- {mem['content'][:150]}...")
        
        # User preferences
        if self.user_preferences:
            top_prefs = sorted(self.user_preferences.items(), key=lambda x: x[1], reverse=True)[:3]
            if top_prefs:
                context_parts.append("\nUSER PREFERENCES:")
                for pref, score in top_prefs:
                    context_parts.append(f"- {pref}: {score:.2f}")
        
        return "\n".join(context_parts)
    
    def _determine_response_strategy(self, analysis: Dict, tool: str) -> str:
        """Determine best response strategy"""
        # Quick response for simple queries
        if analysis['complexity'] == 'simple' and tool != 'NONE':
            return 'quick'
        
        # Detailed response for complex queries
        if analysis['complexity'] == 'complex' or analysis['intent'] == 'question':
            return 'detailed'
        
        # Urgent queries need quick response
        if analysis['urgency'] == 'urgent':
            return 'quick'
        
        return 'balanced'
    
    def _generate_quick_response(self, user_input: str, context: str) -> str:
        """Generate quick response using Gemini Flash"""
        try:
            if self.gemini_flash:
                prompt = f"""You are Safwaan, a helpful AI assistant. Provide a brief, direct response.

{context}

User: {user_input}

Response (be concise):"""
                
                response = self.gemini_flash.generate_content(prompt)
                return response.text.strip()
        except Exception as e:
            logger.error(f"Quick response error: {e}")
        
        return self._generate_intelligent_fallback(user_input, {}, 'NONE')
    
    def _generate_detailed_response(self, user_input: str, context: str) -> str:
        """Generate detailed response using Gemini Pro"""
        try:
            if self.gemini_model:
                prompt = f"""You are Safwaan, an advanced AI assistant with deep knowledge and empathy.

{context}

User: {user_input}

Provide a thoughtful, comprehensive response. Consider:
1. The user's emotional state and respond with appropriate empathy
2. Previous conversation context
3. User preferences and interaction style
4. Be helpful, informative, and natural

Response:"""
                
                response = self.gemini_model.generate_content(prompt)
                return response.text.strip()
        except Exception as e:
            logger.error(f"Detailed response error: {e}")
        
        return self._generate_intelligent_fallback(user_input, {}, 'NONE')
    
    def _generate_intelligent_fallback(self, user_input: str, analysis: Dict, tool: str) -> str:
        """Generate intelligent fallback response"""
        text_lower = user_input.lower()
        
        # Contextual greetings
        if any(word in text_lower for word in ['hello', 'hi', 'hey']):
            greetings = [
                f"Hello! I'm Safwaan, ready to assist you.",
                f"Hi there! How can I help you today?",
                f"Hey! What can I do for you?",
                f"Greetings! I'm here to help."
            ]
            return random.choice(greetings)
        
        # How are you responses
        if 'how are you' in text_lower:
            responses = [
                "I'm functioning perfectly and ready to help you!",
                "I'm doing great! Thanks for asking. How can I assist you?",
                "All systems operational! What can I do for you today?"
            ]
            return random.choice(responses)
        
        # Capability questions
        if any(phrase in text_lower for phrase in ['what can you do', 'your capabilities', 'help me']):
            return ("I can help you with many things! I can tell time, play music, search the web, "
                   "take screenshots, manage your system, answer questions, and much more. "
                   "I'm also great at networking, programming, and technical topics. "
                   "Just ask me anything!")
        
        # Identity questions
        if 'who are you' in text_lower or 'your name' in text_lower:
            return ("I'm Safwaan, your advanced AI assistant. I'm here to help you with "
                   "anything you need - from simple tasks to complex technical questions. "
                   "Think of me as your loyal digital companion!")
        
        # Thank you responses
        if any(word in text_lower for word in ['thank', 'thanks']):
            responses = [
                "You're very welcome! Happy to help anytime.",
                "My pleasure! That's what I'm here for.",
                "Anytime! Feel free to ask me anything else.",
                "Glad I could help! Let me know if you need anything else."
            ]
            return random.choice(responses)
        
        # Tool-specific responses
        tool_responses = {
            'TIME': "Let me check the time for you.",
            'DATE': "I'll tell you today's date.",
            'JOKE': "Here's a joke to brighten your day!",
            'MUSIC': "I'll find that music for you right away.",
            'SEARCH': "Let me search that for you.",
            'WEATHER': "Checking the weather now.",
            'SCREENSHOT': "Taking a screenshot for you.",
            'CALCULATOR': "Let me calculate that."
        }
        
        if tool in tool_responses:
            return tool_responses[tool]
        
        # Intelligent default responses based on context
        if self.current_context['topic']:
            return f"I understand. Let me help you with that regarding {self.current_context['topic']}."
        
        # Personalized responses
        responses = [
            "I understand. Let me help you with that.",
            "Got it! I'm on it.",
            "Sure thing! Let me take care of that for you.",
            "Absolutely! I'll help you with that right away.",
            "Of course! I'm here to help."
        ]
        
        return random.choice(responses)
    
    def _apply_personality(self, text: str, emotion: str) -> str:
        """Apply personality traits to response"""
        # Add empathy for emotional states
        if emotion == 'sad' and 'sorry' not in text.lower():
            text = "I understand how you feel. " + text
        elif emotion == 'angry' and 'understand' not in text.lower():
            text = "I hear you. " + text
        elif emotion == 'excited' and '!' not in text:
            text = text + "!"
        elif emotion == 'grateful':
            text = text + " I'm always here to help!"
        
        # Add friendliness
        if self.personality_traits['friendliness'] > 0.7:
            if random.random() < 0.3:  # 30% chance
                friendly_additions = [
                    " Hope that helps!",
                    " Let me know if you need anything else!",
                    " Feel free to ask me anything!",
                    " I'm here if you need more help!"
                ]
                text = text + random.choice(friendly_additions)
        
        return text
    
    def _detect_response_emotion(self, response: str, user_emotion: str) -> str:
        """Detect appropriate emotion for response"""
        # Mirror positive emotions
        if user_emotion in ['happy', 'excited', 'grateful']:
            return 'happy'
        
        # Empathetic for negative emotions
        if user_emotion in ['sad', 'angry', 'frustrated']:
            return 'empathetic'
        
        # Professional for neutral
        if user_emotion == 'neutral':
            return 'professional'
        
        # Calm for confused
        if user_emotion == 'confused':
            return 'calm'
        
        return 'friendly'
    
    def _detect_tool_advanced(self, text: str, analysis: Dict) -> Tuple[str, Optional[str]]:
        """Advanced tool detection with context awareness"""
        text_lower = text.lower()
        
        # Enhanced tool patterns with context
        tools = {
            'TIME': ['time', 'clock', "what's the time", 'what time', 'current time'],
            'DATE': ['date', 'day', 'today', 'what day', 'current date'],
            'JOKE': ['joke', 'funny', 'laugh', 'tell me a joke', 'make me laugh', 'humor'],
            'MUSIC': ['play music', 'play song', 'music', 'song', 'play', 'listen to'],
            'SEARCH': ['search', 'google', 'find', 'look up', 'search for', 'find out'],
            'WEATHER': ['weather', 'temperature', 'forecast', 'how hot', 'how cold', 'rain'],
            'NEWS': ['news', 'headlines', 'latest news', 'current events'],
            'SCREENSHOT': ['screenshot', 'capture', 'take a screenshot', 'screen capture', 'snap'],
            'VOLUME': ['volume', 'sound level', 'audio level', 'louder', 'quieter'],
            'CALCULATOR': ['calculate', 'math', 'compute', 'what is', 'equals'],
            'EMAIL': ['email', 'send email', 'mail', 'gmail'],
            'CALENDAR': ['calendar', 'schedule', 'appointment', 'meeting'],
            'REMINDER': ['remind', 'reminder', "don't forget", 'remember to'],
            'WEBSITE': ['open', 'visit', 'go to', 'website', 'browse'],
            'SYSTEM_INFO': ['system', 'performance', 'specs', 'computer info', 'cpu', 'memory'],
            'NOTE': ['take note', 'remember', 'write down', 'note', 'jot down'],
            'TRANSLATE': ['translate', 'in spanish', 'in french', 'in german', 'language'],
            'FILE_OPERATION': ['create file', 'delete file', 'copy file', 'move file'],
            'FOLDER_OPERATION': ['create folder', 'delete folder', 'list folder'],
            'CLOSE_APP': ['close', 'exit', 'quit', 'shut down'],
            'MINIMIZE': ['minimize', 'minimize window'],
            'MAXIMIZE': ['maximize', 'maximize window'],
            'LOCK': ['lock', 'lock computer', 'lock screen'],
            'HELP': ['help', 'what can you do', 'commands', 'capabilities']
        }
        
        # Check each tool
        for tool_name, keywords in tools.items():
            for keyword in keywords:
                if keyword in text_lower:
                    # Extract value for certain tools
                    value = self._extract_tool_value(text_lower, keyword, tool_name)
                    return tool_name, value
        
        return 'NONE', None
    
    def _extract_tool_value(self, text: str, keyword: str, tool: str) -> Optional[str]:
        """Extract value for tool"""
        if tool in ['SEARCH', 'MUSIC', 'WEBSITE', 'TRANSLATE', 'NOTE']:
            parts = text.split(keyword, 1)
            if len(parts) > 1:
                value = parts[1].strip()
                # Clean up common words
                value = value.replace('for', '').replace('about', '').strip()
                return value if value else None
        
        elif tool == 'VOLUME':
            import re
            numbers = re.findall(r'\d+', text)
            return numbers[0] if numbers else None
        
        elif tool == 'CALCULATOR':
            import re
            # Extract math expression
            match = re.search(r'(?:what is|calculate|compute)\s+(.+)', text)
            if match:
                return match.group(1).strip()
        
        return None
    
    def _calculate_confidence(self, analysis: Dict, tool: str, response: str) -> float:
        """Calculate response confidence"""
        confidence = 0.5  # Base confidence
        
        # Increase for AI model availability
        if self.gemini_model:
            confidence += 0.3
        
        # Increase for tool detection
        if tool != 'NONE':
            confidence += 0.1
        
        # Increase for clear intent
        if analysis['intent'] != 'unknown':
            confidence += 0.1
        
        # Decrease for complexity
        if analysis['complexity'] == 'complex':
            confidence -= 0.1
        
        # Increase for response quality
        if len(response) > 20:
            confidence += 0.05
        
        return min(1.0, max(0.1, confidence))
    
    def _calculate_importance(self, response: Dict) -> float:
        """Calculate importance for memory storage"""
        importance = 0.5
        
        # Increase for tool usage
        if response['tool'] != 'NONE':
            importance += 0.2
        
        # Increase for high confidence
        importance += response['confidence'] * 0.2
        
        # Increase for emotional content
        if response['emotion'] != 'neutral':
            importance += 0.1
        
        return min(1.0, importance)
    
    def _learn_from_interaction(self, user_input: str, response: Dict):
        """Learn from user interaction"""
        self.metrics['learning_events'] += 1
        
        # Learn tool preferences
        if response['tool'] != 'NONE':
            self.user_preferences[f"tool_{response['tool']}"] += 0.1
        
        # Learn command patterns
        keywords = response['analysis'].get('keywords', [])
        for keyword in keywords:
            self.learned_patterns[keyword] += 1
        
        # Track command success
        tool = response['tool']
        self.command_success_rate[tool]['total'] += 1
        if response['confidence'] > 0.7:
            self.command_success_rate[tool]['success'] += 1
        
        # Store learning data periodically
        if self.metrics['learning_events'] % 10 == 0:
            self._save_learning_data()
    
    def _save_learning_data(self):
        """Save learning data to database"""
        try:
            learning_data = {
                'patterns': dict(self.learned_patterns),
                'preferences': dict(self.user_preferences),
                'success_rates': dict(self.command_success_rate),
                'personality_traits': self.personality_traits
            }
            
            self.db.store_preference('learning_data', learning_data)
            logger.debug("Learning data saved")
        except Exception as e:
            logger.error(f"Learning data save error: {e}")
    
    def _update_context(self, user_input: str, response: Dict):
        """Update current context"""
        # Update topic
        keywords = response['analysis'].get('keywords', [])
        if keywords:
            self.current_context['topic'] = keywords[0]
        
        # Update mood
        self.current_context['mood'] = response['emotion']
        
        # Update last tool
        self.current_context['last_tool_used'] = response['tool']
    
    def _generate_cache_key(self, user_input: str) -> str:
        """Generate cache key"""
        import hashlib
        return hashlib.md5(user_input.lower().encode()).hexdigest()
    
    def _get_cached_response(self, cache_key: str) -> Optional[Dict]:
        """Get cached response if valid"""
        if cache_key in self.response_cache:
            cached = self.response_cache[cache_key]
            if time.time() - cached['timestamp'] < self.cache_ttl:
                return cached['response']
            else:
                del self.response_cache[cache_key]
        return None
    
    def _cache_response(self, cache_key: str, response: Dict):
        """Cache response"""
        self.response_cache[cache_key] = {
            'response': response,
            'timestamp': time.time()
        }
        
        # Limit cache size
        if len(self.response_cache) > 100:
            # Remove oldest entries
            oldest_keys = sorted(
                self.response_cache.keys(),
                key=lambda k: self.response_cache[k]['timestamp']
            )[:20]
            for key in oldest_keys:
                del self.response_cache[key]
    
    def _update_average_response_time(self, response_time: float):
        """Update average response time"""
        avg = self.metrics['average_response_time']
        total = self.metrics['total_requests']
        self.metrics['average_response_time'] = (avg * (total - 1) + response_time) / total
    
    def _create_error_response(self, user_input: str, error: str, response_time: float) -> Dict:
        """Create error response"""
        return {
            'response': "I'm having trouble processing that. Could you try rephrasing?",
            'tool': 'NONE',
            'tool_value': None,
            'emotion': 'apologetic',
            'confidence': 0.1,
            'response_time': response_time,
            'error': error
        }
    
    def get_stats(self) -> Dict:
        """Get comprehensive statistics"""
        stats = {
            **self.metrics,
            'session_id': self.session_id,
            'conversation_count': len(self.conversation_history),
            'gemini_available': self.gemini_model is not None,
            'cache_hit_rate': (
                self.metrics['cache_hits'] / 
                max(1, self.metrics['cache_hits'] + self.metrics['cache_misses'])
            ) * 100,
            'learned_patterns': len(self.learned_patterns),
            'user_preferences': len(self.user_preferences)
        }
        
        # Add success rates
        stats['tool_success_rates'] = {}
        for tool, data in self.command_success_rate.items():
            if data['total'] > 0:
                stats['tool_success_rates'][tool] = (data['success'] / data['total']) * 100
        
        return stats
    
    def get_personality_description(self) -> str:
        """Get personality description"""
        traits = []
        for trait, value in self.personality_traits.items():
            if value > 0.7:
                traits.append(trait)
        
        return f"I'm {', '.join(traits)} and always ready to help!"