"""
AI Brain for SafwaanBuddy
Handles AI processing with Google Gemini and intelligent responses
"""
import google.generativeai as genai
import logging
import time
import uuid
from typing import Dict, Tuple, Optional
from collections import deque

logger = logging.getLogger('SafwaanBuddy.AIBrain')


class AIBrain:
    """Advanced AI brain with Gemini integration"""
    
    def __init__(self, config_manager, db_manager):
        self.config = config_manager
        self.db = db_manager
        
        # Initialize Gemini
        self.gemini_model = None
        self._initialize_gemini()
        
        # Session management
        self.session_id = str(uuid.uuid4())
        self.conversation_history = deque(maxlen=20)
        
        # Performance metrics
        self.metrics = {
            'total_requests': 0,
            'successful_responses': 0,
            'average_response_time': 0.0
        }
        
        logger.info("[OK] AI Brain initialized")
    
    def _initialize_gemini(self):
        """Initialize Google Gemini AI"""
        try:
            api_key = self.config.get_api_key('gemini')
            
            if not api_key or api_key == 'your_gemini_api_key_here':
                logger.warning("[WARNING] Gemini API key not configured. Using fallback responses.")
                return
            
            genai.configure(api_key=api_key)
            self.gemini_model = genai.GenerativeModel('gemini-pro')
            logger.info("[OK] Gemini AI initialized")
            
        except Exception as e:
            logger.error(f"Gemini initialization error: {e}")
            logger.warning("Using fallback response system")
    
    def think(self, user_input: str) -> Dict:
        """
        Process user input and generate intelligent response
        
        Args:
            user_input: User's voice command or text
            
        Returns:
            Dict with response, tool, emotion, and metadata
        """
        start_time = time.time()
        self.metrics['total_requests'] += 1
        
        try:
            # Detect tool first
            tool, tool_value = self._detect_tool(user_input)
            
            # Get relevant memories
            memories = self.db.get_relevant_memories(user_input, limit=3)
            
            # Build context
            context = self._build_context(user_input, memories)
            
            # Generate response
            if self.gemini_model:
                response_text = self._generate_gemini_response(user_input, context)
            else:
                response_text = self._generate_fallback_response(user_input, tool)
            
            # Detect emotion
            emotion = self._detect_emotion(user_input)
            
            # Calculate metrics
            response_time = time.time() - start_time
            confidence = 0.9 if self.gemini_model else 0.6
            
            # Create response object
            response = {
                'response': response_text,
                'tool': tool,
                'tool_value': tool_value,
                'emotion': emotion,
                'confidence': confidence,
                'response_time': response_time
            }
            
            # Store in database
            self.db.store_conversation(
                self.session_id,
                user_input,
                response_text,
                emotion,
                tool,
                confidence,
                response_time
            )
            
            # Store in memory if important
            if tool != 'NONE' or confidence > 0.8:
                self.db.store_memory(
                    f"User: {user_input}\nAssistant: {response_text}",
                    category="conversation",
                    importance=0.7
                )
            
            # Update conversation history
            self.conversation_history.append({
                'user': user_input,
                'assistant': response_text,
                'tool': tool
            })
            
            # Update metrics
            self.metrics['successful_responses'] += 1
            avg_time = self.metrics['average_response_time']
            total = self.metrics['total_requests']
            self.metrics['average_response_time'] = (
                (avg_time * (total - 1) + response_time) / total
            )
            
            return response
            
        except Exception as e:
            logger.error(f"AI thinking error: {e}")
            return {
                'response': "I'm having trouble processing that. Could you try again?",
                'tool': 'NONE',
                'tool_value': None,
                'emotion': 'neutral',
                'confidence': 0.1,
                'response_time': time.time() - start_time
            }
    
    def _build_context(self, user_input: str, memories: list) -> str:
        """Build context for AI from conversation history and memories"""
        context_parts = []
        
        # Add recent conversation
        if self.conversation_history:
            context_parts.append("RECENT CONVERSATION:")
            for conv in list(self.conversation_history)[-3:]:
                context_parts.append(f"User: {conv['user']}")
                context_parts.append(f"Assistant: {conv['assistant']}")
        
        # Add relevant memories
        if memories:
            context_parts.append("\nRELEVANT MEMORIES:")
            for mem in memories[:2]:
                context_parts.append(f"- {mem['content'][:100]}...")
        
        return "\n".join(context_parts)
    
    def _generate_gemini_response(self, user_input: str, context: str) -> str:
        """Generate response using Gemini AI"""
        try:
            prompt = f"""You are Safwaan, a helpful and friendly AI assistant. 
You have a warm personality and always try to be helpful.

{context}

User: {user_input}

Provide a natural, conversational response. Be concise but informative.
If you don't know something, be honest about it.

Response:"""
            
            response = self.gemini_model.generate_content(prompt)
            return response.text.strip()
            
        except Exception as e:
            logger.error(f"Gemini generation error: {e}")
            return self._generate_fallback_response(user_input, 'NONE')
    
    def _generate_fallback_response(self, user_input: str, tool: str) -> str:
        """Generate fallback response when AI is not available"""
        text_lower = user_input.lower()
        
        # Greeting responses
        if any(word in text_lower for word in ['hello', 'hi', 'hey', 'greetings']):
            return "Hello! How can I help you today?"
        
        # How are you
        if 'how are you' in text_lower:
            return "I'm doing great, thank you for asking! How can I assist you?"
        
        # Thank you
        if any(word in text_lower for word in ['thank', 'thanks']):
            return "You're welcome! Happy to help."
        
        # Help request
        if 'help' in text_lower or 'what can you do' in text_lower:
            return ("I can help you with many things! I can tell you the time, "
                   "play music, search the web, tell jokes, take screenshots, "
                   "and much more. Just ask!")
        
        # Name question
        if 'your name' in text_lower or 'who are you' in text_lower:
            return "I'm Safwaan, your AI assistant. I'm here to help you!"
        
        # Tool-specific responses
        if tool == 'TIME':
            return "Let me check the time for you."
        elif tool == 'DATE':
            return "Let me tell you today's date."
        elif tool == 'JOKE':
            return "Here's a joke for you!"
        elif tool == 'MUSIC':
            return "I'll play that for you right away."
        elif tool == 'SEARCH':
            return "Let me search that for you."
        elif tool == 'WEATHER':
            return "Let me check the weather for you."
        
        # Default response
        return "I understand. Let me help you with that."
    
    def _detect_tool(self, text: str) -> Tuple[str, Optional[str]]:
        """Detect which tool should be used based on user input"""
        text_lower = text.lower()
        
        # Tool detection patterns
        tools = {
            'TIME': ['time', 'clock', "what's the time", 'what time'],
            'DATE': ['date', 'day', 'today', 'what day'],
            'JOKE': ['joke', 'funny', 'laugh', 'tell me a joke', 'make me laugh'],
            'MUSIC': ['play music', 'play song', 'music', 'song'],
            'SEARCH': ['search', 'google', 'find', 'look up', 'search for'],
            'WEATHER': ['weather', 'temperature', 'forecast', 'how hot', 'how cold'],
            'NEWS': ['news', 'headlines', 'latest news'],
            'SCREENSHOT': ['screenshot', 'capture', 'take a screenshot', 'screen capture'],
            'VOLUME': ['volume', 'sound level', 'audio level'],
            'CALCULATOR': ['calculate', 'math', 'compute', 'what is'],
            'EMAIL': ['email', 'send email', 'mail'],
            'CALENDAR': ['calendar', 'schedule', 'appointment'],
            'REMINDER': ['remind', 'reminder', "don't forget"],
            'WEBSITE': ['open', 'visit', 'go to', 'website'],
            'SYSTEM_INFO': ['system', 'performance', 'specs', 'computer info'],
            'NOTE': ['take note', 'remember', 'write down', 'note'],
            'TRANSLATE': ['translate', 'in spanish', 'in french', 'in german'],
            'CLOSE_APP': ['close', 'exit', 'quit'],
            'MINIMIZE': ['minimize', 'minimize window'],
            'MAXIMIZE': ['maximize', 'maximize window']
        }
        
        for tool_name, keywords in tools.items():
            for keyword in keywords:
                if keyword in text_lower:
                    # Extract value for certain tools
                    if tool_name in ['SEARCH', 'MUSIC', 'WEBSITE', 'TRANSLATE']:
                        parts = text_lower.split(keyword, 1)
                        if len(parts) > 1:
                            value = parts[1].strip()
                            return tool_name, value if value else None
                    elif tool_name == 'VOLUME':
                        import re
                        numbers = re.findall(r'\d+', text_lower)
                        return tool_name, numbers[0] if numbers else None
                    elif tool_name == 'CALCULATOR':
                        # Extract math expression
                        import re
                        # Look for patterns like "what is 5 + 3"
                        match = re.search(r'what is (.+)', text_lower)
                        if match:
                            return tool_name, match.group(1).strip()
                    
                    return tool_name, None
        
        return 'NONE', None
    
    def _detect_emotion(self, text: str) -> str:
        """Detect emotion from user input"""
        text_lower = text.lower()
        
        # Emotion keywords
        emotions = {
            'happy': ['happy', 'great', 'wonderful', 'awesome', 'excellent', 'love'],
            'sad': ['sad', 'unhappy', 'depressed', 'down', 'upset'],
            'angry': ['angry', 'mad', 'furious', 'annoyed', 'frustrated'],
            'excited': ['excited', 'amazing', 'incredible', 'wow'],
            'calm': ['calm', 'peaceful', 'relaxed'],
            'confused': ['confused', 'don\'t understand', 'what', 'huh']
        }
        
        for emotion, keywords in emotions.items():
            if any(keyword in text_lower for keyword in keywords):
                return emotion
        
        return 'neutral'
    
    def get_stats(self) -> Dict:
        """Get AI brain statistics"""
        return {
            **self.metrics,
            'session_id': self.session_id,
            'conversation_count': len(self.conversation_history),
            'gemini_available': self.gemini_model is not None
        }