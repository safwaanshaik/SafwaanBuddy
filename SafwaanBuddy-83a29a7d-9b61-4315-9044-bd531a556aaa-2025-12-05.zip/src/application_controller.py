"""
Application Controller for SafwaanBuddy
Launch, control, and automate any Windows application
"""
import subprocess
import logging
import time
import os
from typing import Optional, List, Dict
import psutil
import win32gui
import win32con
import win32process
import pyautogui

logger = logging.getLogger('SafwaanBuddy.ApplicationController')


class ApplicationController:
    """Complete application control and automation"""
    
    def __init__(self):
        # Common application paths
        self.app_paths = {
            'notepad': 'notepad.exe',
            'calculator': 'calc.exe',
            'paint': 'mspaint.exe',
            'wordpad': 'write.exe',
            'explorer': 'explorer.exe',
            'cmd': 'cmd.exe',
            'powershell': 'powershell.exe',
            'chrome': r'C:\Program Files\Google\Chrome\Application\chrome.exe',
            'firefox': r'C:\Program Files\Mozilla Firefox\firefox.exe',
            'edge': r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
            'word': r'C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE',
            'excel': r'C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE',
            'powerpoint': r'C:\Program Files\Microsoft Office\root\Office16\POWERPNT.EXE',
            'outlook': r'C:\Program Files\Microsoft Office\root\Office16\OUTLOOK.EXE',
            'vscode': r'C:\Users\{username}\AppData\Local\Programs\Microsoft VS Code\Code.exe',
            'spotify': r'C:\Users\{username}\AppData\Roaming\Spotify\Spotify.exe',
            'discord': r'C:\Users\{username}\AppData\Local\Discord\app-1.0.9000\Discord.exe',
            'steam': r'C:\Program Files (x86)\Steam\steam.exe',
            'vlc': r'C:\Program Files\VideoLAN\VLC\vlc.exe'
        }
        
        # Running applications cache
        self.running_apps = {}
        self._update_running_apps()
        
        logger.info("[OK] Application Controller initialized")
    
    def _update_running_apps(self):
        """Update list of running applications"""
        try:
            self.running_apps = {}
            for proc in psutil.process_iter(['pid', 'name', 'exe']):
                try:
                    info = proc.info
                    if info['name']:
                        self.running_apps[info['name'].lower()] = {
                            'pid': info['pid'],
                            'name': info['name'],
                            'exe': info['exe']
                        }
                except:
                    continue
        except Exception as e:
            logger.error(f"Update running apps error: {e}")
    
    # ==================== APPLICATION LAUNCHING ====================
    
    def launch_application(self, app_name: str, args: List[str] = None) -> bool:
        """Launch any application"""
        try:
            app_name_lower = app_name.lower()
            
            # Check if in predefined paths
            if app_name_lower in self.app_paths:
                app_path = self.app_paths[app_name_lower]
                
                # Replace username placeholder
                if '{username}' in app_path:
                    username = os.getenv('USERNAME')
                    app_path = app_path.replace('{username}', username)
                
                # Check if file exists
                if os.path.exists(app_path):
                    if args:
                        subprocess.Popen([app_path] + args)
                    else:
                        subprocess.Popen(app_path)
                    
                    logger.info(f"[OK] Launched {app_name}")
                    time.sleep(1)
                    self._update_running_apps()
                    return True
                else:
                    logger.warning(f"Application path not found: {app_path}")
            
            # Try launching by name
            try:
                if args:
                    subprocess.Popen([app_name] + args, shell=True)
                else:
                    subprocess.Popen(app_name, shell=True)
                
                logger.info(f"[OK] Launched {app_name}")
                time.sleep(1)
                self._update_running_apps()
                return True
            except:
                pass
            
            # Try with .exe extension
            try:
                exe_name = app_name if app_name.endswith('.exe') else f"{app_name}.exe"
                subprocess.Popen(exe_name, shell=True)
                logger.info(f"[OK] Launched {exe_name}")
                time.sleep(1)
                self._update_running_apps()
                return True
            except:
                pass
            
            logger.error(f"Could not launch {app_name}")
            return False
            
        except Exception as e:
            logger.error(f"Launch application error: {e}")
        return False
    
    def open_file(self, file_path: str) -> bool:
        """Open file with default application"""
        try:
            if os.path.exists(file_path):
                os.startfile(file_path)
                logger.info(f"[OK] Opened file: {file_path}")
                return True
            else:
                logger.error(f"File not found: {file_path}")
        except Exception as e:
            logger.error(f"Open file error: {e}")
        return False
    
    def open_url(self, url: str) -> bool:
        """Open URL in default browser"""
        try:
            import webbrowser
            webbrowser.open(url)
            logger.info(f"[OK] Opened URL: {url}")
            return True
        except Exception as e:
            logger.error(f"Open URL error: {e}")
        return False
    
    # ==================== APPLICATION CONTROL ====================
    
    def is_application_running(self, app_name: str) -> bool:
        """Check if application is running"""
        try:
            self._update_running_apps()
            app_name_lower = app_name.lower()
            
            # Check exact match
            if f"{app_name_lower}.exe" in self.running_apps:
                return True
            
            # Check partial match
            for running_app in self.running_apps:
                if app_name_lower in running_app:
                    return True
            
            return False
        except Exception as e:
            logger.error(f"Check application error: {e}")
        return False
    
    def close_application(self, app_name: str) -> bool:
        """Close running application"""
        try:
            self._update_running_apps()
            app_name_lower = app_name.lower()
            
            # Find application
            target_pid = None
            for running_app, info in self.running_apps.items():
                if app_name_lower in running_app:
                    target_pid = info['pid']
                    break
            
            if target_pid:
                proc = psutil.Process(target_pid)
                proc.terminate()
                proc.wait(timeout=5)
                logger.info(f"[OK] Closed {app_name}")
                return True
            else:
                logger.warning(f"Application not running: {app_name}")
        except Exception as e:
            logger.error(f"Close application error: {e}")
        return False
    
    def get_running_applications(self) -> List[Dict]:
        """Get list of all running applications"""
        try:
            self._update_running_apps()
            return [
                {'name': info['name'], 'pid': info['pid']}
                for info in self.running_apps.values()
            ]
        except Exception as e:
            logger.error(f"Get running apps error: {e}")
        return []
    
    def focus_application(self, app_name: str) -> bool:
        """Bring application to foreground"""
        try:
            app_name_lower = app_name.lower()
            
            def callback(hwnd, windows):
                if win32gui.IsWindowVisible(hwnd):
                    title = win32gui.GetWindowText(hwnd)
                    if app_name_lower in title.lower():
                        windows.append(hwnd)
                return True
            
            windows = []
            win32gui.EnumWindows(callback, windows)
            
            if windows:
                hwnd = windows[0]
                win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
                win32gui.SetForegroundWindow(hwnd)
                logger.info(f"[OK] Focused {app_name}")
                return True
            else:
                logger.warning(f"Window not found: {app_name}")
        except Exception as e:
            logger.error(f"Focus application error: {e}")
        return False
    
    # ==================== BROWSER AUTOMATION ====================
    
    def open_browser(self, url: str = None, browser: str = 'default') -> bool:
        """Open browser with optional URL"""
        try:
            import webbrowser
            
            if browser == 'chrome':
                webbrowser.get('chrome').open(url or 'about:blank')
            elif browser == 'firefox':
                webbrowser.get('firefox').open(url or 'about:blank')
            elif browser == 'edge':
                webbrowser.get('edge').open(url or 'about:blank')
            else:
                webbrowser.open(url or 'about:blank')
            
            logger.info(f"[OK] Opened browser: {url or 'blank page'}")
            return True
        except Exception as e:
            logger.error(f"Open browser error: {e}")
        return False
    
    def search_google(self, query: str) -> bool:
        """Search Google"""
        try:
            url = f"https://www.google.com/search?q={query}"
            return self.open_url(url)
        except Exception as e:
            logger.error(f"Google search error: {e}")
        return False
    
    def search_youtube(self, query: str) -> bool:
        """Search YouTube"""
        try:
            url = f"https://www.youtube.com/results?search_query={query}"
            return self.open_url(url)
        except Exception as e:
            logger.error(f"YouTube search error: {e}")
        return False
    
    # ==================== OFFICE AUTOMATION ====================
    
    def open_word(self, file_path: Optional[str] = None) -> bool:
        """Open Microsoft Word"""
        try:
            if file_path:
                return self.open_file(file_path)
            else:
                return self.launch_application('word')
        except Exception as e:
            logger.error(f"Open Word error: {e}")
        return False
    
    def open_excel(self, file_path: Optional[str] = None) -> bool:
        """Open Microsoft Excel"""
        try:
            if file_path:
                return self.open_file(file_path)
            else:
                return self.launch_application('excel')
        except Exception as e:
            logger.error(f"Open Excel error: {e}")
        return False
    
    def open_powerpoint(self, file_path: Optional[str] = None) -> bool:
        """Open Microsoft PowerPoint"""
        try:
            if file_path:
                return self.open_file(file_path)
            else:
                return self.launch_application('powerpoint')
        except Exception as e:
            logger.error(f"Open PowerPoint error: {e}")
        return False
    
    # ==================== FILE EXPLORER ====================
    
    def open_folder(self, folder_path: str) -> bool:
        """Open folder in File Explorer"""
        try:
            if os.path.exists(folder_path):
                subprocess.Popen(f'explorer "{folder_path}"')
                logger.info(f"[OK] Opened folder: {folder_path}")
                return True
            else:
                logger.error(f"Folder not found: {folder_path}")
        except Exception as e:
            logger.error(f"Open folder error: {e}")
        return False
    
    def open_downloads(self) -> bool:
        """Open Downloads folder"""
        try:
            downloads = os.path.join(os.path.expanduser('~'), 'Downloads')
            return self.open_folder(downloads)
        except Exception as e:
            logger.error(f"Open downloads error: {e}")
        return False
    
    def open_documents(self) -> bool:
        """Open Documents folder"""
        try:
            documents = os.path.join(os.path.expanduser('~'), 'Documents')
            return self.open_folder(documents)
        except Exception as e:
            logger.error(f"Open documents error: {e}")
        return False
    
    def open_desktop(self) -> bool:
        """Open Desktop folder"""
        try:
            desktop = os.path.join(os.path.expanduser('~'), 'Desktop')
            return self.open_folder(desktop)
        except Exception as e:
            logger.error(f"Open desktop error: {e}")
        return False