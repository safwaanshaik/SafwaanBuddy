"""
Audio Device Manager for SafwaanBuddy
Automatic detection and switching between speakers and headphones
"""
import logging
import pygame.mixer
from typing import Optional, List, Dict
import platform

logger = logging.getLogger('SafwaanBuddy.AudioDevice')


class AudioDeviceManager:
    """Manages audio output devices and automatic switching"""
    
    def __init__(self):
        self.current_device = None
        self.available_devices = []
        self.device_preferences = {
            'headphone': None,
            'speaker': None
        }
        
        # Device detection state
        self.last_device_check = 0
        self.device_check_interval = 5  # Check every 5 seconds
        
        # Initialize
        self._detect_devices()
        
        logger.info(f"[OK] Audio Device Manager initialized - {len(self.available_devices)} devices found")
    
    def _detect_devices(self):
        """Detect all available audio devices"""
        try:
            # Get pygame audio devices
            pygame.mixer.init()
            
            # On Windows, we can detect device changes
            if platform.system() == "Windows":
                self._detect_windows_devices()
            
            self.current_device = self._get_current_device()
            logger.info(f"[OK] Current device: {self.current_device}")
            
        except Exception as e:
            logger.error(f"Device detection error: {e}")
    
    def _detect_windows_devices(self):
        """Detect Windows audio devices"""
        try:
            # Try to use Windows API
            try:
                import win32api
                import win32con
                # Get audio devices using Windows API
                # This is a simplified version
                self.available_devices = ['Default', 'Speakers', 'Headphones']
            except ImportError:
                # Fallback to basic detection
                self.available_devices = ['Default']
                
        except Exception as e:
            logger.error(f"Windows device detection error: {e}")
            self.available_devices = ['Default']
    
    def _get_current_device(self) -> str:
        """Get currently active audio device"""
        try:
            # Check if headphones are connected
            if self._is_headphone_connected():
                return 'Headphones'
            else:
                return 'Speakers'
        except:
            return 'Default'
    
    def _is_headphone_connected(self) -> bool:
        """Check if headphones are connected"""
        try:
            if platform.system() == "Windows":
                # Try to detect headphones using Windows API
                try:
                    import win32api
                    # Simplified detection - in reality would use more complex API
                    # For now, assume headphones if not default speakers
                    return False  # Default to speakers
                except:
                    return False
            return False
        except:
            return False
    
    def switch_to_headphones(self) -> bool:
        """Switch audio output to headphones"""
        try:
            if 'Headphones' in self.available_devices:
                self.current_device = 'Headphones'
                logger.info("[OK] Switched to headphones")
                return True
            else:
                logger.warning("[!] Headphones not available")
                return False
        except Exception as e:
            logger.error(f"Switch to headphones error: {e}")
            return False
    
    def switch_to_speakers(self) -> bool:
        """Switch audio output to speakers"""
        try:
            if 'Speakers' in self.available_devices:
                self.current_device = 'Speakers'
                logger.info("[OK] Switched to speakers")
                return True
            else:
                logger.warning("[!] Speakers not available")
                return False
        except Exception as e:
            logger.error(f"Switch to speakers error: {e}")
            return False
    
    def auto_switch_device(self) -> bool:
        """Automatically switch to best available device"""
        try:
            # Check for headphones first (preferred)
            if self._is_headphone_connected():
                return self.switch_to_headphones()
            else:
                return self.switch_to_speakers()
        except Exception as e:
            logger.error(f"Auto switch error: {e}")
            return False
    
    def get_current_device(self) -> str:
        """Get current audio device name"""
        return self.current_device or 'Default'
    
    def get_available_devices(self) -> List[str]:
        """Get list of available audio devices"""
        return self.available_devices
    
    def set_device_preference(self, device_type: str, device_name: str):
        """Set preferred device for a type"""
        if device_type in self.device_preferences:
            self.device_preferences[device_type] = device_name
            logger.info(f"[OK] Set {device_type} preference to {device_name}")
    
    def check_device_changes(self) -> bool:
        """Check if audio device has changed"""
        try:
            import time
            current_time = time.time()
            
            # Only check periodically
            if current_time - self.last_device_check < self.device_check_interval:
                return False
            
            self.last_device_check = current_time
            
            # Re-detect devices
            old_device = self.current_device
            self._detect_devices()
            
            # Check if device changed
            if old_device != self.current_device:
                logger.info(f"[OK] Device changed: {old_device} -> {self.current_device}")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Device change check error: {e}")
            return False