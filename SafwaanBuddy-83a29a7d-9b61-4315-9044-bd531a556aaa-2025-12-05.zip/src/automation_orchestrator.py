"""
Intelligent Automation Orchestrator for SafwaanBuddy ULTIMATE
Advanced workflow automation, task scheduling, and intelligent execution
"""
import logging
import threading
import time
import json
import schedule
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable, Any
from collections import defaultdict, deque
import queue

logger = logging.getLogger('SafwaanBuddy.Orchestrator')


class AutomationOrchestrator:
    """Advanced automation orchestration system"""
    
    def __init__(self, config_manager, db_manager):
        self.config = config_manager
        self.db = db_manager
        
        # Workflow management
        self.workflows = {}
        self.active_workflows = {}
        self.workflow_history = deque(maxlen=1000)
        
        # Task scheduling
        self.scheduler = schedule.Scheduler()
        self.scheduled_tasks = {}
        
        # Execution engine
        self.execution_queue = queue.Queue()
        self.execution_thread = None
        self.is_running = False
        
        # Macro system
        self.macros = {}
        self.macro_recorder = MacroRecorder()
        
        # Conditional automation
        self.triggers = {}
        self.conditions = {}
        
        # Performance tracking
        self.execution_stats = defaultdict(lambda: {
            'count': 0,
            'success': 0,
            'failure': 0,
            'avg_duration': 0.0
        })
        
        logger.info("[OK] Automation orchestrator initialized")
    
    def create_workflow(self, name: str, steps: List[Dict], description: str = "") -> str:
        """
        Create automation workflow
        
        Args:
            name: Workflow name
            steps: List of workflow steps
            description: Workflow description
        
        Returns:
            Workflow ID
        """
        try:
            workflow_id = f"workflow_{len(self.workflows) + 1}"
            
            workflow = {
                'id': workflow_id,
                'name': name,
                'description': description,
                'steps': steps,
                'created_at': datetime.now().isoformat(),
                'enabled': True,
                'execution_count': 0
            }
            
            self.workflows[workflow_id] = workflow
            
            # Save to database
            self.db.execute(
                "INSERT INTO workflows (id, name, description, steps, created_at) VALUES (?, ?, ?, ?, ?)",
                (workflow_id, name, description, json.dumps(steps), workflow['created_at'])
            )
            
            logger.info(f"[OK] Workflow created: {name}")
            return workflow_id
            
        except Exception as e:
            logger.error(f"[ERROR] Workflow creation failed: {e}")
            return None
    
    def execute_workflow(self, workflow_id: str, variables: Dict = None) -> Dict:
        """
        Execute workflow
        
        Args:
            workflow_id: Workflow ID
            variables: Workflow variables
        
        Returns:
            Execution results
        """
        try:
            if workflow_id not in self.workflows:
                return {'error': 'Workflow not found'}
            
            workflow = self.workflows[workflow_id]
            
            if not workflow['enabled']:
                return {'error': 'Workflow is disabled'}
            
            # Start execution
            execution_id = f"exec_{workflow_id}_{int(time.time())}"
            
            execution = {
                'id': execution_id,
                'workflow_id': workflow_id,
                'started_at': datetime.now().isoformat(),
                'status': 'running',
                'steps_completed': 0,
                'steps_total': len(workflow['steps']),
                'results': []
            }
            
            self.active_workflows[execution_id] = execution
            
            # Execute steps
            for i, step in enumerate(workflow['steps']):
                try:
                    # Replace variables
                    if variables:
                        step = self._replace_variables(step, variables)
                    
                    # Execute step
                    result = self._execute_step(step)
                    
                    execution['results'].append({
                        'step': i + 1,
                        'name': step.get('name', f'Step {i+1}'),
                        'result': result,
                        'status': 'success' if result.get('success') else 'failed'
                    })
                    
                    execution['steps_completed'] = i + 1
                    
                    # Check if step failed and stop_on_error is True
                    if not result.get('success') and step.get('stop_on_error', True):
                        execution['status'] = 'failed'
                        break
                    
                except Exception as e:
                    logger.error(f"[ERROR] Step {i+1} failed: {e}")
                    execution['results'].append({
                        'step': i + 1,
                        'error': str(e),
                        'status': 'failed'
                    })
                    
                    if step.get('stop_on_error', True):
                        execution['status'] = 'failed'
                        break
            
            # Complete execution
            if execution['status'] == 'running':
                execution['status'] = 'completed'
            
            execution['completed_at'] = datetime.now().isoformat()
            
            # Update workflow stats
            workflow['execution_count'] += 1
            
            # Store in history
            self.workflow_history.append(execution)
            
            # Remove from active
            del self.active_workflows[execution_id]
            
            logger.info(f"[OK] Workflow executed: {workflow['name']}")
            return execution
            
        except Exception as e:
            logger.error(f"[ERROR] Workflow execution failed: {e}")
            return {'error': str(e)}
    
    def schedule_workflow(self, workflow_id: str, schedule_time: str, variables: Dict = None) -> str:
        """
        Schedule workflow execution
        
        Args:
            workflow_id: Workflow ID
            schedule_time: Schedule time (cron format or time string)
            variables: Workflow variables
        
        Returns:
            Schedule ID
        """
        try:
            schedule_id = f"schedule_{len(self.scheduled_tasks) + 1}"
            
            # Parse schedule time
            if schedule_time.startswith('every'):
                # e.g., "every 1 hour", "every day at 09:00"
                self._schedule_recurring(schedule_id, workflow_id, schedule_time, variables)
            else:
                # One-time schedule
                self._schedule_once(schedule_id, workflow_id, schedule_time, variables)
            
            self.scheduled_tasks[schedule_id] = {
                'workflow_id': workflow_id,
                'schedule_time': schedule_time,
                'variables': variables,
                'created_at': datetime.now().isoformat()
            }
            
            logger.info(f"[OK] Workflow scheduled: {schedule_id}")
            return schedule_id
            
        except Exception as e:
            logger.error(f"[ERROR] Workflow scheduling failed: {e}")
            return None
    
    def create_macro(self, name: str, actions: List[Dict]) -> str:
        """
        Create macro (sequence of actions)
        
        Args:
            name: Macro name
            actions: List of actions
        
        Returns:
            Macro ID
        """
        try:
            macro_id = f"macro_{len(self.macros) + 1}"
            
            self.macros[macro_id] = {
                'id': macro_id,
                'name': name,
                'actions': actions,
                'created_at': datetime.now().isoformat()
            }
            
            logger.info(f"[OK] Macro created: {name}")
            return macro_id
            
        except Exception as e:
            logger.error(f"[ERROR] Macro creation failed: {e}")
            return None
    
    def execute_macro(self, macro_id: str) -> Dict:
        """Execute macro"""
        try:
            if macro_id not in self.macros:
                return {'error': 'Macro not found'}
            
            macro = self.macros[macro_id]
            results = []
            
            for action in macro['actions']:
                result = self._execute_action(action)
                results.append(result)
            
            return {'success': True, 'results': results}
            
        except Exception as e:
            logger.error(f"[ERROR] Macro execution failed: {e}")
            return {'error': str(e)}
    
    def start_macro_recording(self) -> None:
        """Start recording macro"""
        self.macro_recorder.start_recording()
        logger.info("[OK] Macro recording started")
    
    def stop_macro_recording(self) -> List[Dict]:
        """Stop recording and get actions"""
        actions = self.macro_recorder.stop_recording()
        logger.info(f"[OK] Macro recording stopped: {len(actions)} actions")
        return actions
    
    def create_trigger(self, name: str, condition: Dict, action: Dict) -> str:
        """
        Create conditional trigger
        
        Args:
            name: Trigger name
            condition: Trigger condition
            action: Action to execute
        
        Returns:
            Trigger ID
        """
        try:
            trigger_id = f"trigger_{len(self.triggers) + 1}"
            
            self.triggers[trigger_id] = {
                'id': trigger_id,
                'name': name,
                'condition': condition,
                'action': action,
                'enabled': True,
                'triggered_count': 0
            }
            
            logger.info(f"[OK] Trigger created: {name}")
            return trigger_id
            
        except Exception as e:
            logger.error(f"[ERROR] Trigger creation failed: {e}")
            return None
    
    def check_triggers(self, context: Dict) -> List[str]:
        """
        Check and execute triggers
        
        Args:
            context: Current context
        
        Returns:
            List of triggered IDs
        """
        triggered = []
        
        for trigger_id, trigger in self.triggers.items():
            if not trigger['enabled']:
                continue
            
            try:
                if self._evaluate_condition(trigger['condition'], context):
                    # Execute action
                    self._execute_action(trigger['action'])
                    trigger['triggered_count'] += 1
                    triggered.append(trigger_id)
                    
                    logger.info(f"[OK] Trigger executed: {trigger['name']}")
                    
            except Exception as e:
                logger.error(f"[ERROR] Trigger check failed: {e}")
        
        return triggered
    
    def start(self) -> None:
        """Start orchestrator"""
        self.is_running = True
        
        # Start execution thread
        self.execution_thread = threading.Thread(target=self._execution_loop, daemon=True)
        self.execution_thread.start()
        
        # Start scheduler thread
        self.scheduler_thread = threading.Thread(target=self._scheduler_loop, daemon=True)
        self.scheduler_thread.start()
        
        logger.info("[OK] Orchestrator started")
    
    def stop(self) -> None:
        """Stop orchestrator"""
        self.is_running = False
        
        if self.execution_thread:
            self.execution_thread.join(timeout=2.0)
        
        if self.scheduler_thread:
            self.scheduler_thread.join(timeout=2.0)
        
        logger.info("[OK] Orchestrator stopped")
    
    def _execute_step(self, step: Dict) -> Dict:
        """Execute workflow step"""
        try:
            step_type = step.get('type', 'action')
            
            if step_type == 'action':
                return self._execute_action(step)
            elif step_type == 'condition':
                return self._execute_condition(step)
            elif step_type == 'loop':
                return self._execute_loop(step)
            elif step_type == 'wait':
                time.sleep(step.get('duration', 1.0))
                return {'success': True}
            else:
                return {'success': False, 'error': f'Unknown step type: {step_type}'}
                
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _execute_action(self, action: Dict) -> Dict:
        """Execute action"""
        try:
            action_type = action.get('action_type')
            
            if action_type == 'click':
                import pyautogui
                pyautogui.click(action['x'], action['y'])
                return {'success': True}
            
            elif action_type == 'type':
                import pyautogui
                pyautogui.write(action['text'])
                return {'success': True}
            
            elif action_type == 'command':
                import subprocess
                result = subprocess.run(action['command'], shell=True, capture_output=True, text=True)
                return {'success': result.returncode == 0, 'output': result.stdout}
            
            else:
                return {'success': False, 'error': f'Unknown action type: {action_type}'}
                
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _execute_condition(self, condition: Dict) -> Dict:
        """Execute conditional step"""
        # Implement condition evaluation
        return {'success': True}
    
    def _execute_loop(self, loop: Dict) -> Dict:
        """Execute loop step"""
        # Implement loop execution
        return {'success': True}
    
    def _evaluate_condition(self, condition: Dict, context: Dict) -> bool:
        """Evaluate condition"""
        try:
            condition_type = condition.get('type')
            
            if condition_type == 'time':
                # Time-based condition
                current_hour = datetime.now().hour
                return current_hour == condition.get('hour')
            
            elif condition_type == 'value':
                # Value comparison
                key = condition.get('key')
                operator = condition.get('operator')
                value = condition.get('value')
                
                if key not in context:
                    return False
                
                context_value = context[key]
                
                if operator == '==':
                    return context_value == value
                elif operator == '>':
                    return context_value > value
                elif operator == '<':
                    return context_value < value
                
            return False
            
        except Exception as e:
            logger.error(f"[ERROR] Condition evaluation failed: {e}")
            return False
    
    def _replace_variables(self, step: Dict, variables: Dict) -> Dict:
        """Replace variables in step"""
        step_str = json.dumps(step)
        
        for key, value in variables.items():
            step_str = step_str.replace(f"{{{{{key}}}}}", str(value))
        
        return json.loads(step_str)
    
    def _schedule_recurring(self, schedule_id: str, workflow_id: str, schedule_time: str, variables: Dict) -> None:
        """Schedule recurring workflow"""
        # Parse schedule time and create schedule
        # e.g., "every 1 hour" -> schedule.every(1).hours.do(...)
        pass
    
    def _schedule_once(self, schedule_id: str, workflow_id: str, schedule_time: str, variables: Dict) -> None:
        """Schedule one-time workflow"""
        # Parse schedule time and create one-time schedule
        pass
    
    def _execution_loop(self) -> None:
        """Execution loop"""
        while self.is_running:
            try:
                # Process execution queue
                if not self.execution_queue.empty():
                    task = self.execution_queue.get()
                    # Execute task
                    pass
                
                time.sleep(0.1)
                
            except Exception as e:
                logger.error(f"[ERROR] Execution loop error: {e}")
    
    def _scheduler_loop(self) -> None:
        """Scheduler loop"""
        while self.is_running:
            try:
                self.scheduler.run_pending()
                time.sleep(1)
                
            except Exception as e:
                logger.error(f"[ERROR] Scheduler loop error: {e}")


class MacroRecorder:
    """Macro recording system"""
    
    def __init__(self):
        self.is_recording = False
        self.recorded_actions = []
        self.record_thread = None
    
    def start_recording(self) -> None:
        """Start recording"""
        self.is_recording = True
        self.recorded_actions = []
        
        # Start recording thread
        self.record_thread = threading.Thread(target=self._record_loop, daemon=True)
        self.record_thread.start()
    
    def stop_recording(self) -> List[Dict]:
        """Stop recording and return actions"""
        self.is_recording = False
        
        if self.record_thread:
            self.record_thread.join(timeout=2.0)
        
        return self.recorded_actions
    
    def _record_loop(self) -> None:
        """Recording loop"""
        from pynput import mouse, keyboard
        
        def on_click(x, y, button, pressed):
            if pressed and self.is_recording:
                self.recorded_actions.append({
                    'action_type': 'click',
                    'x': x,
                    'y': y,
                    'button': str(button),
                    'timestamp': time.time()
                })
        
        def on_key(key):
            if self.is_recording:
                try:
                    self.recorded_actions.append({
                        'action_type': 'key',
                        'key': key.char,
                        'timestamp': time.time()
                    })
                except AttributeError:
                    pass
        
        # Start listeners
        mouse_listener = mouse.Listener(on_click=on_click)
        keyboard_listener = keyboard.Listener(on_press=on_key)
        
        mouse_listener.start()
        keyboard_listener.start()
        
        # Wait until recording stops
        while self.is_recording:
            time.sleep(0.1)
        
        mouse_listener.stop()
        keyboard_listener.stop()