"""
Complete Screen Control System for SafwaanBuddy
Full laptop control: mouse, keyboard, OCR, window management, settings
"""
import pyautogui
import logging
import subprocess
import platform
import time
import json
from PIL import Image, ImageGrab, ImageOps
import numpy as np
from typing import Optional, Tuple, Dict, List, Any
import win32gui
import win32con
import win32api
import win32process
import psutil

logger = logging.getLogger('SafwaanBuddy.CompleteScreenControl')


class CompleteScreenControl:
    """Complete screen and system control"""
    
    def __init__(self):
        # Screen info
        self.screen_size = pyautogui.size()
        self.center_x = self.screen_size.width // 2
        self.center_y = self.screen_size.height // 2
        
        # Safety settings
        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = 0.1
        
        # OCR availability
        self.ocr_available = self._check_ocr()
        
        # Window cache
        self.window_cache = {}
        self.last_window_scan = 0
        
        logger.info(f"[OK] Complete Screen Control initialized - {self.screen_size.width}x{self.screen_size.height}")
    
    def _check_ocr(self) -> bool:
        """Check if OCR is available"""
        try:
            import pytesseract
            return True
        except:
            logger.warning("Tesseract OCR not available - install for OCR features")
            return False
    
    # ==================== MOUSE CONTROL ====================
    
    def move_mouse(self, x: int, y: int, duration: float = 0.3, smooth: bool = True):
        """Move mouse to position with optional smooth movement"""
        try:
            if smooth:
                pyautogui.moveTo(x, y, duration=duration, tween=pyautogui.easeInOutQuad)
            else:
                pyautogui.moveTo(x, y)
            
            logger.info(f"[OK] Mouse moved to ({x}, {y})")
            return True
        except Exception as e:
            logger.error(f"Mouse move error: {e}")
            return False
    
    def click(self, x: Optional[int] = None, y: Optional[int] = None, 
              button: str = 'left', clicks: int = 1, interval: float = 0.0):
        """Click at position or current location"""
        try:
            if x is not None and y is not None:
                pyautogui.click(x, y, clicks=clicks, interval=interval, button=button)
                logger.info(f"[OK] Clicked at ({x}, {y}) - {button} button")
            else:
                pyautogui.click(clicks=clicks, interval=interval, button=button)
                logger.info(f"[OK] Clicked at current position - {button} button")
            
            return True
        except Exception as e:
            logger.error(f"Click error: {e}")
            return False
    
    def double_click(self, x: Optional[int] = None, y: Optional[int] = None):
        """Double click at position"""
        return self.click(x, y, clicks=2, interval=0.1)
    
    def right_click(self, x: Optional[int] = None, y: Optional[int] = None):
        """Right click at position"""
        return self.click(x, y, button='right')
    
    def drag(self, start_x: int, start_y: int, end_x: int, end_y: int, duration: float = 0.5):
        """Drag from start to end position"""
        try:
            pyautogui.moveTo(start_x, start_y)
            time.sleep(0.1)
            pyautogui.drag(end_x - start_x, end_y - start_y, duration=duration, button='left')
            logger.info(f"[OK] Dragged from ({start_x},{start_y}) to ({end_x},{end_y})")
            return True
        except Exception as e:
            logger.error(f"Drag error: {e}")
            return False
    
    def scroll(self, amount: int, direction: str = 'down'):
        """Scroll up or down"""
        try:
            scroll_amount = -amount if direction == 'down' else amount
            pyautogui.scroll(scroll_amount)
            logger.info(f"[OK] Scrolled {direction} by {amount}")
            return True
        except Exception as e:
            logger.error(f"Scroll error: {e}")
            return False
    
    # ==================== KEYBOARD CONTROL ====================
    
    def type_text(self, text: str, interval: float = 0.05, natural: bool = True):
        """Type text with optional natural typing simulation"""
        try:
            if natural:
                # Natural typing with random delays
                for char in text:
                    pyautogui.write(char, interval=interval + np.random.uniform(0, 0.05))
            else:
                pyautogui.write(text, interval=interval)
            
            logger.info(f"[OK] Typed text: {text[:50]}...")
            return True
        except Exception as e:
            logger.error(f"Type error: {e}")
            return False
    
    def press_key(self, key: str, presses: int = 1, interval: float = 0.0):
        """Press a key"""
        try:
            pyautogui.press(key, presses=presses, interval=interval)
            logger.info(f"[OK] Pressed key: {key}")
            return True
        except Exception as e:
            logger.error(f"Key press error: {e}")
            return False
    
    def hotkey(self, *keys):
        """Press hotkey combination"""
        try:
            pyautogui.hotkey(*keys)
            logger.info(f"[OK] Pressed hotkey: {'+'.join(keys)}")
            return True
        except Exception as e:
            logger.error(f"Hotkey error: {e}")
            return False
    
    def press_enter(self):
        """Press Enter key"""
        return self.press_key('enter')
    
    def press_escape(self):
        """Press Escape key"""
        return self.press_key('escape')
    
    def press_tab(self, times: int = 1):
        """Press Tab key"""
        return self.press_key('tab', presses=times)
    
    def copy_to_clipboard(self):
        """Copy selected text to clipboard"""
        return self.hotkey('ctrl', 'c')
    
    def paste_from_clipboard(self):
        """Paste from clipboard"""
        return self.hotkey('ctrl', 'v')
    
    def select_all(self):
        """Select all text"""
        return self.hotkey('ctrl', 'a')
    
    # ==================== SCREENSHOT & OCR ====================
    
    def screenshot(self, region: Optional[Tuple[int, int, int, int]] = None) -> Optional[Image.Image]:
        """Take screenshot of screen or region"""
        try:
            if region:
                screenshot = ImageGrab.grab(bbox=region)
            else:
                screenshot = ImageGrab.grab()
            
            logger.info("[OK] Screenshot captured")
            return screenshot
        except Exception as e:
            logger.error(f"Screenshot error: {e}")
            return None
    
    def save_screenshot(self, filename: str = None, region: Optional[Tuple] = None) -> Optional[str]:
        """Save screenshot to file"""
        try:
            if filename is None:
                from datetime import datetime
                filename = f"screenshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
            
            screenshot = self.screenshot(region)
            if screenshot:
                # Create screenshots directory
                os.makedirs('screenshots', exist_ok=True)
                filepath = os.path.join('screenshots', filename)
                screenshot.save(filepath)
                logger.info(f"[OK] Screenshot saved: {filepath}")
                return filepath
        except Exception as e:
            logger.error(f"Save screenshot error: {e}")
        return None
    
    def ocr_screen(self, region: Optional[Tuple] = None) -> str:
        """Extract text from screen using OCR"""
        if not self.ocr_available:
            return "OCR not available - install pytesseract"
        
        try:
            import pytesseract
            
            screenshot = self.screenshot(region)
            if screenshot:
                text = pytesseract.image_to_string(screenshot)
                logger.info(f"[OK] OCR extracted {len(text)} characters")
                return text.strip()
        except Exception as e:
            logger.error(f"OCR error: {e}")
        
        return ""
    
    def find_text_on_screen(self, text: str) -> Optional[Tuple[int, int]]:
        """Find text on screen and return coordinates"""
        if not self.ocr_available:
            return None
        
        try:
            import pytesseract
            
            screenshot = self.screenshot()
            if screenshot:
                # Get text with bounding boxes
                data = pytesseract.image_to_data(screenshot, output_type=pytesseract.Output.DICT)
                
                # Search for text
                for i, word in enumerate(data['text']):
                    if text.lower() in word.lower():
                        x = data['left'][i] + data['width'][i] // 2
                        y = data['top'][i] + data['height'][i] // 2
                        logger.info(f"[OK] Found '{text}' at ({x}, {y})")
                        return (x, y)
        except Exception as e:
            logger.error(f"Find text error: {e}")
        
        return None
    
    def click_text(self, text: str) -> bool:
        """Find and click text on screen"""
        coords = self.find_text_on_screen(text)
        if coords:
            return self.click(coords[0], coords[1])
        return False
    
    # ==================== WINDOW MANAGEMENT ====================
    
    def get_all_windows(self) -> List[Dict]:
        """Get all open windows"""
        windows = []
        
        def callback(hwnd, extra):
            if win32gui.IsWindowVisible(hwnd):
                title = win32gui.GetWindowText(hwnd)
                if title:
                    rect = win32gui.GetWindowRect(hwnd)
                    windows.append({
                        'hwnd': hwnd,
                        'title': title,
                        'x': rect[0],
                        'y': rect[1],
                        'width': rect[2] - rect[0],
                        'height': rect[3] - rect[1]
                    })
        
        try:
            win32gui.EnumWindows(callback, None)
            logger.info(f"[OK] Found {len(windows)} windows")
        except Exception as e:
            logger.error(f"Get windows error: {e}")
        
        return windows
    
    def find_window(self, title_contains: str) -> Optional[Dict]:
        """Find window by title"""
        windows = self.get_all_windows()
        for window in windows:
            if title_contains.lower() in window['title'].lower():
                return window
        return None
    
    def focus_window(self, title_contains: str) -> bool:
        """Focus window by title"""
        try:
            window = self.find_window(title_contains)
            if window:
                hwnd = window['hwnd']
                win32gui.SetForegroundWindow(hwnd)
                logger.info(f"[OK] Focused window: {window['title']}")
                return True
        except Exception as e:
            logger.error(f"Focus window error: {e}")
        return False
    
    def minimize_window(self, title_contains: str) -> bool:
        """Minimize window"""
        try:
            window = self.find_window(title_contains)
            if window:
                win32gui.ShowWindow(window['hwnd'], win32con.SW_MINIMIZE)
                logger.info(f"[OK] Minimized: {window['title']}")
                return True
        except Exception as e:
            logger.error(f"Minimize error: {e}")
        return False
    
    def maximize_window(self, title_contains: str) -> bool:
        """Maximize window"""
        try:
            window = self.find_window(title_contains)
            if window:
                win32gui.ShowWindow(window['hwnd'], win32con.SW_MAXIMIZE)
                logger.info(f"[OK] Maximized: {window['title']}")
                return True
        except Exception as e:
            logger.error(f"Maximize error: {e}")
        return False
    
    def close_window(self, title_contains: str) -> bool:
        """Close window"""
        try:
            window = self.find_window(title_contains)
            if window:
                win32gui.PostMessage(window['hwnd'], win32con.WM_CLOSE, 0, 0)
                logger.info(f"[OK] Closed: {window['title']}")
                return True
        except Exception as e:
            logger.error(f"Close window error: {e}")
        return False
    
    def get_active_window(self) -> Optional[Dict]:
        """Get currently active window"""
        try:
            hwnd = win32gui.GetForegroundWindow()
            title = win32gui.GetWindowText(hwnd)
            rect = win32gui.GetWindowRect(hwnd)
            
            return {
                'hwnd': hwnd,
                'title': title,
                'x': rect[0],
                'y': rect[1],
                'width': rect[2] - rect[0],
                'height': rect[3] - rect[1]
            }
        except Exception as e:
            logger.error(f"Get active window error: {e}")
        return None
    
    # ==================== APPLICATION CONTROL ====================
    
    def open_application(self, app_name: str) -> bool:
        """Open application by name"""
        try:
            # Common applications
            apps = {
                'notepad': 'notepad.exe',
                'calculator': 'calc.exe',
                'paint': 'mspaint.exe',
                'explorer': 'explorer.exe',
                'cmd': 'cmd.exe',
                'powershell': 'powershell.exe',
                'task manager': 'taskmgr.exe',
                'control panel': 'control.exe',
                'settings': 'ms-settings:',
                'chrome': 'chrome.exe',
                'edge': 'msedge.exe',
                'firefox': 'firefox.exe',
                'word': 'winword.exe',
                'excel': 'excel.exe',
                'powerpoint': 'powerpnt.exe',
                'outlook': 'outlook.exe'
            }
            
            app_lower = app_name.lower()
            
            if app_lower in apps:
                if apps[app_lower].startswith('ms-settings:'):
                    # Open Windows Settings
                    subprocess.Popen(['start', apps[app_lower]], shell=True)
                else:
                    subprocess.Popen(apps[app_lower])
                
                logger.info(f"[OK] Opened: {app_name}")
                time.sleep(1)  # Wait for app to open
                return True
            else:
                # Try to open as command
                subprocess.Popen(app_name, shell=True)
                logger.info(f"[OK] Attempted to open: {app_name}")
                return True
                
        except Exception as e:
            logger.error(f"Open application error: {e}")
            return False
    
    def close_application(self, app_name: str) -> bool:
        """Close application by name"""
        try:
            # Find and close window
            window = self.find_window(app_name)
            if window:
                return self.close_window(app_name)
            
            # Try to kill process
            for proc in psutil.process_iter(['name']):
                if app_name.lower() in proc.info['name'].lower():
                    proc.kill()
                    logger.info(f"[OK] Killed process: {proc.info['name']}")
                    return True
            
            logger.warning(f"Application not found: {app_name}")
            return False
            
        except Exception as e:
            logger.error(f"Close application error: {e}")
            return False
    
    # ==================== SYSTEM SETTINGS CONTROL ====================
    
    def set_volume(self, level: int) -> bool:
        """Set system volume (0-100)"""
        try:
            level = max(0, min(100, level))
            
            if platform.system() == "Windows":
                # Use nircmd if available, otherwise use PowerShell
                try:
                    # Try nircmd first (faster)
                    subprocess.run(['nircmd', 'setsysvolume', str(int(level * 655.35))], 
                                 check=True, capture_output=True)
                except:
                    # Fallback to PowerShell
                    ps_command = f"(New-Object -ComObject WScript.Shell).SendKeys([char]175)"
                    subprocess.run(['powershell', '-Command', ps_command], 
                                 capture_output=True)
                
                logger.info(f"[OK] Volume set to {level}%")
                return True
        except Exception as e:
            logger.error(f"Set volume error: {e}")
        return False
    
    def mute_volume(self) -> bool:
        """Mute system volume"""
        try:
            if platform.system() == "Windows":
                subprocess.run(['nircmd', 'mutesysvolume', '1'], 
                             capture_output=True)
                logger.info("[OK] Volume muted")
                return True
        except Exception as e:
            logger.error(f"Mute error: {e}")
        return False
    
    def unmute_volume(self) -> bool:
        """Unmute system volume"""
        try:
            if platform.system() == "Windows":
                subprocess.run(['nircmd', 'mutesysvolume', '0'], 
                             capture_output=True)
                logger.info("[OK] Volume unmuted")
                return True
        except Exception as e:
            logger.error(f"Unmute error: {e}")
        return False
    
    def set_brightness(self, level: int) -> bool:
        """Set screen brightness (0-100)"""
        try:
            level = max(0, min(100, level))
            
            if platform.system() == "Windows":
                # Use PowerShell to set brightness
                ps_command = f"(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,{level})"
                subprocess.run(['powershell', '-Command', ps_command], 
                             capture_output=True)
                logger.info(f"[OK] Brightness set to {level}%")
                return True
        except Exception as e:
            logger.error(f"Set brightness error: {e}")
        return False
    
    # ==================== ADVANCED AUTOMATION ====================
    
    def find_and_click_button(self, button_text: str) -> bool:
        """Find button by text and click it"""
        coords = self.find_text_on_screen(button_text)
        if coords:
            return self.click(coords[0], coords[1])
        return False
    
    def fill_form_field(self, field_name: str, value: str) -> bool:
        """Find form field and fill it"""
        try:
            # Find field by label
            coords = self.find_text_on_screen(field_name)
            if coords:
                # Click field (usually to the right of label)
                self.click(coords[0] + 100, coords[1])
                time.sleep(0.2)
                
                # Clear existing text
                self.hotkey('ctrl', 'a')
                time.sleep(0.1)
                
                # Type new value
                self.type_text(value)
                logger.info(f"[OK] Filled field '{field_name}' with '{value}'")
                return True
        except Exception as e:
            logger.error(f"Fill form error: {e}")
        return False
    
    def automate_clicks(self, coordinates: List[Tuple[int, int]], delay: float = 0.5):
        """Automate series of clicks"""
        try:
            for x, y in coordinates:
                self.click(x, y)
                time.sleep(delay)
            logger.info(f"[OK] Automated {len(coordinates)} clicks")
            return True
        except Exception as e:
            logger.error(f"Automate clicks error: {e}")
        return False
    
    # ==================== SYSTEM CONTROL ====================
    
    def lock_computer(self) -> bool:
        """Lock the computer"""
        try:
            if platform.system() == "Windows":
                subprocess.run(['rundll32.exe', 'user32.dll,LockWorkStation'])
                logger.info("[OK] Computer locked")
                return True
        except Exception as e:
            logger.error(f"Lock error: {e}")
        return False
    
    def shutdown_computer(self, delay: int = 60) -> bool:
        """Shutdown computer with delay"""
        try:
            if platform.system() == "Windows":
                subprocess.run(['shutdown', '/s', '/t', str(delay)])
                logger.info(f"[OK] Shutdown scheduled in {delay} seconds")
                return True
        except Exception as e:
            logger.error(f"Shutdown error: {e}")
        return False
    
    def restart_computer(self, delay: int = 60) -> bool:
        """Restart computer with delay"""
        try:
            if platform.system() == "Windows":
                subprocess.run(['shutdown', '/r', '/t', str(delay)])
                logger.info(f"[OK] Restart scheduled in {delay} seconds")
                return True
        except Exception as e:
            logger.error(f"Restart error: {e}")
        return False
    
    def cancel_shutdown(self) -> bool:
        """Cancel scheduled shutdown/restart"""
        try:
            if platform.system() == "Windows":
                subprocess.run(['shutdown', '/a'])
                logger.info("[OK] Shutdown cancelled")
                return True
        except Exception as e:
            logger.error(f"Cancel shutdown error: {e}")
        return False
    
    # ==================== BROWSER AUTOMATION ====================
    
    def open_url(self, url: str) -> bool:
        """Open URL in default browser"""
        try:
            import webbrowser
            webbrowser.open(url)
            logger.info(f"[OK] Opened URL: {url}")
            return True
        except Exception as e:
            logger.error(f"Open URL error: {e}")
        return False
    
    def google_search(self, query: str) -> bool:
        """Perform Google search"""
        url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
        return self.open_url(url)
    
    def youtube_search(self, query: str) -> bool:
        """Search YouTube"""
        url = f"https://www.youtube.com/results?search_query={query.replace(' ', '+')}"
        return self.open_url(url)
    
    # ==================== FILE OPERATIONS ====================
    
    def open_file(self, filepath: str) -> bool:
        """Open file with default application"""
        try:
            if platform.system() == "Windows":
                os.startfile(filepath)
            else:
                subprocess.run(['xdg-open', filepath])
            
            logger.info(f"[OK] Opened file: {filepath}")
            return True
        except Exception as e:
            logger.error(f"Open file error: {e}")
        return False
    
    def open_folder(self, folderpath: str) -> bool:
        """Open folder in file explorer"""
        try:
            if platform.system() == "Windows":
                subprocess.run(['explorer', folderpath])
            else:
                subprocess.run(['xdg-open', folderpath])
            
            logger.info(f"[OK] Opened folder: {folderpath}")
            return True
        except Exception as e:
            logger.error(f"Open folder error: {e}")
        return False
    
    # ==================== ADVANCED FEATURES ====================
    
    def get_screen_color(self, x: int, y: int) -> Tuple[int, int, int]:
        """Get color at screen position"""
        try:
            screenshot = self.screenshot()
            if screenshot:
                color = screenshot.getpixel((x, y))
                return color[:3]  # RGB
        except Exception as e:
            logger.error(f"Get color error: {e}")
        return (0, 0, 0)
    
    def wait_for_color(self, x: int, y: int, target_color: Tuple[int, int, int], 
                       timeout: float = 10.0, tolerance: int = 10) -> bool:
        """Wait for specific color at position"""
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            current_color = self.get_screen_color(x, y)
            
            # Check if colors match within tolerance
            if all(abs(c1 - c2) <= tolerance for c1, c2 in zip(current_color, target_color)):
                logger.info(f"[OK] Color matched at ({x}, {y})")
                return True
            
            time.sleep(0.1)
        
        logger.warning(f"Color wait timeout at ({x}, {y})")
        return False
    
    def record_macro(self, duration: float = 10.0) -> List[Dict]:
        """Record mouse and keyboard actions"""
        logger.info(f"[*] Recording macro for {duration} seconds...")
        
        actions = []
        start_time = time.time()
        last_pos = pyautogui.position()
        
        while time.time() - start_time < duration:
            current_pos = pyautogui.position()
            
            if current_pos != last_pos:
                actions.append({
                    'type': 'move',
                    'x': current_pos.x,
                    'y': current_pos.y,
                    'time': time.time() - start_time
                })
                last_pos = current_pos
            
            time.sleep(0.05)
        
        logger.info(f"[OK] Recorded {len(actions)} actions")
        return actions
    
    def replay_macro(self, actions: List[Dict]) -> bool:
        """Replay recorded macro"""
        try:
            start_time = time.time()
            
            for action in actions:
                # Wait until action time
                while time.time() - start_time < action['time']:
                    time.sleep(0.01)
                
                if action['type'] == 'move':
                    self.move_mouse(action['x'], action['y'], duration=0.1)
                elif action['type'] == 'click':
                    self.click(action['x'], action['y'])
                elif action['type'] == 'type':
                    self.type_text(action['text'])
            
            logger.info(f"[OK] Replayed {len(actions)} actions")
            return True
        except Exception as e:
            logger.error(f"Replay macro error: {e}")
        return False