"""
Computer Vision System for Screen Understanding
Advanced visual processing and analysis
Version: 3.0 HYPER
"""
import logging
import cv2
import numpy as np
from PIL import Image, ImageGrab
from typing import Dict, List, Tuple, Optional
import pytesseract
from datetime import datetime

logger = logging.getLogger('ComputerVision')


class ComputerVisionSystem:
    """
    Advanced Computer Vision System
    
    Features:
    - Screen capture and analysis
    - OCR (Optical Character Recognition)
    - Object detection
    - UI element detection
    - Color analysis
    - Text extraction
    - Image comparison
    - Visual search
    """
    
    def __init__(self):
        # OCR configuration
        self.tesseract_config = '--oem 3 --psm 6'
        
        # Detection thresholds
        self.text_confidence_threshold = 60
        
        # Cache
        self.last_screenshot = None
        self.last_screenshot_time = None
        
        logger.info("[VISION] Computer Vision System initialized")
    
    def capture_screen(self, region: Optional[Tuple[int, int, int, int]] = None) -> np.ndarray:
        """
        Capture screenshot
        
        Args:
            region: Optional (x, y, width, height) to capture specific region
        
        Returns:
            Screenshot as numpy array
        """
        try:
            if region:
                screenshot = ImageGrab.grab(bbox=region)
            else:
                screenshot = ImageGrab.grab()
            
            # Convert to numpy array
            screenshot_np = np.array(screenshot)
            
            # Cache screenshot
            self.last_screenshot = screenshot_np
            self.last_screenshot_time = datetime.now()
            
            logger.debug("[PHOTO] Screen captured")
            return screenshot_np
            
        except Exception as e:
            logger.error(f"Error capturing screen: {e}")
            return None
    
    def extract_text(self, image: np.ndarray = None, 
                    region: Optional[Tuple[int, int, int, int]] = None) -> str:
        """
        Extract text from image using OCR
        
        Args:
            image: Image to process (if None, captures screen)
            region: Optional region to extract from
        
        Returns:
            Extracted text
        """
        try:
            # Get image
            if image is None:
                image = self.capture_screen(region)
            
            if image is None:
                return ""
            
            # Convert to PIL Image
            pil_image = Image.fromarray(image)
            
            # Perform OCR
            text = pytesseract.image_to_string(pil_image, config=self.tesseract_config)
            
            logger.debug(f"[NOTE] Extracted {len(text)} characters")
            return text.strip()
            
        except Exception as e:
            logger.error(f"Error extracting text: {e}")
            return ""
    
    def find_text_on_screen(self, search_text: str) -> Optional[Tuple[int, int]]:
        """
        Find text on screen and return its position
        
        Args:
            search_text: Text to search for
        
        Returns:
            (x, y) coordinates if found, None otherwise
        """
        try:
            # Capture screen
            screenshot = self.capture_screen()
            if screenshot is None:
                return None
            
            # Convert to PIL Image
            pil_image = Image.fromarray(screenshot)
            
            # Get text with bounding boxes
            data = pytesseract.image_to_data(pil_image, output_type=pytesseract.Output.DICT)
            
            # Search for text
            search_lower = search_text.lower()
            for i, text in enumerate(data['text']):
                if text.lower() == search_lower:
                    x = data['left'][i] + data['width'][i] // 2
                    y = data['top'][i] + data['height'][i] // 2
                    logger.info(f"[OK] Found '{search_text}' at ({x}, {y})")
                    return (x, y)
            
            logger.warning(f"[ERROR] Text '{search_text}' not found on screen")
            return None
            
        except Exception as e:
            logger.error(f"Error finding text: {e}")
            return None
    
    def detect_ui_elements(self, image: np.ndarray = None) -> List[Dict]:
        """
        Detect UI elements (buttons, text fields, etc.)
        
        Args:
            image: Image to analyze (if None, captures screen)
        
        Returns:
            List of detected elements with positions
        """
        try:
            # Get image
            if image is None:
                image = self.capture_screen()
            
            if image is None:
                return []
            
            # Convert to grayscale
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # Detect edges
            edges = cv2.Canny(gray, 50, 150)
            
            # Find contours
            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            # Filter and classify contours
            elements = []
            for contour in contours:
                x, y, w, h = cv2.boundingRect(contour)
                
                # Filter by size (ignore very small or very large)
                if w < 20 or h < 20 or w > 500 or h > 500:
                    continue
                
                # Classify based on aspect ratio
                aspect_ratio = w / h
                
                element_type = 'unknown'
                if 0.8 < aspect_ratio < 1.2:
                    element_type = 'button'
                elif aspect_ratio > 3:
                    element_type = 'text_field'
                elif aspect_ratio < 0.5:
                    element_type = 'scrollbar'
                
                elements.append({
                    'type': element_type,
                    'x': x,
                    'y': y,
                    'width': w,
                    'height': h,
                    'center': (x + w // 2, y + h // 2)
                })
            
            logger.debug(f"[SEARCH] Detected {len(elements)} UI elements")
            return elements
            
        except Exception as e:
            logger.error(f"Error detecting UI elements: {e}")
            return []
    
    def analyze_colors(self, image: np.ndarray = None) -> Dict[str, Any]:
        """
        Analyze dominant colors in image
        
        Args:
            image: Image to analyze (if None, captures screen)
        
        Returns:
            Color analysis results
        """
        try:
            # Get image
            if image is None:
                image = self.capture_screen()
            
            if image is None:
                return {}
            
            # Reshape image to list of pixels
            pixels = image.reshape(-1, 3)
            
            # Calculate color statistics
            mean_color = np.mean(pixels, axis=0)
            std_color = np.std(pixels, axis=0)
            
            # Detect dominant color
            unique, counts = np.unique(pixels, axis=0, return_counts=True)
            dominant_idx = np.argmax(counts)
            dominant_color = unique[dominant_idx]
            
            # Calculate brightness
            brightness = np.mean(mean_color)
            
            return {
                'mean_color': mean_color.tolist(),
                'dominant_color': dominant_color.tolist(),
                'brightness': float(brightness),
                'is_dark': brightness < 128,
                'color_variance': std_color.tolist()
            }
            
        except Exception as e:
            logger.error(f"Error analyzing colors: {e}")
            return {}
    
    def find_image_on_screen(self, template_path: str, 
                            threshold: float = 0.8) -> Optional[Tuple[int, int]]:
        """
        Find template image on screen
        
        Args:
            template_path: Path to template image
            threshold: Match threshold (0-1)
        
        Returns:
            (x, y) coordinates if found
        """
        try:
            # Capture screen
            screenshot = self.capture_screen()
            if screenshot is None:
                return None
            
            # Load template
            template = cv2.imread(template_path)
            if template is None:
                logger.error(f"Could not load template: {template_path}")
                return None
            
            # Convert to grayscale
            screenshot_gray = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)
            template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
            
            # Template matching
            result = cv2.matchTemplate(screenshot_gray, template_gray, cv2.TM_CCOEFF_NORMED)
            
            # Find best match
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
            
            if max_val >= threshold:
                # Get center of template
                h, w = template_gray.shape
                center_x = max_loc[0] + w // 2
                center_y = max_loc[1] + h // 2
                
                logger.info(f"[OK] Found template at ({center_x}, {center_y}) with confidence {max_val:.2f}")
                return (center_x, center_y)
            
            logger.warning(f"[ERROR] Template not found (best match: {max_val:.2f})")
            return None
            
        except Exception as e:
            logger.error(f"Error finding image: {e}")
            return None
    
    def get_screen_info(self) -> Dict[str, Any]:
        """Get information about current screen"""
        try:
            screenshot = self.capture_screen()
            if screenshot is None:
                return {}
            
            height, width, channels = screenshot.shape
            
            # Extract text
            text = self.extract_text(screenshot)
            
            # Analyze colors
            colors = self.analyze_colors(screenshot)
            
            # Detect UI elements
            elements = self.detect_ui_elements(screenshot)
            
            return {
                'resolution': (width, height),
                'text_content': text[:500],  # First 500 chars
                'text_length': len(text),
                'color_analysis': colors,
                'ui_elements_count': len(elements),
                'ui_elements': elements[:10]  # First 10 elements
            }
            
        except Exception as e:
            logger.error(f"Error getting screen info: {e}")
            return {}
    
    def compare_images(self, image1: np.ndarray, image2: np.ndarray) -> float:
        """
        Compare two images and return similarity score
        
        Args:
            image1: First image
            image2: Second image
        
        Returns:
            Similarity score (0-1)
        """
        try:
            # Resize to same size
            h1, w1 = image1.shape[:2]
            h2, w2 = image2.shape[:2]
            
            if (h1, w1) != (h2, w2):
                image2 = cv2.resize(image2, (w1, h1))
            
            # Convert to grayscale
            gray1 = cv2.cvtColor(image1, cv2.COLOR_BGR2GRAY)
            gray2 = cv2.cvtColor(image2, cv2.COLOR_BGR2GRAY)
            
            # Calculate structural similarity
            diff = cv2.absdiff(gray1, gray2)
            similarity = 1.0 - (np.sum(diff) / (gray1.size * 255))
            
            return float(similarity)
            
        except Exception as e:
            logger.error(f"Error comparing images: {e}")
            return 0.0
    
    def save_screenshot(self, filename: str, region: Optional[Tuple[int, int, int, int]] = None):
        """
        Save screenshot to file
        
        Args:
            filename: Output filename
            region: Optional region to capture
        """
        try:
            screenshot = self.capture_screen(region)
            if screenshot is None:
                return False
            
            # Convert to PIL Image and save
            pil_image = Image.fromarray(screenshot)
            pil_image.save(filename)
            
            logger.info(f"[SAVE] Screenshot saved: {filename}")
            return True
            
        except Exception as e:
            logger.error(f"Error saving screenshot: {e}")
            return False
    
    def get_stats(self) -> Dict[str, Any]:
        """Get computer vision statistics"""
        return {
            'last_screenshot_time': self.last_screenshot_time.isoformat() if self.last_screenshot_time else None,
            'screenshot_cached': self.last_screenshot is not None
        }