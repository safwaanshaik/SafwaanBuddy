"""
Configuration Manager for SafwaanBuddy
Handles all configuration loading, saving, and management
"""
import json
import os
from pathlib import Path
from typing import Any, Dict, Optional
import logging

logger = logging.getLogger('SafwaanBuddy.Config')


class ConfigManager:
    """Manages application configuration"""
    
    def __init__(self, config_file: str = "config.json"):
        self.config_file = config_file
        self.config = self._load_config()
        self.env_vars = self._load_env()
        
    def _load_config(self) -> Dict:
        """Load configuration from JSON file"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                logger.info(f"[OK] Configuration loaded from {self.config_file}")
                return config
            except Exception as e:
                logger.error(f"Error loading config: {e}")
        
        # Return default configuration
        return self._get_default_config()
    
    def _get_default_config(self) -> Dict:
        """Get default configuration"""
        return {
            "version": "1.0.0",
            "app_name": "SafwaanBuddy",
            "voice_personalities": {
                "professional": "en-GB-RyanNeural",
                "friendly": "en-US-JennyNeural",
                "energetic": "en-US-GuyNeural",
                "calm": "en-US-AriaNeural"
            },
            "wake_words": ["safwaan", "buddy", "hey safwaan", "computer"],
            "features": {
                "enable_emotion_detection": False,
                "enable_learning": True,
                "enable_encryption": False,
                "enable_proactive": True,
                "enable_conversation_mode": True
            },
            "performance": {
                "max_concurrent_threads": 4,
                "cache_size": 100,
                "response_timeout": 30.0
            },
            "ui": {
                "hologram_size": 300,
                "animation_fps": 30,
                "show_on_startup": True
            }
        }
    
    def _load_env(self) -> Dict:
        """Load environment variables from .env file"""
        env_vars = {}
        env_file = ".env"
        
        if os.path.exists(env_file):
            try:
                with open(env_file, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith('#') and '=' in line:
                            key, value = line.split('=', 1)
                            env_vars[key.strip()] = value.strip()
                logger.info("[OK] Environment variables loaded")
            except Exception as e:
                logger.error(f"Error loading .env: {e}")
        else:
            logger.warning("[WARNING] .env file not found. Using defaults.")
        
        return env_vars
    
    def save_config(self):
        """Save configuration to file"""
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
            logger.info(f"[SAVE] Configuration saved to {self.config_file}")
        except Exception as e:
            logger.error(f"Error saving config: {e}")
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value using dot notation"""
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def set(self, key: str, value: Any):
        """Set configuration value using dot notation"""
        keys = key.split('.')
        config = self.config
        
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        config[keys[-1]] = value
        self.save_config()
    
    def get_env(self, key: str, default: str = "") -> str:
        """Get environment variable"""
        return self.env_vars.get(key, os.getenv(key, default))
    
    def get_api_key(self, service: str) -> Optional[str]:
        """Get API key for a service"""
        key_map = {
            'gemini': 'GEMINI_API_KEY',
            'openai': 'OPENAI_API_KEY'
        }
        
        key_name = key_map.get(service.lower())
        if key_name:
            return self.get_env(key_name)
        
        return None
    
    def get_wake_words(self) -> list:
        """Get wake words from config or env"""
        env_wake_words = self.get_env('WAKE_WORDS')
        if env_wake_words:
            return [w.strip() for w in env_wake_words.split(',')]
        
        return self.get('wake_words', ['safwaan', 'buddy'])
    
    def get_voice_settings(self) -> Dict:
        """Get voice settings"""
        return {
            'default_voice': self.get_env('DEFAULT_VOICE', 'en-US-JennyNeural'),
            'rate': self.get_env('SPEECH_RATE', '+0%'),
            'volume': self.get_env('SPEECH_VOLUME', '+0%'),
            'personalities': self.get('voice_personalities', {})
        }