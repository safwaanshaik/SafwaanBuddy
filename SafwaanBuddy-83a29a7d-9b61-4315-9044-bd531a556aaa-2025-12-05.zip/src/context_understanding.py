"""
Advanced Context Understanding for SafwaanBuddy ULTIMATE
Deep contextual analysis, semantic understanding, and situational awareness
"""
import logging
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime, timedelta
from collections import deque, defaultdict
import json
import re

logger = logging.getLogger('SafwaanBuddy.ContextUnderstanding')


class ContextUnderstandingEngine:
    """Advanced context understanding with semantic analysis"""
    
    def __init__(self, db_manager):
        self.db = db_manager
        
        # Context storage
        self.conversation_context = deque(maxlen=50)  # Recent conversation
        self.session_context = {}  # Current session
        self.user_context = {}  # User profile and preferences
        self.environmental_context = {}  # Environment state
        self.temporal_context = {}  # Time-based context
        
        # Semantic understanding
        self.intent_patterns = self._load_intent_patterns()
        self.entity_recognizer = EntityRecognizer()
        self.sentiment_analyzer = SentimentAnalyzer()
        
        # Context weights
        self.context_importance = {
            'immediate': 1.0,
            'recent': 0.7,
            'session': 0.5,
            'historical': 0.3
        }
        
        logger.info("[OK] Context understanding engine initialized")
    
    def _load_intent_patterns(self) -> Dict:
        """Load intent recognition patterns"""
        return {
            'question': [
                r'\b(what|when|where|who|why|how|which)\b',
                r'\?$'
            ],
            'command': [
                r'\b(open|close|start|stop|play|pause|create|delete)\b',
                r'\b(please|could you|can you)\b'
            ],
            'information': [
                r'\b(tell me|show me|find|search|look up)\b'
            ],
            'conversation': [
                r'\b(hello|hi|hey|thanks|thank you|bye|goodbye)\b'
            ],
            'clarification': [
                r'\b(what do you mean|explain|clarify|elaborate)\b'
            ]
        }
    
    def analyze_input(self, user_input: str, metadata: Dict = None) -> Dict:
        """
        Comprehensive input analysis with context
        
        Args:
            user_input: User's input text
            metadata: Additional metadata (time, location, etc.)
            
        Returns:
            Complete analysis with intent, entities, sentiment, context
        """
        try:
            analysis = {
                'input': user_input,
                'timestamp': datetime.now(),
                'intent': self._detect_intent(user_input),
                'entities': self.entity_recognizer.extract_entities(user_input),
                'sentiment': self.sentiment_analyzer.analyze(user_input),
                'context_references': self._find_context_references(user_input),
                'ambiguity_score': self._calculate_ambiguity(user_input),
                'urgency_level': self._detect_urgency(user_input),
                'formality_level': self._detect_formality(user_input)
            }
            
            # Add to conversation context
            self.conversation_context.append(analysis)
            
            # Update session context
            self._update_session_context(analysis)
            
            # Enrich with historical context
            analysis['enriched_context'] = self._enrich_with_context(analysis)
            
            logger.info(f"[OK] Input analyzed: intent={analysis['intent']}, sentiment={analysis['sentiment']}")
            
            return analysis
            
        except Exception as e:
            logger.error(f"[ERROR] Input analysis failed: {e}")
            return {'input': user_input, 'error': str(e)}
    
    def _detect_intent(self, text: str) -> str:
        """Detect user intent from text"""
        text_lower = text.lower()
        
        # Check each intent pattern
        for intent, patterns in self.intent_patterns.items():
            for pattern in patterns:
                if re.search(pattern, text_lower):
                    return intent
        
        return 'general'
    
    def _find_context_references(self, text: str) -> List[str]:
        """Find references to previous context"""
        references = []
        
        # Pronouns and references
        reference_patterns = [
            r'\b(it|that|this|these|those)\b',
            r'\b(he|she|they|them)\b',
            r'\b(earlier|before|previously|last time)\b',
            r'\b(the same|similar|like that)\b'
        ]
        
        for pattern in reference_patterns:
            if re.search(pattern, text.lower()):
                references.append(pattern)
        
        return references
    
    def _calculate_ambiguity(self, text: str) -> float:
        """Calculate ambiguity score (0-1)"""
        ambiguity_indicators = [
            r'\b(maybe|perhaps|possibly|might|could)\b',
            r'\b(something|someone|somewhere)\b',
            r'\b(kind of|sort of|like)\b',
            r'\?.*\?'  # Multiple questions
        ]
        
        score = 0.0
        for pattern in ambiguity_indicators:
            if re.search(pattern, text.lower()):
                score += 0.2
        
        return min(1.0, score)
    
    def _detect_urgency(self, text: str) -> str:
        """Detect urgency level"""
        urgent_patterns = [
            r'\b(urgent|emergency|asap|immediately|now|quick)\b',
            r'!{2,}',  # Multiple exclamation marks
            r'\b(hurry|fast|right now)\b'
        ]
        
        for pattern in urgent_patterns:
            if re.search(pattern, text.lower()):
                return 'high'
        
        return 'normal'
    
    def _detect_formality(self, text: str) -> str:
        """Detect formality level"""
        formal_patterns = [
            r'\b(please|kindly|would you|could you)\b',
            r'\b(sir|madam|mr|mrs|ms)\b'
        ]
        
        informal_patterns = [
            r'\b(hey|yo|sup|gonna|wanna)\b',
            r'\b(lol|omg|btw)\b'
        ]
        
        formal_count = sum(1 for p in formal_patterns if re.search(p, text.lower()))
        informal_count = sum(1 for p in informal_patterns if re.search(p, text.lower()))
        
        if formal_count > informal_count:
            return 'formal'
        elif informal_count > formal_count:
            return 'informal'
        return 'neutral'
    
    def _update_session_context(self, analysis: Dict):
        """Update current session context"""
        self.session_context['last_intent'] = analysis['intent']
        self.session_context['last_sentiment'] = analysis['sentiment']
        self.session_context['interaction_count'] = self.session_context.get('interaction_count', 0) + 1
        self.session_context['last_update'] = datetime.now()
    
    def _enrich_with_context(self, analysis: Dict) -> Dict:
        """Enrich analysis with historical and environmental context"""
        enriched = {
            'recent_topics': self._get_recent_topics(),
            'user_preferences': self._get_user_preferences(),
            'conversation_flow': self._analyze_conversation_flow(),
            'environmental_state': self._get_environmental_state(),
            'temporal_relevance': self._get_temporal_relevance()
        }
        
        return enriched
    
    def _get_recent_topics(self) -> List[str]:
        """Get recent conversation topics"""
        topics = []
        for context in list(self.conversation_context)[-10:]:
            entities = context.get('entities', {})
            topics.extend(entities.get('topics', []))
        return list(set(topics))[-5:]
    
    def _get_user_preferences(self) -> Dict:
        """Get user preferences from context"""
        return self.user_context.get('preferences', {})
    
    def _analyze_conversation_flow(self) -> Dict:
        """Analyze conversation flow and patterns"""
        if len(self.conversation_context) < 2:
            return {'flow': 'new'}
        
        recent = list(self.conversation_context)[-5:]
        intents = [c['intent'] for c in recent]
        
        return {
            'flow': 'continuous' if len(set(intents)) < 3 else 'varied',
            'dominant_intent': max(set(intents), key=intents.count),
            'turn_count': len(recent)
        }
    
    def _get_environmental_state(self) -> Dict:
        """Get current environmental context"""
        return {
            'time_of_day': self._get_time_of_day(),
            'day_of_week': datetime.now().strftime('%A'),
            'is_weekend': datetime.now().weekday() >= 5
        }
    
    def _get_time_of_day(self) -> str:
        """Get time of day category"""
        hour = datetime.now().hour
        if 5 <= hour < 12:
            return 'morning'
        elif 12 <= hour < 17:
            return 'afternoon'
        elif 17 <= hour < 21:
            return 'evening'
        else:
            return 'night'
    
    def _get_temporal_relevance(self) -> Dict:
        """Get temporal relevance information"""
        now = datetime.now()
        return {
            'current_time': now.strftime('%I:%M %p'),
            'current_date': now.strftime('%Y-%m-%d'),
            'season': self._get_season(now.month)
        }
    
    def _get_season(self, month: int) -> str:
        """Get current season"""
        if month in [12, 1, 2]:
            return 'winter'
        elif month in [3, 4, 5]:
            return 'spring'
        elif month in [6, 7, 8]:
            return 'summer'
        else:
            return 'fall'
    
    def resolve_ambiguity(self, analysis: Dict) -> Dict:
        """
        Resolve ambiguous references using context
        
        Args:
            analysis: Input analysis with ambiguity
            
        Returns:
            Resolved analysis with clarifications
        """
        if analysis.get('ambiguity_score', 0) < 0.3:
            return analysis
        
        resolved = analysis.copy()
        resolved['clarifications'] = []
        
        # Resolve pronoun references
        if analysis.get('context_references'):
            recent_entities = self._get_recent_entities()
            if recent_entities:
                resolved['clarifications'].append({
                    'type': 'pronoun_resolution',
                    'likely_referent': recent_entities[0]
                })
        
        # Resolve implicit context
        if analysis['intent'] == 'general':
            conversation_flow = self._analyze_conversation_flow()
            if conversation_flow.get('dominant_intent'):
                resolved['clarifications'].append({
                    'type': 'intent_inference',
                    'likely_intent': conversation_flow['dominant_intent']
                })
        
        return resolved
    
    def _get_recent_entities(self) -> List[str]:
        """Get recently mentioned entities"""
        entities = []
        for context in list(self.conversation_context)[-5:]:
            context_entities = context.get('entities', {})
            for entity_type, entity_list in context_entities.items():
                entities.extend(entity_list)
        return entities[-3:]
    
    def get_context_summary(self) -> Dict:
        """Get comprehensive context summary"""
        return {
            'session': {
                'duration': (datetime.now() - self.session_context.get('start_time', datetime.now())).seconds,
                'interactions': self.session_context.get('interaction_count', 0),
                'dominant_intent': self.session_context.get('last_intent')
            },
            'conversation': {
                'length': len(self.conversation_context),
                'recent_topics': self._get_recent_topics(),
                'flow': self._analyze_conversation_flow()
            },
            'environment': self._get_environmental_state(),
            'user': {
                'preferences': self._get_user_preferences(),
                'interaction_style': self.user_context.get('style', 'neutral')
            }
        }


class EntityRecognizer:
    """Entity recognition and extraction"""
    
    def __init__(self):
        self.entity_patterns = {
            'time': [
                r'\b(\d{1,2}:\d{2}\s*(?:am|pm)?)\b',
                r'\b(morning|afternoon|evening|night|today|tomorrow|yesterday)\b'
            ],
            'date': [
                r'\b(\d{1,2}/\d{1,2}/\d{2,4})\b',
                r'\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b'
            ],
            'number': [
                r'\b(\d+)\b'
            ],
            'email': [
                r'\b([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})\b'
            ],
            'url': [
                r'\b(https?://[^\s]+)\b'
            ],
            'file': [
                r'\b([a-zA-Z0-9_-]+\.[a-zA-Z]{2,4})\b'
            ]
        }
    
    def extract_entities(self, text: str) -> Dict[str, List[str]]:
        """Extract entities from text"""
        entities = {}
        
        for entity_type, patterns in self.entity_patterns.items():
            matches = []
            for pattern in patterns:
                found = re.findall(pattern, text, re.IGNORECASE)
                matches.extend(found)
            
            if matches:
                entities[entity_type] = list(set(matches))
        
        return entities


class SentimentAnalyzer:
    """Sentiment analysis"""
    
    def __init__(self):
        self.positive_words = [
            'good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic',
            'love', 'like', 'happy', 'pleased', 'satisfied', 'perfect'
        ]
        
        self.negative_words = [
            'bad', 'terrible', 'awful', 'horrible', 'hate', 'dislike',
            'angry', 'frustrated', 'disappointed', 'sad', 'upset', 'annoyed'
        ]
    
    def analyze(self, text: str) -> str:
        """Analyze sentiment of text"""
        text_lower = text.lower()
        
        positive_count = sum(1 for word in self.positive_words if word in text_lower)
        negative_count = sum(1 for word in self.negative_words if word in text_lower)
        
        if positive_count > negative_count:
            return 'positive'
        elif negative_count > positive_count:
            return 'negative'
        return 'neutral'