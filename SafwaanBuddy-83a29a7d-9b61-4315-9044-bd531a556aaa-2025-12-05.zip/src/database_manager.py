"""
Database Manager for SafwaanBuddy
Handles all database operations with SQLite
"""
import sqlite3
import logging
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any

logger = logging.getLogger('SafwaanBuddy.Database')


class DatabaseManager:
    """Manages SQLite database operations"""
    
    def __init__(self, db_path: str = "safwaan_data.db"):
        self.db_path = db_path
        self.connection = None
        self._initialize_database()
    
    def _initialize_database(self):
        """Initialize database connection and create tables"""
        try:
            self.connection = sqlite3.connect(self.db_path, check_same_thread=False)
            self.connection.row_factory = sqlite3.Row
            self._create_tables()
            logger.info(f"[OK] Database initialized: {self.db_path}")
        except Exception as e:
            logger.error(f"Database initialization error: {e}")
    
    def _create_tables(self):
        """Create database tables"""
        cursor = self.connection.cursor()
        
        # Conversations table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT,
                user_input TEXT,
                ai_response TEXT,
                emotion TEXT,
                tool_used TEXT,
                confidence REAL,
                response_time REAL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Memories table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT,
                category TEXT,
                importance REAL,
                access_count INTEGER DEFAULT 0,
                last_accessed TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # User preferences table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_preferences (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT UNIQUE,
                value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # System metrics table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS system_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                metric_type TEXT,
                metric_value REAL,
                metadata TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        self.connection.commit()
        logger.info("[OK] Database tables created")
    
    def store_conversation(self, session_id: str, user_input: str, 
                          ai_response: str, emotion: str = "neutral",
                          tool_used: str = "NONE", confidence: float = 0.0,
                          response_time: float = 0.0):
        """Store conversation in database"""
        try:
            cursor = self.connection.cursor()
            cursor.execute("""
                INSERT INTO conversations 
                (session_id, user_input, ai_response, emotion, tool_used, 
                 confidence, response_time)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (session_id, user_input, ai_response, emotion, tool_used,
                  confidence, response_time))
            
            self.connection.commit()
            logger.debug(f"Conversation stored: {user_input[:50]}...")
        except Exception as e:
            logger.error(f"Error storing conversation: {e}")
    
    def get_conversation_history(self, session_id: str, limit: int = 10) -> List[Dict]:
        """Get conversation history for a session"""
        try:
            cursor = self.connection.cursor()
            cursor.execute("""
                SELECT user_input, ai_response, emotion, tool_used, 
                       confidence, timestamp
                FROM conversations
                WHERE session_id = ?
                ORDER BY timestamp DESC
                LIMIT ?
            """, (session_id, limit))
            
            rows = cursor.fetchall()
            history = []
            
            for row in rows:
                history.append({
                    'user_input': row['user_input'],
                    'ai_response': row['ai_response'],
                    'emotion': row['emotion'],
                    'tool_used': row['tool_used'],
                    'confidence': row['confidence'],
                    'timestamp': row['timestamp']
                })
            
            return history
        except Exception as e:
            logger.error(f"Error getting conversation history: {e}")
            return []
    
    def store_memory(self, content: str, category: str = "general",
                    importance: float = 0.5):
        """Store a memory"""
        try:
            cursor = self.connection.cursor()
            cursor.execute("""
                INSERT INTO memories (content, category, importance)
                VALUES (?, ?, ?)
            """, (content, category, importance))
            
            self.connection.commit()
            logger.debug(f"Memory stored: {content[:50]}...")
        except Exception as e:
            logger.error(f"Error storing memory: {e}")
    
    def get_relevant_memories(self, query: str, limit: int = 5) -> List[Dict]:
        """Get relevant memories based on query"""
        try:
            cursor = self.connection.cursor()
            
            # Simple keyword-based search
            keywords = query.lower().split()
            
            cursor.execute("""
                SELECT content, category, importance, access_count
                FROM memories
                ORDER BY importance DESC, access_count DESC
                LIMIT ?
            """, (limit * 2,))
            
            rows = cursor.fetchall()
            memories = []
            
            for row in rows:
                content = row['content'].lower()
                score = sum(1 for keyword in keywords if keyword in content)
                
                if score > 0:
                    memories.append({
                        'content': row['content'],
                        'category': row['category'],
                        'importance': row['importance'],
                        'score': score
                    })
            
            # Sort by score and return top results
            memories.sort(key=lambda x: x['score'], reverse=True)
            return memories[:limit]
            
        except Exception as e:
            logger.error(f"Error getting memories: {e}")
            return []
    
    def update_memory_access(self, memory_id: int):
        """Update memory access count and timestamp"""
        try:
            cursor = self.connection.cursor()
            cursor.execute("""
                UPDATE memories
                SET access_count = access_count + 1,
                    last_accessed = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (memory_id,))
            
            self.connection.commit()
        except Exception as e:
            logger.error(f"Error updating memory access: {e}")
    
    def store_preference(self, key: str, value: Any):
        """Store user preference"""
        try:
            cursor = self.connection.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO user_preferences (key, value, updated_at)
                VALUES (?, ?, CURRENT_TIMESTAMP)
            """, (key, json.dumps(value)))
            
            self.connection.commit()
        except Exception as e:
            logger.error(f"Error storing preference: {e}")
    
    def get_preference(self, key: str, default: Any = None) -> Any:
        """Get user preference"""
        try:
            cursor = self.connection.cursor()
            cursor.execute("""
                SELECT value FROM user_preferences WHERE key = ?
            """, (key,))
            
            row = cursor.fetchone()
            if row:
                return json.loads(row['value'])
            
            return default
        except Exception as e:
            logger.error(f"Error getting preference: {e}")
            return default
    
    def store_metric(self, metric_type: str, metric_value: float, 
                    metadata: Dict = None):
        """Store system metric"""
        try:
            cursor = self.connection.cursor()
            cursor.execute("""
                INSERT INTO system_metrics (metric_type, metric_value, metadata)
                VALUES (?, ?, ?)
            """, (metric_type, metric_value, json.dumps(metadata or {})))
            
            self.connection.commit()
        except Exception as e:
            logger.error(f"Error storing metric: {e}")
    
    def get_metrics(self, metric_type: str, limit: int = 100) -> List[Dict]:
        """Get system metrics"""
        try:
            cursor = self.connection.cursor()
            cursor.execute("""
                SELECT metric_value, metadata, timestamp
                FROM system_metrics
                WHERE metric_type = ?
                ORDER BY timestamp DESC
                LIMIT ?
            """, (metric_type, limit))
            
            rows = cursor.fetchall()
            metrics = []
            
            for row in rows:
                metrics.append({
                    'value': row['metric_value'],
                    'metadata': json.loads(row['metadata']),
                    'timestamp': row['timestamp']
                })
            
            return metrics
        except Exception as e:
            logger.error(f"Error getting metrics: {e}")
            return []
    
    def get_statistics(self) -> Dict:
        """Get database statistics"""
        try:
            cursor = self.connection.cursor()
            
            stats = {}
            
            # Total conversations
            cursor.execute("SELECT COUNT(*) as count FROM conversations")
            stats['total_conversations'] = cursor.fetchone()['count']
            
            # Total memories
            cursor.execute("SELECT COUNT(*) as count FROM memories")
            stats['total_memories'] = cursor.fetchone()['count']
            
            # Most used tools
            cursor.execute("""
                SELECT tool_used, COUNT(*) as count
                FROM conversations
                WHERE tool_used != 'NONE'
                GROUP BY tool_used
                ORDER BY count DESC
                LIMIT 5
            """)
            stats['top_tools'] = [dict(row) for row in cursor.fetchall()]
            
            # Average response time
            cursor.execute("""
                SELECT AVG(response_time) as avg_time
                FROM conversations
                WHERE response_time > 0
            """)
            result = cursor.fetchone()
            stats['avg_response_time'] = result['avg_time'] if result['avg_time'] else 0
            
            return stats
        except Exception as e:
            logger.error(f"Error getting statistics: {e}")
            return {}
    
    def cleanup_old_data(self, days: int = 30):
        """Clean up old data from database"""
        try:
            cursor = self.connection.cursor()
            
            # Delete old conversations
            cursor.execute("""
                DELETE FROM conversations
                WHERE timestamp < datetime('now', '-' || ? || ' days')
            """, (days,))
            
            deleted_conversations = cursor.rowcount
            
            # Delete low-importance memories
            cursor.execute("""
                DELETE FROM memories
                WHERE importance < 0.3 
                AND created_at < datetime('now', '-' || ? || ' days')
            """, (days,))
            
            deleted_memories = cursor.rowcount
            
            self.connection.commit()
            
            logger.info(f"🧹 Cleaned up {deleted_conversations} conversations "
                       f"and {deleted_memories} memories")
            
        except Exception as e:
            logger.error(f"Error cleaning up data: {e}")
    
    def close(self):
        """Close database connection"""
        if self.connection:
            self.connection.close()
            logger.info("Database connection closed")