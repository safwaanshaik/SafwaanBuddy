"""
Emotional Intelligence Engine for SafwaanBuddy ULTIMATE
Advanced emotion detection, empathy, and emotional response generation
"""
import logging
import re
from typing import Dict, List, Optional, Tuple
from datetime import datetime
from collections import deque, defaultdict
import json

logger = logging.getLogger('SafwaanBuddy.EmotionalIntelligence')


class EmotionalIntelligenceEngine:
    """Advanced emotional intelligence with empathy and understanding"""
    
    def __init__(self):
        # Emotion detection
        self.emotion_detector = EmotionDetector()
        self.sentiment_analyzer = SentimentAnalyzer()
        self.empathy_engine = EmpathyEngine()
        
        # Emotional state tracking
        self.user_emotional_history = deque(maxlen=100)
        self.current_user_emotion = 'neutral'
        self.emotional_context = {}
        
        # Response generation
        self.response_modulator = EmotionalResponseModulator()
        
        logger.info("[OK] Emotional intelligence engine initialized")
    
    def analyze_emotion(self, text: str, voice_features: Optional[Dict] = None) -> Dict:
        """
        Analyze emotion from text and optional voice features
        
        Args:
            text: User's text input
            voice_features: Optional voice analysis data
            
        Returns:
            Emotion analysis with confidence
        """
        try:
            # Text-based emotion detection
            text_emotion = self.emotion_detector.detect_from_text(text)
            
            # Voice-based emotion detection (if available)
            voice_emotion = None
            if voice_features:
                voice_emotion = self.emotion_detector.detect_from_voice(voice_features)
            
            # Sentiment analysis
            sentiment = self.sentiment_analyzer.analyze(text)
            
            # Combine analyses
            combined_emotion = self._combine_emotion_analyses(
                text_emotion, 
                voice_emotion, 
                sentiment
            )
            
            # Update emotional history
            self.user_emotional_history.append({
                'timestamp': datetime.now(),
                'emotion': combined_emotion,
                'text': text
            })
            
            self.current_user_emotion = combined_emotion['primary_emotion']
            
            logger.info(f"[OK] Detected emotion: {combined_emotion['primary_emotion']} (confidence: {combined_emotion['confidence']})")
            
            return combined_emotion
            
        except Exception as e:
            logger.error(f"[ERROR] Emotion analysis failed: {e}")
            return {'primary_emotion': 'neutral', 'confidence': 0.5}
    
    def _combine_emotion_analyses(self, text_emotion: Dict, voice_emotion: Optional[Dict], sentiment: Dict) -> Dict:
        """Combine multiple emotion analyses"""
        # Weight different sources
        weights = {
            'text': 0.5,
            'voice': 0.3,
            'sentiment': 0.2
        }
        
        # Combine emotions
        emotion_scores = defaultdict(float)
        
        # Add text emotion
        for emotion, score in text_emotion.items():
            emotion_scores[emotion] += score * weights['text']
        
        # Add voice emotion if available
        if voice_emotion:
            for emotion, score in voice_emotion.items():
                emotion_scores[emotion] += score * weights['voice']
        
        # Add sentiment
        sentiment_emotion = self._sentiment_to_emotion(sentiment)
        for emotion, score in sentiment_emotion.items():
            emotion_scores[emotion] += score * weights['sentiment']
        
        # Get primary emotion
        primary_emotion = max(emotion_scores.items(), key=lambda x: x[1])
        
        return {
            'primary_emotion': primary_emotion[0],
            'confidence': primary_emotion[1],
            'all_emotions': dict(emotion_scores),
            'sentiment': sentiment
        }
    
    def _sentiment_to_emotion(self, sentiment: Dict) -> Dict:
        """Convert sentiment to emotion scores"""
        polarity = sentiment.get('polarity', 0)
        
        if polarity > 0.5:
            return {'happy': 0.8, 'excited': 0.6}
        elif polarity < -0.5:
            return {'sad': 0.7, 'angry': 0.5}
        else:
            return {'neutral': 0.8}
    
    def generate_empathetic_response(self, user_emotion: str, context: str) -> str:
        """
        Generate empathetic response based on user's emotion
        
        Args:
            user_emotion: Detected user emotion
            context: Conversation context
            
        Returns:
            Empathetic response text
        """
        return self.empathy_engine.generate_response(user_emotion, context)
    
    def modulate_response_emotion(self, response: str, target_emotion: str) -> str:
        """
        Modulate response to match target emotional tone
        
        Args:
            response: Original response text
            target_emotion: Desired emotional tone
            
        Returns:
            Emotionally modulated response
        """
        return self.response_modulator.modulate(response, target_emotion)
    
    def get_emotional_context(self) -> Dict:
        """Get current emotional context"""
        return {
            'current_emotion': self.current_user_emotion,
            'emotional_trend': self._analyze_emotional_trend(),
            'emotional_stability': self._calculate_emotional_stability()
        }
    
    def _analyze_emotional_trend(self) -> str:
        """Analyze emotional trend over time"""
        if len(self.user_emotional_history) < 5:
            return 'insufficient_data'
        
        recent_emotions = [e['emotion']['primary_emotion'] for e in list(self.user_emotional_history)[-5:]]
        
        # Check for improvement
        positive_emotions = ['happy', 'excited', 'content']
        negative_emotions = ['sad', 'angry', 'frustrated']
        
        positive_count = sum(1 for e in recent_emotions if e in positive_emotions)
        negative_count = sum(1 for e in recent_emotions if e in negative_emotions)
        
        if positive_count > negative_count:
            return 'improving'
        elif negative_count > positive_count:
            return 'declining'
        else:
            return 'stable'
    
    def _calculate_emotional_stability(self) -> float:
        """Calculate emotional stability score"""
        if len(self.user_emotional_history) < 3:
            return 0.5
        
        recent = list(self.user_emotional_history)[-10:]
        emotions = [e['emotion']['primary_emotion'] for e in recent]
        
        # Calculate variance
        unique_emotions = len(set(emotions))
        stability = 1.0 - (unique_emotions / len(emotions))
        
        return stability


class EmotionDetector:
    """Detects emotions from text and voice"""
    
    def __init__(self):
        # Emotion keywords
        self.emotion_keywords = {
            'happy': ['happy', 'joy', 'great', 'wonderful', 'excellent', 'love', 'amazing'],
            'sad': ['sad', 'unhappy', 'depressed', 'down', 'miserable', 'terrible'],
            'angry': ['angry', 'mad', 'furious', 'annoyed', 'frustrated', 'irritated'],
            'excited': ['excited', 'thrilled', 'enthusiastic', 'eager', 'pumped'],
            'anxious': ['anxious', 'worried', 'nervous', 'stressed', 'concerned'],
            'calm': ['calm', 'peaceful', 'relaxed', 'serene', 'tranquil'],
            'confused': ['confused', 'puzzled', 'uncertain', 'unclear', 'lost'],
            'surprised': ['surprised', 'shocked', 'amazed', 'astonished', 'wow']
        }
    
    def detect_from_text(self, text: str) -> Dict:
        """Detect emotion from text"""
        text_lower = text.lower()
        emotion_scores = defaultdict(float)
        
        # Check for emotion keywords
        for emotion, keywords in self.emotion_keywords.items():
            for keyword in keywords:
                if keyword in text_lower:
                    emotion_scores[emotion] += 1.0
        
        # Check for punctuation intensity
        if '!' in text:
            emotion_scores['excited'] += 0.3
        if '?' in text:
            emotion_scores['confused'] += 0.2
        
        # Normalize scores
        total = sum(emotion_scores.values())
        if total > 0:
            emotion_scores = {k: v/total for k, v in emotion_scores.items()}
        else:
            emotion_scores['neutral'] = 1.0
        
        return dict(emotion_scores)
    
    def detect_from_voice(self, voice_features: Dict) -> Dict:
        """Detect emotion from voice features"""
        # Analyze pitch, tempo, energy
        pitch = voice_features.get('pitch', 0)
        tempo = voice_features.get('tempo', 0)
        energy = voice_features.get('energy', 0)
        
        emotion_scores = {}
        
        # High pitch + fast tempo = excited
        if pitch > 0.7 and tempo > 0.7:
            emotion_scores['excited'] = 0.8
        
        # Low pitch + slow tempo = sad
        elif pitch < 0.3 and tempo < 0.3:
            emotion_scores['sad'] = 0.7
        
        # High energy = happy/angry
        elif energy > 0.7:
            emotion_scores['happy'] = 0.6
            emotion_scores['angry'] = 0.4
        
        else:
            emotion_scores['neutral'] = 0.8
        
        return emotion_scores


class SentimentAnalyzer:
    """Analyzes sentiment polarity and subjectivity"""
    
    def analyze(self, text: str) -> Dict:
        """Analyze sentiment"""
        # Simple sentiment analysis
        positive_words = ['good', 'great', 'excellent', 'wonderful', 'amazing', 'love', 'best']
        negative_words = ['bad', 'terrible', 'awful', 'worst', 'hate', 'horrible', 'poor']
        
        text_lower = text.lower()
        
        positive_count = sum(1 for word in positive_words if word in text_lower)
        negative_count = sum(1 for word in negative_words if word in text_lower)
        
        total = positive_count + negative_count
        if total == 0:
            polarity = 0.0
        else:
            polarity = (positive_count - negative_count) / total
        
        return {
            'polarity': polarity,
            'subjectivity': min(total / 10, 1.0),
            'positive_count': positive_count,
            'negative_count': negative_count
        }


class EmpathyEngine:
    """Generates empathetic responses"""
    
    def __init__(self):
        self.empathy_templates = {
            'happy': [
                "That's wonderful! I'm so happy for you!",
                "That's great to hear! Your happiness is contagious!",
                "I'm thrilled to hear that! Keep that positive energy going!"
            ],
            'sad': [
                "I'm sorry to hear that. I'm here if you need to talk.",
                "That sounds really difficult. How can I help?",
                "I understand this is tough. Take your time, I'm here for you."
            ],
            'angry': [
                "I can sense your frustration. Let's work through this together.",
                "I understand why you're upset. How can I help make this better?",
                "Your feelings are valid. Let's find a solution."
            ],
            'anxious': [
                "I understand you're feeling anxious. Let's take this one step at a time.",
                "It's okay to feel worried. I'm here to help you through this.",
                "Take a deep breath. We'll figure this out together."
            ],
            'excited': [
                "Your excitement is infectious! Tell me more!",
                "That's amazing! I love your enthusiasm!",
                "Wow! That sounds incredible!"
            ]
        }
    
    def generate_response(self, emotion: str, context: str) -> str:
        """Generate empathetic response"""
        templates = self.empathy_templates.get(emotion, self.empathy_templates['happy'])
        
        import random
        return random.choice(templates)


class EmotionalResponseModulator:
    """Modulates response emotional tone"""
    
    def modulate(self, response: str, target_emotion: str) -> str:
        """Modulate response to match emotion"""
        # Add emotional markers
        if target_emotion == 'happy':
            response = response + " [HAPPY]"
        elif target_emotion == 'excited':
            response = response + "!"
        elif target_emotion == 'calm':
            response = response.replace('!', '.')
        
        return response