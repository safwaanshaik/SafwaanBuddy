"""
Enhanced 3D Holographic UI
Advanced visual interface with animations
"""
import sys
import logging
from typing import Dict, List, Optional, Any, Tuple
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QSystemTrayIcon, QMenu
from PyQt6.QtCore import Qt, QTimer, QPoint, QPropertyAnimation, QEasingCurve, pyqtSignal
from PyQt6.QtGui import QPainter, QColor, QPen, QRadialGradient, QIcon, QPixmap, QPainterPath
import math
import random
import numpy as np
from PyQt6.QtWidgets import (QWidget, QApplication, QSystemTrayIcon, QMenu, 
                             QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                             QFrame, QGraphicsDropShadowEffect)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QPointF, QRect, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import (QPainter, QColor, QPalette, QRadialGradient, QIcon, 
                        QPixmap, QPen, QBrush, QLinearGradient, QFont)

logger = logging.getLogger('SafwaanBuddy.EnhancedUI')


class Enhanced3DHologram(QWidget):
    """Enhanced 3D holographic interface with depth effects"""
    
    update_signal = pyqtSignal(str)
    emotion_signal = pyqtSignal(str)
    audio_signal = pyqtSignal(list)  # For waveform data
    
    def __init__(self, config_manager):
        super().__init__()
        self.config = config_manager
        
        # State
        self.state = "IDLE"
        self.current_emotion = "neutral"
        self.audio_waveform = [0] * 50
        
        # 3D Animation properties
        self.rotation_x = 0
        self.rotation_y = 0
        self.rotation_z = 0
        self.depth_offset = 0
        self.scale_factor = 1.0
        
        # Glow and effects
        self.glow_alpha = 50
        self.glow_radius = 150
        self.pulse_phase = 0
        
        # Particles with 3D depth
        self.particles = []
        self._init_3d_particles()
        
        # Waveform visualization
        self.waveform_points = []
        self.waveform_phase = 0
        
        # Emotion face
        self.emotion_faces = {
            'happy': '[HAPPY]',
            'sad': '😢',
            'excited': '🤩',
            'calm': '😌',
            'angry': '😠',
            'confused': '😕',
            'neutral': '😐',
            'thinking': '🤔',
            'speaking': '[SPEAK]'
        }
        
        # Setup window
        self._setup_window()
        
        # Connect signals
        self.update_signal.connect(self.set_state)
        self.emotion_signal.connect(self.set_emotion)
        self.audio_signal.connect(self.update_waveform)
        
        # Animation timer
        self.animation_timer = QTimer(self)
        self.animation_timer.timeout.connect(self.animate)
        fps = self.config.get('ui.animation_fps', 30)
        self.animation_timer.start(1000 // fps)
        
        # System tray
        self.tray_icon = None
        self._setup_system_tray()
        
        logger.info("[OK] Enhanced 3D Hologram UI initialized")
    
    def _setup_window(self):
        """Setup enhanced window"""
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        # Larger size for enhanced UI
        size = self.config.get('ui.hologram_size', 400)
        self.resize(size, size)
        
        # Position
        screen = QApplication.primaryScreen().geometry()
        x = (screen.width() - self.width()) // 2
        y = 50
        self.move(x, y)
        
        self.setWindowTitle("SafwaanBuddy Enhanced")
    
    def _init_3d_particles(self):
        """Initialize 3D particle system"""
        for _ in range(30):
            self.particles.append({
                'x': random.uniform(0, 1),
                'y': random.uniform(0, 1),
                'z': random.uniform(0, 1),  # Depth
                'vx': random.uniform(-0.01, 0.01),
                'vy': random.uniform(-0.01, 0.01),
                'vz': random.uniform(-0.005, 0.005),
                'size': random.uniform(2, 6),
                'alpha': random.uniform(50, 200),
                'color_offset': random.uniform(0, 360)
            })
    
    def _setup_system_tray(self):
        """Setup enhanced system tray"""
        try:
            self.tray_icon = QSystemTrayIcon(self)
            
            # Create animated icon
            pixmap = QPixmap(64, 64)
            pixmap.fill(Qt.GlobalColor.transparent)
            painter = QPainter(pixmap)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            
            # Gradient circle
            gradient = QRadialGradient(32, 32, 28)
            gradient.setColorAt(0, QColor(0, 200, 255, 255))
            gradient.setColorAt(0.7, QColor(100, 150, 255, 200))
            gradient.setColorAt(1, QColor(0, 100, 200, 0))
            
            painter.setBrush(gradient)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(8, 8, 48, 48)
            painter.end()
            
            self.tray_icon.setIcon(QIcon(pixmap))
            self.tray_icon.setToolTip("SafwaanBuddy Enhanced")
            
            # Context menu
            menu = QMenu()
            
            show_action = menu.addAction("🔵 Show/Hide")
            show_action.triggered.connect(self.toggle_visibility)
            
            dashboard_action = menu.addAction("[BAR_CHART] Dashboard")
            dashboard_action.triggered.connect(self.show_dashboard)
            
            menu.addSeparator()
            
            settings_action = menu.addAction("[SETTINGS] Settings")
            settings_action.triggered.connect(self.show_settings)
            
            menu.addSeparator()
            
            quit_action = menu.addAction("[ERROR] Quit")
            quit_action.triggered.connect(QApplication.quit)
            
            self.tray_icon.setContextMenu(menu)
            self.tray_icon.activated.connect(self._on_tray_activated)
            self.tray_icon.show()
            
            logger.info("[OK] Enhanced system tray created")
        
        except Exception as e:
            logger.error(f"System tray error: {e}")
    
    def _on_tray_activated(self, reason):
        """Handle tray activation"""
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            self.toggle_visibility()
    
    def animate(self):
        """Enhanced 3D animation"""
        # State-based animations
        if self.state == "SPEAKING":
            self.rotation_z += 3
            self.glow_alpha = 150 + 50 * math.sin(self.pulse_phase * 5)
            self.scale_factor = 1.0 + 0.05 * math.sin(self.pulse_phase * 3)
            self.pulse_phase += 0.15
            
        elif self.state == "LISTENING":
            self.rotation_y += 2
            self.glow_alpha = 100 + 50 * math.sin(self.pulse_phase * 3)
            self.glow_radius = 150 + 20 * math.sin(self.pulse_phase * 2)
            self.pulse_phase += 0.1
            
        elif self.state == "THINKING":
            self.rotation_x += 2
            self.rotation_z += 3
            self.glow_alpha = 80 + 30 * math.sin(self.pulse_phase * 2)
            self.depth_offset = 10 * math.sin(self.pulse_phase)
            self.pulse_phase += 0.08
            
        else:  # IDLE
            self.rotation_z += 0.5
            self.glow_alpha = 50 + 20 * math.sin(self.pulse_phase)
            self.scale_factor = 1.0 + 0.02 * math.sin(self.pulse_phase * 0.5)
            self.pulse_phase += 0.03
        
        # Update 3D particles
        for particle in self.particles:
            particle['x'] += particle['vx']
            particle['y'] += particle['vy']
            particle['z'] += particle['vz']
            
            # Wrap around in 3D space
            for coord in ['x', 'y', 'z']:
                if particle[coord] < 0:
                    particle[coord] = 1
                elif particle[coord] > 1:
                    particle[coord] = 0
            
            # Rotate color
            particle['color_offset'] = (particle['color_offset'] + 1) % 360
        
        # Update waveform
        self.waveform_phase += 0.1
        
        self.update()
    
    def paintEvent(self, event):
        """Draw enhanced 3D hologram"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        w, h = self.width(), self.height()
        center = QPointF(w / 2, h / 2)
        
        # State colors with gradients
        state_colors = {
            "IDLE": (QColor(0, 200, 255), QColor(0, 150, 200)),
            "LISTENING": (QColor(0, 255, 100), QColor(0, 200, 80)),
            "THINKING": (QColor(150, 100, 255), QColor(100, 50, 200)),
            "SPEAKING": (QColor(255, 100, 150), QColor(200, 50, 100)),
            "PROCESSING": (QColor(255, 200, 0), QColor(200, 150, 0)),
            "ERROR": (QColor(255, 50, 50), QColor(200, 0, 0))
        }
        
        color1, color2 = state_colors.get(self.state, state_colors["IDLE"])
        
        # Adjust for emotion
        color1 = self._adjust_color_for_emotion(color1)
        color2 = self._adjust_color_for_emotion(color2)
        
        # Draw 3D glow layers with depth
        for i in range(7):
            radius = (w // 2 - i * 15) * self.scale_factor
            alpha = max(0, int(self.glow_alpha - i * 25))
            depth = i * 5 + self.depth_offset
            
            # Create 3D effect with offset
            offset_x = depth * math.sin(math.radians(self.rotation_y))
            offset_y = depth * math.sin(math.radians(self.rotation_x))
            
            gradient = QRadialGradient(
                center.x() + offset_x,
                center.y() + offset_y,
                radius
            )
            
            gradient.setColorAt(0, QColor(color1.red(), color1.green(), color1.blue(), alpha))
            gradient.setColorAt(0.5, QColor(color2.red(), color2.green(), color2.blue(), alpha // 2))
            gradient.setColorAt(1, QColor(0, 0, 0, 0))
            
            painter.setBrush(gradient)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(
                center.x() + offset_x - radius,
                center.y() + offset_y - radius,
                radius * 2,
                radius * 2
            )
        
        # Draw 3D particles with depth
        for particle in self.particles:
            # Calculate 3D position
            px = int(particle['x'] * w)
            py = int(particle['y'] * h)
            depth_scale = 0.5 + particle['z'] * 0.5  # Closer = bigger
            
            size = int(particle['size'] * depth_scale)
            alpha = int(particle['alpha'] * depth_scale)
            
            # Color based on depth and offset
            hue = (particle['color_offset'] + particle['z'] * 60) % 360
            color = QColor.fromHsv(int(hue), 200, 255, alpha)
            
            painter.setBrush(color)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(px - size//2, py - size//2, size, size)
        
        # Draw waveform if speaking
        if self.state == "SPEAKING" and self.audio_waveform:
            self._draw_waveform(painter, w, h, color1)
        
        # Draw central core with 3D effect
        core_radius = 40 * self.scale_factor
        core_gradient = QRadialGradient(center, core_radius)
        core_gradient.setColorAt(0, QColor(255, 255, 255, 200))
        core_gradient.setColorAt(0.5, QColor(color1.red(), color1.green(), color1.blue(), 150))
        core_gradient.setColorAt(1, QColor(0, 0, 0, 0))
        
        painter.setBrush(core_gradient)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(center, core_radius, core_radius)
        
        # Draw state text with shadow
        painter.setPen(QColor(255, 255, 255, 220))
        font = painter.font()
        font.setPointSize(14)
        font.setBold(True)
        painter.setFont(font)
        
        # Text shadow
        painter.setPen(QColor(0, 0, 0, 100))
        painter.drawText(self.rect().adjusted(2, 2, 2, 2), 
                        Qt.AlignmentFlag.AlignCenter, self.state)
        
        # Main text
        painter.setPen(QColor(255, 255, 255, 220))
        painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self.state)
        
        # Draw emotion face
        if self.current_emotion in self.emotion_faces:
            font.setPointSize(32)
            painter.setFont(font)
            face = self.emotion_faces[self.current_emotion]
            painter.drawText(
                QRect(0, h - 60, w, 50),
                Qt.AlignmentFlag.AlignCenter,
                face
            )
        
        # Draw emotion text
        font.setPointSize(10)
        painter.setFont(font)
        painter.setPen(QColor(255, 255, 255, 180))
        painter.drawText(
            QRect(10, h - 25, w - 20, 20),
            Qt.AlignmentFlag.AlignRight,
            self.current_emotion.capitalize()
        )
    
    def _draw_waveform(self, painter, w, h, color):
        """Draw audio waveform visualization"""
        if not self.audio_waveform:
            return
        
        painter.setPen(QPen(QColor(color.red(), color.green(), color.blue(), 150), 2))
        
        # Draw waveform
        points = []
        num_points = len(self.audio_waveform)
        
        for i, amplitude in enumerate(self.audio_waveform):
            x = int((i / num_points) * w)
            y = int(h / 2 + amplitude * 50)
            points.append(QPointF(x, y))
        
        # Draw lines connecting points
        for i in range(len(points) - 1):
            painter.drawLine(points[i], points[i + 1])
    
    def _init_3d_particles(self):
        """Initialize 3D particles"""
        for _ in range(30):
            self.particles.append({
                'x': random.uniform(0, 1),
                'y': random.uniform(0, 1),
                'z': random.uniform(0, 1),
                'vx': random.uniform(-0.01, 0.01),
                'vy': random.uniform(-0.01, 0.01),
                'vz': random.uniform(-0.005, 0.005),
                'size': random.uniform(3, 7),
                'alpha': random.uniform(100, 255),
                'color_offset': random.uniform(0, 360)
            })
    
    def _adjust_color_for_emotion(self, base_color: QColor) -> QColor:
        """Adjust color based on emotion"""
        r, g, b = base_color.red(), base_color.green(), base_color.blue()
        
        adjustments = {
            'happy': (50, 30, 0),
            'sad': (-30, -20, 50),
            'angry': (70, -30, -30),
            'excited': (30, 30, 30),
            'calm': (-20, -10, 30),
            'confused': (20, 20, 20)
        }
        
        if self.current_emotion in adjustments:
            dr, dg, db = adjustments[self.current_emotion]
            r = max(0, min(255, r + dr))
            g = max(0, min(255, g + dg))
            b = max(0, min(255, b + db))
        
        return QColor(r, g, b)
    
    def set_state(self, state: str):
        """Update state"""
        self.state = state.upper()
        logger.debug(f"State: {self.state}")
    
    def set_emotion(self, emotion: str):
        """Update emotion"""
        self.current_emotion = emotion.lower()
        logger.debug(f"Emotion: {self.current_emotion}")
    
    def update_waveform(self, waveform_data: List[float]):
        """Update waveform visualization"""
        self.audio_waveform = waveform_data[-50:]  # Keep last 50 samples
    
    def toggle_visibility(self):
        """Toggle window visibility"""
        if self.isVisible():
            self.hide()
        else:
            self.show()
            self.raise_()
            self.activateWindow()
    
    def show_dashboard(self):
        """Show statistics dashboard"""
        # This would open a separate dashboard window
        logger.info("Dashboard requested")
        self.voice.speak("Dashboard feature coming soon!", emotion='helpful')
    
    def show_settings(self):
        """Show settings window"""
        # This would open a settings window
        logger.info("Settings requested")
    
    def mousePressEvent(self, event):
        """Handle mouse press"""
        if event.button() == Qt.MouseButton.LeftButton:
            self.drag_position = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()
    
    def mouseMoveEvent(self, event):
        """Handle mouse move"""
        if event.buttons() == Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self.drag_position)
            event.accept()
    
    def closeEvent(self, event):
        """Handle close"""
        event.ignore()
        self.hide()
        if self.tray_icon:
            self.tray_icon.showMessage(
                "SafwaanBuddy Enhanced",
                "Minimized to system tray",
                QSystemTrayIcon.MessageIcon.Information,
                2000
            )


class StatisticsDashboard(QWidget):
    """Statistics and analytics dashboard"""
    
    def __init__(self, db_manager):
        super().__init__()
        self.db = db_manager
        
        self.setWindowTitle("SafwaanBuddy Dashboard")
        self.setGeometry(100, 100, 800, 600)
        
        self._setup_ui()
        self._load_statistics()
    
    def _setup_ui(self):
        """Setup dashboard UI"""
        layout = QVBoxLayout()
        
        # Title
        title = QLabel("[BAR_CHART] SafwaanBuddy Statistics")
        title.setStyleSheet("font-size: 24px; font-weight: bold; padding: 20px;")
        layout.addWidget(title)
        
        # Stats container
        stats_frame = QFrame()
        stats_frame.setStyleSheet("""
            QFrame {
                background-color: rgba(30, 30, 40, 200);
                border-radius: 10px;
                padding: 20px;
            }
        """)
        
        stats_layout = QVBoxLayout()
        
        # Add stat labels
        self.stat_labels = {}
        stat_names = [
            'Total Conversations',
            'Total Memories',
            'Average Response Time',
            'Most Used Tool',
            'Success Rate'
        ]
        
        for stat_name in stat_names:
            label = QLabel(f"{stat_name}: Loading...")
            label.setStyleSheet("font-size: 14px; padding: 5px;")
            stats_layout.addWidget(label)
            self.stat_labels[stat_name] = label
        
        stats_frame.setLayout(stats_layout)
        layout.addWidget(stats_frame)
        
        # Refresh button
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.clicked.connect(self._load_statistics)
        layout.addWidget(refresh_btn)
        
        self.setLayout(layout)
    
    def _load_statistics(self):
        """Load and display statistics"""
        try:
            stats = self.db.get_statistics()
            
            self.stat_labels['Total Conversations'].setText(
                f"Total Conversations: {stats.get('total_conversations', 0)}"
            )
            self.stat_labels['Total Memories'].setText(
                f"Total Memories: {stats.get('total_memories', 0)}"
            )
            self.stat_labels['Average Response Time'].setText(
                f"Average Response Time: {stats.get('avg_response_time', 0):.2f}s"
            )
            
            top_tools = stats.get('top_tools', [])
            if top_tools:
                top_tool = top_tools[0]
                self.stat_labels['Most Used Tool'].setText(
                    f"Most Used Tool: {top_tool.get('tool_used', 'N/A')} "
                    f"({top_tool.get('count', 0)} times)"
                )
            
            # Calculate success rate
            total = stats.get('total_conversations', 0)
            if total > 0:
                success_rate = (total / (total + 1)) * 100  # Simplified
                self.stat_labels['Success Rate'].setText(
                    f"Success Rate: {success_rate:.1f}%"
                )
        
        except Exception as e:
            logger.error(f"Statistics load error: {e}")