"""
Multi-Model Ensemble AI System for SafwaanBuddy ULTIMATE
Combines Gemini Pro, Flash, and Vision models for superior intelligence
"""
import google.generativeai as genai
import logging
import asyncio
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime
from collections import deque
import json

logger = logging.getLogger('SafwaanBuddy.EnsembleAI')


class EnsembleAISystem:
    """Advanced multi-model ensemble AI system"""
    
    def __init__(self, config_manager):
        self.config = config_manager
        
        # Initialize multiple models
        self.models = {}
        self.model_weights = {}
        self.model_performance = {}
        
        self._initialize_models()
        
        # Response history
        self.response_history = deque(maxlen=1000)
        
        # Model selection strategy
        self.selection_strategy = 'weighted_ensemble'
        
        logger.info("[OK] Ensemble AI system initialized with multiple models")
    
    def _initialize_models(self):
        """Initialize all AI models"""
        try:
            api_key = self.config.get_api_key('GEMINI_API_KEY')
            if not api_key:
                logger.error("[ERROR] No Gemini API key found")
                return
            
            genai.configure(api_key=api_key)
            
            # Initialize Gemini Pro (main reasoning)
            try:
                self.models['gemini_pro'] = genai.GenerativeModel('gemini-pro')
                self.model_weights['gemini_pro'] = 0.4
                self.model_performance['gemini_pro'] = {'success': 0, 'total': 0}
                logger.info("[OK] Gemini Pro initialized")
            except Exception as e:
                logger.error(f"[ERROR] Gemini Pro init failed: {e}")
            
            # Initialize Gemini Flash (fast responses)
            try:
                self.models['gemini_flash'] = genai.GenerativeModel('gemini-1.5-flash')
                self.model_weights['gemini_flash'] = 0.3
                self.model_performance['gemini_flash'] = {'success': 0, 'total': 0}
                logger.info("[OK] Gemini Flash initialized")
            except Exception as e:
                logger.error(f"[ERROR] Gemini Flash init failed: {e}")
            
            # Initialize Gemini Pro Vision (visual understanding)
            try:
                self.models['gemini_vision'] = genai.GenerativeModel('gemini-pro-vision')
                self.model_weights['gemini_vision'] = 0.3
                self.model_performance['gemini_vision'] = {'success': 0, 'total': 0}
                logger.info("[OK] Gemini Vision initialized")
            except Exception as e:
                logger.error(f"[ERROR] Gemini Vision init failed: {e}")
            
        except Exception as e:
            logger.error(f"[ERROR] Model initialization failed: {e}")
    
    def generate_response(self, prompt: str, context: Dict = None, mode: str = 'auto') -> Dict:
        """
        Generate response using ensemble of models
        
        Args:
            prompt: Input prompt
            context: Additional context
            mode: Response mode (auto, fast, deep, visual)
            
        Returns:
            Dict with response and metadata
        """
        try:
            # Select models based on mode
            selected_models = self._select_models(mode, context)
            
            # Generate responses from multiple models
            responses = {}
            for model_name in selected_models:
                try:
                    response = self._generate_single_response(model_name, prompt, context)
                    responses[model_name] = response
                    self._update_performance(model_name, True)
                except Exception as e:
                    logger.error(f"[ERROR] {model_name} failed: {e}")
                    self._update_performance(model_name, False)
            
            # Ensemble responses
            final_response = self._ensemble_responses(responses, mode)
            
            # Store in history
            self.response_history.append({
                'prompt': prompt,
                'responses': responses,
                'final': final_response,
                'timestamp': datetime.now(),
                'mode': mode
            })
            
            return final_response
            
        except Exception as e:
            logger.error(f"[ERROR] Ensemble generation failed: {e}")
            return {
                'text': "I apologize, but I encountered an error processing your request.",
                'confidence': 0.0,
                'error': str(e)
            }
    
    def _select_models(self, mode: str, context: Dict = None) -> List[str]:
        """Select appropriate models based on mode"""
        if mode == 'fast':
            return ['gemini_flash']
        elif mode == 'deep':
            return ['gemini_pro', 'gemini_flash']
        elif mode == 'visual':
            return ['gemini_vision', 'gemini_pro']
        else:  # auto
            # Intelligent model selection based on context
            models = ['gemini_pro']
            
            # Add Flash for speed
            if context and context.get('priority') == 'speed':
                models.append('gemini_flash')
            
            # Add Vision if visual context
            if context and context.get('has_visual'):
                models.append('gemini_vision')
            
            return models
    
    def _generate_single_response(self, model_name: str, prompt: str, context: Dict = None) -> Dict:
        """Generate response from single model"""
        model = self.models.get(model_name)
        if not model:
            raise ValueError(f"Model {model_name} not available")
        
        # Build enhanced prompt
        enhanced_prompt = self._build_enhanced_prompt(prompt, context, model_name)
        
        # Generate response
        response = model.generate_content(enhanced_prompt)
        
        return {
            'text': response.text,
            'model': model_name,
            'timestamp': datetime.now(),
            'confidence': self._estimate_confidence(response.text)
        }
    
    def _build_enhanced_prompt(self, prompt: str, context: Dict = None, model_name: str = None) -> str:
        """Build enhanced prompt with context"""
        enhanced = prompt
        
        if context:
            # Add conversation history
            if context.get('history'):
                history_text = "\n".join([f"User: {h['user']}\nAssistant: {h['assistant']}" 
                                         for h in context['history'][-3:]])
                enhanced = f"Previous conversation:\n{history_text}\n\nCurrent: {prompt}"
            
            # Add user preferences
            if context.get('preferences'):
                prefs = context['preferences']
                enhanced += f"\n\nUser preferences: {json.dumps(prefs)}"
            
            # Add time context
            if context.get('time'):
                enhanced += f"\n\nCurrent time: {context['time']}"
        
        # Model-specific enhancements
        if model_name == 'gemini_pro':
            enhanced = f"Provide a detailed, thoughtful response:\n{enhanced}"
        elif model_name == 'gemini_flash':
            enhanced = f"Provide a quick, concise response:\n{enhanced}"
        elif model_name == 'gemini_vision':
            enhanced = f"Analyze visual elements and provide insights:\n{enhanced}"
        
        return enhanced
    
    def _ensemble_responses(self, responses: Dict, mode: str) -> Dict:
        """Combine responses from multiple models"""
        if not responses:
            return {
                'text': "No response generated",
                'confidence': 0.0
            }
        
        if len(responses) == 1:
            # Single model response
            return list(responses.values())[0]
        
        # Multiple models - ensemble strategy
        if self.selection_strategy == 'weighted_ensemble':
            return self._weighted_ensemble(responses)
        elif self.selection_strategy == 'voting':
            return self._voting_ensemble(responses)
        elif self.selection_strategy == 'best_confidence':
            return self._best_confidence_ensemble(responses)
        else:
            return self._weighted_ensemble(responses)
    
    def _weighted_ensemble(self, responses: Dict) -> Dict:
        """Weighted ensemble based on model performance"""
        # Calculate weighted scores
        weighted_responses = []
        for model_name, response in responses.items():
            weight = self.model_weights.get(model_name, 0.33)
            performance = self._get_model_performance_score(model_name)
            final_weight = weight * performance
            
            weighted_responses.append({
                'response': response,
                'weight': final_weight
            })
        
        # Select best weighted response
        best = max(weighted_responses, key=lambda x: x['weight'])
        
        # Enhance with insights from other models
        final_text = best['response']['text']
        
        # Add alternative perspectives if significantly different
        alternatives = []
        for wr in weighted_responses:
            if wr != best and self._is_significantly_different(wr['response']['text'], final_text):
                alternatives.append(wr['response']['text'][:100])
        
        return {
            'text': final_text,
            'confidence': best['weight'],
            'model': best['response']['model'],
            'alternatives': alternatives,
            'ensemble_method': 'weighted'
        }
    
    def _voting_ensemble(self, responses: Dict) -> Dict:
        """Voting ensemble - majority wins"""
        # Simple voting based on response similarity
        response_texts = [r['text'] for r in responses.values()]
        
        # Find most common response pattern
        # (simplified - in production would use semantic similarity)
        from collections import Counter
        vote_counts = Counter(response_texts)
        winner_text = vote_counts.most_common(1)[0][0]
        
        # Find the response object
        winner = None
        for response in responses.values():
            if response['text'] == winner_text:
                winner = response
                break
        
        return {
            'text': winner_text,
            'confidence': vote_counts[winner_text] / len(responses),
            'model': winner['model'] if winner else 'ensemble',
            'votes': vote_counts[winner_text],
            'ensemble_method': 'voting'
        }
    
    def _best_confidence_ensemble(self, responses: Dict) -> Dict:
        """Select response with highest confidence"""
        best = max(responses.values(), key=lambda x: x.get('confidence', 0))
        
        return {
            'text': best['text'],
            'confidence': best['confidence'],
            'model': best['model'],
            'ensemble_method': 'best_confidence'
        }
    
    def _estimate_confidence(self, text: str) -> float:
        """Estimate confidence of response"""
        # Simple heuristics
        confidence = 0.5
        
        # Longer responses tend to be more confident
        if len(text) > 100:
            confidence += 0.1
        
        # Presence of uncertainty markers
        uncertainty_words = ['maybe', 'perhaps', 'might', 'possibly', 'unsure']
        if any(word in text.lower() for word in uncertainty_words):
            confidence -= 0.2
        
        # Presence of confidence markers
        confidence_words = ['definitely', 'certainly', 'clearly', 'obviously']
        if any(word in text.lower() for word in confidence_words):
            confidence += 0.2
        
        return max(0.0, min(1.0, confidence))
    
    def _update_performance(self, model_name: str, success: bool):
        """Update model performance metrics"""
        if model_name in self.model_performance:
            self.model_performance[model_name]['total'] += 1
            if success:
                self.model_performance[model_name]['success'] += 1
    
    def _get_model_performance_score(self, model_name: str) -> float:
        """Get model performance score"""
        perf = self.model_performance.get(model_name, {'success': 0, 'total': 1})
        if perf['total'] == 0:
            return 0.5
        return perf['success'] / perf['total']
    
    def _is_significantly_different(self, text1: str, text2: str) -> bool:
        """Check if two responses are significantly different"""
        # Simple word overlap check
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        overlap = len(words1 & words2) / max(len(words1), len(words2))
        return overlap < 0.5
    
    def get_model_stats(self) -> Dict:
        """Get statistics for all models"""
        stats = {}
        for model_name in self.models.keys():
            perf = self.model_performance.get(model_name, {'success': 0, 'total': 0})
            stats[model_name] = {
                'weight': self.model_weights.get(model_name, 0),
                'success_rate': self._get_model_performance_score(model_name),
                'total_calls': perf['total']
            }
        return stats
    
    def set_selection_strategy(self, strategy: str):
        """Set ensemble selection strategy"""
        valid_strategies = ['weighted_ensemble', 'voting', 'best_confidence']
        if strategy in valid_strategies:
            self.selection_strategy = strategy
            logger.info(f"[OK] Selection strategy set to: {strategy}")
        else:
            logger.warning(f"[WARN] Invalid strategy: {strategy}")