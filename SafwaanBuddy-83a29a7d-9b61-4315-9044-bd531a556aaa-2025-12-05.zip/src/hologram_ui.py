"""
Holographic UI for SafwaanBuddy
Advanced PyQt6 interface with animations and visual effects
"""
import sys
import math
import random
from PyQt6.QtWidgets import QWidget, QApplication, QSystemTrayIcon, QMenu
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QPointF, QRect
from PyQt6.QtGui import QPainter, QColor, QPalette, QRadialGradient, QIcon, QPixmap
import logging

logger = logging.getLogger('SafwaanBuddy.Hologram')


class HologramUI(QWidget):
    """Advanced holographic interface with animations"""
    
    # Signals
    update_signal = pyqtSignal(str)
    emotion_signal = pyqtSignal(str)
    
    def __init__(self, config_manager):
        super().__init__()
        self.config = config_manager
        
        # State
        self.state = "IDLE"
        self.current_emotion = "neutral"
        
        # Animation properties
        self.glow_alpha = 50
        self.glow_direction = 1
        self.rotation_angle = 0
        self.pulse_phase = 0
        self.particles = []
        
        # Initialize particles
        self._init_particles()
        
        # Setup window
        self._setup_window()
        
        # Connect signals
        self.update_signal.connect(self.set_state)
        self.emotion_signal.connect(self.set_emotion)
        
        # Animation timer
        self.animation_timer = QTimer(self)
        self.animation_timer.timeout.connect(self.animate)
        fps = self.config.get('ui.animation_fps', 30)
        self.animation_timer.start(1000 // fps)
        
        # System tray
        self.tray_icon = None
        self._setup_system_tray()
        
        logger.info("[OK] Hologram UI initialized")
    
    def _setup_window(self):
        """Setup window properties"""
        # Window flags for frameless, always on top
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        # Size
        size = self.config.get('ui.hologram_size', 300)
        self.resize(size, size)
        
        # Position at top center of screen
        screen = QApplication.primaryScreen().geometry()
        x = (screen.width() - self.width()) // 2
        y = 50
        self.move(x, y)
        
        # Set window title
        self.setWindowTitle("SafwaanBuddy")
    
    def _init_particles(self):
        """Initialize particle system"""
        for _ in range(20):
            self.particles.append({
                'x': random.uniform(0, 1),
                'y': random.uniform(0, 1),
                'vx': random.uniform(-0.01, 0.01),
                'vy': random.uniform(-0.01, 0.01),
                'size': random.uniform(2, 5),
                'alpha': random.uniform(50, 200)
            })
    
    def _setup_system_tray(self):
        """Setup system tray icon"""
        try:
            # Create tray icon
            self.tray_icon = QSystemTrayIcon(self)
            
            # Create icon (simple colored circle)
            pixmap = QPixmap(64, 64)
            pixmap.fill(Qt.GlobalColor.transparent)
            painter = QPainter(pixmap)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            painter.setBrush(QColor(0, 200, 255))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(8, 8, 48, 48)
            painter.end()
            
            self.tray_icon.setIcon(QIcon(pixmap))
            self.tray_icon.setToolTip("SafwaanBuddy")
            
            # Create context menu
            menu = QMenu()
            
            show_action = menu.addAction("Show/Hide")
            show_action.triggered.connect(self.toggle_visibility)
            
            menu.addSeparator()
            
            quit_action = menu.addAction("Quit")
            quit_action.triggered.connect(QApplication.quit)
            
            self.tray_icon.setContextMenu(menu)
            self.tray_icon.activated.connect(self._on_tray_activated)
            
            # Show tray icon
            self.tray_icon.show()
            
            logger.info("[OK] System tray icon created")
            
        except Exception as e:
            logger.error(f"System tray setup error: {e}")
    
    def _on_tray_activated(self, reason):
        """Handle tray icon activation"""
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            self.toggle_visibility()
    
    def toggle_visibility(self):
        """Toggle window visibility"""
        if self.isVisible():
            self.hide()
        else:
            self.show()
            self.raise_()
            self.activateWindow()
    
    def animate(self):
        """Update animation"""
        # State-based animations
        if self.state == "SPEAKING":
            # Speaking - rhythmic glow
            self.glow_alpha = 150 + 50 * math.sin(self.pulse_phase * 5)
            self.rotation_angle += 2
            self.pulse_phase += 0.1
            
        elif self.state == "LISTENING":
            # Listening - scanning effect
            self.glow_alpha = 100 + 50 * math.sin(self.pulse_phase * 3)
            self.pulse_phase += 0.1
            
        elif self.state == "THINKING":
            # Thinking - spinning
            self.rotation_angle += 3
            self.glow_alpha = 80 + 20 * math.sin(self.pulse_phase * 2)
            self.pulse_phase += 0.05
            
        else:  # IDLE
            # Idle - gentle pulse
            self.glow_alpha = 50 + 20 * math.sin(self.pulse_phase)
            self.rotation_angle += 0.5
            self.pulse_phase += 0.02
        
        # Update particles
        for particle in self.particles:
            particle['x'] += particle['vx']
            particle['y'] += particle['vy']
            
            # Wrap around
            if particle['x'] < 0:
                particle['x'] = 1
            elif particle['x'] > 1:
                particle['x'] = 0
            
            if particle['y'] < 0:
                particle['y'] = 1
            elif particle['y'] > 1:
                particle['y'] = 0
        
        # Trigger repaint
        self.update()
    
    def paintEvent(self, event):
        """Draw hologram"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        w, h = self.width(), self.height()
        center = QPointF(w / 2, h / 2)
        
        # State colors
        state_colors = {
            "IDLE": QColor(0, 200, 255),
            "LISTENING": QColor(0, 255, 100),
            "THINKING": QColor(100, 100, 255),
            "SPEAKING": QColor(255, 100, 150),
            "PROCESSING": QColor(255, 200, 0),
            "ERROR": QColor(255, 50, 50)
        }
        
        base_color = state_colors.get(self.state, state_colors["IDLE"])
        
        # Adjust color for emotion
        color = self._adjust_color_for_emotion(base_color)
        
        # Draw glow layers
        for i in range(5):
            radius = w // 2 - i * 10
            alpha = max(0, int(self.glow_alpha - i * 30))
            
            gradient = QRadialGradient(center, radius)
            gradient.setColorAt(0, QColor(color.red(), color.green(), color.blue(), alpha))
            gradient.setColorAt(0.7, QColor(color.red(), color.green(), color.blue(), alpha // 3))
            gradient.setColorAt(1, QColor(0, 0, 0, 0))
            
            painter.setBrush(gradient)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(center, radius, radius)
        
        # Draw particles
        for particle in self.particles:
            px = int(particle['x'] * w)
            py = int(particle['y'] * h)
            
            painter.setPen(QColor(
                color.red(), color.green(), color.blue(),
                int(particle['alpha'])
            ))
            painter.drawPoint(px, py)
        
        # Draw state text
        painter.setPen(QColor(255, 255, 255, 200))
        font = painter.font()
        font.setPointSize(12)
        font.setBold(True)
        painter.setFont(font)
        painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self.state)
        
        # Draw emotion indicator
        if self.current_emotion != "neutral":
            font.setPointSize(8)
            painter.setFont(font)
            painter.drawText(
                QRect(10, h - 25, w - 20, 20),
                Qt.AlignmentFlag.AlignRight,
                self.current_emotion.capitalize()
            )
    
    def _adjust_color_for_emotion(self, base_color: QColor) -> QColor:
        """Adjust color based on emotion"""
        r, g, b = base_color.red(), base_color.green(), base_color.blue()
        
        if self.current_emotion == "happy":
            r = min(255, r + 50)
            g = min(255, g + 30)
        elif self.current_emotion == "sad":
            b = min(255, b + 50)
            r = max(0, r - 30)
        elif self.current_emotion == "angry":
            r = min(255, r + 70)
            g = max(0, g - 30)
        elif self.current_emotion == "excited":
            r = min(255, r + 30)
            g = min(255, g + 30)
        elif self.current_emotion == "calm":
            b = min(255, b + 30)
            r = max(0, r - 20)
        
        return QColor(r, g, b)
    
    def set_state(self, state: str):
        """Update hologram state"""
        self.state = state.upper()
        logger.debug(f"State changed to: {self.state}")
    
    def set_emotion(self, emotion: str):
        """Update emotion display"""
        self.current_emotion = emotion.lower()
        logger.debug(f"Emotion changed to: {self.current_emotion}")
    
    def mousePressEvent(self, event):
        """Handle mouse press for dragging"""
        if event.button() == Qt.MouseButton.LeftButton:
            self.drag_position = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()
    
    def mouseMoveEvent(self, event):
        """Handle mouse move for dragging"""
        if event.buttons() == Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self.drag_position)
            event.accept()
    
    def closeEvent(self, event):
        """Handle close event"""
        # Hide to tray instead of closing
        event.ignore()
        self.hide()
        if self.tray_icon:
            self.tray_icon.showMessage(
                "SafwaanBuddy",
                "Application minimized to tray",
                QSystemTrayIcon.MessageIcon.Information,
                2000
            )