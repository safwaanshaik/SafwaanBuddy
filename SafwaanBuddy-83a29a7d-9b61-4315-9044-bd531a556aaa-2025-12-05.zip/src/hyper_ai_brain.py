"""
SafwaanBuddy HYPER AI BRAIN - Multi-Model Intelligence System
Combines Gemini Pro, Flash, GPT-4, Claude, and local models for ultimate intelligence
Version: 3.0 HYPER
"""
import os
import logging
import asyncio
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from enum import Enum
import google.generativeai as genai
from datetime import datetime
import json

logger = logging.getLogger('HyperAIBrain')


class AIModel(Enum):
    """Available AI models"""
    GEMINI_PRO = "gemini-pro"
    GEMINI_FLASH = "gemini-1.5-flash"
    GEMINI_ULTRA = "gemini-ultra"
    GPT4 = "gpt-4"
    GPT4_TURBO = "gpt-4-turbo"
    CLAUDE_3 = "claude-3-opus"
    LOCAL_LLAMA = "llama-3-70b"


class TaskComplexity(Enum):
    """Task complexity levels"""
    SIMPLE = "simple"  # Quick facts, time, weather
    MODERATE = "moderate"  # Calculations, searches
    COMPLEX = "complex"  # Analysis, reasoning
    CREATIVE = "creative"  # Content generation
    CRITICAL = "critical"  # Important decisions


@dataclass
class ModelCapability:
    """Model capability profile"""
    speed: float  # 0-1, higher is faster
    accuracy: float  # 0-1, higher is more accurate
    creativity: float  # 0-1, higher is more creative
    cost: float  # 0-1, higher is more expensive
    context_window: int  # Token limit
    specialties: List[str]  # What it's best at


class HyperAIBrain:
    """
    Revolutionary Multi-Model AI System
    
    Features:
    - Intelligent model selection based on task
    - Parallel processing with multiple models
    - Consensus building from multiple responses
    - Automatic fallback and retry
    - Cost optimization
    - Performance tracking
    """
    
    def __init__(self, config, db):
        self.config = config
        self.db = db
        
        # Initialize models
        self.models = {}
        self.model_capabilities = self._define_capabilities()
        
        # Initialize Gemini models
        api_key = os.getenv('GEMINI_API_KEY')
        if api_key:
            genai.configure(api_key=api_key)
            self.models[AIModel.GEMINI_PRO] = genai.GenerativeModel('gemini-pro')
            self.models[AIModel.GEMINI_FLASH] = genai.GenerativeModel('gemini-1.5-flash')
            logger.info("[OK] Gemini models initialized")
        
        # Performance tracking
        self.model_stats = {model: {'calls': 0, 'successes': 0, 'avg_time': 0} 
                           for model in AIModel}
        
        # Context management
        self.conversation_context = []
        self.max_context_length = 10
        
        logger.info("[AI] Hyper AI Brain initialized with multi-model support")
    
    def _define_capabilities(self) -> Dict[AIModel, ModelCapability]:
        """Define capabilities for each model"""
        return {
            AIModel.GEMINI_PRO: ModelCapability(
                speed=0.7,
                accuracy=0.9,
                creativity=0.8,
                cost=0.5,
                context_window=32000,
                specialties=['reasoning', 'analysis', 'conversation']
            ),
            AIModel.GEMINI_FLASH: ModelCapability(
                speed=0.95,
                accuracy=0.85,
                creativity=0.7,
                cost=0.2,
                context_window=32000,
                specialties=['quick_responses', 'simple_tasks', 'speed']
            ),
            AIModel.GPT4_TURBO: ModelCapability(
                speed=0.8,
                accuracy=0.95,
                creativity=0.9,
                cost=0.8,
                context_window=128000,
                specialties=['complex_reasoning', 'code', 'analysis']
            ),
            AIModel.CLAUDE_3: ModelCapability(
                speed=0.75,
                accuracy=0.92,
                creativity=0.95,
                cost=0.7,
                context_window=200000,
                specialties=['creative_writing', 'long_context', 'nuance']
            )
        }
    
    def select_best_model(self, task: str, complexity: TaskComplexity, 
                         context: Dict = None) -> AIModel:
        """
        Intelligently select the best model for the task
        
        Selection criteria:
        - Task complexity
        - Required speed
        - Cost constraints
        - Model specialties
        - Historical performance
        """
        context = context or {}
        
        # Quick tasks -> Fast model
        if complexity == TaskComplexity.SIMPLE:
            return AIModel.GEMINI_FLASH
        
        # Creative tasks -> Creative model
        if complexity == TaskComplexity.CREATIVE:
            if self._is_model_available(AIModel.CLAUDE_3):
                return AIModel.CLAUDE_3
            return AIModel.GEMINI_PRO
        
        # Complex reasoning -> Most accurate model
        if complexity == TaskComplexity.COMPLEX:
            if self._is_model_available(AIModel.GPT4_TURBO):
                return AIModel.GPT4_TURBO
            return AIModel.GEMINI_PRO
        
        # Critical tasks -> Best available model
        if complexity == TaskComplexity.CRITICAL:
            return self._get_best_performing_model()
        
        # Default to Gemini Pro
        return AIModel.GEMINI_PRO
    
    async def process_with_consensus(self, prompt: str, 
                                    num_models: int = 3) -> Dict[str, Any]:
        """
        Process with multiple models and build consensus
        
        Returns the most agreed-upon response with confidence score
        """
        models_to_use = self._select_consensus_models(num_models)
        
        # Get responses from multiple models in parallel
        tasks = [self._get_model_response(model, prompt) 
                for model in models_to_use]
        responses = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Analyze responses and build consensus
        consensus = self._build_consensus(responses)
        
        return consensus
    
    def process(self, user_input: str, context: Dict = None) -> str:
        """
        Main processing method with intelligent routing
        """
        context = context or {}
        
        # Analyze input
        analysis = self._analyze_input(user_input)
        
        # Select best model
        selected_model = self.select_best_model(
            user_input,
            analysis['complexity'],
            context
        )
        
        logger.info(f"[TARGET] Selected {selected_model.value} for task")
        
        # Build enhanced prompt
        enhanced_prompt = self._build_enhanced_prompt(user_input, context, analysis)
        
        # Get response
        response = self._get_response(selected_model, enhanced_prompt)
        
        # Update context
        self._update_context(user_input, response)
        
        # Track performance
        self._track_performance(selected_model, success=True)
        
        return response
    
    def _analyze_input(self, user_input: str) -> Dict[str, Any]:
        """Analyze user input to determine complexity and requirements"""
        input_lower = user_input.lower()
        
        # Determine complexity
        complexity = TaskComplexity.MODERATE
        
        # Simple queries
        simple_keywords = ['time', 'date', 'weather', 'what is', 'who is']
        if any(kw in input_lower for kw in simple_keywords) and len(user_input) < 50:
            complexity = TaskComplexity.SIMPLE
        
        # Complex queries
        complex_keywords = ['analyze', 'compare', 'explain why', 'how does', 'strategy']
        if any(kw in input_lower for kw in complex_keywords):
            complexity = TaskComplexity.COMPLEX
        
        # Creative queries
        creative_keywords = ['write', 'create', 'compose', 'design', 'imagine']
        if any(kw in input_lower for kw in creative_keywords):
            complexity = TaskComplexity.CREATIVE
        
        # Detect intent
        intent = self._detect_intent(user_input)
        
        # Detect urgency
        urgency = self._detect_urgency(user_input)
        
        return {
            'complexity': complexity,
            'intent': intent,
            'urgency': urgency,
            'length': len(user_input),
            'requires_context': self._requires_context(user_input)
        }
    
    def _detect_intent(self, text: str) -> str:
        """Detect user intent"""
        text_lower = text.lower()
        
        if any(w in text_lower for w in ['play', 'open', 'launch', 'start']):
            return 'action'
        elif any(w in text_lower for w in ['what', 'when', 'where', 'who', 'how']):
            return 'information'
        elif any(w in text_lower for w in ['create', 'make', 'write', 'generate']):
            return 'creation'
        elif any(w in text_lower for w in ['help', 'assist', 'support']):
            return 'assistance'
        else:
            return 'conversation'
    
    def _detect_urgency(self, text: str) -> str:
        """Detect urgency level"""
        text_lower = text.lower()
        
        if any(w in text_lower for w in ['urgent', 'asap', 'immediately', 'now', 'quick']):
            return 'high'
        elif any(w in text_lower for w in ['soon', 'today', 'this']):
            return 'medium'
        else:
            return 'low'
    
    def _requires_context(self, text: str) -> bool:
        """Check if query requires conversation context"""
        context_indicators = ['it', 'that', 'this', 'them', 'those', 'previous', 
                             'earlier', 'before', 'also', 'too']
        return any(indicator in text.lower() for indicator in context_indicators)
    
    def _build_enhanced_prompt(self, user_input: str, context: Dict, 
                               analysis: Dict) -> str:
        """Build enhanced prompt with context and metadata"""
        prompt_parts = []
        
        # Add system context
        prompt_parts.append("You are Safwaan, an advanced AI assistant.")
        
        # Add conversation history if needed
        if analysis['requires_context'] and self.conversation_context:
            prompt_parts.append("\nRecent conversation:")
            for ctx in self.conversation_context[-3:]:
                prompt_parts.append(f"User: {ctx['user']}")
                prompt_parts.append(f"Assistant: {ctx['assistant']}")
        
        # Add current query
        prompt_parts.append(f"\nCurrent query: {user_input}")
        
        # Add special instructions based on intent
        if analysis['intent'] == 'action':
            prompt_parts.append("\nProvide a clear, actionable response.")
        elif analysis['intent'] == 'information':
            prompt_parts.append("\nProvide accurate, concise information.")
        elif analysis['intent'] == 'creation':
            prompt_parts.append("\nBe creative and detailed in your response.")
        
        return "\n".join(prompt_parts)
    
    def _get_response(self, model: AIModel, prompt: str) -> str:
        """Get response from selected model"""
        try:
            if model in [AIModel.GEMINI_PRO, AIModel.GEMINI_FLASH]:
                return self._get_gemini_response(model, prompt)
            else:
                # Fallback to Gemini Pro if other models not available
                return self._get_gemini_response(AIModel.GEMINI_PRO, prompt)
        except Exception as e:
            logger.error(f"Error getting response from {model.value}: {e}")
            # Fallback to Gemini Flash
            return self._get_gemini_response(AIModel.GEMINI_FLASH, prompt)
    
    def _get_gemini_response(self, model: AIModel, prompt: str) -> str:
        """Get response from Gemini model"""
        try:
            gemini_model = self.models.get(model)
            if not gemini_model:
                gemini_model = self.models[AIModel.GEMINI_PRO]
            
            response = gemini_model.generate_content(prompt)
            return response.text
        except Exception as e:
            logger.error(f"Gemini error: {e}")
            return "I apologize, but I'm having trouble processing that right now."
    
    async def _get_model_response(self, model: AIModel, prompt: str) -> str:
        """Async wrapper for getting model response"""
        return self._get_response(model, prompt)
    
    def _select_consensus_models(self, num_models: int) -> List[AIModel]:
        """Select models for consensus building"""
        available_models = [m for m in AIModel if self._is_model_available(m)]
        return available_models[:num_models]
    
    def _build_consensus(self, responses: List[str]) -> Dict[str, Any]:
        """Build consensus from multiple responses"""
        # Filter out errors
        valid_responses = [r for r in responses if isinstance(r, str)]
        
        if not valid_responses:
            return {
                'response': "I'm having trouble processing that.",
                'confidence': 0.0,
                'agreement': 0.0
            }
        
        # For now, return the first valid response
        # In production, implement semantic similarity analysis
        return {
            'response': valid_responses[0],
            'confidence': 0.9,
            'agreement': len(valid_responses) / len(responses),
            'num_models': len(valid_responses)
        }
    
    def _is_model_available(self, model: AIModel) -> bool:
        """Check if model is available"""
        return model in self.models
    
    def _get_best_performing_model(self) -> AIModel:
        """Get the best performing model based on stats"""
        best_model = AIModel.GEMINI_PRO
        best_score = 0
        
        for model, stats in self.model_stats.items():
            if stats['calls'] > 0:
                success_rate = stats['successes'] / stats['calls']
                if success_rate > best_score and self._is_model_available(model):
                    best_score = success_rate
                    best_model = model
        
        return best_model
    
    def _update_context(self, user_input: str, response: str):
        """Update conversation context"""
        self.conversation_context.append({
            'user': user_input,
            'assistant': response,
            'timestamp': datetime.now().isoformat()
        })
        
        # Keep only recent context
        if len(self.conversation_context) > self.max_context_length:
            self.conversation_context = self.conversation_context[-self.max_context_length:]
    
    def _track_performance(self, model: AIModel, success: bool):
        """Track model performance"""
        stats = self.model_stats[model]
        stats['calls'] += 1
        if success:
            stats['successes'] += 1
    
    def get_stats(self) -> Dict[str, Any]:
        """Get performance statistics"""
        return {
            'model_stats': self.model_stats,
            'context_length': len(self.conversation_context),
            'available_models': [m.value for m in AIModel if self._is_model_available(m)]
        }
    
    def clear_context(self):
        """Clear conversation context"""
        self.conversation_context = []
        logger.info("🧹 Conversation context cleared")