"""
Intelligent Orchestrator for SafwaanBuddy ULTIMATE
Advanced workflow automation, task scheduling, and intelligent decision making
"""
import logging
import threading
import time
import json
import schedule
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable, Any
from collections import defaultdict, deque
import queue

logger = logging.getLogger('SafwaanBuddy.Orchestrator')


class IntelligentOrchestrator:
    """Advanced orchestration system with intelligent automation"""
    
    def __init__(self, config_manager, db_manager, ai_brain, voice_system):
        self.config = config_manager
        self.db = db_manager
        self.ai = ai_brain
        self.voice = voice_system
        
        # Workflow management
        self.workflows = {}
        self.active_workflows = {}
        self.workflow_history = deque(maxlen=100)
        
        # Task scheduling
        self.scheduled_tasks = {}
        self.task_queue = queue.PriorityQueue()
        
        # Intelligent decision making
        self.decision_tree = {}
        self.learning_data = defaultdict(list)
        
        # Automation rules
        self.automation_rules = []
        self.trigger_conditions = {}
        
        # Performance tracking
        self.execution_stats = {
            'total_workflows': 0,
            'successful': 0,
            'failed': 0,
            'average_duration': 0
        }
        
        # Threading
        self.is_running = False
        self.orchestrator_thread = None
        self.scheduler_thread = None
        
        logger.info("Intelligent Orchestrator initialized")
    
    def start(self):
        """Start orchestration system"""
        try:
            self.is_running = True
            
            # Start orchestrator thread
            self.orchestrator_thread = threading.Thread(target=self._orchestration_loop, daemon=True)
            self.orchestrator_thread.start()
            
            # Start scheduler thread
            self.scheduler_thread = threading.Thread(target=self._scheduler_loop, daemon=True)
            self.scheduler_thread.start()
            
            logger.info("Orchestrator started")
            
        except Exception as e:
            logger.error(f"Orchestrator start error: {e}")
    
    def stop(self):
        """Stop orchestration system"""
        try:
            self.is_running = False
            
            if self.orchestrator_thread:
                self.orchestrator_thread.join(timeout=2)
            
            if self.scheduler_thread:
                self.scheduler_thread.join(timeout=2)
            
            logger.info("Orchestrator stopped")
            
        except Exception as e:
            logger.error(f"Orchestrator stop error: {e}")
    
    def _orchestration_loop(self):
        """Main orchestration loop"""
        while self.is_running:
            try:
                # Process task queue
                if not self.task_queue.empty():
                    priority, task = self.task_queue.get()
                    self._execute_task(task)
                
                # Check active workflows
                self._monitor_workflows()
                
                # Check automation rules
                self._check_automation_rules()
                
                time.sleep(1)
                
            except Exception as e:
                logger.error(f"Orchestration loop error: {e}")
                time.sleep(5)
    
    def _scheduler_loop(self):
        """Scheduler loop for time-based tasks"""
        while self.is_running:
            try:
                schedule.run_pending()
                time.sleep(30)
                
            except Exception as e:
                logger.error(f"Scheduler loop error: {e}")
                time.sleep(60)
    
    def create_workflow(self, name: str, steps: List[Dict], variables: Dict = None) -> str:
        """
        Create a new workflow
        
        Args:
            name: Workflow name
            steps: List of workflow steps
            variables: Workflow variables
        
        Returns:
            Workflow ID
        """
        try:
            workflow_id = f"workflow_{int(time.time())}"
            
            workflow = {
                'id': workflow_id,
                'name': name,
                'steps': steps,
                'variables': variables or {},
                'created_at': datetime.now().isoformat(),
                'status': 'created',
                'execution_count': 0
            }
            
            self.workflows[workflow_id] = workflow
            
            # Save to database
            self.db.save_workflow(workflow)
            
            logger.info(f"Workflow created: {name} ({workflow_id})")
            return workflow_id
            
        except Exception as e:
            logger.error(f"Workflow creation error: {e}")
            return None
    
    def execute_workflow(self, workflow_id: str, input_data: Dict = None) -> Dict:
        """
        Execute a workflow
        
        Args:
            workflow_id: Workflow ID
            input_data: Input data for workflow
        
        Returns:
            Execution results
        """
        try:
            if workflow_id not in self.workflows:
                return {'error': 'Workflow not found'}
            
            workflow = self.workflows[workflow_id]
            
            # Create execution context
            context = {
                'workflow_id': workflow_id,
                'start_time': datetime.now(),
                'input_data': input_data or {},
                'variables': workflow['variables'].copy(),
                'results': [],
                'status': 'running'
            }
            
            # Add to active workflows
            self.active_workflows[workflow_id] = context
            
            # Execute steps
            for i, step in enumerate(workflow['steps']):
                step_result = self._execute_step(step, context)
                context['results'].append(step_result)
                
                if step_result.get('status') == 'failed':
                    context['status'] = 'failed'
                    break
            
            # Complete execution
            if context['status'] == 'running':
                context['status'] = 'completed'
            
            context['end_time'] = datetime.now()
            context['duration'] = (context['end_time'] - context['start_time']).total_seconds()
            
            # Update stats
            self._update_execution_stats(context)
            
            # Remove from active
            del self.active_workflows[workflow_id]
            
            # Add to history
            self.workflow_history.append(context)
            
            # Update workflow
            workflow['execution_count'] += 1
            workflow['last_execution'] = datetime.now().isoformat()
            
            logger.info(f"Workflow executed: {workflow['name']} - {context['status']}")
            
            return context
            
        except Exception as e:
            logger.error(f"Workflow execution error: {e}")
            return {'error': str(e)}
    
    def _execute_step(self, step: Dict, context: Dict) -> Dict:
        """Execute a single workflow step"""
        try:
            step_type = step.get('type', 'action')
            
            if step_type == 'action':
                return self._execute_action(step, context)
            elif step_type == 'condition':
                return self._evaluate_condition(step, context)
            elif step_type == 'loop':
                return self._execute_loop(step, context)
            elif step_type == 'parallel':
                return self._execute_parallel(step, context)
            else:
                return {'status': 'failed', 'error': f'Unknown step type: {step_type}'}
                
        except Exception as e:
            logger.error(f"Step execution error: {e}")
            return {'status': 'failed', 'error': str(e)}
    
    def _execute_action(self, step: Dict, context: Dict) -> Dict:
        """Execute an action step"""
        try:
            action = step.get('action')
            params = step.get('params', {})
            
            # Replace variables in params
            params = self._replace_variables(params, context['variables'])
            
            # Execute action
            if action == 'speak':
                self.voice.speak(params.get('text', ''))
                return {'status': 'success', 'action': 'speak'}
            
            elif action == 'ai_query':
                response = self.ai.process_query(params.get('query', ''))
                context['variables']['last_ai_response'] = response
                return {'status': 'success', 'action': 'ai_query', 'response': response}
            
            elif action == 'wait':
                time.sleep(params.get('seconds', 1))
                return {'status': 'success', 'action': 'wait'}
            
            elif action == 'set_variable':
                var_name = params.get('name')
                var_value = params.get('value')
                context['variables'][var_name] = var_value
                return {'status': 'success', 'action': 'set_variable'}
            
            else:
                return {'status': 'failed', 'error': f'Unknown action: {action}'}
                
        except Exception as e:
            logger.error(f"Action execution error: {e}")
            return {'status': 'failed', 'error': str(e)}
    
    def _evaluate_condition(self, step: Dict, context: Dict) -> Dict:
        """Evaluate a condition step"""
        try:
            condition = step.get('condition')
            
            # Simple condition evaluation
            if condition:
                # Replace variables
                condition = self._replace_variables(condition, context['variables'])
                
                # Evaluate (simplified)
                result = eval(condition)
                
                return {'status': 'success', 'condition_result': result}
            
            return {'status': 'failed', 'error': 'No condition specified'}
            
        except Exception as e:
            logger.error(f"Condition evaluation error: {e}")
            return {'status': 'failed', 'error': str(e)}
    
    def _execute_loop(self, step: Dict, context: Dict) -> Dict:
        """Execute a loop step"""
        try:
            iterations = step.get('iterations', 1)
            loop_steps = step.get('steps', [])
            
            results = []
            for i in range(iterations):
                context['variables']['loop_index'] = i
                
                for loop_step in loop_steps:
                    result = self._execute_step(loop_step, context)
                    results.append(result)
                    
                    if result.get('status') == 'failed':
                        break
            
            return {'status': 'success', 'loop_results': results}
            
        except Exception as e:
            logger.error(f"Loop execution error: {e}")
            return {'status': 'failed', 'error': str(e)}
    
    def _execute_parallel(self, step: Dict, context: Dict) -> Dict:
        """Execute parallel steps"""
        try:
            parallel_steps = step.get('steps', [])
            
            threads = []
            results = []
            
            def execute_in_thread(s):
                result = self._execute_step(s, context)
                results.append(result)
            
            for parallel_step in parallel_steps:
                thread = threading.Thread(target=execute_in_thread, args=(parallel_step,))
                threads.append(thread)
                thread.start()
            
            # Wait for all threads
            for thread in threads:
                thread.join()
            
            return {'status': 'success', 'parallel_results': results}
            
        except Exception as e:
            logger.error(f"Parallel execution error: {e}")
            return {'status': 'failed', 'error': str(e)}
    
    def _replace_variables(self, data: Any, variables: Dict) -> Any:
        """Replace variables in data"""
        try:
            if isinstance(data, str):
                for var_name, var_value in variables.items():
                    data = data.replace(f'{{{var_name}}}', str(var_value))
                return data
            
            elif isinstance(data, dict):
                return {k: self._replace_variables(v, variables) for k, v in data.items()}
            
            elif isinstance(data, list):
                return [self._replace_variables(item, variables) for item in data]
            
            else:
                return data
                
        except Exception as e:
            logger.error(f"Variable replacement error: {e}")
            return data
    
    def _execute_task(self, task: Dict):
        """Execute a queued task"""
        try:
            task_type = task.get('type')
            
            if task_type == 'workflow':
                workflow_id = task.get('workflow_id')
                input_data = task.get('input_data')
                self.execute_workflow(workflow_id, input_data)
            
            elif task_type == 'action':
                action = task.get('action')
                params = task.get('params', {})
                self._execute_action({'action': action, 'params': params}, {'variables': {}})
            
            logger.info(f"Task executed: {task_type}")
            
        except Exception as e:
            logger.error(f"Task execution error: {e}")
    
    def _monitor_workflows(self):
        """Monitor active workflows"""
        try:
            for workflow_id, context in list(self.active_workflows.items()):
                # Check for timeout
                elapsed = (datetime.now() - context['start_time']).total_seconds()
                
                if elapsed > 300:  # 5 minutes timeout
                    context['status'] = 'timeout'
                    del self.active_workflows[workflow_id]
                    logger.warning(f"Workflow timeout: {workflow_id}")
                    
        except Exception as e:
            logger.error(f"Workflow monitoring error: {e}")
    
    def _check_automation_rules(self):
        """Check and execute automation rules"""
        try:
            for rule in self.automation_rules:
                if self._evaluate_rule(rule):
                    self._execute_rule_action(rule)
                    
        except Exception as e:
            logger.error(f"Automation rule check error: {e}")
    
    def _evaluate_rule(self, rule: Dict) -> bool:
        """Evaluate if automation rule should trigger"""
        try:
            condition = rule.get('condition')
            
            # Simple condition evaluation
            # Can be enhanced with more complex logic
            
            return False  # Placeholder
            
        except Exception as e:
            logger.error(f"Rule evaluation error: {e}")
            return False
    
    def _execute_rule_action(self, rule: Dict):
        """Execute automation rule action"""
        try:
            action = rule.get('action')
            
            if action:
                self.task_queue.put((1, action))
                
        except Exception as e:
            logger.error(f"Rule action execution error: {e}")
    
    def _update_execution_stats(self, context: Dict):
        """Update execution statistics"""
        try:
            self.execution_stats['total_workflows'] += 1
            
            if context['status'] == 'completed':
                self.execution_stats['successful'] += 1
            else:
                self.execution_stats['failed'] += 1
            
            # Update average duration
            total = self.execution_stats['total_workflows']
            current_avg = self.execution_stats['average_duration']
            new_duration = context.get('duration', 0)
            
            self.execution_stats['average_duration'] = (current_avg * (total - 1) + new_duration) / total
            
        except Exception as e:
            logger.error(f"Stats update error: {e}")
    
    def schedule_task(self, task: Dict, schedule_time: str):
        """
        Schedule a task for future execution
        
        Args:
            task: Task to schedule
            schedule_time: Schedule time (e.g., "09:00", "every 1 hour")
        """
        try:
            if schedule_time.startswith('every'):
                # Recurring schedule
                parts = schedule_time.split()
                interval = int(parts[1])
                unit = parts[2]
                
                if unit == 'hour' or unit == 'hours':
                    schedule.every(interval).hours.do(lambda: self.task_queue.put((1, task)))
                elif unit == 'minute' or unit == 'minutes':
                    schedule.every(interval).minutes.do(lambda: self.task_queue.put((1, task)))
                elif unit == 'day' or unit == 'days':
                    schedule.every(interval).days.do(lambda: self.task_queue.put((1, task)))
            
            else:
                # One-time schedule
                schedule.every().day.at(schedule_time).do(lambda: self.task_queue.put((1, task)))
            
            logger.info(f"Task scheduled: {schedule_time}")
            
        except Exception as e:
            logger.error(f"Task scheduling error: {e}")
    
    def get_stats(self) -> Dict:
        """Get orchestration statistics"""
        return {
            'execution_stats': self.execution_stats,
            'active_workflows': len(self.active_workflows),
            'total_workflows': len(self.workflows),
            'scheduled_tasks': len(self.scheduled_tasks),
            'queue_size': self.task_queue.qsize()
        }