"""
Knowledge Management System for SafwaanBuddy ULTIMATE
Advanced knowledge base, learning, and information retrieval
"""
import logging
import json
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime
from collections import defaultdict
import re

logger = logging.getLogger('SafwaanBuddy.KnowledgeManagement')


class KnowledgeManagementSystem:
    """Advanced knowledge management with learning and retrieval"""
    
    def __init__(self, db_manager):
        self.db = db_manager
        
        # Knowledge base
        self.knowledge_base = {
            'facts': {},
            'concepts': {},
            'relationships': {},
            'procedures': {},
            'preferences': {}
        }
        
        # Learning system
        self.learning_buffer = []
        self.confidence_scores = defaultdict(float)
        
        # Semantic network
        self.semantic_network = defaultdict(set)
        
        # Topic modeling
        self.topics = defaultdict(list)
        
        # Load existing knowledge
        self._load_knowledge()
        
        logger.info("[OK] Knowledge management system initialized")
    
    def _load_knowledge(self) -> None:
        """Load knowledge from database"""
        try:
            # Load from database
            knowledge_data = self.db.get_knowledge()
            
            if knowledge_data:
                for item in knowledge_data:
                    category = item.get('category', 'facts')
                    key = item.get('key')
                    value = item.get('value')
                    
                    if category in self.knowledge_base and key:
                        self.knowledge_base[category][key] = value
            
            logger.info(f"[OK] Loaded {len(knowledge_data) if knowledge_data else 0} knowledge items")
            
        except Exception as e:
            logger.error(f"[ERROR] Knowledge loading failed: {e}")
    
    def add_knowledge(self, category: str, key: str, value: Any, confidence: float = 1.0) -> bool:
        """Add new knowledge"""
        try:
            if category not in self.knowledge_base:
                logger.warning(f"[WARNING] Unknown category: {category}")
                return False
            
            # Add to knowledge base
            self.knowledge_base[category][key] = value
            self.confidence_scores[f"{category}:{key}"] = confidence
            
            # Save to database
            self.db.save_knowledge(category, key, value, confidence)
            
            # Update semantic network
            self._update_semantic_network(category, key, value)
            
            logger.info(f"[OK] Added knowledge: {category}/{key}")
            return True
            
        except Exception as e:
            logger.error(f"[ERROR] Knowledge addition failed: {e}")
            return False
    
    def get_knowledge(self, category: str, key: str) -> Optional[Any]:
        """Retrieve knowledge"""
        try:
            if category in self.knowledge_base:
                return self.knowledge_base[category].get(key)
            return None
            
        except Exception as e:
            logger.error(f"[ERROR] Knowledge retrieval failed: {e}")
            return None
    
    def search_knowledge(self, query: str, category: Optional[str] = None) -> List[Dict]:
        """Search knowledge base"""
        try:
            results = []
            query_lower = query.lower()
            
            # Search in specified category or all
            categories = [category] if category else self.knowledge_base.keys()
            
            for cat in categories:
                for key, value in self.knowledge_base[cat].items():
                    # Check if query matches key or value
                    if query_lower in key.lower() or query_lower in str(value).lower():
                        confidence = self.confidence_scores.get(f"{cat}:{key}", 0.5)
                        results.append({
                            'category': cat,
                            'key': key,
                            'value': value,
                            'confidence': confidence
                        })
            
            # Sort by confidence
            results.sort(key=lambda x: x['confidence'], reverse=True)
            
            return results
            
        except Exception as e:
            logger.error(f"[ERROR] Knowledge search failed: {e}")
            return []
    
    def learn_from_interaction(self, user_input: str, response: str, feedback: Optional[str] = None) -> None:
        """Learn from user interactions"""
        try:
            # Extract entities and concepts
            entities = self._extract_entities(user_input)
            concepts = self._extract_concepts(user_input)
            
            # Store in learning buffer
            self.learning_buffer.append({
                'input': user_input,
                'response': response,
                'feedback': feedback,
                'entities': entities,
                'concepts': concepts,
                'timestamp': datetime.now().isoformat()
            })
            
            # Process learning buffer periodically
            if len(self.learning_buffer) >= 10:
                self._process_learning_buffer()
            
        except Exception as e:
            logger.error(f"[ERROR] Learning failed: {e}")
    
    def _extract_entities(self, text: str) -> List[str]:
        """Extract named entities from text"""
        try:
            entities = []
            
            # Simple entity extraction (can be enhanced with NLP)
            # Extract capitalized words
            words = text.split()
            for word in words:
                if word and word[0].isupper() and len(word) > 2:
                    entities.append(word)
            
            return entities
            
        except Exception as e:
            logger.error(f"[ERROR] Entity extraction failed: {e}")
            return []
    
    def _extract_concepts(self, text: str) -> List[str]:
        """Extract concepts from text"""
        try:
            concepts = []
            
            # Extract noun phrases and key terms
            # Simple implementation - can be enhanced
            text_lower = text.lower()
            
            # Common concept patterns
            concept_patterns = [
                r'\b(how to \w+)',
                r'\b(what is \w+)',
                r'\b(why \w+)',
                r'\b(\w+ process)',
                r'\b(\w+ system)'
            ]
            
            for pattern in concept_patterns:
                matches = re.findall(pattern, text_lower)
                concepts.extend(matches)
            
            return concepts
            
        except Exception as e:
            logger.error(f"[ERROR] Concept extraction failed: {e}")
            return []
    
    def _process_learning_buffer(self) -> None:
        """Process accumulated learning"""
        try:
            # Analyze patterns in learning buffer
            for item in self.learning_buffer:
                # Extract common patterns
                entities = item['entities']
                concepts = item['concepts']
                
                # Update knowledge base
                for entity in entities:
                    if entity not in self.knowledge_base['facts']:
                        self.add_knowledge('facts', entity, {
                            'first_seen': item['timestamp'],
                            'occurrences': 1
                        }, confidence=0.5)
                
                for concept in concepts:
                    if concept not in self.knowledge_base['concepts']:
                        self.add_knowledge('concepts', concept, {
                            'first_seen': item['timestamp'],
                            'related_entities': entities
                        }, confidence=0.5)
            
            # Clear buffer
            self.learning_buffer.clear()
            
            logger.info("[OK] Learning buffer processed")
            
        except Exception as e:
            logger.error(f"[ERROR] Learning buffer processing failed: {e}")
    
    def _update_semantic_network(self, category: str, key: str, value: Any) -> None:
        """Update semantic network with new knowledge"""
        try:
            # Create relationships between concepts
            if category == 'concepts':
                # Extract related terms
                if isinstance(value, dict) and 'related_entities' in value:
                    for entity in value['related_entities']:
                        self.semantic_network[key].add(entity)
                        self.semantic_network[entity].add(key)
            
        except Exception as e:
            logger.error(f"[ERROR] Semantic network update failed: {e}")
    
    def get_related_knowledge(self, key: str, max_depth: int = 2) -> List[str]:
        """Get related knowledge using semantic network"""
        try:
            related = set()
            visited = set()
            queue = [(key, 0)]
            
            while queue:
                current, depth = queue.pop(0)
                
                if current in visited or depth > max_depth:
                    continue
                
                visited.add(current)
                related.add(current)
                
                # Add neighbors
                if current in self.semantic_network:
                    for neighbor in self.semantic_network[current]:
                        if neighbor not in visited:
                            queue.append((neighbor, depth + 1))
            
            return list(related)
            
        except Exception as e:
            logger.error(f"[ERROR] Related knowledge retrieval failed: {e}")
            return []
    
    def get_knowledge_summary(self) -> Dict:
        """Get summary of knowledge base"""
        try:
            summary = {
                'total_items': 0,
                'categories': {},
                'confidence_avg': 0,
                'last_updated': datetime.now().isoformat()
            }
            
            for category, items in self.knowledge_base.items():
                summary['categories'][category] = len(items)
                summary['total_items'] += len(items)
            
            # Calculate average confidence
            if self.confidence_scores:
                summary['confidence_avg'] = sum(self.confidence_scores.values()) / len(self.confidence_scores)
            
            return summary
            
        except Exception as e:
            logger.error(f"[ERROR] Knowledge summary failed: {e}")
            return {'error': str(e)}
    
    def export_knowledge(self, filepath: str) -> bool:
        """Export knowledge base to file"""
        try:
            export_data = {
                'knowledge_base': self.knowledge_base,
                'confidence_scores': dict(self.confidence_scores),
                'semantic_network': {k: list(v) for k, v in self.semantic_network.items()},
                'exported_at': datetime.now().isoformat()
            }
            
            with open(filepath, 'w') as f:
                json.dump(export_data, f, indent=2)
            
            logger.info(f"[OK] Knowledge exported to {filepath}")
            return True
            
        except Exception as e:
            logger.error(f"[ERROR] Knowledge export failed: {e}")
            return False
    
    def import_knowledge(self, filepath: str) -> bool:
        """Import knowledge base from file"""
        try:
            with open(filepath, 'r') as f:
                import_data = json.load(f)
            
            # Import knowledge base
            if 'knowledge_base' in import_data:
                self.knowledge_base.update(import_data['knowledge_base'])
            
            # Import confidence scores
            if 'confidence_scores' in import_data:
                self.confidence_scores.update(import_data['confidence_scores'])
            
            # Import semantic network
            if 'semantic_network' in import_data:
                for key, values in import_data['semantic_network'].items():
                    self.semantic_network[key] = set(values)
            
            logger.info(f"[OK] Knowledge imported from {filepath}")
            return True
            
        except Exception as e:
            logger.error(f"[ERROR] Knowledge import failed: {e}")
            return False