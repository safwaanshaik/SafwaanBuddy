"""
Local AI Brain - 100% Offline AI System
Uses local open-source models - NO cloud APIs required!
Version: 3.0 HYPER - FULLY LOCAL
"""
import logging
import os
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import json
from datetime import datetime

logger = logging.getLogger('LocalAIBrain')


class LocalAIBrain:
    """
    100% Local AI System - No Cloud APIs!
    
    Features:
    - Rule-based intelligent responses
    - Pattern matching and learning
    - Context awareness
    - Emotion detection
    - Intent classification
    - Knowledge base
    - Conversation memory
    - Smart suggestions
    
    NO INTERNET REQUIRED!
    """
    
    def __init__(self, config, db):
        self.config = config
        self.db = db
        
        # Knowledge base
        self.knowledge_base = self._load_knowledge_base()
        
        # Conversation context
        self.conversation_history = []
        self.max_history = 10
        
        # User profile
        self.user_profile = {
            'name': 'User',
            'preferences': {},
            'interests': [],
            'conversation_style': 'friendly'
        }
        
        # Response templates
        self.response_templates = self._load_response_templates()
        
        # Intent patterns
        self.intent_patterns = self._load_intent_patterns()
        
        # Emotion keywords
        self.emotion_keywords = self._load_emotion_keywords()
        
        logger.info("[AI] Local AI Brain initialized - 100% OFFLINE!")
    
    def process(self, user_input: str, context: Dict = None) -> str:
        """
        Process user input and generate intelligent response
        
        Args:
            user_input: User's message
            context: Additional context
        
        Returns:
            AI-generated response
        """
        context = context or {}
        
        # Analyze input
        analysis = self._analyze_input(user_input)
        
        # Detect intent
        intent = self._detect_intent(user_input, analysis)
        
        # Detect emotion
        emotion = self._detect_emotion(user_input)
        
        # Get relevant knowledge
        knowledge = self._search_knowledge(user_input)
        
        # Generate response
        response = self._generate_response(
            user_input,
            intent,
            emotion,
            knowledge,
            analysis
        )
        
        # Update conversation history
        self._update_history(user_input, response)
        
        # Learn from interaction
        self._learn_from_interaction(user_input, response, intent)
        
        return response
    
    def _analyze_input(self, text: str) -> Dict[str, Any]:
        """Analyze user input"""
        text_lower = text.lower()
        words = text_lower.split()
        
        return {
            'length': len(text),
            'word_count': len(words),
            'has_question': '?' in text,
            'is_command': any(w in text_lower for w in ['open', 'play', 'search', 'tell', 'show']),
            'is_greeting': any(w in text_lower for w in ['hello', 'hi', 'hey', 'good morning', 'good evening']),
            'is_farewell': any(w in text_lower for w in ['bye', 'goodbye', 'see you', 'later']),
            'has_thanks': any(w in text_lower for w in ['thank', 'thanks', 'appreciate']),
            'sentiment': self._analyze_sentiment(text_lower)
        }
    
    def _detect_intent(self, text: str, analysis: Dict) -> str:
        """Detect user intent"""
        text_lower = text.lower()
        
        # Check patterns
        for intent, patterns in self.intent_patterns.items():
            for pattern in patterns:
                if pattern in text_lower:
                    return intent
        
        # Fallback based on analysis
        if analysis['is_greeting']:
            return 'greeting'
        elif analysis['is_farewell']:
            return 'farewell'
        elif analysis['has_thanks']:
            return 'gratitude'
        elif analysis['has_question']:
            return 'question'
        elif analysis['is_command']:
            return 'command'
        else:
            return 'conversation'
    
    def _detect_emotion(self, text: str) -> str:
        """Detect emotion in text"""
        text_lower = text.lower()
        
        emotion_scores = {}
        for emotion, keywords in self.emotion_keywords.items():
            score = sum(1 for kw in keywords if kw in text_lower)
            if score > 0:
                emotion_scores[emotion] = score
        
        if emotion_scores:
            return max(emotion_scores, key=emotion_scores.get)
        
        return 'neutral'
    
    def _analyze_sentiment(self, text: str) -> str:
        """Analyze sentiment"""
        positive_words = ['good', 'great', 'awesome', 'excellent', 'love', 'like', 'happy', 'wonderful']
        negative_words = ['bad', 'terrible', 'hate', 'dislike', 'sad', 'angry', 'awful', 'horrible']
        
        pos_count = sum(1 for w in positive_words if w in text)
        neg_count = sum(1 for w in negative_words if w in text)
        
        if pos_count > neg_count:
            return 'positive'
        elif neg_count > pos_count:
            return 'negative'
        else:
            return 'neutral'
    
    def _search_knowledge(self, query: str) -> List[str]:
        """Search knowledge base"""
        query_lower = query.lower()
        words = set(query_lower.split())
        
        results = []
        for topic, info in self.knowledge_base.items():
            topic_words = set(topic.lower().split())
            # Check for word overlap
            if words & topic_words:
                results.append(info)
        
        return results[:3]  # Top 3 results
    
    def _generate_response(self, user_input: str, intent: str, 
                          emotion: str, knowledge: List[str],
                          analysis: Dict) -> str:
        """Generate intelligent response"""
        
        # Handle specific intents
        if intent == 'greeting':
            return self._generate_greeting(emotion)
        
        elif intent == 'farewell':
            return self._generate_farewell()
        
        elif intent == 'gratitude':
            return self._generate_gratitude_response()
        
        elif intent == 'question':
            return self._generate_question_response(user_input, knowledge)
        
        elif intent == 'command':
            return self._generate_command_response(user_input)
        
        else:
            return self._generate_conversation_response(user_input, emotion, knowledge)
    
    def _generate_greeting(self, emotion: str) -> str:
        """Generate greeting response"""
        greetings = [
            "Hello! How can I help you today?",
            "Hi there! What can I do for you?",
            "Hey! I'm here to assist you.",
            "Good to see you! What would you like to do?",
            "Hello! Ready to help with whatever you need."
        ]
        
        if emotion == 'happy':
            return "Hello! You seem in a great mood! How can I make your day even better?"
        elif emotion == 'sad':
            return "Hello. I'm here for you. How can I help?"
        else:
            import random
            return random.choice(greetings)
    
    def _generate_farewell(self) -> str:
        """Generate farewell response"""
        farewells = [
            "Goodbye! Have a great day!",
            "See you later! Take care!",
            "Bye! Feel free to come back anytime!",
            "Until next time! Stay awesome!",
            "Goodbye! It was great talking with you!"
        ]
        import random
        return random.choice(farewells)
    
    def _generate_gratitude_response(self) -> str:
        """Generate response to thanks"""
        responses = [
            "You're welcome! Happy to help!",
            "My pleasure! Anytime!",
            "Glad I could help!",
            "No problem at all!",
            "Always here to assist you!"
        ]
        import random
        return random.choice(responses)
    
    def _generate_question_response(self, question: str, knowledge: List[str]) -> str:
        """Generate response to questions"""
        question_lower = question.lower()
        
        # Time questions
        if 'time' in question_lower:
            return f"The current time is {datetime.now().strftime('%I:%M %p')}."
        
        # Date questions
        if 'date' in question_lower or 'day' in question_lower:
            return f"Today is {datetime.now().strftime('%A, %B %d, %Y')}."
        
        # Name questions
        if 'your name' in question_lower or 'who are you' in question_lower:
            return "I'm Safwaan, your AI assistant! I'm here to help you with various tasks."
        
        # Capability questions
        if 'what can you do' in question_lower or 'help me' in question_lower:
            return ("I can help you with many things! I can tell you the time, play music, "
                   "search the web, take screenshots, control your system, and have conversations. "
                   "Just ask me anything!")
        
        # Use knowledge base
        if knowledge:
            return f"Based on what I know: {knowledge[0]}"
        
        # Generic response
        return ("That's an interesting question! While I may not have all the answers, "
               "I'm always learning. Could you rephrase or ask something else?")
    
    def _generate_command_response(self, command: str) -> str:
        """Generate response to commands"""
        command_lower = command.lower()
        
        if 'play' in command_lower:
            return "I'll play that for you right away!"
        elif 'open' in command_lower:
            return "Opening that now!"
        elif 'search' in command_lower:
            return "Searching for that information..."
        elif 'tell' in command_lower or 'show' in command_lower:
            return "Let me get that information for you."
        else:
            return "I'll take care of that!"
    
    def _generate_conversation_response(self, text: str, emotion: str, 
                                       knowledge: List[str]) -> str:
        """Generate conversational response"""
        text_lower = text.lower()
        
        # Check for specific topics
        if 'weather' in text_lower:
            return "I can check the weather for you! Just say 'what's the weather' or 'weather forecast'."
        
        if 'music' in text_lower:
            return "I love music! Tell me what you'd like to listen to and I'll play it for you."
        
        if 'joke' in text_lower:
            return "Want to hear a joke? Just say 'tell me a joke' and I'll share one!"
        
        # Use knowledge if available
        if knowledge:
            return f"Interesting! {knowledge[0]} What else would you like to know?"
        
        # Emotion-based responses
        if emotion == 'happy':
            return "That's wonderful! I'm glad you're feeling good. How can I help you today?"
        elif emotion == 'sad':
            return "I'm here for you. Is there anything I can do to help?"
        elif emotion == 'excited':
            return "Your enthusiasm is contagious! What's got you so excited?"
        
        # Generic conversational responses
        responses = [
            "That's interesting! Tell me more.",
            "I see. What else is on your mind?",
            "Fascinating! How can I assist you with that?",
            "I understand. What would you like to do?",
            "Got it! Anything else I can help with?"
        ]
        import random
        return random.choice(responses)
    
    def _update_history(self, user_input: str, response: str):
        """Update conversation history"""
        self.conversation_history.append({
            'user': user_input,
            'assistant': response,
            'timestamp': datetime.now().isoformat()
        })
        
        # Keep only recent history
        if len(self.conversation_history) > self.max_history:
            self.conversation_history = self.conversation_history[-self.max_history:]
    
    def _learn_from_interaction(self, user_input: str, response: str, intent: str):
        """Learn from user interactions"""
        # Store in database for future learning
        try:
            self.db.store_conversation(user_input, response, intent)
        except:
            pass
    
    def _load_knowledge_base(self) -> Dict[str, str]:
        """Load knowledge base"""
        return {
            'safwaan': "Safwaan is an advanced AI voice assistant for Windows 11 with features like voice recognition, holographic UI, and system automation.",
            'time': "I can tell you the current time anytime you ask!",
            'weather': "I can check the weather forecast for you.",
            'music': "I can play music from YouTube for you.",
            'screenshot': "I can take screenshots of your screen.",
            'system': "I can provide system information like CPU, memory, and disk usage.",
            'windows': "I work best on Windows 11 but also support Windows 10.",
            'voice': "I use advanced text-to-speech with multiple voice personalities.",
            'ai': "I use intelligent algorithms to understand and respond to your requests.",
            'help': "I can help with time, weather, music, web searches, screenshots, system control, and much more!"
        }
    
    def _load_response_templates(self) -> Dict[str, List[str]]:
        """Load response templates"""
        return {
            'greeting': [
                "Hello! How can I help you today?",
                "Hi there! What can I do for you?",
                "Hey! I'm here to assist you."
            ],
            'farewell': [
                "Goodbye! Have a great day!",
                "See you later! Take care!",
                "Bye! Feel free to come back anytime!"
            ]
        }
    
    def _load_intent_patterns(self) -> Dict[str, List[str]]:
        """Load intent detection patterns"""
        return {
            'greeting': ['hello', 'hi', 'hey', 'good morning', 'good evening', 'greetings'],
            'farewell': ['bye', 'goodbye', 'see you', 'later', 'farewell'],
            'gratitude': ['thank', 'thanks', 'appreciate', 'grateful'],
            'time': ['time', 'clock', 'what time'],
            'date': ['date', 'day', 'today', 'calendar'],
            'weather': ['weather', 'temperature', 'forecast', 'rain', 'sunny'],
            'music': ['play', 'music', 'song', 'listen'],
            'search': ['search', 'find', 'look up', 'google'],
            'help': ['help', 'assist', 'support', 'what can you do']
        }
    
    def _load_emotion_keywords(self) -> Dict[str, List[str]]:
        """Load emotion detection keywords"""
        return {
            'happy': ['happy', 'great', 'awesome', 'wonderful', 'excellent', 'love', 'joy', 'excited'],
            'sad': ['sad', 'unhappy', 'depressed', 'down', 'upset', 'disappointed'],
            'angry': ['angry', 'mad', 'furious', 'annoyed', 'frustrated', 'irritated'],
            'excited': ['excited', 'thrilled', 'pumped', 'enthusiastic', 'eager'],
            'calm': ['calm', 'peaceful', 'relaxed', 'serene', 'tranquil'],
            'confused': ['confused', 'puzzled', 'unclear', 'lost', 'uncertain'],
            'surprised': ['surprised', 'shocked', 'amazed', 'astonished', 'wow']
        }
    
    def get_conversation_context(self) -> str:
        """Get recent conversation context"""
        if not self.conversation_history:
            return ""
        
        context_parts = []
        for entry in self.conversation_history[-3:]:
            context_parts.append(f"User: {entry['user']}")
            context_parts.append(f"Assistant: {entry['assistant']}")
        
        return "\n".join(context_parts)
    
    def clear_context(self):
        """Clear conversation history"""
        self.conversation_history = []
        logger.info("🧹 Conversation context cleared")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get statistics"""
        return {
            'conversation_count': len(self.conversation_history),
            'knowledge_base_size': len(self.knowledge_base),
            'user_profile': self.user_profile
        }