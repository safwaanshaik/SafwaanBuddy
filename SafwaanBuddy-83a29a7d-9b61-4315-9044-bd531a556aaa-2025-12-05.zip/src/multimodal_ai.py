"""
Multi-Modal AI System for SafwaanBuddy
Supports text, vision, and advanced reasoning
"""
import google.generativeai as genai
import logging
from typing import Dict, Optional, List, Any
from PIL import Image
import base64
import io

logger = logging.getLogger('SafwaanBuddy.MultiModal')


class MultiModalAI:
    """Advanced multi-modal AI with vision and reasoning"""
    
    def __init__(self, config_manager):
        self.config = config_manager
        
        # Initialize models
        self.text_model = None
        self.vision_model = None
        self.flash_model = None
        
        self._initialize_models()
        
        # Capabilities
        self.capabilities = {
            'text_generation': True,
            'image_understanding': False,
            'code_generation': True,
            'reasoning': True,
            'summarization': True,
            'translation': True
        }
        
        logger.info("[OK] Multi-Modal AI initialized")
    
    def _initialize_models(self):
        """Initialize all AI models"""
        try:
            api_key = self.config.get_api_key('gemini')
            
            if not api_key or api_key == 'your_gemini_api_key_here':
                logger.warning("[WARNING] Gemini API key not configured")
                return
            
            genai.configure(api_key=api_key)
            
            # Text model (Gemini Pro)
            self.text_model = genai.GenerativeModel('gemini-pro')
            logger.info("[OK] Gemini Pro (text) initialized")
            
            # Vision model (Gemini Pro Vision)
            try:
                self.vision_model = genai.GenerativeModel('gemini-pro-vision')
                self.capabilities['image_understanding'] = True
                logger.info("[OK] Gemini Pro Vision initialized")
            except:
                logger.info("Gemini Pro Vision not available")
            
            # Flash model for quick responses
            try:
                self.flash_model = genai.GenerativeModel('gemini-1.5-flash-latest')
                logger.info("[OK] Gemini Flash initialized")
            except:
                logger.info("Gemini Flash not available")
        
        except Exception as e:
            logger.error(f"Model initialization error: {e}")
    
    def generate_text(self, prompt: str, context: str = "", 
                     temperature: float = 0.7) -> str:
        """Generate text response"""
        try:
            if not self.text_model:
                return "AI model not available. Please configure API key."
            
            full_prompt = f"{context}\n\n{prompt}" if context else prompt
            
            response = self.text_model.generate_content(
                full_prompt,
                generation_config=genai.types.GenerationConfig(
                    temperature=temperature
                )
            )
            
            return response.text.strip()
        
        except Exception as e:
            logger.error(f"Text generation error: {e}")
            return "I had trouble generating a response."
    
    def analyze_image(self, image_path: str, question: str = "Describe this image") -> str:
        """Analyze image with vision model"""
        try:
            if not self.vision_model:
                return "Vision model not available."
            
            # Load image
            image = Image.open(image_path)
            
            # Generate response
            response = self.vision_model.generate_content([question, image])
            
            return response.text.strip()
        
        except Exception as e:
            logger.error(f"Image analysis error: {e}")
            return "I couldn't analyze that image."
    
    def analyze_screenshot(self, screenshot_path: str) -> Dict:
        """Analyze screenshot and extract information"""
        try:
            if not self.vision_model:
                return {'error': 'Vision model not available'}
            
            # Analyze with multiple questions
            analyses = {}
            
            questions = [
                "What is shown in this screenshot?",
                "What application or website is this?",
                "Are there any important elements or text visible?"
            ]
            
            for question in questions:
                response = self.analyze_image(screenshot_path, question)
                analyses[question] = response
            
            return analyses
        
        except Exception as e:
            logger.error(f"Screenshot analysis error: {e}")
            return {'error': str(e)}
    
    def generate_code(self, description: str, language: str = "python") -> str:
        """Generate code from description"""
        try:
            if not self.text_model:
                return "# AI model not available"
            
            prompt = f"""Generate {language} code for the following task:

{description}

Provide clean, well-commented, production-ready code.
Include error handling and best practices.

Code:"""
            
            response = self.text_model.generate_content(prompt)
            return response.text.strip()
        
        except Exception as e:
            logger.error(f"Code generation error: {e}")
            return f"# Error generating code: {e}"
    
    def summarize_text(self, text: str, max_length: int = 100) -> str:
        """Summarize long text"""
        try:
            if not self.flash_model and not self.text_model:
                return "AI model not available"
            
            model = self.flash_model or self.text_model
            
            prompt = f"""Summarize the following text in {max_length} words or less:

{text}

Summary:"""
            
            response = model.generate_content(prompt)
            return response.text.strip()
        
        except Exception as e:
            logger.error(f"Summarization error: {e}")
            return "I couldn't summarize that text."
    
    def translate_text(self, text: str, target_language: str) -> str:
        """Translate text to target language"""
        try:
            if not self.text_model:
                return "AI model not available"
            
            prompt = f"""Translate the following text to {target_language}:

{text}

Translation:"""
            
            response = self.text_model.generate_content(prompt)
            return response.text.strip()
        
        except Exception as e:
            logger.error(f"Translation error: {e}")
            return "I couldn't translate that."
    
    def answer_question(self, question: str, context: str = "") -> str:
        """Answer question with reasoning"""
        try:
            if not self.text_model:
                return "AI model not available"
            
            prompt = f"""Answer the following question thoughtfully and accurately.

{f'Context: {context}' if context else ''}

Question: {question}

Provide a clear, informative answer with reasoning if needed.

Answer:"""
            
            response = self.text_model.generate_content(prompt)
            return response.text.strip()
        
        except Exception as e:
            logger.error(f"Question answering error: {e}")
            return "I couldn't answer that question."
    
    def explain_concept(self, concept: str, level: str = "intermediate") -> str:
        """Explain a concept at specified level"""
        try:
            if not self.text_model:
                return "AI model not available"
            
            prompt = f"""Explain the concept of "{concept}" at a {level} level.

Make it clear, engaging, and easy to understand.
Use examples if helpful.

Explanation:"""
            
            response = self.text_model.generate_content(prompt)
            return response.text.strip()
        
        except Exception as e:
            logger.error(f"Explanation error: {e}")
            return "I couldn't explain that concept."
    
    def brainstorm_ideas(self, topic: str, count: int = 5) -> List[str]:
        """Brainstorm ideas on a topic"""
        try:
            if not self.text_model:
                return ["AI model not available"]
            
            prompt = f"""Brainstorm {count} creative and practical ideas about: {topic}

Provide diverse, innovative ideas.

Ideas:"""
            
            response = self.text_model.generate_content(prompt)
            
            # Parse ideas
            ideas = []
            for line in response.text.strip().split('\n'):
                line = line.strip()
                if line and (line[0].isdigit() or line.startswith('-') or line.startswith('•')):
                    # Remove numbering/bullets
                    idea = line.lstrip('0123456789.-•) ').strip()
                    if idea:
                        ideas.append(idea)
            
            return ideas[:count]
        
        except Exception as e:
            logger.error(f"Brainstorming error: {e}")
            return ["I couldn't brainstorm ideas."]
    
    def analyze_sentiment(self, text: str) -> Dict:
        """Analyze sentiment of text"""
        try:
            if not self.flash_model and not self.text_model:
                return {'sentiment': 'unknown', 'confidence': 0.0}
            
            model = self.flash_model or self.text_model
            
            prompt = f"""Analyze the sentiment of this text:

"{text}"

Respond with ONLY one word: positive, negative, or neutral"""
            
            response = model.generate_content(prompt)
            sentiment = response.text.strip().lower()
            
            # Calculate confidence based on text
            confidence = 0.8 if sentiment in ['positive', 'negative', 'neutral'] else 0.5
            
            return {
                'sentiment': sentiment,
                'confidence': confidence,
                'text': text
            }
        
        except Exception as e:
            logger.error(f"Sentiment analysis error: {e}")
            return {'sentiment': 'unknown', 'confidence': 0.0}
    
    def get_capabilities(self) -> Dict:
        """Get current AI capabilities"""
        return {
            **self.capabilities,
            'models_available': {
                'text': self.text_model is not None,
                'vision': self.vision_model is not None,
                'flash': self.flash_model is not None
            }
        }