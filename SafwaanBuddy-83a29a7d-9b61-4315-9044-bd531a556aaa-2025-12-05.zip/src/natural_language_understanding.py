"""
Natural Language Understanding for SafwaanBuddy ULTIMATE
Advanced NLU with intent recognition, entity extraction, and semantic analysis
"""
import logging
import re
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime
from collections import defaultdict

logger = logging.getLogger('SafwaanBuddy.NLU')


class NaturalLanguageUnderstanding:
    """Advanced natural language understanding system"""
    
    def __init__(self):
        # Intent patterns
        self.intent_patterns = self._initialize_intent_patterns()
        
        # Entity patterns
        self.entity_patterns = self._initialize_entity_patterns()
        
        # Sentiment lexicon
        self.sentiment_lexicon = self._initialize_sentiment_lexicon()
        
        # Context tracking
        self.conversation_context = deque(maxlen=10)
        
        logger.info("[OK] NLU system initialized")
    
    def _initialize_intent_patterns(self) -> Dict:
        """Initialize intent recognition patterns"""
        return {
            'greeting': [
                r'\b(hello|hi|hey|greetings|good morning|good afternoon|good evening)\b',
                r'\b(what\'s up|how are you|how\'s it going)\b'
            ],
            'farewell': [
                r'\b(goodbye|bye|see you|farewell|take care)\b',
                r'\b(catch you later|talk to you later)\b'
            ],
            'question': [
                r'\b(what|when|where|who|why|how|which)\b',
                r'\?$'
            ],
            'command': [
                r'\b(open|close|start|stop|launch|run|execute)\b',
                r'\b(create|make|build|generate)\b',
                r'\b(search|find|look for|get)\b'
            ],
            'information': [
                r'\b(tell me|show me|explain|describe)\b',
                r'\b(what is|what are|who is)\b'
            ],
            'help': [
                r'\b(help|assist|support)\b',
                r'\b(how do i|how can i|can you help)\b'
            ],
            'confirmation': [
                r'\b(yes|yeah|yep|sure|okay|ok|alright)\b',
                r'\b(correct|right|exactly)\b'
            ],
            'negation': [
                r'\b(no|nope|nah|not really)\b',
                r'\b(incorrect|wrong)\b'
            ],
            'gratitude': [
                r'\b(thank you|thanks|appreciate)\b',
                r'\b(grateful|thankful)\b'
            ],
            'apology': [
                r'\b(sorry|apologize|my bad)\b',
                r'\b(excuse me|pardon)\b'
            ]
        }
    
    def _initialize_entity_patterns(self) -> Dict:
        """Initialize entity extraction patterns"""
        return {
            'time': [
                r'\b(\d{1,2}:\d{2}\s*(?:am|pm)?)\b',
                r'\b(morning|afternoon|evening|night)\b',
                r'\b(today|tomorrow|yesterday)\b',
                r'\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b'
            ],
            'date': [
                r'\b(\d{1,2}/\d{1,2}/\d{2,4})\b',
                r'\b(\d{1,2}-\d{1,2}-\d{2,4})\b',
                r'\b(january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2}\b'
            ],
            'number': [
                r'\b(\d+)\b',
                r'\b(one|two|three|four|five|six|seven|eight|nine|ten)\b'
            ],
            'email': [
                r'\b([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})\b'
            ],
            'url': [
                r'\b(https?://[^\s]+)\b',
                r'\b(www\.[^\s]+)\b'
            ],
            'phone': [
                r'\b(\d{3}[-.]?\d{3}[-.]?\d{4})\b',
                r'\b(\(\d{3}\)\s*\d{3}[-.]?\d{4})\b'
            ],
            'location': [
                r'\b(in|at|near|around)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b'
            ],
            'person': [
                r'\b([A-Z][a-z]+\s+[A-Z][a-z]+)\b'
            ],
            'file': [
                r'\b([a-zA-Z0-9_-]+\.[a-zA-Z0-9]+)\b'
            ],
            'application': [
                r'\b(chrome|firefox|edge|notepad|word|excel|powerpoint|outlook)\b'
            ]
        }
    
    def _initialize_sentiment_lexicon(self) -> Dict:
        """Initialize sentiment analysis lexicon"""
        return {
            'positive': [
                'good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic',
                'love', 'like', 'enjoy', 'happy', 'pleased', 'satisfied',
                'perfect', 'awesome', 'brilliant', 'superb', 'outstanding'
            ],
            'negative': [
                'bad', 'terrible', 'awful', 'horrible', 'poor', 'disappointing',
                'hate', 'dislike', 'unhappy', 'sad', 'angry', 'frustrated',
                'worst', 'useless', 'broken', 'failed', 'error'
            ],
            'neutral': [
                'okay', 'fine', 'alright', 'normal', 'average', 'standard'
            ]
        }
    
    def analyze(self, text: str) -> Dict:
        """Comprehensive NLU analysis"""
        try:
            analysis = {
                'text': text,
                'intent': self.detect_intent(text),
                'entities': self.extract_entities(text),
                'sentiment': self.analyze_sentiment(text),
                'keywords': self.extract_keywords(text),
                'context': self.get_context(),
                'timestamp': datetime.now().isoformat()
            }
            
            # Update context
            self.conversation_context.append(analysis)
            
            return analysis
            
        except Exception as e:
            logger.error(f"[ERROR] NLU analysis failed: {e}")
            return {'error': str(e)}
    
    def detect_intent(self, text: str) -> Dict:
        """Detect user intent"""
        try:
            text_lower = text.lower()
            detected_intents = []
            
            for intent, patterns in self.intent_patterns.items():
                for pattern in patterns:
                    if re.search(pattern, text_lower):
                        detected_intents.append(intent)
                        break
            
            # Determine primary intent
            primary_intent = detected_intents[0] if detected_intents else 'unknown'
            
            return {
                'primary': primary_intent,
                'all': detected_intents,
                'confidence': 0.8 if detected_intents else 0.3
            }
            
        except Exception as e:
            logger.error(f"[ERROR] Intent detection failed: {e}")
            return {'primary': 'unknown', 'all': [], 'confidence': 0.0}
    
    def extract_entities(self, text: str) -> Dict:
        """Extract named entities"""
        try:
            entities = defaultdict(list)
            
            for entity_type, patterns in self.entity_patterns.items():
                for pattern in patterns:
                    matches = re.findall(pattern, text, re.IGNORECASE)
                    if matches:
                        # Handle tuple matches
                        for match in matches:
                            if isinstance(match, tuple):
                                entities[entity_type].extend([m for m in match if m])
                            else:
                                entities[entity_type].append(match)
            
            return dict(entities)
            
        except Exception as e:
            logger.error(f"[ERROR] Entity extraction failed: {e}")
            return {}
    
    def analyze_sentiment(self, text: str) -> Dict:
        """Analyze sentiment"""
        try:
            text_lower = text.lower()
            words = text_lower.split()
            
            scores = {'positive': 0, 'negative': 0, 'neutral': 0}
            
            for word in words:
                for sentiment, lexicon in self.sentiment_lexicon.items():
                    if word in lexicon:
                        scores[sentiment] += 1
            
            # Calculate overall sentiment
            total = sum(scores.values())
            if total == 0:
                return {'sentiment': 'neutral', 'confidence': 0.5, 'scores': scores}
            
            # Determine dominant sentiment
            dominant = max(scores, key=scores.get)
            confidence = scores[dominant] / total
            
            return {
                'sentiment': dominant,
                'confidence': confidence,
                'scores': scores
            }
            
        except Exception as e:
            logger.error(f"[ERROR] Sentiment analysis failed: {e}")
            return {'sentiment': 'neutral', 'confidence': 0.0, 'scores': {}}
    
    def extract_keywords(self, text: str) -> List[str]:
        """Extract important keywords"""
        try:
            # Remove common stop words
            stop_words = {
                'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
                'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'be',
                'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
                'would', 'should', 'could', 'may', 'might', 'must', 'can', 'this',
                'that', 'these', 'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they'
            }
            
            words = text.lower().split()
            keywords = [word for word in words if word not in stop_words and len(word) > 3]
            
            # Remove duplicates while preserving order
            seen = set()
            unique_keywords = []
            for keyword in keywords:
                if keyword not in seen:
                    seen.add(keyword)
                    unique_keywords.append(keyword)
            
            return unique_keywords[:10]  # Return top 10 keywords
            
        except Exception as e:
            logger.error(f"[ERROR] Keyword extraction failed: {e}")
            return []
    
    def get_context(self) -> Dict:
        """Get current conversation context"""
        try:
            if not self.conversation_context:
                return {'history': [], 'topics': [], 'entities': {}}
            
            # Extract topics from recent context
            topics = set()
            entities = defaultdict(list)
            
            for item in self.conversation_context:
                if 'keywords' in item:
                    topics.update(item['keywords'])
                if 'entities' in item:
                    for entity_type, entity_list in item['entities'].items():
                        entities[entity_type].extend(entity_list)
            
            return {
                'history': list(self.conversation_context),
                'topics': list(topics),
                'entities': dict(entities)
            }
            
        except Exception as e:
            logger.error(f"[ERROR] Context retrieval failed: {e}")
            return {'history': [], 'topics': [], 'entities': {}}
    
    def clear_context(self) -> None:
        """Clear conversation context"""
        self.conversation_context.clear()
        logger.info("[OK] Conversation context cleared")