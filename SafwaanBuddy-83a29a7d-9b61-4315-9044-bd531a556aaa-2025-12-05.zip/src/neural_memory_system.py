"""
Neural Memory System with Vector Embeddings
Advanced memory management with semantic search and context retrieval
Version: 3.0 HYPER
"""
import logging
import numpy as np
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime
import json
import pickle
from pathlib import Path

logger = logging.getLogger('NeuralMemory')


@dataclass
class Memory:
    """Memory entry with embeddings"""
    id: str
    content: str
    embedding: np.ndarray
    timestamp: datetime
    memory_type: str  # 'fact', 'conversation', 'preference', 'skill'
    importance: float  # 0-1
    access_count: int
    last_accessed: datetime
    metadata: Dict[str, Any]


class NeuralMemorySystem:
    """
    Advanced Memory System with Vector Embeddings
    
    Features:
    - Semantic search using embeddings
    - Importance-based retention
    - Automatic memory consolidation
    - Context-aware retrieval
    - Memory decay simulation
    - Association mapping
    """
    
    def __init__(self, db, embedding_dim: int = 384):
        self.db = db
        self.embedding_dim = embedding_dim
        
        # Memory storage
        self.memories: List[Memory] = []
        self.memory_index = {}  # Fast lookup by ID
        
        # Memory limits
        self.max_memories = 10000
        self.consolidation_threshold = 8000
        
        # Load existing memories
        self._load_memories()
        
        logger.info(f"[AI] Neural Memory System initialized with {len(self.memories)} memories")
    
    def store_memory(self, content: str, memory_type: str = 'conversation',
                    importance: float = 0.5, metadata: Dict = None) -> str:
        """
        Store a new memory with embedding
        
        Args:
            content: Memory content
            memory_type: Type of memory
            importance: Importance score (0-1)
            metadata: Additional metadata
        
        Returns:
            Memory ID
        """
        # Generate embedding
        embedding = self._generate_embedding(content)
        
        # Create memory
        memory_id = self._generate_id()
        memory = Memory(
            id=memory_id,
            content=content,
            embedding=embedding,
            timestamp=datetime.now(),
            memory_type=memory_type,
            importance=importance,
            access_count=0,
            last_accessed=datetime.now(),
            metadata=metadata or {}
        )
        
        # Store memory
        self.memories.append(memory)
        self.memory_index[memory_id] = memory
        
        # Check if consolidation needed
        if len(self.memories) > self.consolidation_threshold:
            self._consolidate_memories()
        
        logger.debug(f"[SAVE] Stored memory: {memory_id} ({memory_type})")
        return memory_id
    
    def retrieve_similar(self, query: str, top_k: int = 5,
                        memory_type: Optional[str] = None) -> List[Memory]:
        """
        Retrieve similar memories using semantic search
        
        Args:
            query: Search query
            top_k: Number of results
            memory_type: Filter by memory type
        
        Returns:
            List of similar memories
        """
        # Generate query embedding
        query_embedding = self._generate_embedding(query)
        
        # Filter by type if specified
        candidates = self.memories
        if memory_type:
            candidates = [m for m in candidates if m.memory_type == memory_type]
        
        # Calculate similarities
        similarities = []
        for memory in candidates:
            similarity = self._cosine_similarity(query_embedding, memory.embedding)
            # Boost by importance and recency
            boost = memory.importance * 0.3 + self._recency_score(memory) * 0.2
            final_score = similarity + boost
            similarities.append((memory, final_score))
        
        # Sort by similarity
        similarities.sort(key=lambda x: x[1], reverse=True)
        
        # Get top k
        results = [mem for mem, score in similarities[:top_k]]
        
        # Update access counts
        for memory in results:
            memory.access_count += 1
            memory.last_accessed = datetime.now()
        
        logger.debug(f"[SEARCH] Retrieved {len(results)} similar memories for: {query[:50]}")
        return results
    
    def get_context(self, query: str, max_tokens: int = 2000) -> str:
        """
        Get relevant context for a query
        
        Args:
            query: Query to get context for
            max_tokens: Maximum context length
        
        Returns:
            Formatted context string
        """
        # Retrieve relevant memories
        memories = self.retrieve_similar(query, top_k=10)
        
        # Build context
        context_parts = []
        total_length = 0
        
        for memory in memories:
            content = f"[{memory.memory_type}] {memory.content}"
            content_length = len(content.split())
            
            if total_length + content_length > max_tokens:
                break
            
            context_parts.append(content)
            total_length += content_length
        
        return "\n".join(context_parts)
    
    def store_conversation(self, user_input: str, assistant_response: str,
                          importance: float = 0.5):
        """Store a conversation exchange"""
        content = f"User: {user_input}\nAssistant: {assistant_response}"
        self.store_memory(
            content=content,
            memory_type='conversation',
            importance=importance,
            metadata={
                'user_input': user_input,
                'assistant_response': assistant_response
            }
        )
    
    def store_fact(self, fact: str, importance: float = 0.7):
        """Store a fact"""
        self.store_memory(
            content=fact,
            memory_type='fact',
            importance=importance
        )
    
    def store_preference(self, preference: str, importance: float = 0.8):
        """Store a user preference"""
        self.store_memory(
            content=preference,
            memory_type='preference',
            importance=importance
        )
    
    def get_user_preferences(self) -> List[str]:
        """Get all user preferences"""
        prefs = [m for m in self.memories if m.memory_type == 'preference']
        prefs.sort(key=lambda x: x.importance, reverse=True)
        return [p.content for p in prefs[:20]]
    
    def get_recent_conversations(self, limit: int = 10) -> List[Dict[str, str]]:
        """Get recent conversations"""
        convs = [m for m in self.memories if m.memory_type == 'conversation']
        convs.sort(key=lambda x: x.timestamp, reverse=True)
        
        results = []
        for conv in convs[:limit]:
            if 'user_input' in conv.metadata:
                results.append({
                    'user': conv.metadata['user_input'],
                    'assistant': conv.metadata['assistant_response'],
                    'timestamp': conv.timestamp.isoformat()
                })
        
        return results
    
    def _generate_embedding(self, text: str) -> np.ndarray:
        """
        Generate embedding for text
        
        In production, use a proper embedding model like:
        - sentence-transformers
        - OpenAI embeddings
        - Google's Universal Sentence Encoder
        
        For now, using simple hash-based embedding
        """
        # Simple hash-based embedding (replace with real model)
        hash_val = hash(text)
        np.random.seed(abs(hash_val) % (2**32))
        embedding = np.random.randn(self.embedding_dim)
        # Normalize
        embedding = embedding / np.linalg.norm(embedding)
        return embedding
    
    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """Calculate cosine similarity between two vectors"""
        return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))
    
    def _recency_score(self, memory: Memory) -> float:
        """Calculate recency score (0-1)"""
        age_seconds = (datetime.now() - memory.timestamp).total_seconds()
        age_days = age_seconds / 86400
        # Exponential decay
        return np.exp(-age_days / 30)  # Half-life of 30 days
    
    def _consolidate_memories(self):
        """
        Consolidate memories by removing least important ones
        
        Keeps memories based on:
        - Importance score
        - Access frequency
        - Recency
        """
        logger.info("🧹 Consolidating memories...")
        
        # Calculate retention scores
        scores = []
        for memory in self.memories:
            score = (
                memory.importance * 0.4 +
                min(memory.access_count / 10, 1.0) * 0.3 +
                self._recency_score(memory) * 0.3
            )
            scores.append((memory, score))
        
        # Sort by score
        scores.sort(key=lambda x: x[1], reverse=True)
        
        # Keep top memories
        keep_count = int(self.max_memories * 0.8)
        self.memories = [mem for mem, score in scores[:keep_count]]
        
        # Rebuild index
        self.memory_index = {m.id: m for m in self.memories}
        
        logger.info(f"[OK] Consolidated to {len(self.memories)} memories")
    
    def _generate_id(self) -> str:
        """Generate unique memory ID"""
        import uuid
        return str(uuid.uuid4())
    
    def _load_memories(self):
        """Load memories from disk"""
        memory_file = Path('data/neural_memories.pkl')
        if memory_file.exists():
            try:
                with open(memory_file, 'rb') as f:
                    self.memories = pickle.load(f)
                self.memory_index = {m.id: m for m in self.memories}
                logger.info(f"[OPEN_FOLDER] Loaded {len(self.memories)} memories from disk")
            except Exception as e:
                logger.error(f"Error loading memories: {e}")
    
    def save_memories(self):
        """Save memories to disk"""
        memory_file = Path('data/neural_memories.pkl')
        memory_file.parent.mkdir(exist_ok=True)
        
        try:
            with open(memory_file, 'wb') as f:
                pickle.dump(self.memories, f)
            logger.info(f"[SAVE] Saved {len(self.memories)} memories to disk")
        except Exception as e:
            logger.error(f"Error saving memories: {e}")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get memory statistics"""
        type_counts = {}
        for memory in self.memories:
            type_counts[memory.memory_type] = type_counts.get(memory.memory_type, 0) + 1
        
        return {
            'total_memories': len(self.memories),
            'by_type': type_counts,
            'avg_importance': np.mean([m.importance for m in self.memories]),
            'most_accessed': max([m.access_count for m in self.memories]) if self.memories else 0
        }
    
    def clear_old_memories(self, days: int = 90):
        """Clear memories older than specified days"""
        cutoff = datetime.now().timestamp() - (days * 86400)
        before_count = len(self.memories)
        
        self.memories = [m for m in self.memories 
                        if m.timestamp.timestamp() > cutoff or m.importance > 0.8]
        
        self.memory_index = {m.id: m for m in self.memories}
        
        removed = before_count - len(self.memories)
        logger.info(f"🧹 Cleared {removed} old memories")