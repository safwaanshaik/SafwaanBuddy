"""
Neural Voice Engine for SafwaanBuddy ULTIMATE
Ultra-realistic human-like voice with advanced prosody and emotion
"""
import asyncio
import edge_tts
import pygame
import threading
import time
import logging
import random
import re
from pathlib import Path
from typing import Optional, Dict, List
import queue
import numpy as np

logger = logging.getLogger('SafwaanBuddy.NeuralVoice')


class NeuralVoiceEngine:
    """Ultra-realistic neural voice synthesis engine"""
    
    def __init__(self, config_manager):
        self.config = config_manager
        
        # Initialize pygame mixer
        pygame.mixer.init(frequency=24000, size=-16, channels=2, buffer=512)
        
        # Voice personalities with detailed characteristics
        self.personalities = {
            'professional': {
                'voice': 'en-GB-RyanNeural',
                'rate': '+0%',
                'pitch': '+0Hz',
                'volume': '+0%',
                'style': 'professional',
                'description': 'Confident British professional'
            },
            'friendly': {
                'voice': 'en-US-JennyNeural',
                'rate': '+5%',
                'pitch': '+2Hz',
                'volume': '+0%',
                'style': 'friendly',
                'description': 'Warm and approachable American'
            },
            'energetic': {
                'voice': 'en-US-GuyNeural',
                'rate': '+10%',
                'pitch': '+5Hz',
                'volume': '+5%',
                'style': 'excited',
                'description': 'Enthusiastic and dynamic'
            },
            'calm': {
                'voice': 'en-US-AriaNeural',
                'rate': '-5%',
                'pitch': '-2Hz',
                'volume': '-5%',
                'style': 'calm',
                'description': 'Soothing and peaceful'
            },
            'confident': {
                'voice': 'en-US-DavisNeural',
                'rate': '+0%',
                'pitch': '+3Hz',
                'volume': '+5%',
                'style': 'confident',
                'description': 'Strong and assertive'
            },
            'empathetic': {
                'voice': 'en-US-SaraNeural',
                'rate': '-3%',
                'pitch': '+0Hz',
                'volume': '+0%',
                'style': 'empathetic',
                'description': 'Understanding and caring'
            }
        }
        
        self.current_personality = 'friendly'
        self.temp_dir = Path("temp_audio")
        self.temp_dir.mkdir(exist_ok=True)
        
        # Speech queue for smooth playback
        self.speech_queue = queue.Queue()
        self.is_speaking = False
        
        # Prosody controls
        self.prosody_settings = {
            'emphasis_words': ['very', 'really', 'extremely', 'absolutely', 'definitely'],
            'pause_punctuation': {'.': 0.5, ',': 0.3, '!': 0.6, '?': 0.5, ';': 0.4},
            'breathing_intervals': 15  # Add breath every N words
        }
        
        # Emotion-based voice modulation
        self.emotion_modulation = {
            'happy': {'rate': '+8%', 'pitch': '+4Hz', 'volume': '+3%'},
            'sad': {'rate': '-10%', 'pitch': '-5Hz', 'volume': '-8%'},
            'excited': {'rate': '+15%', 'pitch': '+8Hz', 'volume': '+10%'},
            'angry': {'rate': '+5%', 'pitch': '+6Hz', 'volume': '+15%'},
            'calm': {'rate': '-5%', 'pitch': '-2Hz', 'volume': '-5%'},
            'anxious': {'rate': '+12%', 'pitch': '+3Hz', 'volume': '+5%'},
            'confident': {'rate': '+3%', 'pitch': '+4Hz', 'volume': '+8%'},
            'neutral': {'rate': '+0%', 'pitch': '+0Hz', 'volume': '+0%'}
        }
        
        logger.info("Neural Voice Engine initialized")
    
    def speak(self, text: str, emotion: str = 'neutral', personality: str = None, 
              blocking: bool = True) -> bool:
        """
        Speak text with ultra-realistic voice
        
        Args:
            text: Text to speak
            emotion: Emotional tone (happy, sad, excited, etc.)
            personality: Voice personality to use
            blocking: Wait for speech to complete
        """
        try:
            if not text or not text.strip():
                return False
            
            # Use specified personality or current
            personality = personality or self.current_personality
            
            # Enhance text with prosody
            enhanced_text = self._add_prosody(text, emotion)
            
            # Get voice settings
            voice_config = self._get_voice_config(personality, emotion)
            
            logger.info(f"Speaking: {text[:50]}... [Emotion: {emotion}, Personality: {personality}]")
            
            # Generate and play speech
            if blocking:
                asyncio.run(self._speak_async(enhanced_text, voice_config))
            else:
                threading.Thread(
                    target=lambda: asyncio.run(self._speak_async(enhanced_text, voice_config)),
                    daemon=True
                ).start()
            
            return True
            
        except Exception as e:
            logger.error(f"Speech error: {e}")
            return False
    
    def _add_prosody(self, text: str, emotion: str) -> str:
        """
        Add prosody markers for natural speech
        Includes pauses, emphasis, breathing, and natural variations
        """
        # Add thinking sounds for natural feel
        thinking_sounds = ['um', 'uh', 'hmm', 'well', 'you know', 'let me see']
        
        # Add natural pauses
        text = self._add_natural_pauses(text)
        
        # Add emphasis to important words
        text = self._add_emphasis(text)
        
        # Add breathing pauses
        text = self._add_breathing(text)
        
        # Add emotion-specific variations
        text = self._add_emotional_variations(text, emotion)
        
        return text
    
    def _add_natural_pauses(self, text: str) -> str:
        """Add natural pauses at punctuation"""
        for punct, duration in self.prosody_settings['pause_punctuation'].items():
            # Add SSML break tags
            text = text.replace(punct, f'{punct}<break time="{int(duration*1000)}ms"/>')
        
        return text
    
    def _add_emphasis(self, text: str) -> str:
        """Add emphasis to important words"""
        words = text.split()
        result = []
        
        for word in words:
            # Check if word should be emphasized
            word_lower = word.lower().strip('.,!?;:')
            if word_lower in self.prosody_settings['emphasis_words']:
                result.append(f'<emphasis level="strong">{word}</emphasis>')
            else:
                result.append(word)
        
        return ' '.join(result)
    
    def _add_breathing(self, text: str) -> str:
        """Add natural breathing pauses"""
        words = text.split()
        result = []
        
        for i, word in enumerate(words):
            result.append(word)
            # Add breath every N words
            if (i + 1) % self.prosody_settings['breathing_intervals'] == 0:
                result.append('<break time="200ms"/>')
        
        return ' '.join(result)
    
    def _add_emotional_variations(self, text: str, emotion: str) -> str:
        """Add emotion-specific speech variations"""
        if emotion == 'excited':
            # Add exclamation emphasis
            text = text.replace('.', '!')
        elif emotion == 'sad':
            # Add longer pauses
            text = text.replace('.', '.<break time="800ms"/>')
        elif emotion == 'happy':
            # Add upbeat tone
            text = f'<prosody pitch="+5%">{text}</prosody>'
        
        return text
    
    def _get_voice_config(self, personality: str, emotion: str) -> Dict:
        """Get voice configuration with emotion modulation"""
        base_config = self.personalities.get(personality, self.personalities['friendly'])
        emotion_mod = self.emotion_modulation.get(emotion, self.emotion_modulation['neutral'])
        
        # Combine base and emotion settings
        return {
            'voice': base_config['voice'],
            'rate': emotion_mod['rate'],
            'pitch': emotion_mod['pitch'],
            'volume': emotion_mod['volume']
        }
    
    async def _speak_async(self, text: str, voice_config: Dict):
        """Asynchronous speech generation and playback"""
        try:
            self.is_speaking = True
            
            # Generate unique filename
            audio_file = self.temp_dir / f"speech_{int(time.time()*1000)}.mp3"
            
            # Create TTS communicate object
            communicate = edge_tts.Communicate(
                text,
                voice_config['voice'],
                rate=voice_config['rate'],
                pitch=voice_config['pitch'],
                volume=voice_config['volume']
            )
            
            # Save audio
            await communicate.save(str(audio_file))
            
            # Play audio
            pygame.mixer.music.load(str(audio_file))
            pygame.mixer.music.play()
            
            # Wait for completion
            while pygame.mixer.music.get_busy():
                await asyncio.sleep(0.1)
            
            # Cleanup
            try:
                audio_file.unlink()
            except:
                pass
            
            self.is_speaking = False
            
        except Exception as e:
            logger.error(f"Async speech error: {e}")
            self.is_speaking = False
    
    def change_personality(self, personality: str) -> bool:
        """Change voice personality"""
        if personality in self.personalities:
            self.current_personality = personality
            logger.info(f"Personality changed to: {personality}")
            return True
        return False
    
    def get_available_personalities(self) -> Dict:
        """Get all available personalities with descriptions"""
        return {
            name: config['description'] 
            for name, config in self.personalities.items()
        }
    
    def stop_speaking(self):
        """Stop current speech"""
        try:
            pygame.mixer.music.stop()
            self.is_speaking = False
            logger.info("Speech stopped")
        except Exception as e:
            logger.error(f"Stop speech error: {e}")
    
    def is_currently_speaking(self) -> bool:
        """Check if currently speaking"""
        return self.is_speaking
    
    def cleanup(self):
        """Cleanup resources"""
        try:
            self.stop_speaking()
            pygame.mixer.quit()
            
            # Clean temp files
            for file in self.temp_dir.glob("*.mp3"):
                try:
                    file.unlink()
                except:
                    pass
            
            logger.info("Neural Voice Engine cleanup completed")
        except Exception as e:
            logger.error(f"Cleanup error: {e}")