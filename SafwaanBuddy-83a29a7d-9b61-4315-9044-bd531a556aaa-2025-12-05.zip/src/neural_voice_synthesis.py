"""
Neural Voice Synthesis for SafwaanBuddy ULTIMATE
Ultra-realistic voice with prosody, intonation, emotion, and natural speech patterns
"""
import asyncio
import edge_tts
import pygame
import threading
import time
import logging
import random
import re
from pathlib import Path
from typing import Optional, Dict, List, Tuple
import queue

logger = logging.getLogger('SafwaanBuddy.NeuralVoice')


class NeuralVoiceSynthesis:
    """Ultra-realistic neural voice synthesis engine"""
    
    def __init__(self, config_manager):
        self.config = config_manager
        
        # Initialize pygame mixer
        pygame.mixer.init(frequency=24000, size=-16, channels=2, buffer=512)
        
        # Voice settings
        self.current_voice = 'en-US-JennyNeural'
        self.speech_rate = '+0%'
        self.speech_volume = '+0%'
        self.speech_pitch = '+0Hz'
        
        # Prosody control
        self.prosody_controller = ProsodyController()
        self.intonation_engine = IntonationEngine()
        self.emotion_modulator = EmotionVoiceModulator()
        
        # Natural speech patterns
        self.speech_pattern_generator = NaturalSpeechPatternGenerator()
        self.breathing_controller = BreathingController()
        
        # Multi-language support
        self.language_manager = MultiLanguageVoiceManager()
        
        # Voice queue
        self.voice_queue = queue.Queue()
        self.is_speaking = False
        
        # Temp directory
        self.temp_dir = Path("temp_audio")
        self.temp_dir.mkdir(exist_ok=True)
        
        logger.info("[OK] Neural voice synthesis initialized")
    
    async def speak_async(self, text: str, emotion: str = 'neutral', language: str = 'en-US') -> None:
        """
        Speak text with emotion and natural patterns
        
        Args:
            text: Text to speak
            emotion: Emotional tone
            language: Language code
        """
        try:
            # Add natural speech patterns
            enhanced_text = self.speech_pattern_generator.enhance_text(text, emotion)
            
            # Add breathing pauses
            enhanced_text = self.breathing_controller.add_breathing(enhanced_text)
            
            # Get voice for language
            voice = self.language_manager.get_voice(language)
            
            # Apply prosody
            prosody_params = self.prosody_controller.get_prosody_params(emotion)
            
            # Apply intonation
            ssml_text = self.intonation_engine.apply_intonation(enhanced_text, emotion)
            
            # Apply emotion modulation
            rate, pitch, volume = self.emotion_modulator.get_voice_params(emotion)
            
            # Generate speech
            communicate = edge_tts.Communicate(
                ssml_text,
                voice,
                rate=rate,
                pitch=pitch,
                volume=volume
            )
            
            # Save to temp file
            temp_file = self.temp_dir / f"speech_{int(time.time() * 1000)}.mp3"
            await communicate.save(str(temp_file))
            
            # Play audio
            self._play_audio(temp_file)
            
            # Cleanup
            if temp_file.exists():
                temp_file.unlink()
            
            logger.info(f"[OK] Spoke with emotion: {emotion}")
            
        except Exception as e:
            logger.error(f"[ERROR] Speech synthesis failed: {e}")
    
    def speak(self, text: str, emotion: str = 'neutral', language: str = 'en-US') -> None:
        """Synchronous speak wrapper"""
        asyncio.run(self.speak_async(text, emotion, language))
    
    def _play_audio(self, audio_file: Path) -> None:
        """Play audio file"""
        try:
            self.is_speaking = True
            pygame.mixer.music.load(str(audio_file))
            pygame.mixer.music.play()
            
            while pygame.mixer.music.get_busy():
                time.sleep(0.1)
            
            self.is_speaking = False
            
        except Exception as e:
            logger.error(f"[ERROR] Audio playback failed: {e}")
            self.is_speaking = False
    
    def stop(self) -> None:
        """Stop speaking"""
        pygame.mixer.music.stop()
        self.is_speaking = False
    
    def set_voice(self, voice_name: str) -> None:
        """Set voice"""
        self.current_voice = voice_name
        logger.info(f"[OK] Voice set to: {voice_name}")


class ProsodyController:
    """Controls prosody (rhythm, stress, intonation)"""
    
    def get_prosody_params(self, emotion: str) -> Dict:
        """Get prosody parameters for emotion"""
        prosody_map = {
            'happy': {'rate': '+10%', 'pitch': '+5Hz', 'volume': '+5%'},
            'sad': {'rate': '-10%', 'pitch': '-5Hz', 'volume': '-5%'},
            'excited': {'rate': '+20%', 'pitch': '+10Hz', 'volume': '+10%'},
            'angry': {'rate': '+15%', 'pitch': '+8Hz', 'volume': '+15%'},
            'calm': {'rate': '-5%', 'pitch': '-2Hz', 'volume': '+0%'},
            'neutral': {'rate': '+0%', 'pitch': '+0Hz', 'volume': '+0%'}
        }
        
        return prosody_map.get(emotion, prosody_map['neutral'])


class IntonationEngine:
    """Controls intonation patterns"""
    
    def apply_intonation(self, text: str, emotion: str) -> str:
        """Apply intonation using SSML"""
        # Add emphasis to important words
        text = self._add_emphasis(text)
        
        # Add prosody tags
        prosody = self._get_prosody_tags(emotion)
        
        ssml = f'<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="en-US">'
        ssml += f'<prosody {prosody}>{text}</prosody>'
        ssml += '</speak>'
        
        return ssml
    
    def _add_emphasis(self, text: str) -> str:
        """Add emphasis to important words"""
        # Emphasize words in ALL CAPS
        text = re.sub(r'\b([A-Z]{2,})\b', r'<emphasis level="strong">\1</emphasis>', text)
        
        return text
    
    def _get_prosody_tags(self, emotion: str) -> str:
        """Get SSML prosody tags"""
        prosody_map = {
            'happy': 'rate="fast" pitch="high"',
            'sad': 'rate="slow" pitch="low"',
            'excited': 'rate="x-fast" pitch="x-high"',
            'angry': 'rate="fast" pitch="high" volume="loud"',
            'calm': 'rate="slow" pitch="medium"',
            'neutral': 'rate="medium" pitch="medium"'
        }
        
        return prosody_map.get(emotion, prosody_map['neutral'])


class EmotionVoiceModulator:
    """Modulates voice parameters based on emotion"""
    
    def get_voice_params(self, emotion: str) -> Tuple[str, str, str]:
        """Get rate, pitch, volume for emotion"""
        params_map = {
            'happy': ('+10%', '+5Hz', '+5%'),
            'sad': ('-10%', '-5Hz', '-5%'),
            'excited': ('+20%', '+10Hz', '+10%'),
            'angry': ('+15%', '+8Hz', '+15%'),
            'calm': ('-5%', '-2Hz', '+0%'),
            'anxious': ('+5%', '+3Hz', '+2%'),
            'confident': ('+5%', '+2Hz', '+5%'),
            'neutral': ('+0%', '+0Hz', '+0%')
        }
        
        return params_map.get(emotion, params_map['neutral'])


class NaturalSpeechPatternGenerator:
    """Generates natural speech patterns with fillers"""
    
    def __init__(self):
        self.fillers = {
            'thinking': ['um', 'uh', 'hmm', 'well', 'let me think'],
            'transition': ['so', 'now', 'okay', 'alright', 'anyway'],
            'emphasis': ['actually', 'really', 'definitely', 'absolutely'],
            'softening': ['kind of', 'sort of', 'maybe', 'perhaps']
        }
    
    def enhance_text(self, text: str, emotion: str) -> str:
        """Add natural speech patterns"""
        # Add thinking fillers for complex responses
        if len(text) > 100:
            text = self._add_thinking_fillers(text)
        
        # Add transitions
        text = self._add_transitions(text)
        
        # Add emphasis based on emotion
        if emotion in ['excited', 'happy']:
            text = self._add_emphasis_words(text)
        
        return text
    
    def _add_thinking_fillers(self, text: str) -> str:
        """Add thinking fillers"""
        sentences = text.split('. ')
        if len(sentences) > 2:
            filler = random.choice(self.fillers['thinking'])
            sentences[1] = f"{filler}, {sentences[1]}"
        
        return '. '.join(sentences)
    
    def _add_transitions(self, text: str) -> str:
        """Add transition words"""
        sentences = text.split('. ')
        if len(sentences) > 3:
            transition = random.choice(self.fillers['transition'])
            sentences[2] = f"{transition}, {sentences[2]}"
        
        return '. '.join(sentences)
    
    def _add_emphasis_words(self, text: str) -> str:
        """Add emphasis words"""
        if random.random() < 0.3:
            emphasis = random.choice(self.fillers['emphasis'])
            text = f"{emphasis}, {text}"
        
        return text


class BreathingController:
    """Adds natural breathing pauses"""
    
    def add_breathing(self, text: str) -> str:
        """Add breathing pauses"""
        # Add pauses after long sentences
        text = re.sub(r'([.!?])\s+', r'\1 <break time="300ms"/> ', text)
        
        # Add shorter pauses after commas
        text = re.sub(r',\s+', r', <break time="150ms"/> ', text)
        
        # Add breathing before long phrases
        sentences = text.split('. ')
        enhanced_sentences = []
        
        for sentence in sentences:
            if len(sentence) > 80:
                # Add breath in middle
                words = sentence.split()
                mid = len(words) // 2
                words.insert(mid, '<break time="200ms"/>')
                sentence = ' '.join(words)
            
            enhanced_sentences.append(sentence)
        
        return '. '.join(enhanced_sentences)


class MultiLanguageVoiceManager:
    """Manages multi-language voices with accents"""
    
    def __init__(self):
        self.voices = {
            'en-US': 'en-US-JennyNeural',
            'en-GB': 'en-GB-SoniaNeural',
            'en-IN': 'en-IN-NeerjaNeural',
            'hi-IN': 'hi-IN-SwaraNeural',
            'es-ES': 'es-ES-ElviraNeural',
            'fr-FR': 'fr-FR-DeniseNeural',
            'de-DE': 'de-DE-KatjaNeural',
            'ja-JP': 'ja-JP-NanamiNeural',
            'zh-CN': 'zh-CN-XiaoxiaoNeural'
        }
        
        self.accents = {
            'american': 'en-US-JennyNeural',
            'british': 'en-GB-RyanNeural',
            'indian': 'en-IN-NeerjaNeural',
            'australian': 'en-AU-NatashaNeural'
        }
    
    def get_voice(self, language: str, accent: Optional[str] = None) -> str:
        """Get voice for language and accent"""
        if accent:
            return self.accents.get(accent, self.voices.get(language, 'en-US-JennyNeural'))
        
        return self.voices.get(language, 'en-US-JennyNeural')
    
    def list_available_voices(self) -> Dict:
        """List all available voices"""
        return {
            'languages': self.voices,
            'accents': self.accents
        }