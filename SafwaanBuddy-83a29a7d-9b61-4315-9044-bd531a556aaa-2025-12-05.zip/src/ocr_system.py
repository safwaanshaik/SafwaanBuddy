"""
OCR System for SafwaanBuddy
Advanced text extraction and screen reading
"""
import logging
from PIL import Image, ImageGrab
import numpy as np
from typing import Optional, List, Dict, Tuple
import pyautogui

logger = logging.getLogger('SafwaanBuddy.OCR')


class OCRSystem:
    """Advanced OCR and text extraction"""
    
    def __init__(self):
        self.ocr_available = self._check_ocr()
        self.tesseract_cmd = None
        
        if self.ocr_available:
            self._configure_tesseract()
        
        logger.info(f"[OK] OCR System initialized - Available: {self.ocr_available}")
    
    def _check_ocr(self) -> bool:
        """Check if Tesseract OCR is available"""
        try:
            import pytesseract
            return True
        except ImportError:
            logger.warning("pytesseract not installed - OCR features limited")
            return False
    
    def _configure_tesseract(self):
        """Configure Tesseract path"""
        try:
            import pytesseract
            
            # Common Tesseract installation paths
            possible_paths = [
                r'C:\Program Files\Tesseract-OCR\tesseract.exe',
                r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe',
                r'C:\Tesseract-OCR\tesseract.exe',
                '/usr/bin/tesseract',
                '/usr/local/bin/tesseract'
            ]
            
            for path in possible_paths:
                import os
                if os.path.exists(path):
                    pytesseract.pytesseract.tesseract_cmd = path
                    self.tesseract_cmd = path
                    logger.info(f"[OK] Tesseract found: {path}")
                    return
            
            logger.warning("Tesseract executable not found in common locations")
        except Exception as e:
            logger.error(f"Tesseract configuration error: {e}")
    
    def extract_text_from_screen(self, region: Optional[Tuple[int, int, int, int]] = None) -> str:
        """Extract text from screen or region"""
        try:
            if not self.ocr_available:
                return self._fallback_text_extraction(region)
            
            import pytesseract
            
            # Capture screen
            if region:
                screenshot = ImageGrab.grab(bbox=region)
            else:
                screenshot = ImageGrab.grab()
            
            # Extract text
            text = pytesseract.image_to_string(screenshot)
            
            logger.info(f"[OK] Extracted {len(text)} characters")
            return text.strip()
            
        except Exception as e:
            logger.error(f"OCR extraction error: {e}")
            return ""
    
    def _fallback_text_extraction(self, region: Optional[Tuple] = None) -> str:
        """Fallback text extraction without Tesseract"""
        try:
            # Use Windows built-in OCR if available
            import subprocess
            
            # Save screenshot
            if region:
                screenshot = ImageGrab.grab(bbox=region)
            else:
                screenshot = ImageGrab.grab()
            
            screenshot.save('temp_ocr.png')
            
            # Try Windows OCR via PowerShell
            ps_script = """
            Add-Type -AssemblyName System.Runtime.WindowsRuntime
            $null = [Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]
            $null = [Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime]
            
            $file = [Windows.Storage.StorageFile]::GetFileFromPathAsync('temp_ocr.png').GetResults()
            $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
            $result = $engine.RecognizeAsync($file).GetResults()
            $result.Text
            """
            
            result = subprocess.run(['powershell', '-Command', ps_script],
                                  capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                return result.stdout.strip()
                
        except Exception as e:
            logger.error(f"Fallback OCR error: {e}")
        
        return "OCR not available - please install Tesseract"
    
    def find_text_on_screen(self, text: str) -> Optional[Tuple[int, int]]:
        """Find text on screen and return coordinates"""
        try:
            if not self.ocr_available:
                logger.warning("OCR not available for text finding")
                return None
            
            import pytesseract
            
            # Capture screen
            screenshot = ImageGrab.grab()
            
            # Get text with bounding boxes
            data = pytesseract.image_to_data(screenshot, output_type=pytesseract.Output.DICT)
            
            # Search for text
            text_lower = text.lower()
            for i, word in enumerate(data['text']):
                if text_lower in word.lower():
                    x = data['left'][i] + data['width'][i] // 2
                    y = data['top'][i] + data['height'][i] // 2
                    logger.info(f"[OK] Found '{text}' at ({x}, {y})")
                    return (x, y)
            
            logger.info(f"[*] Text '{text}' not found on screen")
            return None
            
        except Exception as e:
            logger.error(f"Find text error: {e}")
        return None
    
    def click_text(self, text: str) -> bool:
        """Find and click text on screen"""
        try:
            coords = self.find_text_on_screen(text)
            if coords:
                pyautogui.click(coords[0], coords[1])
                logger.info(f"[OK] Clicked on '{text}'")
                return True
            return False
        except Exception as e:
            logger.error(f"Click text error: {e}")
        return False
    
    def read_screen_region(self, x: int, y: int, width: int, height: int) -> str:
        """Read text from specific screen region"""
        try:
            region = (x, y, x + width, y + height)
            return self.extract_text_from_screen(region)
        except Exception as e:
            logger.error(f"Read region error: {e}")
        return ""
    
    def get_all_text_locations(self) -> List[Dict]:
        """Get all text on screen with locations"""
        try:
            if not self.ocr_available:
                return []
            
            import pytesseract
            
            screenshot = ImageGrab.grab()
            data = pytesseract.image_to_data(screenshot, output_type=pytesseract.Output.DICT)
            
            text_locations = []
            for i in range(len(data['text'])):
                if data['text'][i].strip():
                    text_locations.append({
                        'text': data['text'][i],
                        'x': data['left'][i],
                        'y': data['top'][i],
                        'width': data['width'][i],
                        'height': data['height'][i],
                        'confidence': data['conf'][i]
                    })
            
            return text_locations
            
        except Exception as e:
            logger.error(f"Get text locations error: {e}")
        return []
    
    def extract_numbers_from_screen(self) -> List[str]:
        """Extract all numbers from screen"""
        try:
            text = self.extract_text_from_screen()
            import re
            numbers = re.findall(r'\d+(?:\.\d+)?', text)
            return numbers
        except Exception as e:
            logger.error(f"Extract numbers error: {e}")
        return []
    
    def extract_emails_from_screen(self) -> List[str]:
        """Extract email addresses from screen"""
        try:
            text = self.extract_text_from_screen()
            import re
            emails = re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text)
            return emails
        except Exception as e:
            logger.error(f"Extract emails error: {e}")
        return []
    
    def extract_urls_from_screen(self) -> List[str]:
        """Extract URLs from screen"""
        try:
            text = self.extract_text_from_screen()
            import re
            urls = re.findall(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', text)
            return urls
        except Exception as e:
            logger.error(f"Extract URLs error: {e}")
        return []