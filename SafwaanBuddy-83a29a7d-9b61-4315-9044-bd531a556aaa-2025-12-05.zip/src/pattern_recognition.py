"""
Deep Learning Pattern Recognition for SafwaanBuddy ULTIMATE
Advanced pattern detection, learning, and prediction
"""
import logging
import numpy as np
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime, timedelta
from collections import defaultdict, deque
import json

logger = logging.getLogger('SafwaanBuddy.PatternRecognition')


class PatternRecognitionEngine:
    """Advanced pattern recognition with deep learning"""
    
    def __init__(self, db_manager):
        self.db = db_manager
        
        # Pattern storage
        self.temporal_patterns = defaultdict(list)  # Time-based patterns
        self.behavioral_patterns = defaultdict(list)  # User behavior patterns
        self.contextual_patterns = defaultdict(list)  # Context-based patterns
        self.sequential_patterns = deque(maxlen=1000)  # Sequential patterns
        
        # Pattern weights
        self.pattern_weights = {}
        
        # Learning parameters
        self.learning_rate = 0.1
        self.decay_factor = 0.95
        self.confidence_threshold = 0.7
        
        # Load existing patterns
        self._load_patterns()
        
        logger.info("[OK] Pattern recognition engine initialized")
    
    def _load_patterns(self):
        """Load patterns from database"""
        try:
            patterns = self.db.get_all_patterns()
            for pattern in patterns:
                pattern_type = pattern.get('type')
                if pattern_type == 'temporal':
                    self.temporal_patterns[pattern['key']].append(pattern)
                elif pattern_type == 'behavioral':
                    self.behavioral_patterns[pattern['key']].append(pattern)
                elif pattern_type == 'contextual':
                    self.contextual_patterns[pattern['key']].append(pattern)
            
            logger.info(f"[OK] Loaded {len(patterns)} patterns")
        except Exception as e:
            logger.error(f"[ERROR] Pattern loading failed: {e}")
    
    def learn_pattern(self, event: Dict, context: Dict = None):
        """
        Learn new pattern from event
        
        Args:
            event: Event data (action, time, result, etc.)
            context: Additional context
        """
        try:
            # Extract pattern features
            features = self._extract_features(event, context)
            
            # Detect pattern type
            pattern_type = self._detect_pattern_type(features)
            
            # Store pattern
            pattern = {
                'features': features,
                'type': pattern_type,
                'timestamp': datetime.now(),
                'frequency': 1,
                'confidence': 0.5
            }
            
            # Update existing or create new
            self._update_pattern(pattern)
            
            # Save to database
            self.db.save_pattern(pattern)
            
            logger.info(f"[OK] Learned {pattern_type} pattern")
            
        except Exception as e:
            logger.error(f"[ERROR] Pattern learning failed: {e}")
    
    def _extract_features(self, event: Dict, context: Dict = None) -> Dict:
        """Extract features from event"""
        features = {
            'action': event.get('action'),
            'hour': datetime.now().hour,
            'day_of_week': datetime.now().weekday(),
            'result': event.get('result'),
            'duration': event.get('duration', 0)
        }
        
        if context:
            features.update({
                'location': context.get('location'),
                'previous_action': context.get('previous_action'),
                'user_state': context.get('user_state')
            })
        
        return features
    
    def _detect_pattern_type(self, features: Dict) -> str:
        """Detect type of pattern"""
        # Temporal pattern (time-based)
        if 'hour' in features or 'day_of_week' in features:
            return 'temporal'
        
        # Behavioral pattern (action-based)
        if 'action' in features and 'result' in features:
            return 'behavioral'
        
        # Contextual pattern (context-based)
        if 'location' in features or 'user_state' in features:
            return 'contextual'
        
        return 'general'
    
    def _update_pattern(self, new_pattern: Dict):
        """Update existing pattern or create new"""
        pattern_type = new_pattern['type']
        features = new_pattern['features']
        
        # Generate pattern key
        key = self._generate_pattern_key(features)
        
        # Find similar patterns
        if pattern_type == 'temporal':
            patterns = self.temporal_patterns[key]
        elif pattern_type == 'behavioral':
            patterns = self.behavioral_patterns[key]
        elif pattern_type == 'contextual':
            patterns = self.contextual_patterns[key]
        else:
            return
        
        # Check for similar pattern
        similar = self._find_similar_pattern(new_pattern, patterns)
        
        if similar:
            # Update existing pattern
            similar['frequency'] += 1
            similar['confidence'] = min(1.0, similar['confidence'] + self.learning_rate)
            similar['last_seen'] = datetime.now()
        else:
            # Add new pattern
            new_pattern['key'] = key
            patterns.append(new_pattern)
    
    def _generate_pattern_key(self, features: Dict) -> str:
        """Generate unique key for pattern"""
        key_parts = []
        for k, v in sorted(features.items()):
            if v is not None:
                key_parts.append(f"{k}:{v}")
        return "|".join(key_parts)
    
    def _find_similar_pattern(self, pattern: Dict, patterns: List[Dict]) -> Optional[Dict]:
        """Find similar pattern in list"""
        for p in patterns:
            if self._calculate_similarity(pattern['features'], p['features']) > 0.8:
                return p
        return None
    
    def _calculate_similarity(self, features1: Dict, features2: Dict) -> float:
        """Calculate similarity between two feature sets"""
        common_keys = set(features1.keys()) & set(features2.keys())
        if not common_keys:
            return 0.0
        
        matches = sum(1 for k in common_keys if features1[k] == features2[k])
        return matches / len(common_keys)
    
    def predict_next_action(self, context: Dict) -> Optional[Dict]:
        """
        Predict next likely action based on patterns
        
        Args:
            context: Current context
            
        Returns:
            Predicted action with confidence
        """
        try:
            # Extract current features
            current_features = {
                'hour': datetime.now().hour,
                'day_of_week': datetime.now().weekday(),
                'location': context.get('location'),
                'previous_action': context.get('previous_action')
            }
            
            # Find matching patterns
            matches = []
            
            # Check temporal patterns
            for key, patterns in self.temporal_patterns.items():
                for pattern in patterns:
                    similarity = self._calculate_similarity(current_features, pattern['features'])
                    if similarity > 0.6:
                        matches.append({
                            'pattern': pattern,
                            'similarity': similarity,
                            'confidence': pattern['confidence']
                        })
            
            # Check behavioral patterns
            for key, patterns in self.behavioral_patterns.items():
                for pattern in patterns:
                    similarity = self._calculate_similarity(current_features, pattern['features'])
                    if similarity > 0.6:
                        matches.append({
                            'pattern': pattern,
                            'similarity': similarity,
                            'confidence': pattern['confidence']
                        })
            
            if not matches:
                return None
            
            # Select best match
            best_match = max(matches, key=lambda x: x['similarity'] * x['confidence'])
            
            if best_match['confidence'] < self.confidence_threshold:
                return None
            
            return {
                'action': best_match['pattern']['features'].get('action'),
                'confidence': best_match['confidence'],
                'reasoning': f"Based on {best_match['pattern']['type']} pattern"
            }
            
        except Exception as e:
            logger.error(f"[ERROR] Prediction failed: {e}")
            return None
    
    def detect_anomaly(self, event: Dict, context: Dict = None) -> bool:
        """
        Detect if event is anomalous based on learned patterns
        
        Args:
            event: Event to check
            context: Additional context
            
        Returns:
            True if anomalous
        """
        try:
            features = self._extract_features(event, context)
            
            # Check against all patterns
            all_patterns = []
            all_patterns.extend([p for patterns in self.temporal_patterns.values() for p in patterns])
            all_patterns.extend([p for patterns in self.behavioral_patterns.values() for p in patterns])
            all_patterns.extend([p for patterns in self.contextual_patterns.values() for p in patterns])
            
            # Calculate similarity to known patterns
            max_similarity = 0.0
            for pattern in all_patterns:
                similarity = self._calculate_similarity(features, pattern['features'])
                max_similarity = max(max_similarity, similarity)
            
            # Anomaly if very different from all patterns
            return max_similarity < 0.3
            
        except Exception as e:
            logger.error(f"[ERROR] Anomaly detection failed: {e}")
            return False
    
    def get_pattern_insights(self) -> Dict:
        """Get insights about learned patterns"""
        insights = {
            'total_patterns': 0,
            'temporal_patterns': len(self.temporal_patterns),
            'behavioral_patterns': len(self.behavioral_patterns),
            'contextual_patterns': len(self.contextual_patterns),
            'most_common_actions': [],
            'peak_hours': [],
            'confidence_distribution': {}
        }
        
        # Count total patterns
        for patterns in self.temporal_patterns.values():
            insights['total_patterns'] += len(patterns)
        for patterns in self.behavioral_patterns.values():
            insights['total_patterns'] += len(patterns)
        for patterns in self.contextual_patterns.values():
            insights['total_patterns'] += len(patterns)
        
        # Find most common actions
        action_counts = defaultdict(int)
        for patterns in self.behavioral_patterns.values():
            for pattern in patterns:
                action = pattern['features'].get('action')
                if action:
                    action_counts[action] += pattern['frequency']
        
        insights['most_common_actions'] = sorted(
            action_counts.items(), 
            key=lambda x: x[1], 
            reverse=True
        )[:5]
        
        # Find peak hours
        hour_counts = defaultdict(int)
        for patterns in self.temporal_patterns.values():
            for pattern in patterns:
                hour = pattern['features'].get('hour')
                if hour is not None:
                    hour_counts[hour] += pattern['frequency']
        
        insights['peak_hours'] = sorted(
            hour_counts.items(), 
            key=lambda x: x[1], 
            reverse=True
        )[:3]
        
        return insights
    
    def decay_patterns(self):
        """Decay old patterns to forget unused ones"""
        try:
            current_time = datetime.now()
            
            # Decay temporal patterns
            for key, patterns in list(self.temporal_patterns.items()):
                for pattern in patterns[:]:
                    days_old = (current_time - pattern['timestamp']).days
                    if days_old > 30:
                        pattern['confidence'] *= self.decay_factor
                        if pattern['confidence'] < 0.1:
                            patterns.remove(pattern)
                
                if not patterns:
                    del self.temporal_patterns[key]
            
            # Decay behavioral patterns
            for key, patterns in list(self.behavioral_patterns.items()):
                for pattern in patterns[:]:
                    days_old = (current_time - pattern['timestamp']).days
                    if days_old > 30:
                        pattern['confidence'] *= self.decay_factor
                        if pattern['confidence'] < 0.1:
                            patterns.remove(pattern)
                
                if not patterns:
                    del self.behavioral_patterns[key]
            
            logger.info("[OK] Pattern decay completed")
            
        except Exception as e:
            logger.error(f"[ERROR] Pattern decay failed: {e}")