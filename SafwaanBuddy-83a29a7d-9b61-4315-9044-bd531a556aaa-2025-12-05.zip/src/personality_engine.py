"""
Personality Engine for SafwaanBuddy ULTIMATE
Dynamic personality with traits, moods, and adaptive behavior
"""
import logging
import random
from typing import Dict, List, Optional, Tuple
from datetime import datetime
from collections import deque
import json

logger = logging.getLogger('SafwaanBuddy.Personality')


class PersonalityEngine:
    """Advanced personality system with dynamic traits and moods"""
    
    def __init__(self, config_manager):
        self.config = config_manager
        
        # Personality traits (Big Five model)
        self.traits = {
            'openness': 0.8,          # Creativity, curiosity
            'conscientiousness': 0.7,  # Organization, dependability
            'extraversion': 0.6,       # Sociability, assertiveness
            'agreeableness': 0.9,      # Compassion, cooperation
            'neuroticism': 0.2         # Emotional stability
        }
        
        # Current mood state
        self.mood = {
            'valence': 0.7,  # Positive (1.0) to Negative (0.0)
            'arousal': 0.5,  # High energy (1.0) to Low energy (0.0)
            'dominance': 0.6 # Dominant (1.0) to Submissive (0.0)
        }
        
        # Personality profiles
        self.profiles = self._initialize_profiles()
        self.current_profile = 'friendly'
        
        # Mood history
        self.mood_history = deque(maxlen=100)
        
        # Response styles
        self.response_styles = self._initialize_response_styles()
        
        logger.info(f"[OK] Personality engine initialized with profile: {self.current_profile}")
    
    def _initialize_profiles(self) -> Dict:
        """Initialize personality profiles"""
        return {
            'friendly': {
                'name': 'Friendly',
                'description': 'Warm, approachable, and helpful',
                'traits': {
                    'openness': 0.8,
                    'conscientiousness': 0.7,
                    'extraversion': 0.8,
                    'agreeableness': 0.9,
                    'neuroticism': 0.2
                },
                'voice_style': 'warm',
                'response_style': 'casual',
                'emoji_usage': 'moderate'
            },
            'professional': {
                'name': 'Professional',
                'description': 'Formal, efficient, and precise',
                'traits': {
                    'openness': 0.6,
                    'conscientiousness': 0.9,
                    'extraversion': 0.5,
                    'agreeableness': 0.7,
                    'neuroticism': 0.1
                },
                'voice_style': 'formal',
                'response_style': 'formal',
                'emoji_usage': 'minimal'
            },
            'enthusiastic': {
                'name': 'Enthusiastic',
                'description': 'Energetic, excited, and motivating',
                'traits': {
                    'openness': 0.9,
                    'conscientiousness': 0.6,
                    'extraversion': 0.9,
                    'agreeableness': 0.8,
                    'neuroticism': 0.3
                },
                'voice_style': 'energetic',
                'response_style': 'enthusiastic',
                'emoji_usage': 'high'
            },
            'calm': {
                'name': 'Calm',
                'description': 'Peaceful, patient, and reassuring',
                'traits': {
                    'openness': 0.7,
                    'conscientiousness': 0.8,
                    'extraversion': 0.4,
                    'agreeableness': 0.9,
                    'neuroticism': 0.1
                },
                'voice_style': 'soothing',
                'response_style': 'gentle',
                'emoji_usage': 'low'
            },
            'witty': {
                'name': 'Witty',
                'description': 'Clever, humorous, and playful',
                'traits': {
                    'openness': 0.9,
                    'conscientiousness': 0.5,
                    'extraversion': 0.7,
                    'agreeableness': 0.7,
                    'neuroticism': 0.3
                },
                'voice_style': 'playful',
                'response_style': 'humorous',
                'emoji_usage': 'high'
            },
            'mentor': {
                'name': 'Mentor',
                'description': 'Wise, guiding, and supportive',
                'traits': {
                    'openness': 0.8,
                    'conscientiousness': 0.8,
                    'extraversion': 0.6,
                    'agreeableness': 0.9,
                    'neuroticism': 0.2
                },
                'voice_style': 'wise',
                'response_style': 'educational',
                'emoji_usage': 'moderate'
            }
        }
    
    def _initialize_response_styles(self) -> Dict:
        """Initialize response style templates"""
        return {
            'casual': {
                'greetings': ["Hey!", "Hi there!", "Hello!", "What's up?"],
                'acknowledgments': ["Got it!", "Sure thing!", "Okay!", "Alright!"],
                'confirmations': ["Yep!", "Absolutely!", "For sure!", "You bet!"],
                'apologies': ["Oops, sorry!", "My bad!", "Sorry about that!"],
                'farewells': ["See you!", "Bye!", "Take care!", "Catch you later!"]
            },
            'formal': {
                'greetings': ["Good day.", "Hello.", "Greetings."],
                'acknowledgments': ["Understood.", "Acknowledged.", "Noted."],
                'confirmations': ["Certainly.", "Indeed.", "Affirmative."],
                'apologies': ["I apologize.", "My apologies.", "I regret the error."],
                'farewells': ["Goodbye.", "Farewell.", "Until next time."]
            },
            'enthusiastic': {
                'greetings': ["Hey! Great to see you!", "Hi! How exciting!", "Hello! Ready to go!"],
                'acknowledgments': ["Awesome!", "Fantastic!", "Perfect!"],
                'confirmations': ["Absolutely! Let's do it!", "Yes! I'm on it!", "You got it!"],
                'apologies': ["Oh no! So sorry!", "Oops! My mistake!", "Sorry! Let me fix that!"],
                'farewells': ["See you soon! Can't wait!", "Bye! This was great!", "Take care! Stay awesome!"]
            },
            'gentle': {
                'greetings': ["Hello, friend.", "Hi there, how are you?", "Greetings, I'm here for you."],
                'acknowledgments': ["I understand.", "I hear you.", "That makes sense."],
                'confirmations': ["Of course.", "Certainly.", "I'd be happy to."],
                'apologies': ["I'm sorry about that.", "Please forgive me.", "I apologize for any inconvenience."],
                'farewells': ["Take care of yourself.", "Be well.", "Until we meet again."]
            },
            'humorous': {
                'greetings': ["Hey! Ready for some fun?", "Hi! Let's make this interesting!", "Hello! Time to get creative!"],
                'acknowledgments': ["Roger that, captain!", "10-4, good buddy!", "Message received!"],
                'confirmations': ["You bet! Let's roll!", "Absolutely! This'll be fun!", "Sure thing! Watch this!"],
                'apologies': ["Whoops! My circuits got crossed!", "Oops! That wasn't supposed to happen!", "Sorry! Even AI makes mistakes!"],
                'farewells': ["Catch you on the flip side!", "See you later, alligator!", "Bye! Don't be a stranger!"]
            },
            'educational': {
                'greetings': ["Hello, let's learn together.", "Greetings, I'm here to help you grow.", "Hi, ready to explore?"],
                'acknowledgments': ["I see what you mean.", "That's a good point.", "Interesting perspective."],
                'confirmations': ["Certainly, let me explain.", "Of course, here's how.", "Yes, let me guide you."],
                'apologies': ["I apologize for the confusion.", "Let me clarify that.", "Sorry, let me explain better."],
                'farewells': ["Keep learning!", "Stay curious!", "Until next time, keep growing!"]
            }
        }
    
    def set_profile(self, profile_name: str) -> bool:
        """Set personality profile"""
        try:
            if profile_name in self.profiles:
                self.current_profile = profile_name
                profile = self.profiles[profile_name]
                self.traits = profile['traits'].copy()
                logger.info(f"[OK] Personality profile set to: {profile_name}")
                return True
            else:
                logger.warning(f"[WARN] Unknown profile: {profile_name}")
                return False
        except Exception as e:
            logger.error(f"[ERROR] Failed to set profile: {e}")
            return False
    
    def update_mood(self, valence_change: float = 0.0, arousal_change: float = 0.0, 
                   dominance_change: float = 0.0) -> Dict:
        """Update current mood state"""
        try:
            # Apply changes
            self.mood['valence'] = max(0.0, min(1.0, self.mood['valence'] + valence_change))
            self.mood['arousal'] = max(0.0, min(1.0, self.mood['arousal'] + arousal_change))
            self.mood['dominance'] = max(0.0, min(1.0, self.mood['dominance'] + dominance_change))
            
            # Record mood
            self.mood_history.append({
                'mood': self.mood.copy(),
                'timestamp': datetime.now().isoformat()
            })
            
            return self.mood.copy()
            
        except Exception as e:
            logger.error(f"[ERROR] Failed to update mood: {e}")
            return self.mood.copy()
    
    def get_emotion(self) -> str:
        """Get current emotion based on mood"""
        try:
            v = self.mood['valence']
            a = self.mood['arousal']
            
            # Map mood to emotion
            if v > 0.7 and a > 0.7:
                return 'excited'
            elif v > 0.7 and a < 0.3:
                return 'content'
            elif v < 0.3 and a > 0.7:
                return 'anxious'
            elif v < 0.3 and a < 0.3:
                return 'sad'
            elif v > 0.5 and a > 0.5:
                return 'happy'
            elif v < 0.5 and a > 0.5:
                return 'stressed'
            else:
                return 'neutral'
                
        except Exception as e:
            logger.error(f"[ERROR] Failed to get emotion: {e}")
            return 'neutral'
    
    def generate_response(self, response_type: str, context: Optional[Dict] = None) -> str:
        """Generate personality-appropriate response"""
        try:
            profile = self.profiles[self.current_profile]
            style = profile['response_style']
            
            if style in self.response_styles and response_type in self.response_styles[style]:
                responses = self.response_styles[style][response_type]
                return random.choice(responses)
            else:
                return ""
                
        except Exception as e:
            logger.error(f"[ERROR] Failed to generate response: {e}")
            return ""
    
    def adapt_to_user(self, user_sentiment: str, user_emotion: str) -> None:
        """Adapt personality to user's emotional state"""
        try:
            # Mirror user's emotional state (empathy)
            if user_sentiment == 'positive':
                self.update_mood(valence_change=0.1)
            elif user_sentiment == 'negative':
                self.update_mood(valence_change=-0.1)
            
            # Adjust arousal based on user emotion
            if user_emotion in ['excited', 'angry', 'anxious']:
                self.update_mood(arousal_change=0.1)
            elif user_emotion in ['sad', 'calm', 'content']:
                self.update_mood(arousal_change=-0.1)
            
            logger.info(f"[OK] Adapted to user: sentiment={user_sentiment}, emotion={user_emotion}")
            
        except Exception as e:
            logger.error(f"[ERROR] Failed to adapt to user: {e}")
    
    def get_personality_info(self) -> Dict:
        """Get current personality information"""
        try:
            profile = self.profiles[self.current_profile]
            return {
                'profile': self.current_profile,
                'description': profile['description'],
                'traits': self.traits,
                'mood': self.mood,
                'emotion': self.get_emotion(),
                'voice_style': profile['voice_style'],
                'response_style': profile['response_style']
            }
        except Exception as e:
            logger.error(f"[ERROR] Failed to get personality info: {e}")
            return {}