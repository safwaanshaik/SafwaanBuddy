"""
Plugin System for SafwaanBuddy
Extensible architecture for adding custom features
Version: 3.0 HYPER
"""
import logging
import importlib
import inspect
from typing import Dict, List, Any, Callable, Optional
from pathlib import Path
from dataclasses import dataclass
import json

logger = logging.getLogger('PluginSystem')


@dataclass
class PluginMetadata:
    """Plugin metadata"""
    name: str
    version: str
    author: str
    description: str
    dependencies: List[str]
    commands: List[str]
    enabled: bool = True


class Plugin:
    """Base plugin class"""
    
    def __init__(self, config, db):
        self.config = config
        self.db = db
        self.name = "BasePlugin"
        self.version = "1.0.0"
        self.author = "Unknown"
        self.description = "Base plugin"
    
    def initialize(self):
        """Initialize plugin"""
        pass
    
    def execute(self, command: str, context: Dict) -> Any:
        """Execute plugin command"""
        raise NotImplementedError
    
    def get_commands(self) -> List[str]:
        """Get available commands"""
        return []
    
    def cleanup(self):
        """Cleanup plugin resources"""
        pass


class PluginSystem:
    """
    Plugin Management System
    
    Features:
    - Dynamic plugin loading
    - Plugin lifecycle management
    - Command routing
    - Dependency management
    - Hot reload support
    - Plugin marketplace integration
    """
    
    def __init__(self, config, db):
        self.config = config
        self.db = db
        
        # Plugin storage
        self.plugins: Dict[str, Plugin] = {}
        self.plugin_metadata: Dict[str, PluginMetadata] = {}
        
        # Plugin directory
        self.plugin_dir = Path('plugins')
        self.plugin_dir.mkdir(exist_ok=True)
        
        # Command registry
        self.command_registry: Dict[str, str] = {}  # command -> plugin_name
        
        # Load plugins
        self._discover_plugins()
        self._load_plugins()
        
        logger.info(f"[PLUGIN] Plugin System initialized with {len(self.plugins)} plugins")
    
    def _discover_plugins(self):
        """Discover available plugins"""
        if not self.plugin_dir.exists():
            return
        
        for plugin_file in self.plugin_dir.glob('*.py'):
            if plugin_file.name.startswith('_'):
                continue
            
            try:
                # Load metadata
                metadata_file = plugin_file.with_suffix('.json')
                if metadata_file.exists():
                    with open(metadata_file, 'r') as f:
                        metadata_dict = json.load(f)
                        metadata = PluginMetadata(**metadata_dict)
                        self.plugin_metadata[plugin_file.stem] = metadata
                        logger.info(f"[PACKAGE] Discovered plugin: {metadata.name}")
            except Exception as e:
                logger.error(f"Error discovering plugin {plugin_file}: {e}")
    
    def _load_plugins(self):
        """Load all enabled plugins"""
        for plugin_name, metadata in self.plugin_metadata.items():
            if metadata.enabled:
                self.load_plugin(plugin_name)
    
    def load_plugin(self, plugin_name: str) -> bool:
        """
        Load a specific plugin
        
        Args:
            plugin_name: Name of the plugin to load
        
        Returns:
            True if loaded successfully
        """
        try:
            # Import plugin module
            module_path = f"plugins.{plugin_name}"
            module = importlib.import_module(module_path)
            
            # Find plugin class
            plugin_class = None
            for name, obj in inspect.getmembers(module):
                if inspect.isclass(obj) and issubclass(obj, Plugin) and obj != Plugin:
                    plugin_class = obj
                    break
            
            if not plugin_class:
                logger.error(f"No plugin class found in {plugin_name}")
                return False
            
            # Instantiate plugin
            plugin = plugin_class(self.config, self.db)
            plugin.initialize()
            
            # Store plugin
            self.plugins[plugin_name] = plugin
            
            # Register commands
            for command in plugin.get_commands():
                self.command_registry[command.lower()] = plugin_name
            
            logger.info(f"[OK] Loaded plugin: {plugin_name}")
            return True
            
        except Exception as e:
            logger.error(f"Error loading plugin {plugin_name}: {e}")
            return False
    
    def unload_plugin(self, plugin_name: str):
        """Unload a plugin"""
        if plugin_name in self.plugins:
            plugin = self.plugins[plugin_name]
            
            # Cleanup
            plugin.cleanup()
            
            # Remove commands
            commands_to_remove = [cmd for cmd, pname in self.command_registry.items() 
                                 if pname == plugin_name]
            for cmd in commands_to_remove:
                del self.command_registry[cmd]
            
            # Remove plugin
            del self.plugins[plugin_name]
            
            logger.info(f"[PLUGIN] Unloaded plugin: {plugin_name}")
    
    def reload_plugin(self, plugin_name: str):
        """Reload a plugin"""
        self.unload_plugin(plugin_name)
        self.load_plugin(plugin_name)
    
    def execute_command(self, command: str, context: Dict = None) -> Any:
        """
        Execute a plugin command
        
        Args:
            command: Command to execute
            context: Execution context
        
        Returns:
            Command result
        """
        context = context or {}
        command_lower = command.lower()
        
        # Find plugin for command
        plugin_name = self.command_registry.get(command_lower)
        if not plugin_name:
            logger.warning(f"No plugin found for command: {command}")
            return None
        
        # Get plugin
        plugin = self.plugins.get(plugin_name)
        if not plugin:
            logger.error(f"Plugin {plugin_name} not loaded")
            return None
        
        # Execute command
        try:
            result = plugin.execute(command, context)
            logger.info(f"[OK] Executed command '{command}' via plugin '{plugin_name}'")
            return result
        except Exception as e:
            logger.error(f"Error executing command '{command}': {e}")
            return None
    
    def get_available_commands(self) -> List[str]:
        """Get all available commands"""
        return list(self.command_registry.keys())
    
    def get_plugin_info(self, plugin_name: str) -> Optional[Dict]:
        """Get information about a plugin"""
        if plugin_name not in self.plugin_metadata:
            return None
        
        metadata = self.plugin_metadata[plugin_name]
        is_loaded = plugin_name in self.plugins
        
        return {
            'name': metadata.name,
            'version': metadata.version,
            'author': metadata.author,
            'description': metadata.description,
            'dependencies': metadata.dependencies,
            'commands': metadata.commands,
            'enabled': metadata.enabled,
            'loaded': is_loaded
        }
    
    def list_plugins(self) -> List[Dict]:
        """List all plugins"""
        return [self.get_plugin_info(name) for name in self.plugin_metadata.keys()]
    
    def enable_plugin(self, plugin_name: str):
        """Enable a plugin"""
        if plugin_name in self.plugin_metadata:
            self.plugin_metadata[plugin_name].enabled = True
            self.load_plugin(plugin_name)
            logger.info(f"[OK] Enabled plugin: {plugin_name}")
    
    def disable_plugin(self, plugin_name: str):
        """Disable a plugin"""
        if plugin_name in self.plugin_metadata:
            self.plugin_metadata[plugin_name].enabled = False
            self.unload_plugin(plugin_name)
            logger.info(f"[PLUGIN] Disabled plugin: {plugin_name}")
    
    def create_plugin_template(self, plugin_name: str, description: str):
        """Create a plugin template"""
        template = f'''"""
{plugin_name} Plugin for SafwaanBuddy
{description}
"""
from src.plugin_system import Plugin
import logging

logger = logging.getLogger('{plugin_name}')


class {plugin_name.title().replace('_', '')}Plugin(Plugin):
    """
    {plugin_name} plugin
    """
    
    def __init__(self, config, db):
        super().__init__(config, db)
        self.name = "{plugin_name}"
        self.version = "1.0.0"
        self.author = "Your Name"
        self.description = "{description}"
    
    def initialize(self):
        """Initialize plugin"""
        logger.info(f"Initializing {{self.name}} plugin")
        # Add initialization code here
    
    def execute(self, command: str, context: dict) -> any:
        """Execute plugin command"""
        command_lower = command.lower()
        
        # Add command handling here
        if 'example' in command_lower:
            return "Example command executed!"
        
        return None
    
    def get_commands(self) -> list:
        """Get available commands"""
        return ['example command']
    
    def cleanup(self):
        """Cleanup plugin resources"""
        logger.info(f"Cleaning up {{self.name}} plugin")
        # Add cleanup code here
'''
        
        # Save template
        plugin_file = self.plugin_dir / f"{plugin_name}.py"
        with open(plugin_file, 'w') as f:
            f.write(template)
        
        # Create metadata
        metadata = {
            'name': plugin_name,
            'version': '1.0.0',
            'author': 'Your Name',
            'description': description,
            'dependencies': [],
            'commands': ['example command'],
            'enabled': True
        }
        
        metadata_file = self.plugin_dir / f"{plugin_name}.json"
        with open(metadata_file, 'w') as f:
            json.dump(metadata, f, indent=2)
        
        logger.info(f"[OK] Created plugin template: {plugin_name}")
        return plugin_file
    
    def get_stats(self) -> Dict[str, Any]:
        """Get plugin system statistics"""
        return {
            'total_plugins': len(self.plugin_metadata),
            'loaded_plugins': len(self.plugins),
            'total_commands': len(self.command_registry),
            'enabled_plugins': sum(1 for m in self.plugin_metadata.values() if m.enabled)
        }