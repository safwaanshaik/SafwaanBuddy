"""
Premium Enterprise Hologram UI for SafwaanBuddy
Ultra-realistic, animated hologram with professional design
Inspired by futuristic AI interfaces
"""
import sys
import math
import random
import numpy as np
from PyQt6.QtWidgets import (QWidget, QApplication, QSystemTrayIcon, QMenu, 
                             QLabel, QVBoxLayout, QGraphicsOpacityEffect)
from PyQt6.QtCore import (Qt, QTimer, pyqtSignal, QPointF, QRect, 
                          QPropertyAnimation, QEasingCurve, QPoint, QSize)
from PyQt6.QtGui import (QPainter, QColor, QPalette, QRadialGradient, QIcon, 
                        QPixmap, QPen, QBrush, QLinearGradient, QFont, 
                        QConicalGradient, QPainterPath, QPolygonF)
import logging

logger = logging.getLogger('SafwaanBuddy.PremiumHologram')


class PremiumHologram(QWidget):
    """Enterprise-level premium holographic interface"""
    
    # Signals
    update_signal = pyqtSignal(str)
    emotion_signal = pyqtSignal(str)
    audio_signal = pyqtSignal(list)
    text_signal = pyqtSignal(str)
    
    def __init__(self, config_manager):
        super().__init__()
        self.config = config_manager
        
        # State
        self.state = "IDLE"
        self.current_emotion = "neutral"
        self.display_text = "Safwaan"
        self.audio_levels = [0] * 64
        
        # Premium color schemes
        self.color_schemes = {
            'IDLE': {
                'primary': QColor(0, 200, 255, 255),      # Cyan
                'secondary': QColor(100, 150, 255, 200),  # Blue
                'accent': QColor(0, 255, 200, 150),       # Teal
                'glow': QColor(0, 200, 255, 100)
            },
            'LISTENING': {
                'primary': QColor(0, 255, 150, 255),      # Green
                'secondary': QColor(50, 255, 100, 200),   # Light Green
                'accent': QColor(150, 255, 0, 150),       # Lime
                'glow': QColor(0, 255, 150, 100)
            },
            'THINKING': {
                'primary': QColor(200, 100, 255, 255),    # Purple
                'secondary': QColor(150, 50, 255, 200),   # Deep Purple
                'accent': QColor(255, 100, 200, 150),     # Pink
                'glow': QColor(200, 100, 255, 100)
            },
            'SPEAKING': {
                'primary': QColor(255, 100, 150, 255),    # Pink
                'secondary': QColor(255, 150, 100, 200),  # Orange-Pink
                'accent': QColor(255, 200, 100, 150),     # Gold
                'glow': QColor(255, 100, 150, 100)
            },
            'ERROR': {
                'primary': QColor(255, 50, 50, 255),      # Red
                'secondary': QColor(255, 100, 0, 200),    # Orange
                'accent': QColor(255, 150, 0, 150),       # Yellow
                'glow': QColor(255, 50, 50, 100)
            }
        }
        
        # Animation properties
        self.rotation_angle = 0
        self.pulse_phase = 0
        self.wave_phase = 0
        self.glow_intensity = 0.5
        self.scale_factor = 1.0
        
        # 3D rotation
        self.rotation_x = 0
        self.rotation_y = 0
        self.rotation_z = 0
        
        # Particles - Premium particle system
        self.particles = []
        self.energy_rings = []
        self.data_streams = []
        self._init_premium_particles()
        
        # Waveform visualization
        self.waveform_history = []
        self.spectrum_bars = [0] * 32
        
        # Text animation
        self.text_alpha = 255
        self.text_scale = 1.0
        self.text_y_offset = 0
        
        # Hologram layers
        self.hologram_layers = 7
        self.layer_offsets = [i * 5 for i in range(self.hologram_layers)]
        
        # Setup window
        self._setup_premium_window()
        
        # Connect signals
        self.update_signal.connect(self.set_state)
        self.emotion_signal.connect(self.set_emotion)
        self.audio_signal.connect(self.update_audio)
        self.text_signal.connect(self.set_text)
        
        # High-performance animation timer (60 FPS)
        self.animation_timer = QTimer(self)
        self.animation_timer.timeout.connect(self.animate)
        self.animation_timer.start(16)  # ~60 FPS
        
        # System tray
        self.tray_icon = None
        self._setup_premium_tray()
        
        logger.info("[OK] Premium Enterprise Hologram initialized")
    
    def _setup_premium_window(self):
        """Setup premium window with advanced properties"""
        # Frameless, transparent, always on top
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        
        # Premium size - larger for better visibility
        size = 500
        self.resize(size, size)
        
        # Position at top center
        screen = QApplication.primaryScreen().geometry()
        x = (screen.width() - self.width()) // 2
        y = 30
        self.move(x, y)
        
        self.setWindowTitle("SafwaanBuddy Premium")
        
        # Enable mouse tracking for interactions
        self.setMouseTracking(True)
        
        # Cursor
        self.setCursor(Qt.CursorShape.PointingHandCursor)
    
    def _init_premium_particles(self):
        """Initialize premium particle systems"""
        # Main particles - floating data points
        for _ in range(50):
            self.particles.append({
                'x': random.uniform(0, 1),
                'y': random.uniform(0, 1),
                'z': random.uniform(0, 1),
                'vx': random.uniform(-0.005, 0.005),
                'vy': random.uniform(-0.005, 0.005),
                'vz': random.uniform(-0.003, 0.003),
                'size': random.uniform(1, 4),
                'alpha': random.uniform(100, 255),
                'color_offset': random.uniform(0, 360),
                'pulse_speed': random.uniform(0.02, 0.05)
            })
        
        # Energy rings - rotating circles
        for i in range(5):
            self.energy_rings.append({
                'radius': 50 + i * 30,
                'rotation': random.uniform(0, 360),
                'speed': random.uniform(0.5, 2.0),
                'thickness': random.uniform(1, 3),
                'alpha': random.uniform(50, 150)
            })
        
        # Data streams - flowing lines
        for _ in range(8):
            self.data_streams.append({
                'angle': random.uniform(0, 360),
                'length': random.uniform(50, 150),
                'speed': random.uniform(1, 3),
                'alpha': random.uniform(100, 200),
                'flow_offset': random.uniform(0, 100)
            })
    
    def _setup_premium_tray(self):
        """Setup premium system tray with gradient icon"""
        try:
            self.tray_icon = QSystemTrayIcon(self)
            
            # Create premium gradient icon
            pixmap = QPixmap(128, 128)
            pixmap.fill(Qt.GlobalColor.transparent)
            painter = QPainter(pixmap)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            
            # Radial gradient
            gradient = QRadialGradient(64, 64, 56)
            gradient.setColorAt(0, QColor(0, 255, 255, 255))
            gradient.setColorAt(0.5, QColor(100, 150, 255, 200))
            gradient.setColorAt(1, QColor(0, 100, 200, 0))
            
            painter.setBrush(gradient)
            painter.setPen(QPen(QColor(0, 200, 255, 255), 3))
            painter.drawEllipse(16, 16, 96, 96)
            
            # Inner glow
            inner_gradient = QRadialGradient(64, 64, 40)
            inner_gradient.setColorAt(0, QColor(255, 255, 255, 200))
            inner_gradient.setColorAt(1, QColor(0, 200, 255, 0))
            painter.setBrush(inner_gradient)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(32, 32, 64, 64)
            
            painter.end()
            
            self.tray_icon.setIcon(QIcon(pixmap))
            self.tray_icon.setToolTip("SafwaanBuddy Premium")
            
            # Premium context menu
            menu = QMenu()
            menu.setStyleSheet("""
                QMenu {
                    background-color: rgba(20, 20, 40, 240);
                    color: rgb(200, 220, 255);
                    border: 2px solid rgb(0, 200, 255);
                    border-radius: 8px;
                    padding: 8px;
                }
                QMenu::item {
                    padding: 8px 24px;
                    border-radius: 4px;
                }
                QMenu::item:selected {
                    background-color: rgba(0, 200, 255, 100);
                }
            """)
            
            show_action = menu.addAction("🔵 Show/Hide Hologram")
            show_action.triggered.connect(self.toggle_visibility)
            
            menu.addSeparator()
            
            dashboard_action = menu.addAction("[BAR_CHART] Dashboard")
            dashboard_action.triggered.connect(self.show_dashboard)
            
            settings_action = menu.addAction("[SETTINGS] Settings")
            settings_action.triggered.connect(self.show_settings)
            
            menu.addSeparator()
            
            quit_action = menu.addAction("[ERROR] Quit")
            quit_action.triggered.connect(QApplication.quit)
            
            self.tray_icon.setContextMenu(menu)
            self.tray_icon.activated.connect(self._on_tray_activated)
            self.tray_icon.show()
            
            logger.info("[OK] Premium system tray created")
        
        except Exception as e:
            logger.error(f"Premium tray error: {e}")
    
    def _on_tray_activated(self, reason):
        """Handle tray activation"""
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            self.toggle_visibility()
    
    def paintEvent(self, event):
        """Paint premium hologram with all effects"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        
        # Get current colors
        colors = self.color_schemes.get(self.state, self.color_schemes['IDLE'])
        
        # Center point
        center_x = self.width() / 2
        center_y = self.height() / 2
        
        # Draw background glow layers
        self._draw_background_glow(painter, center_x, center_y, colors)
        
        # Draw energy rings
        self._draw_energy_rings(painter, center_x, center_y, colors)
        
        # Draw data streams
        self._draw_data_streams(painter, center_x, center_y, colors)
        
        # Draw main hologram sphere with layers
        self._draw_hologram_sphere(painter, center_x, center_y, colors)
        
        # Draw particles
        self._draw_premium_particles(painter, colors)
        
        # Draw waveform visualization
        if self.state == "SPEAKING":
            self._draw_waveform(painter, center_x, center_y, colors)
        
        # Draw spectrum analyzer
        if self.state in ["LISTENING", "SPEAKING"]:
            self._draw_spectrum(painter, center_x, center_y, colors)
        
        # Draw center core
        self._draw_center_core(painter, center_x, center_y, colors)
        
        # Draw text display
        self._draw_premium_text(painter, center_x, center_y, colors)
        
        # Draw state indicator
        self._draw_state_indicator(painter, colors)
        
        # Draw emotion indicator
        self._draw_emotion_indicator(painter, colors)
    
    def _draw_background_glow(self, painter, cx, cy, colors):
        """Draw multi-layer background glow"""
        # Outer glow
        for i in range(5):
            radius = 200 + i * 20
            alpha = int(30 - i * 5)
            
            gradient = QRadialGradient(cx, cy, radius)
            gradient.setColorAt(0, QColor(colors['glow'].red(), 
                                         colors['glow'].green(), 
                                         colors['glow'].blue(), alpha))
            gradient.setColorAt(1, QColor(colors['glow'].red(), 
                                         colors['glow'].green(), 
                                         colors['glow'].blue(), 0))
            
            painter.setBrush(gradient)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(QPointF(cx, cy), radius, radius)
    
    def _draw_energy_rings(self, painter, cx, cy, colors):
        """Draw rotating energy rings"""
        for ring in self.energy_rings:
            # Calculate position with rotation
            angle_rad = math.radians(ring['rotation'])
            
            # Draw ring
            pen = QPen(colors['secondary'], ring['thickness'])
            pen.setStyle(Qt.PenStyle.DashLine)
            painter.setPen(pen)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            
            # Apply rotation transform
            painter.save()
            painter.translate(cx, cy)
            painter.rotate(ring['rotation'])
            painter.translate(-cx, -cy)
            
            # Draw ellipse
            rect = QRect(int(cx - ring['radius']), int(cy - ring['radius']),
                        int(ring['radius'] * 2), int(ring['radius'] * 2))
            painter.drawEllipse(rect)
            
            painter.restore()
    
    def _draw_data_streams(self, painter, cx, cy, colors):
        """Draw flowing data streams"""
        for stream in self.data_streams:
            angle_rad = math.radians(stream['angle'])
            
            # Calculate stream points
            start_x = cx + math.cos(angle_rad) * 50
            start_y = cy + math.sin(angle_rad) * 50
            
            end_x = cx + math.cos(angle_rad) * (50 + stream['length'])
            end_y = cy + math.sin(angle_rad) * (50 + stream['length'])
            
            # Create gradient along stream
            gradient = QLinearGradient(start_x, start_y, end_x, end_y)
            gradient.setColorAt(0, QColor(colors['accent'].red(),
                                         colors['accent'].green(),
                                         colors['accent'].blue(), 0))
            gradient.setColorAt(0.5, QColor(colors['accent'].red(),
                                           colors['accent'].green(),
                                           colors['accent'].blue(), stream['alpha']))
            gradient.setColorAt(1, QColor(colors['accent'].red(),
                                         colors['accent'].green(),
                                         colors['accent'].blue(), 0))
            
            pen = QPen(QBrush(gradient), 2)
            painter.setPen(pen)
            painter.drawLine(QPointF(start_x, start_y), QPointF(end_x, end_y))
            
            # Draw flow dots
            flow_pos = (stream['flow_offset'] % 100) / 100
            dot_x = start_x + (end_x - start_x) * flow_pos
            dot_y = start_y + (end_y - start_y) * flow_pos
            
            painter.setBrush(colors['accent'])
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(QPointF(dot_x, dot_y), 3, 3)
    
    def _draw_hologram_sphere(self, painter, cx, cy, colors):
        """Draw main hologram sphere with multiple layers"""
        base_radius = 120
        
        # Draw multiple layers for depth
        for layer in range(self.hologram_layers):
            layer_alpha = int(255 - layer * 30)
            layer_radius = base_radius - layer * 8
            
            # Create conical gradient for hologram effect
            gradient = QConicalGradient(cx, cy, self.rotation_angle + layer * 20)
            
            # Add color stops
            gradient.setColorAt(0.0, QColor(colors['primary'].red(),
                                           colors['primary'].green(),
                                           colors['primary'].blue(), layer_alpha))
            gradient.setColorAt(0.25, QColor(colors['secondary'].red(),
                                            colors['secondary'].green(),
                                            colors['secondary'].blue(), layer_alpha))
            gradient.setColorAt(0.5, QColor(colors['accent'].red(),
                                           colors['accent'].green(),
                                           colors['accent'].blue(), layer_alpha))
            gradient.setColorAt(0.75, QColor(colors['secondary'].red(),
                                            colors['secondary'].green(),
                                            colors['secondary'].blue(), layer_alpha))
            gradient.setColorAt(1.0, QColor(colors['primary'].red(),
                                           colors['primary'].green(),
                                           colors['primary'].blue(), layer_alpha))
            
            # Draw layer
            painter.setBrush(gradient)
            pen = QPen(colors['primary'], 1)
            pen.setStyle(Qt.PenStyle.DotLine if layer % 2 == 0 else Qt.PenStyle.DashLine)
            painter.setPen(pen)
            
            # Apply scale
            scaled_radius = layer_radius * self.scale_factor
            painter.drawEllipse(QPointF(cx, cy), scaled_radius, scaled_radius)
            
            # Draw grid lines for hologram effect
            if layer % 2 == 0:
                self._draw_grid_lines(painter, cx, cy, scaled_radius, colors, layer_alpha)
    
    def _draw_grid_lines(self, painter, cx, cy, radius, colors, alpha):
        """Draw holographic grid lines"""
        pen = QPen(QColor(colors['primary'].red(),
                         colors['primary'].green(),
                         colors['primary'].blue(), alpha // 2), 1)
        painter.setPen(pen)
        
        # Horizontal lines
        for i in range(-3, 4):
            y_offset = i * (radius / 3)
            if abs(y_offset) < radius:
                x_offset = math.sqrt(radius**2 - y_offset**2)
                painter.drawLine(QPointF(cx - x_offset, cy + y_offset),
                               QPointF(cx + x_offset, cy + y_offset))
        
        # Vertical lines
        for i in range(-3, 4):
            x_offset = i * (radius / 3)
            if abs(x_offset) < radius:
                y_offset = math.sqrt(radius**2 - x_offset**2)
                painter.drawLine(QPointF(cx + x_offset, cy - y_offset),
                               QPointF(cx + x_offset, cy + y_offset))
    
    def _draw_premium_particles(self, painter, colors):
        """Draw premium particle system"""
        for particle in self.particles:
            # Calculate 3D position
            x = particle['x'] * self.width()
            y = particle['y'] * self.height()
            z_scale = 0.5 + particle['z'] * 0.5
            
            # Size based on depth
            size = particle['size'] * z_scale
            
            # Color with depth
            alpha = int(particle['alpha'] * z_scale)
            
            # Pulsing effect
            pulse = math.sin(self.pulse_phase + particle['color_offset']) * 0.3 + 0.7
            alpha = int(alpha * pulse)
            
            # Draw particle
            color = QColor(colors['accent'].red(),
                          colors['accent'].green(),
                          colors['accent'].blue(), alpha)
            
            painter.setBrush(color)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(QPointF(x, y), size, size)
            
            # Draw particle trail
            if size > 2:
                trail_color = QColor(color.red(), color.green(), color.blue(), alpha // 3)
                painter.setBrush(trail_color)
                painter.drawEllipse(QPointF(x - particle['vx'] * 100, 
                                           y - particle['vy'] * 100), 
                                  size * 0.5, size * 0.5)
    
    def _draw_waveform(self, painter, cx, cy, colors):
        """Draw audio waveform visualization"""
        if not self.audio_levels:
            return
        
        # Draw circular waveform
        num_bars = len(self.audio_levels)
        angle_step = 360 / num_bars
        base_radius = 140
        
        for i, level in enumerate(self.audio_levels):
            angle = math.radians(i * angle_step + self.wave_phase)
            
            # Calculate bar position
            bar_length = level * 40
            start_radius = base_radius
            end_radius = base_radius + bar_length
            
            start_x = cx + math.cos(angle) * start_radius
            start_y = cy + math.sin(angle) * start_radius
            end_x = cx + math.cos(angle) * end_radius
            end_y = cy + math.sin(angle) * end_radius
            
            # Color based on level
            alpha = int(100 + level * 155)
            color = QColor(colors['primary'].red(),
                          colors['primary'].green(),
                          colors['primary'].blue(), alpha)
            
            pen = QPen(color, 3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
            painter.setPen(pen)
            painter.drawLine(QPointF(start_x, start_y), QPointF(end_x, end_y))
    
    def _draw_spectrum(self, painter, cx, cy, colors):
        """Draw spectrum analyzer"""
        bar_width = 8
        bar_spacing = 4
        total_width = len(self.spectrum_bars) * (bar_width + bar_spacing)
        start_x = cx - total_width / 2
        base_y = cy + 180
        
        for i, height in enumerate(self.spectrum_bars):
            x = start_x + i * (bar_width + bar_spacing)
            bar_height = height * 60
            
            # Gradient for each bar
            gradient = QLinearGradient(x, base_y, x, base_y - bar_height)
            gradient.setColorAt(0, colors['primary'])
            gradient.setColorAt(0.5, colors['secondary'])
            gradient.setColorAt(1, colors['accent'])
            
            painter.setBrush(gradient)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawRect(int(x), int(base_y - bar_height), 
                           bar_width, int(bar_height))
    
    def _draw_center_core(self, painter, cx, cy, colors):
        """Draw glowing center core"""
        # Pulsing core
        core_radius = 30 + math.sin(self.pulse_phase * 2) * 5
        
        # Multiple glow layers
        for i in range(5):
            radius = core_radius + i * 10
            alpha = int(200 - i * 40)
            
            gradient = QRadialGradient(cx, cy, radius)
            gradient.setColorAt(0, QColor(255, 255, 255, alpha))
            gradient.setColorAt(0.5, QColor(colors['primary'].red(),
                                           colors['primary'].green(),
                                           colors['primary'].blue(), alpha))
            gradient.setColorAt(1, QColor(colors['primary'].red(),
                                         colors['primary'].green(),
                                         colors['primary'].blue(), 0))
            
            painter.setBrush(gradient)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(QPointF(cx, cy), radius, radius)
        
        # Bright center
        painter.setBrush(QColor(255, 255, 255, 255))
        painter.drawEllipse(QPointF(cx, cy), core_radius * 0.5, core_radius * 0.5)
    
    def _draw_premium_text(self, painter, cx, cy, colors):
        """Draw premium text with effects"""
        # Setup font
        font = QFont("Segoe UI", 24, QFont.Weight.Bold)
        painter.setFont(font)
        
        # Text position (below hologram)
        text_y = cy + 200 + self.text_y_offset
        
        # Draw text shadow
        shadow_color = QColor(0, 0, 0, 150)
        painter.setPen(shadow_color)
        painter.drawText(QRect(int(cx - 150) + 2, int(text_y) + 2, 300, 50),
                        Qt.AlignmentFlag.AlignCenter, self.display_text)
        
        # Draw main text with gradient
        gradient = QLinearGradient(cx - 150, text_y, cx + 150, text_y)
        gradient.setColorAt(0, colors['secondary'])
        gradient.setColorAt(0.5, colors['primary'])
        gradient.setColorAt(1, colors['secondary'])
        
        pen = QPen(QBrush(gradient), 1)
        painter.setPen(pen)
        painter.drawText(QRect(int(cx - 150), int(text_y), 300, 50),
                        Qt.AlignmentFlag.AlignCenter, self.display_text)
    
    def _draw_state_indicator(self, painter, colors):
        """Draw state indicator in corner"""
        # Top right corner
        x = self.width() - 100
        y = 20
        
        # State text
        font = QFont("Segoe UI", 10, QFont.Weight.Bold)
        painter.setFont(font)
        painter.setPen(colors['primary'])
        painter.drawText(x, y, self.state)
        
        # State dot
        dot_x = x - 15
        dot_y = y - 5
        
        # Pulsing dot
        dot_size = 6 + math.sin(self.pulse_phase * 3) * 2
        
        painter.setBrush(colors['primary'])
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(QPointF(dot_x, dot_y), dot_size, dot_size)
    
    def _draw_emotion_indicator(self, painter, colors):
        """Draw emotion indicator"""
        # Top left corner
        x = 20
        y = 20
        
        # Emotion faces
        emotion_faces = {
            'happy': '[HAPPY]',
            'sad': '😢',
            'excited': '🤩',
            'calm': '😌',
            'neutral': '😐',
            'thinking': '🤔',
            'confident': '😎',
            'empathetic': '🥺'
        }
        
        face = emotion_faces.get(self.current_emotion, '😐')
        
        # Draw emotion
        font = QFont("Segoe UI Emoji", 20)
        painter.setFont(font)
        painter.setPen(colors['primary'])
        painter.drawText(x, y + 20, face)
    
    def animate(self):
        """Update all animations"""
        # Rotation
        self.rotation_angle += 1
        if self.rotation_angle >= 360:
            self.rotation_angle = 0
        
        # Pulse
        self.pulse_phase += 0.05
        if self.pulse_phase >= math.pi * 2:
            self.pulse_phase = 0
        
        # Wave
        self.wave_phase += 2
        if self.wave_phase >= 360:
            self.wave_phase = 0
        
        # State-based animations
        if self.state == "SPEAKING":
            self.scale_factor = 1.0 + math.sin(self.pulse_phase * 5) * 0.1
            self.glow_intensity = 0.7 + math.sin(self.pulse_phase * 3) * 0.3
            
            # Animate audio levels
            for i in range(len(self.audio_levels)):
                target = random.uniform(0.3, 1.0)
                self.audio_levels[i] += (target - self.audio_levels[i]) * 0.3
            
        elif self.state == "LISTENING":
            self.scale_factor = 1.0 + math.sin(self.pulse_phase * 2) * 0.05
            self.glow_intensity = 0.6 + math.sin(self.pulse_phase * 2) * 0.2
            
        elif self.state == "THINKING":
            self.scale_factor = 1.0 + math.sin(self.pulse_phase * 3) * 0.08
            self.glow_intensity = 0.5 + math.sin(self.pulse_phase) * 0.3
            
        else:  # IDLE
            self.scale_factor = 1.0 + math.sin(self.pulse_phase) * 0.03
            self.glow_intensity = 0.4 + math.sin(self.pulse_phase * 0.5) * 0.2
        
        # Update particles
        for particle in self.particles:
            particle['x'] += particle['vx']
            particle['y'] += particle['vy']
            particle['z'] += particle['vz']
            
            # Wrap around
            if particle['x'] < 0 or particle['x'] > 1:
                particle['vx'] *= -1
            if particle['y'] < 0 or particle['y'] > 1:
                particle['vy'] *= -1
            if particle['z'] < 0 or particle['z'] > 1:
                particle['vz'] *= -1
        
        # Update energy rings
        for ring in self.energy_rings:
            ring['rotation'] += ring['speed']
            if ring['rotation'] >= 360:
                ring['rotation'] = 0
        
        # Update data streams
        for stream in self.data_streams:
            stream['flow_offset'] += stream['speed']
            if stream['flow_offset'] >= 100:
                stream['flow_offset'] = 0
        
        # Update spectrum
        for i in range(len(self.spectrum_bars)):
            self.spectrum_bars[i] *= 0.9  # Decay
        
        # Text animation
        if self.state == "SPEAKING":
            self.text_y_offset = math.sin(self.pulse_phase * 4) * 3
        else:
            self.text_y_offset = 0
        
        # Trigger repaint
        self.update()
    
    def set_state(self, state: str):
        """Set hologram state"""
        if state != self.state:
            logger.info(f"Hologram state: {self.state} → {state}")
            self.state = state
            
            # State-specific text
            state_texts = {
                'IDLE': 'Safwaan',
                'LISTENING': 'Listening...',
                'THINKING': 'Thinking...',
                'SPEAKING': 'Speaking...',
                'ERROR': 'Error'
            }
            self.display_text = state_texts.get(state, 'Safwaan')
    
    def set_emotion(self, emotion: str):
        """Set current emotion"""
        if emotion != self.current_emotion:
            logger.info(f"Emotion: {self.current_emotion} → {emotion}")
            self.current_emotion = emotion
    
    def set_text(self, text: str):
        """Set display text"""
        self.display_text = text[:30]  # Limit length
    
    def update_audio(self, levels: list):
        """Update audio visualization"""
        if len(levels) == len(self.audio_levels):
            self.audio_levels = levels
        
        # Update spectrum
        if len(levels) >= 32:
            self.spectrum_bars = levels[:32]
    
    def toggle_visibility(self):
        """Toggle window visibility"""
        if self.isVisible():
            self.hide()
        else:
            self.show()
            self.raise_()
            self.activateWindow()
    
    def show_dashboard(self):
        """Show dashboard (placeholder)"""
        logger.info("Dashboard requested")
        # TODO: Implement dashboard window
    
    def show_settings(self):
        """Show settings (placeholder)"""
        logger.info("Settings requested")
        # TODO: Implement settings window
    
    def mousePressEvent(self, event):
        """Handle mouse press for dragging"""
        if event.button() == Qt.MouseButton.LeftButton:
            self.drag_position = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()
    
    def mouseMoveEvent(self, event):
        """Handle mouse move for dragging"""
        if event.buttons() == Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self.drag_position)
            event.accept()
    
    def mouseDoubleClickEvent(self, event):
        """Handle double click"""
        if event.button() == Qt.MouseButton.LeftButton:
            self.show_dashboard()