"""
Proactive Assistant for SafwaanBuddy
Monitors system, predicts needs, and offers proactive help
"""
import threading
import time
import psutil
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable
from collections import defaultdict

logger = logging.getLogger('SafwaanBuddy.Proactive')


class ProactiveAssistant:
    """Proactive monitoring and assistance system"""
    
    def __init__(self, config_manager, voice_system, db_manager):
        self.config = config_manager
        self.voice = voice_system
        self.db = db_manager
        
        # Monitoring state
        self.is_monitoring = False
        self.monitoring_thread = None
        
        # Thresholds
        self.thresholds = {
            'cpu_high': 85,
            'memory_high': 85,
            'disk_high': 90,
            'battery_low': 20,
            'battery_critical': 10
        }
        
        # Notification cooldowns (prevent spam)
        self.last_notifications = defaultdict(float)
        self.notification_cooldown = 300  # 5 minutes
        
        # User patterns
        self.user_patterns = {
            'morning_routine': None,
            'work_hours': None,
            'break_times': [],
            'evening_routine': None
        }
        
        # Suggestions
        self.pending_suggestions = []
        
        logger.info("[OK] Proactive Assistant initialized")
    
    def start_monitoring(self):
        """Start proactive monitoring"""
        if self.is_monitoring:
            logger.warning("Monitoring already active")
            return
        
        self.is_monitoring = True
        self.monitoring_thread = threading.Thread(
            target=self._monitoring_loop,
            daemon=True
        )
        self.monitoring_thread.start()
        logger.info("[SEARCH] Proactive monitoring started")
    
    def stop_monitoring(self):
        """Stop proactive monitoring"""
        self.is_monitoring = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=2)
        logger.info("Proactive monitoring stopped")
    
    def _monitoring_loop(self):
        """Main monitoring loop"""
        while self.is_monitoring:
            try:
                # Check system health
                self._check_system_health()
                
                # Check time-based patterns
                self._check_time_patterns()
                
                # Check user activity
                self._check_user_activity()
                
                # Process pending suggestions
                self._process_suggestions()
                
                # Sleep before next check
                time.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                logger.error(f"Monitoring loop error: {e}")
                time.sleep(30)
    
    def _check_system_health(self):
        """Check system health and offer help"""
        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=1)
            if cpu_percent > self.thresholds['cpu_high']:
                self._notify_if_cooldown_passed(
                    'cpu_high',
                    f"Your CPU usage is quite high at {cpu_percent:.0f}%. "
                    f"Would you like me to help optimize performance?",
                    'concerned'
                )
            
            # Memory usage
            memory = psutil.virtual_memory()
            if memory.percent > self.thresholds['memory_high']:
                self._notify_if_cooldown_passed(
                    'memory_high',
                    f"Memory usage is at {memory.percent:.0f}%. "
                    f"I can help free up some memory if you'd like.",
                    'helpful'
                )
            
            # Disk usage
            disk = psutil.disk_usage('/')
            if disk.percent > self.thresholds['disk_high']:
                self._notify_if_cooldown_passed(
                    'disk_high',
                    f"Your disk is {disk.percent:.0f}% full. "
                    f"Would you like me to help clean up some space?",
                    'concerned'
                )
            
            # Battery (if available)
            battery = psutil.sensors_battery()
            if battery:
                if battery.percent < self.thresholds['battery_critical'] and not battery.power_plugged:
                    self._notify_if_cooldown_passed(
                        'battery_critical',
                        f"Battery is critically low at {battery.percent}%! "
                        f"Please plug in your charger.",
                        'urgent',
                        priority=True
                    )
                elif battery.percent < self.thresholds['battery_low'] and not battery.power_plugged:
                    self._notify_if_cooldown_passed(
                        'battery_low',
                        f"Battery is getting low at {battery.percent}%. "
                        f"You might want to plug in soon.",
                        'helpful'
                    )
        
        except Exception as e:
            logger.error(f"System health check error: {e}")
    
    def _check_time_patterns(self):
        """Check time-based patterns and offer suggestions"""
        try:
            now = datetime.now()
            hour = now.hour
            
            # Morning routine (7-9 AM)
            if 7 <= hour < 9:
                self._suggest_if_not_done_today(
                    'morning_greeting',
                    "Good morning! Would you like me to give you a quick update "
                    "on the weather and news?",
                    'friendly'
                )
            
            # Lunch time (12-1 PM)
            elif 12 <= hour < 13:
                self._suggest_if_not_done_today(
                    'lunch_reminder',
                    "It's lunch time! Don't forget to take a break and eat something.",
                    'caring'
                )
            
            # Afternoon break (3-4 PM)
            elif 15 <= hour < 16:
                self._suggest_if_not_done_today(
                    'afternoon_break',
                    "You've been working hard! How about a quick break? "
                    "I can play some relaxing music if you'd like.",
                    'caring'
                )
            
            # Evening routine (6-8 PM)
            elif 18 <= hour < 20:
                self._suggest_if_not_done_today(
                    'evening_routine',
                    "The day is winding down. Would you like me to help you "
                    "organize tomorrow's tasks?",
                    'calm'
                )
            
            # Late night (11 PM - 1 AM)
            elif hour >= 23 or hour < 1:
                self._suggest_if_not_done_today(
                    'sleep_reminder',
                    "It's getting quite late. Don't forget to get some rest! "
                    "Your health is important.",
                    'caring'
                )
        
        except Exception as e:
            logger.error(f"Time pattern check error: {e}")
    
    def _check_user_activity(self):
        """Check user activity patterns"""
        try:
            # Check if user has been idle
            # This is a simplified version
            pass
        
        except Exception as e:
            logger.error(f"Activity check error: {e}")
    
    def _process_suggestions(self):
        """Process pending suggestions"""
        if self.pending_suggestions:
            # Process one suggestion at a time
            suggestion = self.pending_suggestions.pop(0)
            
            # Speak suggestion
            self.voice.speak(
                suggestion['message'],
                emotion=suggestion['emotion'],
                priority=suggestion.get('priority', False)
            )
    
    def _notify_if_cooldown_passed(self, notification_id: str, message: str,
                                   emotion: str, priority: bool = False):
        """Notify if cooldown period has passed"""
        current_time = time.time()
        last_time = self.last_notifications.get(notification_id, 0)
        
        if current_time - last_time > self.notification_cooldown:
            self.voice.speak(message, emotion=emotion, priority=priority)
            self.last_notifications[notification_id] = current_time
            
            # Store in database
            self.db.store_metric(
                'proactive_notification',
                1.0,
                {'type': notification_id, 'message': message}
            )
    
    def _suggest_if_not_done_today(self, suggestion_id: str, message: str, emotion: str):
        """Suggest if not done today"""
        today = datetime.now().date().isoformat()
        last_date = self.db.get_preference(f'last_{suggestion_id}', '')
        
        if last_date != today:
            # Add to pending suggestions
            self.pending_suggestions.append({
                'id': suggestion_id,
                'message': message,
                'emotion': emotion,
                'priority': False
            })
            
            # Mark as done for today
            self.db.store_preference(f'last_{suggestion_id}', today)
    
    def suggest_break(self, work_duration: int = 60):
        """Suggest break after work duration"""
        message = (
            f"You've been working for {work_duration} minutes. "
            f"How about a quick 5-minute break? It's good for your productivity!"
        )
        self.voice.speak(message, emotion='caring')
    
    def suggest_task_completion(self, task: str):
        """Suggest completing a task"""
        message = f"Just a reminder: you mentioned wanting to {task}. Would you like to work on that now?"
        self.voice.speak(message, emotion='helpful')
    
    def offer_help_based_on_context(self, context: Dict):
        """Offer contextual help"""
        # Analyze context and offer relevant help
        if context.get('task_type') == 'coding':
            self.voice.speak(
                "I notice you're coding. I can help with debugging, "
                "searching documentation, or explaining concepts if you need.",
                emotion='helpful'
            )
        elif context.get('task_type') == 'research':
            self.voice.speak(
                "I see you're researching. I can help search for information, "
                "summarize articles, or organize your findings.",
                emotion='helpful'
            )
    
    def predict_next_action(self, recent_actions: List[str]) -> Optional[str]:
        """Predict user's next likely action"""
        # Simple pattern matching
        if not recent_actions:
            return None
        
        # Common patterns
        patterns = {
            ('open', 'chrome'): 'search',
            ('search', 'google'): 'open_website',
            ('take', 'screenshot'): 'open_image_editor',
            ('open', 'email'): 'compose_email'
        }
        
        # Check last two actions
        if len(recent_actions) >= 2:
            last_two = tuple(recent_actions[-2:])
            if last_two in patterns:
                return patterns[last_two]
        
        return None
    
    def learn_user_pattern(self, action: str, time_of_day: int):
        """Learn user patterns over time"""
        # Store pattern in database
        pattern_data = {
            'action': action,
            'hour': time_of_day,
            'timestamp': datetime.now().isoformat()
        }
        
        self.db.store_metric('user_pattern', 1.0, pattern_data)
    
    def get_proactive_suggestions(self) -> List[str]:
        """Get list of proactive suggestions"""
        suggestions = []
        
        # Time-based suggestions
        hour = datetime.now().hour
        
        if 7 <= hour < 9:
            suggestions.append("Morning briefing (weather, news, calendar)")
        elif 12 <= hour < 13:
            suggestions.append("Lunch break reminder")
        elif 15 <= hour < 16:
            suggestions.append("Afternoon break suggestion")
        elif 18 <= hour < 20:
            suggestions.append("Evening routine planning")
        
        # System-based suggestions
        cpu = psutil.cpu_percent()
        if cpu > 80:
            suggestions.append("System optimization")
        
        memory = psutil.virtual_memory().percent
        if memory > 80:
            suggestions.append("Memory cleanup")
        
        return suggestions
    
    def enable_smart_notifications(self):
        """Enable smart notification system"""
        logger.info("Smart notifications enabled")
        # Would integrate with Windows notification system
    
    def disable_smart_notifications(self):
        """Disable smart notifications"""
        logger.info("Smart notifications disabled")