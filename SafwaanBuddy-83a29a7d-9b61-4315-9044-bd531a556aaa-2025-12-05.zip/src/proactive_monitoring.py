"""
Proactive Monitoring System for SafwaanBuddy ULTIMATE
Intelligent system monitoring, prediction, and proactive assistance
"""
import logging
import psutil
import threading
import time
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
from collections import defaultdict, deque
import json

logger = logging.getLogger('SafwaanBuddy.ProactiveMonitoring')


class ProactiveMonitoringSystem:
    """Advanced proactive monitoring and assistance"""
    
    def __init__(self, config_manager, voice_system, db_manager, predictive_engine):
        self.config = config_manager
        self.voice = voice_system
        self.db = db_manager
        self.predictive = predictive_engine
        
        # Monitoring state
        self.is_monitoring = False
        self.monitor_thread = None
        
        # System metrics
        self.system_metrics = {
            'cpu': deque(maxlen=100),
            'memory': deque(maxlen=100),
            'disk': deque(maxlen=100),
            'network': deque(maxlen=100),
            'battery': deque(maxlen=100)
        }
        
        # Application monitoring
        self.app_usage = defaultdict(lambda: {
            'total_time': 0,
            'sessions': 0,
            'last_used': None
        })
        
        # User behavior patterns
        self.behavior_patterns = {
            'work_hours': [],
            'break_times': [],
            'focus_periods': [],
            'distraction_periods': []
        }
        
        # Alerts and notifications
        self.alerts = deque(maxlen=100)
        self.alert_thresholds = {
            'cpu_high': 80,
            'memory_high': 85,
            'disk_low': 10,
            'battery_low': 20
        }
        
        # Proactive suggestions
        self.suggestions = deque(maxlen=50)
        self.suggestion_cooldown = {}
        
        # Health monitoring
        self.health_reminders = {
            'water': {'interval': 3600, 'last': None},  # Every hour
            'break': {'interval': 1800, 'last': None},  # Every 30 min
            'posture': {'interval': 1200, 'last': None},  # Every 20 min
            'eyes': {'interval': 1200, 'last': None}  # Every 20 min
        }
        
        logger.info("[OK] Proactive monitoring system initialized")
    
    def start_monitoring(self) -> None:
        """Start proactive monitoring"""
        if self.is_monitoring:
            return
        
        self.is_monitoring = True
        self.monitor_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitor_thread.start()
        
        logger.info("[OK] Proactive monitoring started")
    
    def stop_monitoring(self) -> None:
        """Stop proactive monitoring"""
        self.is_monitoring = False
        
        if self.monitor_thread:
            self.monitor_thread.join(timeout=2.0)
        
        logger.info("[OK] Proactive monitoring stopped")
    
    def _monitoring_loop(self) -> None:
        """Main monitoring loop"""
        while self.is_monitoring:
            try:
                # Collect system metrics
                self._collect_system_metrics()
                
                # Monitor applications
                self._monitor_applications()
                
                # Check for alerts
                self._check_alerts()
                
                # Generate proactive suggestions
                self._generate_suggestions()
                
                # Health reminders
                self._check_health_reminders()
                
                # Sleep
                time.sleep(5)  # Check every 5 seconds
                
            except Exception as e:
                logger.error(f"[ERROR] Monitoring loop error: {e}")
    
    def _collect_system_metrics(self) -> None:
        """Collect system performance metrics"""
        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=1)
            self.system_metrics['cpu'].append({
                'value': cpu_percent,
                'timestamp': datetime.now().isoformat()
            })
            
            # Memory usage
            memory = psutil.virtual_memory()
            self.system_metrics['memory'].append({
                'value': memory.percent,
                'timestamp': datetime.now().isoformat()
            })
            
            # Disk usage
            disk = psutil.disk_usage('/')
            self.system_metrics['disk'].append({
                'value': disk.percent,
                'timestamp': datetime.now().isoformat()
            })
            
            # Network usage
            net_io = psutil.net_io_counters()
            self.system_metrics['network'].append({
                'sent': net_io.bytes_sent,
                'recv': net_io.bytes_recv,
                'timestamp': datetime.now().isoformat()
            })
            
            # Battery status
            battery = psutil.sensors_battery()
            if battery:
                self.system_metrics['battery'].append({
                    'percent': battery.percent,
                    'plugged': battery.power_plugged,
                    'timestamp': datetime.now().isoformat()
                })
            
        except Exception as e:
            logger.error(f"[ERROR] Metrics collection failed: {e}")
    
    def _monitor_applications(self) -> None:
        """Monitor application usage"""
        try:
            for proc in psutil.process_iter(['name', 'cpu_percent', 'memory_percent']):
                try:
                    app_name = proc.info['name']
                    
                    # Update usage stats
                    self.app_usage[app_name]['sessions'] += 1
                    self.app_usage[app_name]['last_used'] = datetime.now().isoformat()
                    
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
                    
        except Exception as e:
            logger.error(f"[ERROR] Application monitoring failed: {e}")
    
    def _check_alerts(self) -> None:
        """Check for system alerts"""
        try:
            current_time = datetime.now()
            
            # CPU alert
            if self.system_metrics['cpu']:
                cpu_value = self.system_metrics['cpu'][-1]['value']
                if cpu_value > self.alert_thresholds['cpu_high']:
                    self._create_alert('cpu_high', f"CPU usage is high: {cpu_value:.1f}%")
            
            # Memory alert
            if self.system_metrics['memory']:
                memory_value = self.system_metrics['memory'][-1]['value']
                if memory_value > self.alert_thresholds['memory_high']:
                    self._create_alert('memory_high', f"Memory usage is high: {memory_value:.1f}%")
            
            # Disk alert
            if self.system_metrics['disk']:
                disk_value = self.system_metrics['disk'][-1]['value']
                if disk_value > (100 - self.alert_thresholds['disk_low']):
                    self._create_alert('disk_low', f"Disk space is low: {100-disk_value:.1f}% free")
            
            # Battery alert
            if self.system_metrics['battery']:
                battery_data = self.system_metrics['battery'][-1]
                if not battery_data['plugged'] and battery_data['percent'] < self.alert_thresholds['battery_low']:
                    self._create_alert('battery_low', f"Battery is low: {battery_data['percent']}%")
            
        except Exception as e:
            logger.error(f"[ERROR] Alert checking failed: {e}")
    
    def _create_alert(self, alert_type: str, message: str) -> None:
        """Create system alert"""
        try:
            # Check cooldown
            if alert_type in self.suggestion_cooldown:
                last_time = self.suggestion_cooldown[alert_type]
                if (datetime.now() - last_time).seconds < 300:  # 5 min cooldown
                    return
            
            alert = {
                'type': alert_type,
                'message': message,
                'timestamp': datetime.now().isoformat(),
                'severity': 'high' if 'high' in alert_type or 'low' in alert_type else 'medium'
            }
            
            self.alerts.append(alert)
            self.suggestion_cooldown[alert_type] = datetime.now()
            
            # Notify user
            self.voice.speak(f"Alert: {message}")
            
            logger.warning(f"[ALERT] {message}")
            
        except Exception as e:
            logger.error(f"[ERROR] Alert creation failed: {e}")
    
    def _generate_suggestions(self) -> None:
        """Generate proactive suggestions"""
        try:
            current_time = datetime.now()
            current_hour = current_time.hour
            
            # Work-life balance suggestions
            if current_hour >= 22:  # Late night
                self._create_suggestion('rest', "It's getting late. Consider taking a break and getting some rest.")
            
            # Productivity suggestions
            if self._is_work_hours() and self._detect_distraction():
                self._create_suggestion('focus', "I notice you might be distracted. Would you like me to enable focus mode?")
            
            # System optimization suggestions
            if self._should_optimize_system():
                self._create_suggestion('optimize', "Your system could benefit from optimization. Shall I run cleanup?")
            
        except Exception as e:
            logger.error(f"[ERROR] Suggestion generation failed: {e}")
    
    def _create_suggestion(self, suggestion_type: str, message: str) -> None:
        """Create proactive suggestion"""
        try:
            # Check cooldown
            if suggestion_type in self.suggestion_cooldown:
                last_time = self.suggestion_cooldown[suggestion_type]
                if (datetime.now() - last_time).seconds < 1800:  # 30 min cooldown
                    return
            
            suggestion = {
                'type': suggestion_type,
                'message': message,
                'timestamp': datetime.now().isoformat()
            }
            
            self.suggestions.append(suggestion)
            self.suggestion_cooldown[suggestion_type] = datetime.now()
            
            # Notify user (non-intrusive)
            logger.info(f"[SUGGESTION] {message}")
            
        except Exception as e:
            logger.error(f"[ERROR] Suggestion creation failed: {e}")
    
    def _check_health_reminders(self) -> None:
        """Check and send health reminders"""
        try:
            current_time = datetime.now()
            
            for reminder_type, config in self.health_reminders.items():
                last_time = config['last']
                interval = config['interval']
                
                if last_time is None or (current_time - last_time).seconds >= interval:
                    self._send_health_reminder(reminder_type)
                    config['last'] = current_time
            
        except Exception as e:
            logger.error(f"[ERROR] Health reminder check failed: {e}")
    
    def _send_health_reminder(self, reminder_type: str) -> None:
        """Send health reminder"""
        try:
            messages = {
                'water': "Time to hydrate! Remember to drink some water.",
                'break': "You've been working for a while. Time for a short break!",
                'posture': "Check your posture. Sit up straight and relax your shoulders.",
                'eyes': "Give your eyes a rest. Look away from the screen for 20 seconds."
            }
            
            if reminder_type in messages:
                message = messages[reminder_type]
                self.voice.speak(message)
                logger.info(f"[HEALTH] {message}")
            
        except Exception as e:
            logger.error(f"[ERROR] Health reminder failed: {e}")
    
    def _is_work_hours(self) -> bool:
        """Check if current time is work hours"""
        current_hour = datetime.now().hour
        return 9 <= current_hour <= 18
    
    def _detect_distraction(self) -> bool:
        """Detect if user is distracted"""
        # Implement distraction detection logic
        return False
    
    def _should_optimize_system(self) -> bool:
        """Check if system needs optimization"""
        try:
            # Check if memory usage is consistently high
            if len(self.system_metrics['memory']) >= 10:
                recent_memory = [m['value'] for m in list(self.system_metrics['memory'])[-10:]]
                avg_memory = sum(recent_memory) / len(recent_memory)
                return avg_memory > 80
            
            return False
            
        except Exception as e:
            logger.error(f"[ERROR] Optimization check failed: {e}")
            return False
    
    def get_system_health(self) -> Dict:
        """Get overall system health"""
        try:
            health = {
                'status': 'healthy',
                'metrics': {},
                'alerts': list(self.alerts),
                'suggestions': list(self.suggestions)
            }
            
            # Calculate average metrics
            for metric_name, metric_data in self.system_metrics.items():
                if metric_data:
                    if metric_name == 'network':
                        health['metrics'][metric_name] = {
                            'sent': metric_data[-1]['sent'],
                            'recv': metric_data[-1]['recv']
                        }
                    elif metric_name == 'battery':
                        health['metrics'][metric_name] = metric_data[-1]
                    else:
                        values = [m['value'] for m in metric_data]
                        health['metrics'][metric_name] = {
                            'current': values[-1],
                            'average': sum(values) / len(values),
                            'max': max(values),
                            'min': min(values)
                        }
            
            # Determine overall status
            if len(self.alerts) > 5:
                health['status'] = 'warning'
            elif len(self.alerts) > 10:
                health['status'] = 'critical'
            
            return health
            
        except Exception as e:
            logger.error(f"[ERROR] Health check failed: {e}")
            return {'status': 'unknown', 'error': str(e)}
    
    def get_productivity_report(self) -> Dict:
        """Get productivity analytics report"""
        try:
            report = {
                'date': datetime.now().isoformat(),
                'work_time': 0,
                'break_time': 0,
                'focus_time': 0,
                'distraction_time': 0,
                'top_applications': [],
                'productivity_score': 0
            }
            
            # Calculate work time
            # Implement work time calculation
            
            # Get top applications
            sorted_apps = sorted(
                self.app_usage.items(),
                key=lambda x: x[1]['sessions'],
                reverse=True
            )
            report['top_applications'] = [
                {'name': app, 'sessions': data['sessions']}
                for app, data in sorted_apps[:10]
            ]
            
            # Calculate productivity score
            # Implement productivity scoring
            
            return report
            
        except Exception as e:
            logger.error(f"[ERROR] Productivity report failed: {e}")
            return {'error': str(e)}