"""
Quantum-Level AI Brain for SafwaanBuddy ULTIMATE
Multi-model ensemble with advanced reasoning and emotional intelligence
"""
import google.generativeai as genai
import logging
import asyncio
import numpy as np
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime
from collections import deque
import json
import re

logger = logging.getLogger('SafwaanBuddy.QuantumAI')


class QuantumAIBrain:
    """Advanced quantum-level AI brain with multi-model ensemble"""
    
    def __init__(self, config_manager, db_manager):
        self.config = config_manager
        self.db = db_manager
        
        # Initialize multiple Gemini models
        self.models = {}
        self._initialize_models()
        
        # Advanced memory systems
        self.short_term_memory = deque(maxlen=50)
        self.working_memory = {}
        self.episodic_memory = []
        self.semantic_memory = {}
        
        # Reasoning engine
        self.reasoning_depth = 5
        self.confidence_threshold = 0.7
        self.context_window = 20
        
        # Emotional intelligence
        self.emotional_state = {
            'valence': 0.0,  # -1 (negative) to 1 (positive)
            'arousal': 0.0,  # 0 (calm) to 1 (excited)
            'dominance': 0.5  # 0 (submissive) to 1 (dominant)
        }
        
        # Pattern recognition
        self.learned_patterns = {}
        self.user_preferences = {}
        self.interaction_history = deque(maxlen=1000)
        
        # Predictive system
        self.predictions = {}
        self.prediction_accuracy = {}
        
        logger.info("Quantum AI Brain initialized with multi-model ensemble")
    
    def _initialize_models(self):
        """Initialize multiple Gemini models for ensemble"""
        try:
            api_key = self.config.get_env('GEMINI_API_KEY')
            if not api_key:
                logger.error("No Gemini API key found")
                return
            
            genai.configure(api_key=api_key)
            
            # Initialize multiple models
            self.models['pro'] = genai.GenerativeModel('gemini-pro')
            self.models['flash'] = genai.GenerativeModel('gemini-1.5-flash')
            self.models['vision'] = genai.GenerativeModel('gemini-pro-vision')
            
            # Configure generation settings
            self.generation_config = {
                'temperature': 0.9,
                'top_p': 0.95,
                'top_k': 40,
                'max_output_tokens': 2048,
            }
            
            # Safety settings
            self.safety_settings = [
                {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
                {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
                {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
                {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},
            ]
            
            logger.info("Multi-model ensemble initialized successfully")
            
        except Exception as e:
            logger.error(f"Model initialization error: {e}")
    
    async def quantum_reasoning(self, query: str, context: Dict = None) -> Dict:
        """
        Quantum-level reasoning with multi-model ensemble
        Uses multiple models and combines their outputs for superior results
        """
        try:
            # Prepare context
            full_context = self._build_context(query, context)
            
            # Multi-model processing
            results = await self._ensemble_processing(query, full_context)
            
            # Deep reasoning
            reasoning_result = self._deep_reasoning(results)
            
            # Emotional analysis
            emotion = self._analyze_emotion(query, reasoning_result)
            
            # Pattern recognition
            patterns = self._recognize_patterns(query, reasoning_result)
            
            # Predictive analysis
            predictions = self._generate_predictions(query, reasoning_result)
            
            # Combine all insights
            final_result = {
                'response': reasoning_result['best_response'],
                'confidence': reasoning_result['confidence'],
                'emotion': emotion,
                'patterns': patterns,
                'predictions': predictions,
                'reasoning_chain': reasoning_result['reasoning_chain'],
                'model_consensus': reasoning_result['consensus']
            }
            
            # Update memory systems
            self._update_memories(query, final_result)
            
            # Learn from interaction
            self._learn_from_interaction(query, final_result)
            
            return final_result
            
        except Exception as e:
            logger.error(f"Quantum reasoning error: {e}")
            return self._fallback_response(query)
    
    async def _ensemble_processing(self, query: str, context: str) -> List[Dict]:
        """Process query with multiple models simultaneously"""
        results = []
        
        try:
            # Create tasks for parallel processing
            tasks = []
            
            for model_name, model in self.models.items():
                if model_name != 'vision':  # Vision requires images
                    task = self._query_model(model, query, context, model_name)
                    tasks.append(task)
            
            # Execute all models in parallel
            model_results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Process results
            for i, result in enumerate(model_results):
                if not isinstance(result, Exception):
                    results.append(result)
            
            return results
            
        except Exception as e:
            logger.error(f"Ensemble processing error: {e}")
            return []
    
    async def _query_model(self, model, query: str, context: str, model_name: str) -> Dict:
        """Query a single model"""
        try:
            prompt = f"{context}\n\nUser Query: {query}\n\nProvide a detailed, helpful response:"
            
            response = model.generate_content(
                prompt,
                generation_config=self.generation_config,
                safety_settings=self.safety_settings
            )
            
            return {
                'model': model_name,
                'response': response.text,
                'confidence': self._calculate_confidence(response.text),
                'timestamp': datetime.now()
            }
            
        except Exception as e:
            logger.error(f"Model query error ({model_name}): {e}")
            return {'model': model_name, 'response': '', 'confidence': 0.0}
    
    def _deep_reasoning(self, results: List[Dict]) -> Dict:
        """
        Deep reasoning to combine multiple model outputs
        Uses consensus, confidence weighting, and logical analysis
        """
        if not results:
            return {'best_response': '', 'confidence': 0.0, 'reasoning_chain': [], 'consensus': 0.0}
        
        # Calculate consensus
        responses = [r['response'] for r in results if r['response']]
        confidences = [r['confidence'] for r in results if r['response']]
        
        if not responses:
            return {'best_response': '', 'confidence': 0.0, 'reasoning_chain': [], 'consensus': 0.0}
        
        # Find best response based on confidence and length
        best_idx = np.argmax([c * len(r) for c, r in zip(confidences, responses)])
        best_response = responses[best_idx]
        
        # Calculate consensus score
        consensus = self._calculate_consensus(responses)
        
        # Build reasoning chain
        reasoning_chain = [
            f"Analyzed {len(results)} model outputs",
            f"Consensus score: {consensus:.2f}",
            f"Selected response from model with highest confidence",
            f"Applied context from {len(self.short_term_memory)} recent interactions"
        ]
        
        return {
            'best_response': best_response,
            'confidence': confidences[best_idx],
            'reasoning_chain': reasoning_chain,
            'consensus': consensus
        }
    
    def _analyze_emotion(self, query: str, reasoning_result: Dict) -> Dict:
        """
        Advanced emotional analysis of query and response
        Returns emotional state with valence, arousal, and dominance
        """
        emotion_keywords = {
            'happy': {'valence': 0.8, 'arousal': 0.6, 'dominance': 0.6},
            'sad': {'valence': -0.7, 'arousal': 0.3, 'dominance': 0.3},
            'angry': {'valence': -0.6, 'arousal': 0.9, 'dominance': 0.8},
            'excited': {'valence': 0.7, 'arousal': 0.9, 'dominance': 0.7},
            'calm': {'valence': 0.5, 'arousal': 0.2, 'dominance': 0.5},
            'anxious': {'valence': -0.4, 'arousal': 0.8, 'dominance': 0.3},
            'confident': {'valence': 0.6, 'arousal': 0.5, 'dominance': 0.9},
            'curious': {'valence': 0.5, 'arousal': 0.6, 'dominance': 0.5}
        }
        
        # Analyze query for emotional content
        query_lower = query.lower()
        detected_emotions = []
        
        for emotion, values in emotion_keywords.items():
            if emotion in query_lower:
                detected_emotions.append(values)
        
        # Calculate average emotional state
        if detected_emotions:
            avg_emotion = {
                'valence': np.mean([e['valence'] for e in detected_emotions]),
                'arousal': np.mean([e['arousal'] for e in detected_emotions]),
                'dominance': np.mean([e['dominance'] for e in detected_emotions])
            }
        else:
            # Default neutral state
            avg_emotion = {'valence': 0.0, 'arousal': 0.5, 'dominance': 0.5}
        
        # Map to emotion label
        emotion_label = self._map_to_emotion_label(avg_emotion)
        
        # Update internal emotional state
        self.emotional_state = avg_emotion
        
        return {
            'label': emotion_label,
            'valence': avg_emotion['valence'],
            'arousal': avg_emotion['arousal'],
            'dominance': avg_emotion['dominance'],
            'intensity': abs(avg_emotion['valence']) * avg_emotion['arousal']
        }
    
    def _map_to_emotion_label(self, emotion: Dict) -> str:
        """Map emotional dimensions to emotion label"""
        v, a, d = emotion['valence'], emotion['arousal'], emotion['dominance']
        
        if v > 0.5 and a > 0.6:
            return 'excited'
        elif v > 0.5 and a < 0.4:
            return 'calm'
        elif v > 0.3:
            return 'happy'
        elif v < -0.5 and a > 0.6:
            return 'angry'
        elif v < -0.5 and a < 0.4:
            return 'sad'
        elif v < -0.3:
            return 'anxious'
        elif d > 0.7:
            return 'confident'
        else:
            return 'neutral'
    
    def _recognize_patterns(self, query: str, reasoning_result: Dict) -> List[str]:
        """
        Advanced pattern recognition from user interactions
        Identifies recurring themes, preferences, and behaviors
        """
        patterns = []
        
        # Time-based patterns
        current_hour = datetime.now().hour
        if current_hour in self.learned_patterns.get('active_hours', []):
            patterns.append(f"User typically active at {current_hour}:00")
        
        # Query type patterns
        query_type = self._classify_query_type(query)
        if query_type in self.learned_patterns.get('frequent_queries', {}):
            count = self.learned_patterns['frequent_queries'][query_type]
            patterns.append(f"Frequent {query_type} queries (count: {count})")
        
        # Topic patterns
        topics = self._extract_topics(query)
        for topic in topics:
            if topic in self.learned_patterns.get('interests', []):
                patterns.append(f"Recurring interest: {topic}")
        
        # Behavioral patterns
        if len(self.interaction_history) > 10:
            avg_response_time = np.mean([h.get('response_time', 0) for h in list(self.interaction_history)[-10:]])
            if avg_response_time < 2.0:
                patterns.append("User prefers quick responses")
        
        return patterns
    
    def _generate_predictions(self, query: str, reasoning_result: Dict) -> Dict:
        """
        Generate predictions about user needs and future interactions
        Uses historical data and pattern recognition
        """
        predictions = {
            'next_likely_query': None,
            'user_intent': None,
            'suggested_actions': [],
            'confidence': 0.0
        }
        
        try:
            # Predict next query based on patterns
            if len(self.interaction_history) > 5:
                recent_queries = [h['query'] for h in list(self.interaction_history)[-5:]]
                predictions['next_likely_query'] = self._predict_next_query(recent_queries)
            
            # Infer user intent
            predictions['user_intent'] = self._infer_intent(query, reasoning_result)
            
            # Generate suggested actions
            predictions['suggested_actions'] = self._generate_suggestions(query, reasoning_result)
            
            # Calculate prediction confidence
            predictions['confidence'] = self._calculate_prediction_confidence()
            
        except Exception as e:
            logger.error(f"Prediction generation error: {e}")
        
        return predictions
    
    def _build_context(self, query: str, additional_context: Dict = None) -> str:
        """Build comprehensive context for AI processing"""
        context_parts = []
        
        # System context
        context_parts.append("You are SafwaanBuddy, an advanced AI assistant with quantum-level reasoning.")
        context_parts.append("You have access to the user's computer and can perform various tasks.")
        
        # Recent conversation history
        if self.short_term_memory:
            context_parts.append("\nRecent conversation:")
            for mem in list(self.short_term_memory)[-5:]:
                context_parts.append(f"User: {mem.get('query', '')}")
                context_parts.append(f"You: {mem.get('response', '')[:100]}...")
        
        # User preferences
        if self.user_preferences:
            context_parts.append(f"\nUser preferences: {json.dumps(self.user_preferences)}")
        
        # Current emotional state
        emotion_label = self._map_to_emotion_label(self.emotional_state)
        context_parts.append(f"\nCurrent emotional tone: {emotion_label}")
        
        # Additional context
        if additional_context:
            context_parts.append(f"\nAdditional context: {json.dumps(additional_context)}")
        
        return "\n".join(context_parts)
    
    def _calculate_confidence(self, response: str) -> float:
        """Calculate confidence score for a response"""
        if not response:
            return 0.0
        
        # Factors affecting confidence
        length_score = min(len(response) / 500, 1.0)  # Longer responses generally more detailed
        specificity_score = len(re.findall(r'\b\d+\b', response)) / 10  # Numbers indicate specificity
        structure_score = response.count('\n') / 5  # Structured responses are better
        
        # Combine scores
        confidence = (length_score * 0.4 + specificity_score * 0.3 + structure_score * 0.3)
        return min(confidence, 1.0)
    
    def _calculate_consensus(self, responses: List[str]) -> float:
        """Calculate consensus score between multiple responses"""
        if len(responses) < 2:
            return 1.0
        
        # Simple similarity check based on common words
        all_words = []
        for response in responses:
            words = set(response.lower().split())
            all_words.append(words)
        
        # Calculate pairwise similarity
        similarities = []
        for i in range(len(all_words)):
            for j in range(i + 1, len(all_words)):
                intersection = len(all_words[i] & all_words[j])
                union = len(all_words[i] | all_words[j])
                if union > 0:
                    similarities.append(intersection / union)
        
        return np.mean(similarities) if similarities else 0.5
    
    def _classify_query_type(self, query: str) -> str:
        """Classify the type of query"""
        query_lower = query.lower()
        
        if any(word in query_lower for word in ['what', 'who', 'where', 'when', 'why', 'how']):
            return 'question'
        elif any(word in query_lower for word in ['open', 'launch', 'start', 'run']):
            return 'command'
        elif any(word in query_lower for word in ['search', 'find', 'look']):
            return 'search'
        elif any(word in query_lower for word in ['create', 'make', 'write']):
            return 'creation'
        elif any(word in query_lower for word in ['play', 'show', 'watch']):
            return 'entertainment'
        else:
            return 'general'
    
    def _extract_topics(self, query: str) -> List[str]:
        """Extract main topics from query"""
        # Simple topic extraction (can be enhanced with NLP)
        topics = []
        
        topic_keywords = {
            'technology': ['computer', 'software', 'app', 'program', 'code'],
            'entertainment': ['music', 'video', 'movie', 'game', 'play'],
            'productivity': ['work', 'task', 'schedule', 'reminder', 'note'],
            'information': ['weather', 'news', 'time', 'date', 'fact'],
            'communication': ['email', 'message', 'call', 'chat']
        }
        
        query_lower = query.lower()
        for topic, keywords in topic_keywords.items():
            if any(keyword in query_lower for keyword in keywords):
                topics.append(topic)
        
        return topics
    
    def _predict_next_query(self, recent_queries: List[str]) -> str:
        """Predict next likely query based on patterns"""
        # Simple prediction based on common sequences
        # In production, this would use ML models
        
        if not recent_queries:
            return None
        
        last_query = recent_queries[-1].lower()
        
        # Common query sequences
        sequences = {
            'time': 'weather',
            'weather': 'news',
            'news': 'email',
            'open': 'search',
            'search': 'open'
        }
        
        for trigger, next_query in sequences.items():
            if trigger in last_query:
                return f"Likely to ask about {next_query}"
        
        return None
    
    def _infer_intent(self, query: str, reasoning_result: Dict) -> str:
        """Infer user's underlying intent"""
        query_type = self._classify_query_type(query)
        
        intent_map = {
            'question': 'seeking_information',
            'command': 'task_execution',
            'search': 'information_retrieval',
            'creation': 'content_generation',
            'entertainment': 'leisure_activity',
            'general': 'conversation'
        }
        
        return intent_map.get(query_type, 'unknown')
    
    def _generate_suggestions(self, query: str, reasoning_result: Dict) -> List[str]:
        """Generate proactive suggestions for user"""
        suggestions = []
        
        # Based on query type
        query_type = self._classify_query_type(query)
        
        if query_type == 'question':
            suggestions.append("Would you like me to search for more information?")
        elif query_type == 'command':
            suggestions.append("Should I create a shortcut for this action?")
        elif query_type == 'search':
            suggestions.append("Would you like me to summarize the results?")
        
        # Based on time of day
        hour = datetime.now().hour
        if 9 <= hour < 12:
            suggestions.append("Morning productivity tip: Review your tasks for today")
        elif 12 <= hour < 14:
            suggestions.append("Lunch break reminder: Take a short break")
        elif 18 <= hour < 22:
            suggestions.append("Evening wind-down: Consider reviewing your day")
        
        return suggestions[:3]  # Limit to 3 suggestions
    
    def _calculate_prediction_confidence(self) -> float:
        """Calculate confidence in predictions"""
        if len(self.interaction_history) < 10:
            return 0.3  # Low confidence with limited data
        
        # Base confidence on historical accuracy
        if self.prediction_accuracy:
            return np.mean(list(self.prediction_accuracy.values()))
        
        return 0.5  # Medium confidence
    
    def _update_memories(self, query: str, result: Dict):
        """Update all memory systems"""
        # Short-term memory
        self.short_term_memory.append({
            'query': query,
            'response': result['response'],
            'emotion': result['emotion'],
            'timestamp': datetime.now()
        })
        
        # Working memory (current session)
        session_id = datetime.now().strftime("%Y%m%d")
        if session_id not in self.working_memory:
            self.working_memory[session_id] = []
        self.working_memory[session_id].append({
            'query': query,
            'response': result['response'][:200]
        })
        
        # Episodic memory (significant events)
        if result['confidence'] > 0.8:
            self.episodic_memory.append({
                'query': query,
                'response': result['response'],
                'confidence': result['confidence'],
                'timestamp': datetime.now()
            })
        
        # Semantic memory (facts and knowledge)
        topics = self._extract_topics(query)
        for topic in topics:
            if topic not in self.semantic_memory:
                self.semantic_memory[topic] = []
            self.semantic_memory[topic].append({
                'query': query,
                'key_info': result['response'][:100]
            })
    
    def _learn_from_interaction(self, query: str, result: Dict):
        """Learn from user interaction to improve future responses"""
        # Update interaction history
        self.interaction_history.append({
            'query': query,
            'response': result['response'],
            'confidence': result['confidence'],
            'emotion': result['emotion'],
            'timestamp': datetime.now(),
            'response_time': 0.0  # Will be updated by caller
        })
        
        # Update learned patterns
        query_type = self._classify_query_type(query)
        if 'frequent_queries' not in self.learned_patterns:
            self.learned_patterns['frequent_queries'] = {}
        
        if query_type not in self.learned_patterns['frequent_queries']:
            self.learned_patterns['frequent_queries'][query_type] = 0
        self.learned_patterns['frequent_queries'][query_type] += 1
        
        # Update active hours
        current_hour = datetime.now().hour
        if 'active_hours' not in self.learned_patterns:
            self.learned_patterns['active_hours'] = []
        if current_hour not in self.learned_patterns['active_hours']:
            self.learned_patterns['active_hours'].append(current_hour)
        
        # Update interests
        topics = self._extract_topics(query)
        if 'interests' not in self.learned_patterns:
            self.learned_patterns['interests'] = []
        for topic in topics:
            if topic not in self.learned_patterns['interests']:
                self.learned_patterns['interests'].append(topic)
        
        # Save to database
        try:
            self.db.save_interaction(
                query=query,
                response=result['response'],
                confidence=result['confidence'],
                emotion=result['emotion']['label']
            )
        except Exception as e:
            logger.error(f"Database save error: {e}")
    
    def _fallback_response(self, query: str) -> Dict:
        """Fallback response when main processing fails"""
        return {
            'response': "I apologize, but I'm having trouble processing that request. Could you rephrase it?",
            'confidence': 0.3,
            'emotion': {'label': 'neutral', 'valence': 0.0, 'arousal': 0.5, 'dominance': 0.5, 'intensity': 0.0},
            'patterns': [],
            'predictions': {},
            'reasoning_chain': ['Fallback response due to processing error'],
            'model_consensus': 0.0
        }
    
    def get_memory_summary(self) -> Dict:
        """Get summary of all memory systems"""
        return {
            'short_term_count': len(self.short_term_memory),
            'working_memory_sessions': len(self.working_memory),
            'episodic_memory_count': len(self.episodic_memory),
            'semantic_topics': len(self.semantic_memory),
            'learned_patterns': len(self.learned_patterns),
            'interaction_count': len(self.interaction_history)
        }
    
    def get_emotional_state(self) -> Dict:
        """Get current emotional state"""
        return {
            'label': self._map_to_emotion_label(self.emotional_state),
            **self.emotional_state
        }
    
    def reset_session(self):
        """Reset session-specific data"""
        self.short_term_memory.clear()
        self.working_memory.clear()
        logger.info("Session reset completed")