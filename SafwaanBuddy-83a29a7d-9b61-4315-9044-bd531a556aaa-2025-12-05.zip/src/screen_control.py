"""
Screen Control System for SafwaanBuddy
Advanced screen capture, analysis, OCR, and automation
"""
import pyautogui
import logging
from PIL import Image, ImageGrab, ImageOps
import numpy as np
from datetime import datetime
from typing import Optional, Tuple, Dict, List
import json

logger = logging.getLogger('SafwaanBuddy.ScreenControl')


class ScreenControl:
    """Advanced screen control and automation"""
    
    def __init__(self):
        # Screen info
        self.screen_size = pyautogui.size()
        self.center_x = self.screen_size.width // 2
        self.center_y = self.screen_size.height // 2
        
        # Safety settings
        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = 0.1
        
        # Configuration
        self.config = {
            'screenshot_dir': 'screenshots',
            'default_duration': 0.5,
            'mouse_speed': 0.3
        }
        
        # Create screenshot directory
        import os
        os.makedirs(self.config['screenshot_dir'], exist_ok=True)
        
        logger.info(f"[OK] Screen Control initialized - Resolution: {self.screen_size.width}x{self.screen_size.height}")
    
    # ==================== MOUSE CONTROL ====================
    
    def move_mouse(self, x: int, y: int, duration: float = None):
        """Move mouse to position"""
        try:
            duration = duration or self.config['mouse_speed']
            pyautogui.moveTo(x, y, duration=duration)
            logger.debug(f"Mouse moved to ({x}, {y})")
        except Exception as e:
            logger.error(f"Mouse move error: {e}")
    
    def click(self, x: Optional[int] = None, y: Optional[int] = None, 
             button: str = 'left', clicks: int = 1):
        """Click at position"""
        try:
            if x is not None and y is not None:
                pyautogui.click(x, y, clicks=clicks, button=button)
            else:
                pyautogui.click(clicks=clicks, button=button)
            logger.debug(f"Clicked at ({x}, {y}) - {button} button")
        except Exception as e:
            logger.error(f"Click error: {e}")
    
    def double_click(self, x: Optional[int] = None, y: Optional[int] = None):
        """Double click"""
        self.click(x, y, clicks=2)
    
    def right_click(self, x: Optional[int] = None, y: Optional[int] = None):
        """Right click"""
        self.click(x, y, button='right')
    
    def drag(self, start_x: int, start_y: int, end_x: int, end_y: int, 
            duration: float = 0.5):
        """Drag from start to end"""
        try:
            pyautogui.moveTo(start_x, start_y)
            pyautogui.drag(end_x - start_x, end_y - start_y, duration=duration)
            logger.debug(f"Dragged from ({start_x}, {start_y}) to ({end_x}, {end_y})")
        except Exception as e:
            logger.error(f"Drag error: {e}")
    
    def scroll(self, amount: int, direction: str = 'down'):
        """Scroll screen"""
        try:
            scroll_amount = -amount if direction == 'down' else amount
            pyautogui.scroll(scroll_amount)
            logger.debug(f"Scrolled {direction} by {amount}")
        except Exception as e:
            logger.error(f"Scroll error: {e}")
    
    # ==================== KEYBOARD CONTROL ====================
    
    def type_text(self, text: str, interval: float = 0.05):
        """Type text"""
        try:
            pyautogui.write(text, interval=interval)
            logger.debug(f"Typed: {text[:50]}...")
        except Exception as e:
            logger.error(f"Type error: {e}")
    
    def press_key(self, key: str):
        """Press a key"""
        try:
            pyautogui.press(key)
            logger.debug(f"Pressed key: {key}")
        except Exception as e:
            logger.error(f"Key press error: {e}")
    
    def hotkey(self, *keys):
        """Press hotkey combination"""
        try:
            pyautogui.hotkey(*keys)
            logger.debug(f"Hotkey: {' + '.join(keys)}")
        except Exception as e:
            logger.error(f"Hotkey error: {e}")
    
    # ==================== SCREENSHOT & CAPTURE ====================
    
    def take_screenshot(self, filename: Optional[str] = None, 
                       region: Optional[Tuple] = None) -> str:
        """Take screenshot"""
        try:
            if filename is None:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"{self.config['screenshot_dir']}/screenshot_{timestamp}.png"
            
            if region:
                screenshot = pyautogui.screenshot(region=region)
            else:
                screenshot = pyautogui.screenshot()
            
            screenshot.save(filename)
            logger.info(f"[PHOTO] Screenshot saved: {filename}")
            return filename
        except Exception as e:
            logger.error(f"Screenshot error: {e}")
            return ""
    
    def capture_region(self, x: int, y: int, width: int, height: int) -> Optional[Image.Image]:
        """Capture specific screen region"""
        try:
            region = (x, y, x + width, y + height)
            screenshot = ImageGrab.grab(bbox=region)
            return screenshot
        except Exception as e:
            logger.error(f"Region capture error: {e}")
            return None
    
    def capture_window(self, window_title: str) -> Optional[str]:
        """Capture specific window"""
        try:
            import pygetwindow as gw
            
            windows = gw.getWindowsWithTitle(window_title)
            if windows:
                window = windows[0]
                
                # Get window position and size
                left, top = window.left, window.top
                width, height = window.width, window.height
                
                # Capture region
                screenshot = self.capture_region(left, top, width, height)
                
                if screenshot:
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"{self.config['screenshot_dir']}/window_{timestamp}.png"
                    screenshot.save(filename)
                    logger.info(f"Window captured: {filename}")
                    return filename
            
            logger.warning(f"Window not found: {window_title}")
            return None
            
        except Exception as e:
            logger.error(f"Window capture error: {e}")
            return None
    
    # ==================== SCREEN ANALYSIS ====================
    
    def analyze_screen(self) -> Dict:
        """Analyze current screen content"""
        try:
            screenshot = pyautogui.screenshot()
            
            # Convert to numpy array
            img_array = np.array(screenshot)
            
            analysis = {
                'resolution': f"{self.screen_size.width}x{self.screen_size.height}",
                'brightness': self._calculate_brightness(img_array),
                'dominant_colors': self._get_dominant_colors(img_array),
                'has_text': self._detect_text_presence(img_array),
                'timestamp': datetime.now().isoformat()
            }
            
            return analysis
            
        except Exception as e:
            logger.error(f"Screen analysis error: {e}")
            return {}
    
    def _calculate_brightness(self, img_array: np.ndarray) -> float:
        """Calculate average screen brightness"""
        try:
            # Convert to grayscale
            gray = np.mean(img_array, axis=2)
            brightness = np.mean(gray)
            return float(brightness)
        except:
            return 0.0
    
    def _get_dominant_colors(self, img_array: np.ndarray, n_colors: int = 3) -> List[Tuple]:
        """Get dominant colors in image"""
        try:
            # Reshape image
            pixels = img_array.reshape(-1, 3)
            
            # Sample pixels for speed
            sample_size = min(10000, len(pixels))
            sampled = pixels[np.random.choice(len(pixels), sample_size, replace=False)]
            
            # Simple clustering - get most common colors
            unique, counts = np.unique(sampled, axis=0, return_counts=True)
            top_indices = np.argsort(counts)[-n_colors:]
            
            dominant = [tuple(unique[i]) for i in top_indices]
            return dominant
            
        except Exception as e:
            logger.error(f"Color analysis error: {e}")
            return []
    
    def _detect_text_presence(self, img_array: np.ndarray) -> bool:
        """Detect if screen has text (simplified)"""
        try:
            # Convert to grayscale
            gray = np.mean(img_array, axis=2)
            
            # Calculate edge density (text has many edges)
            edges = np.abs(np.diff(gray, axis=0))
            edge_density = np.mean(edges)
            
            # Threshold for text presence
            return edge_density > 10
            
        except:
            return False
    
    def get_screen_text(self) -> str:
        """Get text from screen using OCR (requires pytesseract)"""
        try:
            import pytesseract
            
            screenshot = pyautogui.screenshot()
            text = pytesseract.image_to_string(screenshot)
            
            return text.strip()
            
        except ImportError:
            logger.warning("pytesseract not installed. OCR not available.")
            return ""
        except Exception as e:
            logger.error(f"OCR error: {e}")
            return ""
    
    # ==================== WINDOW MANAGEMENT ====================
    
    def get_active_window(self) -> Optional[str]:
        """Get active window title"""
        try:
            import pygetwindow as gw
            active = gw.getActiveWindow()
            return active.title if active else None
        except Exception as e:
            logger.error(f"Get active window error: {e}")
            return None
    
    def list_windows(self) -> List[str]:
        """List all open windows"""
        try:
            import pygetwindow as gw
            windows = gw.getAllTitles()
            return [w for w in windows if w.strip()]
        except Exception as e:
            logger.error(f"List windows error: {e}")
            return []
    
    def focus_window(self, window_title: str) -> bool:
        """Focus on specific window"""
        try:
            import pygetwindow as gw
            
            windows = gw.getWindowsWithTitle(window_title)
            if windows:
                window = windows[0]
                window.activate()
                logger.info(f"Focused window: {window_title}")
                return True
            
            logger.warning(f"Window not found: {window_title}")
            return False
            
        except Exception as e:
            logger.error(f"Focus window error: {e}")
            return False
    
    # ==================== AUTOMATION ====================
    
    def automate_clicks(self, positions: List[Tuple[int, int]], delay: float = 0.5):
        """Automate series of clicks"""
        try:
            for x, y in positions:
                self.click(x, y)
                time.sleep(delay)
            logger.info(f"Automated {len(positions)} clicks")
        except Exception as e:
            logger.error(f"Automation error: {e}")
    
    def automate_typing(self, text_sequence: List[str], delay: float = 1.0):
        """Automate typing sequence"""
        try:
            for text in text_sequence:
                self.type_text(text)
                time.sleep(delay)
            logger.info(f"Automated typing of {len(text_sequence)} texts")
        except Exception as e:
            logger.error(f"Typing automation error: {e}")
    
    def record_actions(self, duration: int = 10) -> List[Dict]:
        """Record mouse and keyboard actions (simplified)"""
        logger.info(f"Recording actions for {duration} seconds...")
        
        actions = []
        start_time = time.time()
        
        while time.time() - start_time < duration:
            x, y = pyautogui.position()
            actions.append({
                'timestamp': time.time() - start_time,
                'type': 'mouse_position',
                'x': x,
                'y': y
            })
            time.sleep(0.1)
        
        logger.info(f"Recorded {len(actions)} actions")
        return actions
    
    def replay_actions(self, actions: List[Dict]):
        """Replay recorded actions"""
        logger.info(f"Replaying {len(actions)} actions...")
        
        for action in actions:
            if action['type'] == 'mouse_position':
                self.move_mouse(action['x'], action['y'], duration=0.1)
            time.sleep(0.1)
        
        logger.info("Action replay complete")
    
    # ==================== UTILITIES ====================
    
    def get_mouse_position(self) -> Tuple[int, int]:
        """Get current mouse position"""
        return pyautogui.position()
    
    def get_screen_info(self) -> Dict:
        """Get comprehensive screen information"""
        return {
            'resolution': {
                'width': self.screen_size.width,
                'height': self.screen_size.height
            },
            'center': {
                'x': self.center_x,
                'y': self.center_y
            },
            'mouse_position': self.get_mouse_position(),
            'active_window': self.get_active_window(),
            'timestamp': datetime.now().isoformat()
        }
    
    def find_image_on_screen(self, image_path: str, confidence: float = 0.8) -> Optional[Tuple]:
        """Find image on screen"""
        try:
            location = pyautogui.locateOnScreen(image_path, confidence=confidence)
            if location:
                center = pyautogui.center(location)
                return (center.x, center.y)
            return None
        except Exception as e:
            logger.error(f"Image search error: {e}")
            return None
    
    def wait_for_image(self, image_path: str, timeout: int = 10) -> bool:
        """Wait for image to appear on screen"""
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            if self.find_image_on_screen(image_path):
                return True
            time.sleep(0.5)
        
        return False
    
    # ==================== ADVANCED FEATURES ====================
    
    def create_screen_recording(self, duration: int = 10, filename: Optional[str] = None):
        """Create screen recording (requires additional libraries)"""
        logger.warning("Screen recording requires additional libraries (opencv-python, numpy)")
        # Placeholder for screen recording functionality
        return None
    
    def detect_changes(self, interval: float = 1.0, duration: int = 10) -> List[Dict]:
        """Detect screen changes over time"""
        logger.info(f"Monitoring screen changes for {duration} seconds...")
        
        changes = []
        previous_screenshot = None
        start_time = time.time()
        
        while time.time() - start_time < duration:
            current_screenshot = pyautogui.screenshot()
            
            if previous_screenshot:
                # Compare screenshots
                diff = self._compare_images(previous_screenshot, current_screenshot)
                if diff > 0.05:  # 5% change threshold
                    changes.append({
                        'timestamp': time.time() - start_time,
                        'change_percentage': diff * 100
                    })
            
            previous_screenshot = current_screenshot
            time.sleep(interval)
        
        logger.info(f"Detected {len(changes)} changes")
        return changes
    
    def _compare_images(self, img1: Image.Image, img2: Image.Image) -> float:
        """Compare two images and return difference percentage"""
        try:
            # Convert to numpy arrays
            arr1 = np.array(img1)
            arr2 = np.array(img2)
            
            # Calculate difference
            diff = np.abs(arr1.astype(float) - arr2.astype(float))
            diff_percentage = np.mean(diff) / 255.0
            
            return diff_percentage
        except:
            return 0.0
    
    # ==================== SCREEN READING ====================
    
    def read_screen_region(self, x: int, y: int, width: int, height: int) -> str:
        """Read text from screen region using OCR"""
        try:
            import pytesseract
            
            region = self.capture_region(x, y, width, height)
            if region:
                text = pytesseract.image_to_string(region)
                return text.strip()
            
            return ""
            
        except ImportError:
            logger.warning("pytesseract not installed")
            return ""
        except Exception as e:
            logger.error(f"Screen reading error: {e}")
            return ""
    
    def find_text_on_screen(self, search_text: str) -> Optional[Tuple[int, int]]:
        """Find text on screen and return position (requires OCR)"""
        try:
            import pytesseract
            
            screenshot = pyautogui.screenshot()
            
            # Get text with bounding boxes
            data = pytesseract.image_to_data(screenshot, output_type=pytesseract.Output.DICT)
            
            # Search for text
            for i, text in enumerate(data['text']):
                if search_text.lower() in text.lower():
                    x = data['left'][i] + data['width'][i] // 2
                    y = data['top'][i] + data['height'][i] // 2
                    return (x, y)
            
            return None
            
        except ImportError:
            logger.warning("pytesseract not installed")
            return None
        except Exception as e:
            logger.error(f"Text search error: {e}")
            return None
    
    # ==================== APPLICATION CONTROL ====================
    
    def open_application(self, app_name: str) -> bool:
        """Open application"""
        try:
            import subprocess
            import platform
            
            system = platform.system()
            
            if system == "Windows":
                # Try to open application
                try:
                    subprocess.Popen(app_name)
                    logger.info(f"Opened application: {app_name}")
                    return True
                except:
                    # Try with .exe extension
                    try:
                        subprocess.Popen(f"{app_name}.exe")
                        logger.info(f"Opened application: {app_name}.exe")
                        return True
                    except:
                        logger.warning(f"Could not open: {app_name}")
                        return False
            
            return False
            
        except Exception as e:
            logger.error(f"Open application error: {e}")
            return False
    
    def close_application(self, app_name: str) -> bool:
        """Close application by name"""
        try:
            import psutil
            
            for proc in psutil.process_iter(['name']):
                if app_name.lower() in proc.info['name'].lower():
                    proc.terminate()
                    logger.info(f"Closed application: {app_name}")
                    return True
            
            logger.warning(f"Application not found: {app_name}")
            return False
            
        except Exception as e:
            logger.error(f"Close application error: {e}")
            return False
    
    # ==================== SAVE/LOAD ====================
    
    def save_config(self):
        """Save configuration"""
        try:
            config_path = "config/screen_config.json"
            import os
            os.makedirs(os.path.dirname(config_path), exist_ok=True)
            
            with open(config_path, 'w') as f:
                json.dump(self.config, f, indent=2)
            
            logger.debug("Screen config saved")
        except Exception as e:
            logger.error(f"Config save error: {e}")
    
    def load_config(self):
        """Load configuration"""
        try:
            config_path = "config/screen_config.json"
            with open(config_path, 'r') as f:
                self.config.update(json.load(f))
            
            logger.debug("Screen config loaded")
        except FileNotFoundError:
            pass
        except Exception as e:
            logger.error(f"Config load error: {e}")


# Global instance
_screen_control = None

def get_screen_control() -> ScreenControl:
    """Get global screen control instance"""
    global _screen_control
    if _screen_control is None:
        _screen_control = ScreenControl()
    return _screen_control