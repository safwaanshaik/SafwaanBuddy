"""
Security and Privacy System for SafwaanBuddy ULTIMATE
Advanced encryption, authentication, and privacy protection
"""
import logging
import hashlib
import base64
import os
from typing import Dict, Optional, Any
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2
import json

logger = logging.getLogger('SafwaanBuddy.Security')


class SecurityPrivacySystem:
    """Advanced security and privacy protection"""
    
    def __init__(self, config_manager):
        self.config = config_manager
        
        # Encryption
        self.cipher = None
        self.encryption_enabled = config_manager.get('features', {}).get('enable_encryption', False)
        
        if self.encryption_enabled:
            self._initialize_encryption()
        
        # Privacy settings
        self.privacy_settings = {
            'data_collection': True,
            'conversation_logging': True,
            'analytics': False,
            'third_party_sharing': False,
            'data_retention_days': 90
        }
        
        # Security settings
        self.security_settings = {
            'require_authentication': False,
            'session_timeout': 3600,  # 1 hour
            'max_failed_attempts': 3,
            'lockout_duration': 300  # 5 minutes
        }
        
        logger.info("[OK] Security and privacy system initialized")
    
    def _initialize_encryption(self) -> None:
        """Initialize encryption system"""
        try:
            # Generate or load encryption key
            key_file = 'encryption.key'
            
            if os.path.exists(key_file):
                with open(key_file, 'rb') as f:
                    key = f.read()
            else:
                key = Fernet.generate_key()
                with open(key_file, 'wb') as f:
                    f.write(key)
            
            self.cipher = Fernet(key)
            logger.info("[OK] Encryption initialized")
            
        except Exception as e:
            logger.error(f"[ERROR] Failed to initialize encryption: {e}")
            self.encryption_enabled = False
    
    def encrypt_data(self, data: str) -> Optional[str]:
        """Encrypt sensitive data"""
        try:
            if not self.encryption_enabled or not self.cipher:
                return data
            
            encrypted = self.cipher.encrypt(data.encode())
            return base64.b64encode(encrypted).decode()
            
        except Exception as e:
            logger.error(f"[ERROR] Encryption failed: {e}")
            return None
    
    def decrypt_data(self, encrypted_data: str) -> Optional[str]:
        """Decrypt encrypted data"""
        try:
            if not self.encryption_enabled or not self.cipher:
                return encrypted_data
            
            decoded = base64.b64decode(encrypted_data.encode())
            decrypted = self.cipher.decrypt(decoded)
            return decrypted.decode()
            
        except Exception as e:
            logger.error(f"[ERROR] Decryption failed: {e}")
            return None
    
    def hash_password(self, password: str) -> str:
        """Hash password securely"""
        try:
            salt = os.urandom(32)
            key = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)
            return base64.b64encode(salt + key).decode()
            
        except Exception as e:
            logger.error(f"[ERROR] Password hashing failed: {e}")
            return ""
    
    def verify_password(self, password: str, hashed: str) -> bool:
        """Verify password against hash"""
        try:
            decoded = base64.b64decode(hashed.encode())
            salt = decoded[:32]
            stored_key = decoded[32:]
            
            key = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)
            return key == stored_key
            
        except Exception as e:
            logger.error(f"[ERROR] Password verification failed: {e}")
            return False
    
    def sanitize_input(self, user_input: str) -> str:
        """Sanitize user input for security"""
        try:
            # Remove potentially dangerous characters
            sanitized = user_input.replace('<', '').replace('>', '')
            sanitized = sanitized.replace('script', '').replace('eval', '')
            return sanitized
            
        except Exception as e:
            logger.error(f"[ERROR] Input sanitization failed: {e}")
            return user_input
    
    def anonymize_data(self, data: Dict) -> Dict:
        """Anonymize sensitive data"""
        try:
            anonymized = data.copy()
            
            # Remove or hash sensitive fields
            sensitive_fields = ['email', 'phone', 'address', 'ssn', 'credit_card']
            
            for field in sensitive_fields:
                if field in anonymized:
                    anonymized[field] = self._hash_value(anonymized[field])
            
            return anonymized
            
        except Exception as e:
            logger.error(f"[ERROR] Data anonymization failed: {e}")
            return data
    
    def _hash_value(self, value: str) -> str:
        """Hash a value for anonymization"""
        try:
            return hashlib.sha256(value.encode()).hexdigest()[:16]
        except:
            return "***"
    
    def check_privacy_compliance(self, action: str) -> bool:
        """Check if action complies with privacy settings"""
        try:
            if action == 'log_conversation':
                return self.privacy_settings['conversation_logging']
            elif action == 'collect_data':
                return self.privacy_settings['data_collection']
            elif action == 'analytics':
                return self.privacy_settings['analytics']
            elif action == 'third_party':
                return self.privacy_settings['third_party_sharing']
            else:
                return True
                
        except Exception as e:
            logger.error(f"[ERROR] Privacy compliance check failed: {e}")
            return False
    
    def update_privacy_settings(self, settings: Dict) -> bool:
        """Update privacy settings"""
        try:
            self.privacy_settings.update(settings)
            logger.info(f"[OK] Privacy settings updated: {settings}")
            return True
            
        except Exception as e:
            logger.error(f"[ERROR] Failed to update privacy settings: {e}")
            return False
    
    def get_privacy_report(self) -> Dict:
        """Get privacy compliance report"""
        try:
            return {
                'privacy_settings': self.privacy_settings,
                'encryption_enabled': self.encryption_enabled,
                'security_settings': self.security_settings,
                'compliance_status': 'compliant'
            }
        except Exception as e:
            logger.error(f"[ERROR] Failed to generate privacy report: {e}")
            return {}