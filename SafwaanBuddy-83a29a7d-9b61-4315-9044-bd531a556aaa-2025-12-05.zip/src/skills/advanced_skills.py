"""
Advanced Skills for SafwaanBuddy
System automation and advanced features
"""
import os
import platform
import psutil
import subprocess
import logging
from typing import Optional

logger = logging.getLogger('SafwaanBuddy.AdvancedSkills')


class AdvancedSkills:
    """Advanced skill implementations"""
    
    def __init__(self, config=None, logger=None):
        """
        Initialize AdvancedSkills
        
        Args:
            config: Optional configuration manager
            logger: Optional logger instance
        """
        self.config = config
        self.logger = logger or logging.getLogger('AdvancedSkills')

    @staticmethod
    def get_system_info() -> str:
        """Get system information"""
        try:
            info = []
            info.append(f"System: {platform.system()} {platform.release()}")
            info.append(f"Processor: {platform.processor()}")
            info.append(f"CPU Usage: {psutil.cpu_percent()}%")
            info.append(f"Memory Usage: {psutil.virtual_memory().percent}%")
            info.append(f"Disk Usage: {psutil.disk_usage('/').percent}%")
            
            return "\n".join(info)
        except Exception as e:
            logger.error(f"System info error: {e}")
            return "I couldn't get system information"
    
    @staticmethod
    def set_volume(level: Optional[str]) -> str:
        """Set system volume (Windows only)"""
        try:
            if not level:
                return "What volume level would you like? (0-100)"
            
            volume = int(level)
            volume = max(0, min(100, volume))
            
            if platform.system() == "Windows":
                # Use nircmd or other Windows volume control
                # This is a placeholder - actual implementation would use Windows API
                return f"Volume set to {volume}%"
            else:
                return "Volume control is only available on Windows"
                
        except Exception as e:
            logger.error(f"Set volume error: {e}")
            return "I couldn't set the volume"
    
    @staticmethod
    def close_window() -> str:
        """Close current window"""
        try:
            if platform.system() == "Windows":
                import pyautogui
                pyautogui.hotkey('alt', 'f4')
                return "Closing current window"
            else:
                return "Window closing is only available on Windows"
        except Exception as e:
            logger.error(f"Close window error: {e}")
            return "I couldn't close the window"
    
    @staticmethod
    def minimize_window() -> str:
        """Minimize current window"""
        try:
            if platform.system() == "Windows":
                import pyautogui
                pyautogui.hotkey('win', 'down')
                return "Minimizing window"
            else:
                return "Window minimizing is only available on Windows"
        except Exception as e:
            logger.error(f"Minimize window error: {e}")
            return "I couldn't minimize the window"
    
    @staticmethod
    def maximize_window() -> str:
        """Maximize current window"""
        try:
            if platform.system() == "Windows":
                import pyautogui
                pyautogui.hotkey('win', 'up')
                return "Maximizing window"
            else:
                return "Window maximizing is only available on Windows"
        except Exception as e:
            logger.error(f"Maximize window error: {e}")
            return "I couldn't maximize the window"
    
    @staticmethod
    def lock_computer() -> str:
        """Lock the computer"""
        try:
            if platform.system() == "Windows":
                subprocess.run(['rundll32.exe', 'user32.dll,LockWorkStation'])
                return "Locking computer"
            else:
                return "Computer locking is only available on Windows"
        except Exception as e:
            logger.error(f"Lock computer error: {e}")
            return "I couldn't lock the computer"
    
    @staticmethod
    def shutdown_computer(delay: int = 60) -> str:
        """Shutdown computer with delay"""
        try:
            if platform.system() == "Windows":
                subprocess.run(['shutdown', '/s', '/t', str(delay)])
                return f"Computer will shutdown in {delay} seconds"
            else:
                return "Shutdown is only available on Windows"
        except Exception as e:
            logger.error(f"Shutdown error: {e}")
            return "I couldn't shutdown the computer"
    
    @staticmethod
    def restart_computer(delay: int = 60) -> str:
        """Restart computer with delay"""
        try:
            if platform.system() == "Windows":
                subprocess.run(['shutdown', '/r', '/t', str(delay)])
                return f"Computer will restart in {delay} seconds"
            else:
                return "Restart is only available on Windows"
        except Exception as e:
            logger.error(f"Restart error: {e}")
            return "I couldn't restart the computer"
    
    @staticmethod
    def cancel_shutdown() -> str:
        """Cancel scheduled shutdown/restart"""
        try:
            if platform.system() == "Windows":
                subprocess.run(['shutdown', '/a'])
                return "Shutdown/restart cancelled"
            else:
                return "Cancel shutdown is only available on Windows"
        except Exception as e:
            logger.error(f"Cancel shutdown error: {e}")
            return "I couldn't cancel the shutdown"
    
    @staticmethod
    def empty_recycle_bin() -> str:
        """Empty recycle bin (Windows only)"""
        try:
            if platform.system() == "Windows":
                import winshell
                winshell.recycle_bin().empty(confirm=False, show_progress=False)
                return "Recycle bin emptied"
            else:
                return "Recycle bin is only available on Windows"
        except ImportError:
            return "winshell module not installed"
        except Exception as e:
            logger.error(f"Empty recycle bin error: {e}")
            return "I couldn't empty the recycle bin"
    
    @staticmethod
    def get_battery_status() -> str:
        """Get battery status"""
        try:
            battery = psutil.sensors_battery()
            if battery:
                percent = battery.percent
                plugged = "plugged in" if battery.power_plugged else "not plugged in"
                return f"Battery is at {percent}% and {plugged}"
            else:
                return "No battery detected"
        except Exception as e:
            logger.error(f"Battery status error: {e}")
            return "I couldn't get battery status"
    
    @staticmethod
    def get_network_info() -> str:
        """Get network information"""
        try:
            import socket
            hostname = socket.gethostname()
            ip_address = socket.gethostbyname(hostname)
            return f"Hostname: {hostname}\nIP Address: {ip_address}"
        except Exception as e:
            logger.error(f"Network info error: {e}")
            return "I couldn't get network information"
    
    @staticmethod
    def open_task_manager() -> str:
        """Open task manager (Windows only)"""
        try:
            if platform.system() == "Windows":
                subprocess.Popen('taskmgr.exe')
                return "Opening Task Manager"
            else:
                return "Task Manager is only available on Windows"
        except Exception as e:
            logger.error(f"Open task manager error: {e}")
            return "I couldn't open Task Manager"
    
    @staticmethod
    def open_control_panel() -> str:
        """Open control panel (Windows only)"""
        try:
            if platform.system() == "Windows":
                subprocess.Popen('control.exe')
                return "Opening Control Panel"
            else:
                return "Control Panel is only available on Windows"
        except Exception as e:
            logger.error(f"Open control panel error: {e}")
            return "I couldn't open Control Panel"