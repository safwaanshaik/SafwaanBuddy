"""
Basic Skills for SafwaanBuddy
Common utility functions and basic commands
"""
import os
import webbrowser
import pyautogui
import logging
from datetime import datetime
import random

logger = logging.getLogger('SafwaanBuddy.BasicSkills')


class BasicSkills:
    """Basic skill implementations"""
    
    def __init__(self, config=None, logger=None):
        """
        Initialize BasicSkills
        
        Args:
            config: Optional configuration manager
            logger: Optional logger instance
        """
        self.config = config
        self.logger = logger or logging.getLogger('BasicSkills')

    @staticmethod
    def get_time() -> str:
        """Get current time"""
        try:
            current_time = datetime.now().strftime("%I:%M %p")
            return f"The current time is {current_time}"
        except Exception as e:
            logger.error(f"Get time error: {e}")
            return "I couldn't get the time"
    
    @staticmethod
    def get_date() -> str:
        """Get current date"""
        try:
            current_date = datetime.now().strftime("%A, %B %d, %Y")
            return f"Today is {current_date}"
        except Exception as e:
            logger.error(f"Get date error: {e}")
            return "I couldn't get the date"
    
    @staticmethod
    def tell_joke() -> str:
        """Tell a random joke"""
        jokes = [
            "Why don't programmers like nature? It has too many bugs!",
            "Why did the AI go to school? To improve its neural network!",
            "What's an AI's favorite snack? Microchips!",
            "Why was the computer cold? It left its Windows open!",
            "I told my computer a joke about UDP, but I don't know if it got it.",
            "Why do programmers prefer dark mode? Because light attracts bugs!",
            "What do you call a programmer from Finland? Nerdic!",
            "Why did the developer go broke? Because he used up all his cache!",
            "How many programmers does it take to change a light bulb? None, that's a hardware problem!",
            "Why do Java developers wear glasses? Because they don't C#!"
        ]
        return random.choice(jokes)
    
    @staticmethod
    def search_web(query: str) -> str:
        """Search the web"""
        try:
            if query:
                url = f"https://www.google.com/search?q={query}"
                webbrowser.open(url)
                return f"Searching for {query}"
            return "What would you like me to search for?"
        except Exception as e:
            logger.error(f"Web search error: {e}")
            return "I couldn't open the browser"
    
    @staticmethod
    def play_music(query: str) -> str:
        """Play music on YouTube"""
        try:
            if query:
                url = f"https://www.youtube.com/results?search_query={query}"
                webbrowser.open(url)
                return f"Playing {query} on YouTube"
            return "What would you like me to play?"
        except Exception as e:
            logger.error(f"Play music error: {e}")
            return "I couldn't open YouTube"
    
    @staticmethod
    def open_website(url: str) -> str:
        """Open a website"""
        try:
            if url:
                if not url.startswith('http'):
                    url = f"https://{url}"
                webbrowser.open(url)
                return f"Opening {url}"
            return "Which website would you like to visit?"
        except Exception as e:
            logger.error(f"Open website error: {e}")
            return "I couldn't open that website"
    
    @staticmethod
    def take_screenshot() -> str:
        """Take a screenshot"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"screenshot_{timestamp}.png"
            screenshot = pyautogui.screenshot()
            screenshot.save(filename)
            return f"Screenshot saved as {filename}"
        except Exception as e:
            logger.error(f"Screenshot error: {e}")
            return "I couldn't take a screenshot"
    
    @staticmethod
    def get_weather() -> str:
        """Open weather website"""
        try:
            webbrowser.open("https://www.weather.com")
            return "Opening weather information"
        except Exception as e:
            logger.error(f"Weather error: {e}")
            return "I couldn't open the weather"
    
    @staticmethod
    def get_news() -> str:
        """Open news website"""
        try:
            webbrowser.open("https://news.google.com")
            return "Opening latest news"
        except Exception as e:
            logger.error(f"News error: {e}")
            return "I couldn't open the news"
    
    @staticmethod
    def open_email() -> str:
        """Open email"""
        try:
            webbrowser.open("https://gmail.com")
            return "Opening your email"
        except Exception as e:
            logger.error(f"Email error: {e}")
            return "I couldn't open email"
    
    @staticmethod
    def open_calendar() -> str:
        """Open calendar"""
        try:
            webbrowser.open("https://calendar.google.com")
            return "Opening your calendar"
        except Exception as e:
            logger.error(f"Calendar error: {e}")
            return "I couldn't open calendar"
    
    @staticmethod
    def calculate(expression: str) -> str:
        """Calculate mathematical expression"""
        try:
            if expression:
                # Clean expression
                expression = expression.replace('x', '*').replace('÷', '/')
                result = eval(expression)
                return f"The result is {result}"
            return "What would you like me to calculate?"
        except Exception as e:
            logger.error(f"Calculate error: {e}")
            return "I couldn't calculate that expression"
    
    @staticmethod
    def take_note(note: str) -> str:
        """Take a note"""
        try:
            if note:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"note_{timestamp}.txt"
                with open(filename, 'w') as f:
                    f.write(f"Note taken at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}:\n\n")
                    f.write(note)
                return f"Note saved as {filename}"
            return "What would you like me to note?"
        except Exception as e:
            logger.error(f"Take note error: {e}")
            return "I couldn't save the note"
    
    @staticmethod
    def translate(text: str) -> str:
        """Open Google Translate"""
        try:
            if text:
                url = f"https://translate.google.com/?text={text}"
                webbrowser.open(url)
                return f"Translating: {text}"
            return "What would you like me to translate?"
        except Exception as e:
            logger.error(f"Translate error: {e}")
            return "I couldn't open translator"