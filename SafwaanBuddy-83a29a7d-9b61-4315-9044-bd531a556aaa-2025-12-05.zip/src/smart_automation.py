"""
Smart Automation Engine for SafwaanBuddy
Intelligent task scheduling, workflows, and automation
"""
import logging
import time
import json
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable, Any
from collections import defaultdict
import schedule

logger = logging.getLogger('SafwaanBuddy.SmartAutomation')


class SmartAutomation:
    """Intelligent automation and task scheduling"""
    
    def __init__(self, config_manager, db_manager, voice_system):
        self.config = config_manager
        self.db = db_manager
        self.voice = voice_system
        
        # Task scheduler
        self.scheduler = schedule
        self.scheduled_tasks = {}
        
        # Workflows
        self.workflows = {}
        self.workflow_history = []
        
        # Task queue
        self.task_queue = []
        
        # State
        self.is_running = False
        self.scheduler_thread = None
        
        # Smart features
        self.smart_reminders = []
        self.context_tasks = defaultdict(list)
        
        logger.info("[OK] Smart Automation initialized")
    
    def start(self):
        """Start automation engine"""
        if self.is_running:
            return
        
        self.is_running = True
        self.scheduler_thread = threading.Thread(
            target=self._scheduler_loop,
            daemon=True
        )
        self.scheduler_thread.start()
        logger.info("[BOT] Smart Automation started")
    
    def stop(self):
        """Stop automation engine"""
        self.is_running = False
        if self.scheduler_thread:
            self.scheduler_thread.join(timeout=2)
        logger.info("Smart Automation stopped")
    
    def _scheduler_loop(self):
        """Main scheduler loop"""
        while self.is_running:
            try:
                schedule.run_pending()
                time.sleep(1)
            except Exception as e:
                logger.error(f"Scheduler error: {e}")
                time.sleep(1)
    
    # ==================== TASK SCHEDULING ====================
    
    def schedule_task(self, task_name: str, task_func: Callable,
                     schedule_time: str, repeat: str = "once") -> bool:
        """
        Schedule a task
        
        Args:
            task_name: Name of the task
            task_func: Function to execute
            schedule_time: Time string (e.g., "10:30", "14:00")
            repeat: "once", "daily", "hourly"
        """
        try:
            if repeat == "daily":
                schedule.every().day.at(schedule_time).do(task_func)
            elif repeat == "hourly":
                schedule.every().hour.do(task_func)
            elif repeat == "once":
                # Schedule for specific time today or tomorrow
                target_time = datetime.strptime(schedule_time, "%H:%M").time()
                now = datetime.now()
                target_datetime = datetime.combine(now.date(), target_time)
                
                if target_datetime < now:
                    target_datetime += timedelta(days=1)
                
                delay = (target_datetime - now).total_seconds()
                
                def delayed_task():
                    time.sleep(delay)
                    task_func()
                
                thread = threading.Thread(target=delayed_task, daemon=True)
                thread.start()
            
            self.scheduled_tasks[task_name] = {
                'function': task_func,
                'schedule_time': schedule_time,
                'repeat': repeat,
                'created_at': datetime.now().isoformat()
            }
            
            logger.info(f"[CALENDAR] Task scheduled: {task_name} at {schedule_time} ({repeat})")
            return True
        
        except Exception as e:
            logger.error(f"Task scheduling error: {e}")
            return False
    
    def cancel_task(self, task_name: str) -> bool:
        """Cancel scheduled task"""
        if task_name in self.scheduled_tasks:
            del self.scheduled_tasks[task_name]
            schedule.clear(task_name)
            logger.info(f"Task cancelled: {task_name}")
            return True
        return False
    
    def list_scheduled_tasks(self) -> List[Dict]:
        """List all scheduled tasks"""
        return [
            {'name': name, **details}
            for name, details in self.scheduled_tasks.items()
        ]
    
    # ==================== WORKFLOWS ====================
    
    def create_workflow(self, workflow_name: str, steps: List[Dict]) -> bool:
        """
        Create automation workflow
        
        Args:
            workflow_name: Name of workflow
            steps: List of steps with 'action' and 'params'
        """
        try:
            self.workflows[workflow_name] = {
                'steps': steps,
                'created_at': datetime.now().isoformat(),
                'execution_count': 0
            }
            
            logger.info(f"🔄 Workflow created: {workflow_name} with {len(steps)} steps")
            return True
        
        except Exception as e:
            logger.error(f"Workflow creation error: {e}")
            return False
    
    def execute_workflow(self, workflow_name: str) -> bool:
        """Execute a workflow"""
        try:
            if workflow_name not in self.workflows:
                logger.warning(f"Workflow not found: {workflow_name}")
                return False
            
            workflow = self.workflows[workflow_name]
            steps = workflow['steps']
            
            logger.info(f"▶️ Executing workflow: {workflow_name}")
            
            for i, step in enumerate(steps):
                logger.info(f"  Step {i+1}/{len(steps)}: {step.get('action', 'unknown')}")
                
                action = step.get('action')
                params = step.get('params', {})
                
                # Execute step
                success = self._execute_workflow_step(action, params)
                
                if not success and step.get('required', True):
                    logger.error(f"Workflow failed at step {i+1}")
                    return False
                
                # Delay between steps
                delay = step.get('delay', 0.5)
                time.sleep(delay)
            
            # Update execution count
            workflow['execution_count'] += 1
            workflow['last_executed'] = datetime.now().isoformat()
            
            # Store in history
            self.workflow_history.append({
                'workflow': workflow_name,
                'timestamp': datetime.now().isoformat(),
                'success': True
            })
            
            logger.info(f"[OK] Workflow completed: {workflow_name}")
            return True
        
        except Exception as e:
            logger.error(f"Workflow execution error: {e}")
            return False
    
    def _execute_workflow_step(self, action: str, params: Dict) -> bool:
        """Execute a single workflow step"""
        try:
            if action == 'speak':
                text = params.get('text', '')
                self.voice.speak(text)
                return True
            
            elif action == 'wait':
                duration = params.get('duration', 1.0)
                time.sleep(duration)
                return True
            
            elif action == 'open_website':
                import webbrowser
                url = params.get('url', '')
                webbrowser.open(url)
                return True
            
            elif action == 'take_screenshot':
                from src.screen_control import get_screen_control
                screen = get_screen_control()
                screen.take_screenshot()
                return True
            
            elif action == 'type_text':
                from src.screen_control import get_screen_control
                screen = get_screen_control()
                text = params.get('text', '')
                screen.type_text(text)
                return True
            
            elif action == 'click':
                from src.screen_control import get_screen_control
                screen = get_screen_control()
                x = params.get('x', 0)
                y = params.get('y', 0)
                screen.click(x, y)
                return True
            
            elif action == 'press_key':
                from src.screen_control import get_screen_control
                screen = get_screen_control()
                key = params.get('key', '')
                screen.press_key(key)
                return True
            
            else:
                logger.warning(f"Unknown workflow action: {action}")
                return False
        
        except Exception as e:
            logger.error(f"Workflow step error: {e}")
            return False
    
    def list_workflows(self) -> List[Dict]:
        """List all workflows"""
        return [
            {'name': name, **details}
            for name, details in self.workflows.items()
        ]
    
    # ==================== SMART REMINDERS ====================
    
    def create_smart_reminder(self, reminder_text: str, 
                             trigger_time: Optional[str] = None,
                             trigger_context: Optional[str] = None) -> bool:
        """
        Create smart reminder with time or context trigger
        
        Args:
            reminder_text: What to remind
            trigger_time: Time to remind (e.g., "15:30")
            trigger_context: Context to trigger (e.g., "when_idle")
        """
        try:
            reminder = {
                'text': reminder_text,
                'trigger_time': trigger_time,
                'trigger_context': trigger_context,
                'created_at': datetime.now().isoformat(),
                'triggered': False
            }
            
            self.smart_reminders.append(reminder)
            
            # Schedule if time-based
            if trigger_time:
                def remind():
                    self.voice.speak(
                        f"Reminder: {reminder_text}",
                        emotion='helpful'
                    )
                    reminder['triggered'] = True
                
                self.schedule_task(
                    f"reminder_{len(self.smart_reminders)}",
                    remind,
                    trigger_time,
                    "once"
                )
            
            logger.info(f"[NOTE] Smart reminder created: {reminder_text}")
            return True
        
        except Exception as e:
            logger.error(f"Reminder creation error: {e}")
            return False
    
    def check_context_reminders(self, current_context: str):
        """Check and trigger context-based reminders"""
        for reminder in self.smart_reminders:
            if not reminder['triggered'] and reminder['trigger_context'] == current_context:
                self.voice.speak(
                    f"Reminder: {reminder['text']}",
                    emotion='helpful'
                )
                reminder['triggered'] = True
    
    # ==================== FILE MANAGEMENT ====================
    
    def organize_files(self, directory: str, by: str = "type") -> Dict:
        """Organize files in directory"""
        try:
            import os
            import shutil
            from pathlib import Path
            
            dir_path = Path(directory)
            if not dir_path.exists():
                return {'error': 'Directory not found'}
            
            organized = defaultdict(list)
            
            if by == "type":
                # Organize by file extension
                for file in dir_path.iterdir():
                    if file.is_file():
                        ext = file.suffix.lower() or 'no_extension'
                        
                        # Create category folder
                        category_folder = dir_path / f"_{ext[1:]}_files"
                        category_folder.mkdir(exist_ok=True)
                        
                        # Move file
                        new_path = category_folder / file.name
                        shutil.move(str(file), str(new_path))
                        
                        organized[ext].append(file.name)
            
            elif by == "date":
                # Organize by modification date
                for file in dir_path.iterdir():
                    if file.is_file():
                        mod_time = datetime.fromtimestamp(file.stat().st_mtime)
                        date_str = mod_time.strftime("%Y-%m")
                        
                        # Create date folder
                        date_folder = dir_path / date_str
                        date_folder.mkdir(exist_ok=True)
                        
                        # Move file
                        new_path = date_folder / file.name
                        shutil.move(str(file), str(new_path))
                        
                        organized[date_str].append(file.name)
            
            logger.info(f"[FOLDER] Files organized in {directory}")
            return dict(organized)
        
        except Exception as e:
            logger.error(f"File organization error: {e}")
            return {'error': str(e)}
    
    def cleanup_temp_files(self, older_than_days: int = 7) -> int:
        """Clean up temporary files"""
        try:
            import os
            from pathlib import Path
            
            temp_dirs = ['temp_audio', 'screenshots']
            cleaned_count = 0
            cutoff_time = time.time() - (older_than_days * 86400)
            
            for temp_dir in temp_dirs:
                if os.path.exists(temp_dir):
                    for file in Path(temp_dir).iterdir():
                        if file.is_file() and file.stat().st_mtime < cutoff_time:
                            file.unlink()
                            cleaned_count += 1
            
            logger.info(f"🧹 Cleaned {cleaned_count} temporary files")
            return cleaned_count
        
        except Exception as e:
            logger.error(f"Cleanup error: {e}")
            return 0
    
    # ==================== APPLICATION LAUNCHER ====================
    
    def smart_launch_app(self, app_description: str) -> bool:
        """Launch application using AI to understand description"""
        try:
            # Common application mappings
            app_map = {
                'browser': 'chrome.exe',
                'chrome': 'chrome.exe',
                'firefox': 'firefox.exe',
                'edge': 'msedge.exe',
                'notepad': 'notepad.exe',
                'calculator': 'calc.exe',
                'paint': 'mspaint.exe',
                'word': 'winword.exe',
                'excel': 'excel.exe',
                'powerpoint': 'powerpnt.exe',
                'outlook': 'outlook.exe',
                'teams': 'teams.exe',
                'vscode': 'code.exe',
                'visual studio code': 'code.exe',
                'spotify': 'spotify.exe',
                'discord': 'discord.exe',
                'slack': 'slack.exe'
            }
            
            # Find matching app
            app_lower = app_description.lower()
            
            for key, exe in app_map.items():
                if key in app_lower:
                    import subprocess
                    subprocess.Popen(exe, shell=True)
                    logger.info(f"[LAUNCH] Launched: {exe}")
                    return True
            
            # Try direct launch
            import subprocess
            subprocess.Popen(app_description, shell=True)
            logger.info(f"[LAUNCH] Launched: {app_description}")
            return True
        
        except Exception as e:
            logger.error(f"App launch error: {e}")
            return False
    
    # ==================== CLIPBOARD MANAGER ====================
    
    def get_clipboard_content(self) -> str:
        """Get clipboard content"""
        try:
            import pyperclip
            content = pyperclip.paste()
            return content
        except ImportError:
            logger.warning("pyperclip not installed")
            return ""
        except Exception as e:
            logger.error(f"Clipboard read error: {e}")
            return ""
    
    def set_clipboard_content(self, content: str) -> bool:
        """Set clipboard content"""
        try:
            import pyperclip
            pyperclip.copy(content)
            logger.info("[CLIPBOARD] Clipboard updated")
            return True
        except ImportError:
            logger.warning("pyperclip not installed")
            return False
        except Exception as e:
            logger.error(f"Clipboard write error: {e}")
            return False
    
    def clipboard_history(self, max_items: int = 10) -> List[str]:
        """Get clipboard history (simplified)"""
        # This would require continuous monitoring
        # Placeholder for now
        return []
    
    # ==================== SMART SUGGESTIONS ====================
    
    def suggest_workflow_for_task(self, task_description: str) -> Optional[Dict]:
        """Suggest workflow for a task"""
        task_lower = task_description.lower()
        
        # Predefined workflow templates
        templates = {
            'morning_routine': {
                'name': 'Morning Routine',
                'steps': [
                    {'action': 'speak', 'params': {'text': 'Good morning! Starting your morning routine.'}},
                    {'action': 'open_website', 'params': {'url': 'https://weather.com'}},
                    {'action': 'wait', 'params': {'duration': 2}},
                    {'action': 'open_website', 'params': {'url': 'https://news.google.com'}},
                    {'action': 'wait', 'params': {'duration': 2}},
                    {'action': 'open_website', 'params': {'url': 'https://calendar.google.com'}},
                    {'action': 'speak', 'params': {'text': 'Your morning briefing is ready!'}}
                ]
            },
            'focus_mode': {
                'name': 'Focus Mode',
                'steps': [
                    {'action': 'speak', 'params': {'text': 'Activating focus mode. Minimizing distractions.'}},
                    {'action': 'wait', 'params': {'duration': 1}},
                    {'action': 'speak', 'params': {'text': 'Focus mode active. Good luck with your work!'}}
                ]
            },
            'end_of_day': {
                'name': 'End of Day Routine',
                'steps': [
                    {'action': 'speak', 'params': {'text': 'Wrapping up your day.'}},
                    {'action': 'take_screenshot', 'params': {}},
                    {'action': 'speak', 'params': {'text': 'Screenshot saved. Have a great evening!'}}
                ]
            }
        }
        
        # Match task to template
        for key, template in templates.items():
            if key.replace('_', ' ') in task_lower:
                return template
        
        return None
    
    def auto_create_workflow_from_description(self, description: str) -> Optional[str]:
        """Use AI to create workflow from natural language description"""
        # This would use the AI to parse description and create workflow
        # Placeholder for advanced feature
        logger.info(f"AI workflow creation requested: {description}")
        return None
    
    # ==================== PRODUCTIVITY TRACKING ====================
    
    def start_focus_session(self, duration_minutes: int = 25):
        """Start Pomodoro-style focus session"""
        logger.info(f"[TARGET] Focus session started: {duration_minutes} minutes")
        
        self.voice.speak(
            f"Starting {duration_minutes} minute focus session. I'll let you know when time is up.",
            emotion='professional'
        )
        
        def end_session():
            time.sleep(duration_minutes * 60)
            self.voice.speak(
                "Focus session complete! Great work! Time for a break.",
                emotion='happy'
            )
        
        thread = threading.Thread(target=end_session, daemon=True)
        thread.start()
    
    def track_productivity(self) -> Dict:
        """Track productivity metrics"""
        # Get statistics from database
        stats = self.db.get_statistics()
        
        productivity = {
            'commands_today': 0,
            'focus_sessions': 0,
            'tasks_completed': 0,
            'active_time': 0
        }
        
        # Calculate from database
        # This is simplified - real implementation would track more
        
        return productivity
    
    # ==================== UTILITIES ====================
    
    def save_workflows(self):
        """Save workflows to file"""
        try:
            with open('workflows.json', 'w') as f:
                json.dump(self.workflows, f, indent=2)
            logger.info("[SAVE] Workflows saved")
        except Exception as e:
            logger.error(f"Workflow save error: {e}")
    
    def load_workflows(self):
        """Load workflows from file"""
        try:
            if os.path.exists('workflows.json'):
                with open('workflows.json', 'r') as f:
                    self.workflows = json.load(f)
                logger.info(f"[OPEN_FOLDER] Loaded {len(self.workflows)} workflows")
        except Exception as e:
            logger.error(f"Workflow load error: {e}")
    
    def get_automation_stats(self) -> Dict:
        """Get automation statistics"""
        return {
            'scheduled_tasks': len(self.scheduled_tasks),
            'workflows': len(self.workflows),
            'workflow_executions': len(self.workflow_history),
            'smart_reminders': len(self.smart_reminders),
            'is_running': self.is_running
        }