"""
Smart Features for SafwaanBuddy
Weather-based suggestions, news summarization, focus mode, and more
"""
import logging
import requests
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import threading
import time

logger = logging.getLogger('SafwaanBuddy.SmartFeatures')


class SmartFeatures:
    """Advanced smart features and integrations"""
    
    def __init__(self, config_manager, voice_system, db_manager, ai_brain):
        self.config = config_manager
        self.voice = voice_system
        self.db = db_manager
        self.ai = ai_brain
        
        # Focus mode
        self.focus_mode_active = False
        self.focus_start_time = None
        self.focus_duration = 0
        self.focus_breaks = []
        
        # Productivity tracking
        self.productivity_stats = {
            'tasks_completed': 0,
            'focus_sessions': 0,
            'total_focus_time': 0,
            'breaks_taken': 0
        }
        
        # Weather cache
        self.weather_cache = None
        self.weather_cache_time = None
        self.weather_cache_ttl = 1800  # 30 minutes
        
        # News cache
        self.news_cache = []
        self.news_cache_time = None
        self.news_cache_ttl = 3600  # 1 hour
        
        logger.info("[OK] Smart Features initialized")
    
    # ==================== FOCUS MODE ====================
    
    def start_focus_mode(self, duration_minutes: int = 25):
        """Start focus mode (Pomodoro-style)"""
        try:
            self.focus_mode_active = True
            self.focus_start_time = time.time()
            self.focus_duration = duration_minutes * 60
            
            self.voice.speak(
                f"Focus mode activated for {duration_minutes} minutes. "
                f"I'll let you know when it's time for a break. Good luck!",
                emotion='confident'
            )
            
            # Schedule break reminder
            def break_reminder():
                time.sleep(self.focus_duration)
                if self.focus_mode_active:
                    self.end_focus_mode()
            
            thread = threading.Thread(target=break_reminder, daemon=True)
            thread.start()
            
            # Update stats
            self.productivity_stats['focus_sessions'] += 1
            
            logger.info(f"[TARGET] Focus mode started: {duration_minutes} minutes")
            return True
        
        except Exception as e:
            logger.error(f"Focus mode start error: {e}")
            return False
    
    def end_focus_mode(self):
        """End focus mode"""
        if not self.focus_mode_active:
            return
        
        self.focus_mode_active = False
        
        # Calculate session time
        session_time = time.time() - self.focus_start_time
        self.productivity_stats['total_focus_time'] += session_time
        
        # Suggest break
        self.voice.speak(
            "Great work! Your focus session is complete. "
            "How about a 5-minute break? You've earned it!",
            emotion='happy'
        )
        
        logger.info(f"[OK] Focus mode ended: {session_time/60:.1f} minutes")
    
    def take_break(self, duration_minutes: int = 5):
        """Take a break"""
        self.voice.speak(
            f"Taking a {duration_minutes}-minute break. I'll remind you when it's time to get back.",
            emotion='calm'
        )
        
        def break_end():
            time.sleep(duration_minutes * 60)
            self.voice.speak(
                "Break time is over! Ready to get back to work?",
                emotion='energetic'
            )
        
        thread = threading.Thread(target=break_end, daemon=True)
        thread.start()
        
        self.productivity_stats['breaks_taken'] += 1
        self.focus_breaks.append({
            'duration': duration_minutes,
            'timestamp': datetime.now().isoformat()
        })
    
    def get_productivity_stats(self) -> Dict:
        """Get productivity statistics"""
        stats = self.productivity_stats.copy()
        
        # Calculate averages
        if stats['focus_sessions'] > 0:
            stats['avg_focus_time'] = stats['total_focus_time'] / stats['focus_sessions'] / 60
        else:
            stats['avg_focus_time'] = 0
        
        stats['total_focus_hours'] = stats['total_focus_time'] / 3600
        
        return stats
    
    # ==================== WEATHER INTEGRATION ====================
    
    def get_weather_suggestion(self, location: str = "auto") -> str:
        """Get weather-based suggestions"""
        try:
            weather = self._fetch_weather(location)
            
            if not weather:
                return "I couldn't get weather information right now."
            
            temp = weather.get('temperature', 0)
            condition = weather.get('condition', 'unknown').lower()
            
            # Generate contextual suggestion
            suggestions = []
            
            if temp < 10:
                suggestions.append("It's quite cold outside. Don't forget your jacket!")
            elif temp > 30:
                suggestions.append("It's very hot today. Stay hydrated!")
            
            if 'rain' in condition:
                suggestions.append("It's rainy. You might want to bring an umbrella.")
            elif 'snow' in condition:
                suggestions.append("It's snowing! Drive carefully if you're going out.")
            elif 'sunny' in condition or 'clear' in condition:
                suggestions.append("It's a beautiful day! Perfect for outdoor activities.")
            
            if not suggestions:
                suggestions.append(f"The weather is {condition} with a temperature of {temp}°C.")
            
            return " ".join(suggestions)
        
        except Exception as e:
            logger.error(f"Weather suggestion error: {e}")
            return "I couldn't get weather suggestions right now."
    
    def _fetch_weather(self, location: str) -> Optional[Dict]:
        """Fetch weather data (simplified - would use real API)"""
        # Check cache
        if self.weather_cache and self.weather_cache_time:
            if time.time() - self.weather_cache_time < self.weather_cache_ttl:
                return self.weather_cache
        
        # In real implementation, would call weather API
        # For now, return mock data
        weather = {
            'temperature': 22,
            'condition': 'Partly Cloudy',
            'humidity': 65,
            'wind_speed': 15,
            'location': location
        }
        
        self.weather_cache = weather
        self.weather_cache_time = time.time()
        
        return weather
    
    # ==================== NEWS INTEGRATION ====================
    
    def get_news_summary(self, category: str = "general", count: int = 5) -> str:
        """Get summarized news"""
        try:
            news_items = self._fetch_news(category, count)
            
            if not news_items:
                return "I couldn't fetch news right now."
            
            # Summarize news
            summary_parts = [f"Here are the top {len(news_items)} headlines:"]
            
            for i, item in enumerate(news_items, 1):
                title = item.get('title', 'Unknown')
                summary_parts.append(f"{i}. {title}")
            
            return " ".join(summary_parts)
        
        except Exception as e:
            logger.error(f"News summary error: {e}")
            return "I couldn't get news summaries right now."
    
    def _fetch_news(self, category: str, count: int) -> List[Dict]:
        """Fetch news (simplified - would use real API)"""
        # Check cache
        if self.news_cache and self.news_cache_time:
            if time.time() - self.news_cache_time < self.news_cache_ttl:
                return self.news_cache[:count]
        
        # In real implementation, would call news API
        # For now, return mock data
        news = [
            {'title': 'Latest Technology Advances', 'source': 'Tech News'},
            {'title': 'AI Breakthrough Announced', 'source': 'Science Daily'},
            {'title': 'New Software Release', 'source': 'Developer News'},
            {'title': 'Market Updates', 'source': 'Business Wire'},
            {'title': 'Health and Wellness Tips', 'source': 'Health Today'}
        ]
        
        self.news_cache = news
        self.news_cache_time = time.time()
        
        return news[:count]
    
    # ==================== SMART REMINDERS ====================
    
    def create_context_reminder(self, reminder_text: str, 
                               context_trigger: str) -> bool:
        """Create reminder that triggers based on context"""
        try:
            reminder = {
                'text': reminder_text,
                'context': context_trigger,
                'created_at': datetime.now().isoformat(),
                'triggered': False
            }
            
            # Store in database
            self.db.store_memory(
                json.dumps(reminder),
                category='reminder',
                importance=0.8
            )
            
            logger.info(f"[NOTE] Context reminder created: {reminder_text}")
            return True
        
        except Exception as e:
            logger.error(f"Reminder creation error: {e}")
            return False
    
    def check_context_reminders(self, current_context: Dict):
        """Check and trigger context-based reminders"""
        try:
            # Get reminders from database
            memories = self.db.get_relevant_memories("reminder", limit=10)
            
            for memory in memories:
                try:
                    reminder = json.loads(memory['content'])
                    
                    if not reminder.get('triggered', False):
                        # Check if context matches
                        if self._context_matches(reminder['context'], current_context):
                            self.voice.speak(
                                f"Reminder: {reminder['text']}",
                                emotion='helpful'
                            )
                            reminder['triggered'] = True
                
                except json.JSONDecodeError:
                    continue
        
        except Exception as e:
            logger.error(f"Context reminder check error: {e}")
    
    def _context_matches(self, trigger: str, current: Dict) -> bool:
        """Check if context matches trigger"""
        # Simplified context matching
        if trigger == 'idle' and current.get('activity') == 'idle':
            return True
        elif trigger == 'working' and current.get('activity') == 'working':
            return True
        elif trigger == 'evening' and datetime.now().hour >= 18:
            return True
        
        return False
    
    # ==================== SMART HOME (Framework) ====================
    
    def smart_home_command(self, device: str, action: str) -> str:
        """Smart home integration framework"""
        logger.info(f"Smart home command: {device} - {action}")
        
        # This is a framework - actual implementation would integrate with
        # smart home APIs like Home Assistant, Google Home, Alexa, etc.
        
        commands = {
            'lights': {
                'on': 'Turning lights on',
                'off': 'Turning lights off',
                'dim': 'Dimming lights',
                'brighten': 'Brightening lights'
            },
            'thermostat': {
                'increase': 'Increasing temperature',
                'decrease': 'Decreasing temperature',
                'auto': 'Setting to auto mode'
            },
            'music': {
                'play': 'Playing music',
                'pause': 'Pausing music',
                'next': 'Next track',
                'previous': 'Previous track'
            }
        }
        
        if device in commands and action in commands[device]:
            response = commands[device][action]
            logger.info(f"Smart home: {response}")
            return f"{response}. Note: Smart home integration requires setup."
        
        return "Smart home feature requires configuration. This is a framework for future integration."
    
    # ==================== DAILY BRIEFING ====================
    
    def get_daily_briefing(self) -> str:
        """Get comprehensive daily briefing"""
        try:
            briefing_parts = []
            
            # Greeting based on time
            hour = datetime.now().hour
            if hour < 12:
                greeting = "Good morning!"
            elif hour < 18:
                greeting = "Good afternoon!"
            else:
                greeting = "Good evening!"
            
            briefing_parts.append(greeting)
            
            # Date and time
            now = datetime.now()
            briefing_parts.append(
                f"It's {now.strftime('%A, %B %d, %Y')}. "
                f"The time is {now.strftime('%I:%M %p')}."
            )
            
            # Weather
            weather_suggestion = self.get_weather_suggestion()
            briefing_parts.append(weather_suggestion)
            
            # News headlines
            news_summary = self.get_news_summary(count=3)
            briefing_parts.append(news_summary)
            
            # Productivity stats
            if self.productivity_stats['focus_sessions'] > 0:
                briefing_parts.append(
                    f"You've completed {self.productivity_stats['focus_sessions']} "
                    f"focus sessions today. Great work!"
                )
            
            return " ".join(briefing_parts)
        
        except Exception as e:
            logger.error(f"Daily briefing error: {e}")
            return "I couldn't prepare your daily briefing right now."
    
    # ==================== MOTIVATION & WELLNESS ====================
    
    def get_motivational_quote(self) -> str:
        """Get motivational quote"""
        quotes = [
            "Believe you can and you're halfway there. - Theodore Roosevelt",
            "The only way to do great work is to love what you do. - Steve Jobs",
            "Success is not final, failure is not fatal: it is the courage to continue that counts. - Winston Churchill",
            "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
            "It always seems impossible until it's done. - Nelson Mandela",
            "Don't watch the clock; do what it does. Keep going. - Sam Levenson",
            "The only impossible journey is the one you never begin. - Tony Robbins",
            "Your time is limited, don't waste it living someone else's life. - Steve Jobs"
        ]
        
        import random
        return random.choice(quotes)
    
    def suggest_wellness_activity(self) -> str:
        """Suggest wellness activity based on time and context"""
        hour = datetime.now().hour
        
        if 6 <= hour < 9:
            return "How about starting your day with some light stretching or a short walk?"
        elif 12 <= hour < 14:
            return "It's lunch time! Remember to eat something healthy and take a proper break."
        elif 15 <= hour < 17:
            return "Afternoon slump? Try a quick 5-minute walk or some deep breathing exercises."
        elif 20 <= hour < 23:
            return "Evening is a great time for relaxation. Consider some light reading or meditation."
        else:
            return "Remember to take care of yourself! Regular breaks and movement are important."
    
    # ==================== SMART CLIPBOARD ====================
    
    def get_clipboard_history(self, limit: int = 10) -> List[str]:
        """Get clipboard history (would require clipboard monitoring)"""
        # This is a placeholder - actual implementation would monitor clipboard
        logger.info("Clipboard history requested")
        return ["Clipboard monitoring not yet implemented"]
    
    def smart_paste(self, context: str) -> str:
        """Smart paste based on context"""
        # Would analyze clipboard and suggest best item to paste
        logger.info(f"Smart paste for context: {context}")
        return "Smart paste feature coming soon"
    
    # ==================== FILE ORGANIZATION ====================
    
    def suggest_file_organization(self, directory: str) -> Dict:
        """Suggest file organization strategy"""
        try:
            import os
            from pathlib import Path
            from collections import Counter
            
            dir_path = Path(directory)
            if not dir_path.exists():
                return {'error': 'Directory not found'}
            
            # Analyze files
            file_types = Counter()
            file_sizes = []
            
            for file in dir_path.rglob('*'):
                if file.is_file():
                    file_types[file.suffix.lower()] += 1
                    file_sizes.append(file.stat().st_size)
            
            # Generate suggestions
            suggestions = []
            
            if len(file_types) > 10:
                suggestions.append("You have many different file types. Consider organizing by type.")
            
            if file_sizes and max(file_sizes) > 100 * 1024 * 1024:  # 100MB
                suggestions.append("You have some large files. Consider archiving or moving them.")
            
            total_files = sum(file_types.values())
            if total_files > 100:
                suggestions.append(f"You have {total_files} files. Consider creating subdirectories.")
            
            return {
                'file_types': dict(file_types),
                'total_files': total_files,
                'suggestions': suggestions
            }
        
        except Exception as e:
            logger.error(f"File organization error: {e}")
            return {'error': str(e)}
    
    # ==================== LEARNING ASSISTANT ====================
    
    def explain_topic(self, topic: str, level: str = "simple") -> str:
        """Explain a topic at specified level"""
        try:
            if hasattr(self.ai, 'explain_concept'):
                return self.ai.explain_concept(topic, level)
            else:
                return f"Let me explain {topic} in {level} terms. This feature requires the multi-modal AI system."
        
        except Exception as e:
            logger.error(f"Topic explanation error: {e}")
            return "I couldn't explain that topic right now."
    
    def quiz_me(self, topic: str, num_questions: int = 5) -> List[Dict]:
        """Generate quiz questions on a topic"""
        try:
            # Would use AI to generate questions
            logger.info(f"Quiz requested: {topic} ({num_questions} questions)")
            
            return [{
                'question': f"Sample question about {topic}",
                'answer': 'Sample answer',
                'difficulty': 'medium'
            }]
        
        except Exception as e:
            logger.error(f"Quiz generation error: {e}")
            return []
    
    # ==================== HABIT TRACKING ====================
    
    def track_habit(self, habit_name: str, completed: bool = True):
        """Track habit completion"""
        try:
            habit_data = {
                'habit': habit_name,
                'completed': completed,
                'date': datetime.now().date().isoformat(),
                'timestamp': datetime.now().isoformat()
            }
            
            self.db.store_metric('habit_tracking', 1.0 if completed else 0.0, habit_data)
            
            if completed:
                self.voice.speak(
                    f"Great job completing your {habit_name} habit today!",
                    emotion='happy'
                )
            
            logger.info(f"[OK] Habit tracked: {habit_name} - {completed}")
        
        except Exception as e:
            logger.error(f"Habit tracking error: {e}")
    
    def get_habit_stats(self, habit_name: str, days: int = 30) -> Dict:
        """Get habit statistics"""
        try:
            metrics = self.db.get_metrics('habit_tracking', limit=days * 10)
            
            # Filter for specific habit
            habit_metrics = [
                m for m in metrics
                if json.loads(m['metadata']).get('habit') == habit_name
            ]
            
            if not habit_metrics:
                return {'error': 'No data for this habit'}
            
            completed_count = sum(1 for m in habit_metrics if m['value'] == 1.0)
            total_count = len(habit_metrics)
            
            return {
                'habit': habit_name,
                'completed': completed_count,
                'total': total_count,
                'completion_rate': (completed_count / total_count * 100) if total_count > 0 else 0,
                'streak': self._calculate_streak(habit_metrics)
            }
        
        except Exception as e:
            logger.error(f"Habit stats error: {e}")
            return {'error': str(e)}
    
    def _calculate_streak(self, metrics: List[Dict]) -> int:
        """Calculate current streak"""
        if not metrics:
            return 0
        
        # Sort by date
        sorted_metrics = sorted(metrics, key=lambda x: x['timestamp'], reverse=True)
        
        streak = 0
        for metric in sorted_metrics:
            if metric['value'] == 1.0:
                streak += 1
            else:
                break
        
        return streak
    
    # ==================== GOAL TRACKING ====================
    
    def set_goal(self, goal_name: str, target_value: float, 
                deadline: Optional[str] = None) -> bool:
        """Set a goal"""
        try:
            goal = {
                'name': goal_name,
                'target': target_value,
                'current': 0.0,
                'deadline': deadline,
                'created_at': datetime.now().isoformat()
            }
            
            self.db.store_preference(f'goal_{goal_name}', goal)
            
            self.voice.speak(
                f"Goal set: {goal_name}. Let's work towards it together!",
                emotion='confident'
            )
            
            logger.info(f"[TARGET] Goal set: {goal_name}")
            return True
        
        except Exception as e:
            logger.error(f"Goal setting error: {e}")
            return False
    
    def update_goal_progress(self, goal_name: str, progress: float):
        """Update goal progress"""
        try:
            goal = self.db.get_preference(f'goal_{goal_name}')
            
            if not goal:
                return False
            
            goal['current'] = progress
            goal['updated_at'] = datetime.now().isoformat()
            
            self.db.store_preference(f'goal_{goal_name}', goal)
            
            # Calculate percentage
            percentage = (progress / goal['target'] * 100) if goal['target'] > 0 else 0
            
            # Provide encouragement
            if percentage >= 100:
                self.voice.speak(
                    f"Congratulations! You've achieved your goal: {goal_name}!",
                    emotion='excited'
                )
            elif percentage >= 75:
                self.voice.speak(
                    f"You're almost there! {percentage:.0f}% complete on {goal_name}.",
                    emotion='happy'
                )
            elif percentage >= 50:
                self.voice.speak(
                    f"Great progress! You're {percentage:.0f}% of the way to {goal_name}.",
                    emotion='confident'
                )
            
            logger.info(f"[TRENDING_UP] Goal progress updated: {goal_name} - {percentage:.0f}%")
            return True
        
        except Exception as e:
            logger.error(f"Goal update error: {e}")
            return False
    
    # ==================== UTILITIES ====================
    
    def get_feature_status(self) -> Dict:
        """Get status of all smart features"""
        return {
            'focus_mode': {
                'active': self.focus_mode_active,
                'duration': self.focus_duration if self.focus_mode_active else 0
            },
            'productivity': self.productivity_stats,
            'scheduled_tasks': len(self.scheduled_tasks),
            'workflows': len(self.workflows),
            'weather_cached': self.weather_cache is not None,
            'news_cached': len(self.news_cache) > 0
        }