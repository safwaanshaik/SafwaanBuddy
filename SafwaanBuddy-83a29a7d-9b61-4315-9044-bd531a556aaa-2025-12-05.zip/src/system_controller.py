"""
System Controller for SafwaanBuddy
Complete control over Windows settings, accessories, and system configuration
"""
import subprocess
import platform
import logging
import winreg
import ctypes
from typing import Optional, Dict, List
import psutil

logger = logging.getLogger('SafwaanBuddy.SystemController')


class SystemController:
    """Complete Windows system control"""
    
    def __init__(self):
        self.is_windows = platform.system() == "Windows"
        self.is_admin = self._check_admin()
        logger.info(f"[OK] System Controller initialized - Admin: {self.is_admin}")
    
    def _check_admin(self) -> bool:
        """Check if running with admin privileges"""
        try:
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        except:
            return False
    
    # ==================== DISPLAY SETTINGS ====================
    
    def set_brightness(self, level: int) -> bool:
        """Set screen brightness (0-100)"""
        try:
            level = max(0, min(100, level))
            
            # PowerShell command for brightness
            ps_cmd = f"(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,{level})"
            subprocess.run(['powershell', '-Command', ps_cmd], 
                         capture_output=True, timeout=5)
            
            logger.info(f"[OK] Brightness set to {level}%")
            return True
        except Exception as e:
            logger.error(f"Set brightness error: {e}")
        return False
    
    def get_brightness(self) -> Optional[int]:
        """Get current brightness level"""
        try:
            ps_cmd = "(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightness).CurrentBrightness"
            result = subprocess.run(['powershell', '-Command', ps_cmd],
                                  capture_output=True, text=True, timeout=5)
            
            if result.returncode == 0:
                brightness = int(result.stdout.strip())
                return brightness
        except Exception as e:
            logger.error(f"Get brightness error: {e}")
        return None
    
    def set_resolution(self, width: int, height: int) -> bool:
        """Set screen resolution"""
        try:
            # This requires admin and is complex - using display settings
            subprocess.run(['control', 'desk.cpl'], shell=True)
            logger.info(f"[*] Opened display settings for resolution change")
            return True
        except Exception as e:
            logger.error(f"Set resolution error: {e}")
        return False
    
    # ==================== AUDIO SETTINGS ====================
    
    def set_volume(self, level: int) -> bool:
        """Set system volume (0-100)"""
        try:
            level = max(0, min(100, level))
            
            # Calculate volume for Windows (0-65535)
            volume_level = int(level * 655.35)
            
            # Try nircmd first
            try:
                subprocess.run(['nircmd', 'setsysvolume', str(volume_level)],
                             capture_output=True, timeout=2)
                logger.info(f"[OK] Volume set to {level}%")
                return True
            except:
                # Fallback: use keyboard volume keys
                current_vol = 50  # Assume middle
                diff = level - current_vol
                
                if diff > 0:
                    for _ in range(abs(diff) // 2):
                        subprocess.run(['nircmd', 'changesysvolume', '2000'])
                else:
                    for _ in range(abs(diff) // 2):
                        subprocess.run(['nircmd', 'changesysvolume', '-2000'])
                
                logger.info(f"[OK] Volume adjusted to ~{level}%")
                return True
                
        except Exception as e:
            logger.error(f"Set volume error: {e}")
        return False
    
    def mute(self) -> bool:
        """Mute system audio"""
        try:
            subprocess.run(['nircmd', 'mutesysvolume', '1'], capture_output=True)
            logger.info("[OK] Audio muted")
            return True
        except Exception as e:
            logger.error(f"Mute error: {e}")
        return False
    
    def unmute(self) -> bool:
        """Unmute system audio"""
        try:
            subprocess.run(['nircmd', 'mutesysvolume', '0'], capture_output=True)
            logger.info("[OK] Audio unmuted")
            return True
        except Exception as e:
            logger.error(f"Unmute error: {e}")
        return False
    
    # ==================== POWER MANAGEMENT ====================
    
    def get_battery_status(self) -> Dict:
        """Get battery information"""
        try:
            battery = psutil.sensors_battery()
            
            if battery:
                return {
                    'percent': battery.percent,
                    'plugged': battery.power_plugged,
                    'time_left': battery.secsleft if battery.secsleft != -1 else None
                }
            else:
                return {'percent': 100, 'plugged': True, 'time_left': None}
        except Exception as e:
            logger.error(f"Battery status error: {e}")
        return {}
    
    def set_power_plan(self, plan: str) -> bool:
        """Set Windows power plan"""
        try:
            plans = {
                'balanced': 'SCHEME_BALANCED',
                'high performance': 'SCHEME_MIN',
                'power saver': 'SCHEME_MAX'
            }
            
            plan_lower = plan.lower()
            if plan_lower in plans:
                subprocess.run(['powercfg', '/setactive', plans[plan_lower]],
                             capture_output=True)
                logger.info(f"[OK] Power plan set to: {plan}")
                return True
        except Exception as e:
            logger.error(f"Set power plan error: {e}")
        return False
    
    def sleep_computer(self) -> bool:
        """Put computer to sleep"""
        try:
            subprocess.run(['rundll32.exe', 'powrprof.dll,SetSuspendState', '0,1,0'])
            logger.info("[OK] Computer going to sleep")
            return True
        except Exception as e:
            logger.error(f"Sleep error: {e}")
        return False
    
    # ==================== NETWORK SETTINGS ====================
    
    def enable_wifi(self) -> bool:
        """Enable WiFi"""
        try:
            subprocess.run(['netsh', 'interface', 'set', 'interface', 'Wi-Fi', 'enabled'],
                         capture_output=True)
            logger.info("[OK] WiFi enabled")
            return True
        except Exception as e:
            logger.error(f"Enable WiFi error: {e}")
        return False
    
    def disable_wifi(self) -> bool:
        """Disable WiFi"""
        try:
            subprocess.run(['netsh', 'interface', 'set', 'interface', 'Wi-Fi', 'disabled'],
                         capture_output=True)
            logger.info("[OK] WiFi disabled")
            return True
        except Exception as e:
            logger.error(f"Disable WiFi error: {e}")
        return False
    
    def enable_bluetooth(self) -> bool:
        """Enable Bluetooth"""
        try:
            # Open Bluetooth settings
            subprocess.run(['start', 'ms-settings:bluetooth'], shell=True)
            logger.info("[*] Opened Bluetooth settings")
            return True
        except Exception as e:
            logger.error(f"Enable Bluetooth error: {e}")
        return False
    
    # ==================== ACCESSIBILITY ====================
    
    def enable_narrator(self) -> bool:
        """Enable Windows Narrator"""
        try:
            subprocess.Popen(['narrator.exe'])
            logger.info("[OK] Narrator enabled")
            return True
        except Exception as e:
            logger.error(f"Enable narrator error: {e}")
        return False
    
    def enable_magnifier(self) -> bool:
        """Enable Windows Magnifier"""
        try:
            subprocess.Popen(['magnify.exe'])
            logger.info("[OK] Magnifier enabled")
            return True
        except Exception as e:
            logger.error(f"Enable magnifier error: {e}")
        return False
    
    # ==================== SYSTEM INFO ====================
    
    def get_system_info(self) -> Dict:
        """Get comprehensive system information"""
        try:
            info = {
                'os': platform.system(),
                'os_version': platform.version(),
                'os_release': platform.release(),
                'machine': platform.machine(),
                'processor': platform.processor(),
                'cpu_count': psutil.cpu_count(),
                'cpu_percent': psutil.cpu_percent(interval=1),
                'memory_total': psutil.virtual_memory().total,
                'memory_available': psutil.virtual_memory().available,
                'memory_percent': psutil.virtual_memory().percent,
                'disk_total': psutil.disk_usage('/').total,
                'disk_used': psutil.disk_usage('/').used,
                'disk_percent': psutil.disk_usage('/').percent
            }
            
            # Add battery if available
            battery = self.get_battery_status()
            if battery:
                info['battery'] = battery
            
            return info
        except Exception as e:
            logger.error(f"Get system info error: {e}")
        return {}
    
    def get_running_processes(self) -> List[Dict]:
        """Get list of running processes"""
        try:
            processes = []
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
                try:
                    processes.append(proc.info)
                except:
                    pass
            
            return sorted(processes, key=lambda x: x['cpu_percent'], reverse=True)
        except Exception as e:
            logger.error(f"Get processes error: {e}")
        return []
    
    def kill_process(self, process_name: str) -> bool:
        """Kill process by name"""
        try:
            killed = False
            for proc in psutil.process_iter(['name']):
                if process_name.lower() in proc.info['name'].lower():
                    proc.kill()
                    logger.info(f"[OK] Killed process: {proc.info['name']}")
                    killed = True
            
            return killed
        except Exception as e:
            logger.error(f"Kill process error: {e}")
        return False