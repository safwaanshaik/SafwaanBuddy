"""
Ultimate Skills for SafwaanBuddy
Comprehensive skill set with all advanced capabilities
"""
import os
import sys
import webbrowser
import pyautogui
import logging
import subprocess
import platform
import psutil
import json
import requests
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any
import random

logger = logging.getLogger('SafwaanBuddy.UltimateSkills')


class UltimateSkills:
    """Complete skill set with all capabilities"""
    
    def __init__(self, screen_control=None, multimodal_ai=None):
        self.screen = screen_control
        self.ai = multimodal_ai
        logger.info("[OK] Ultimate Skills initialized")
    
    # ==================== INFORMATION & KNOWLEDGE ====================
    
    @staticmethod
    def get_time() -> str:
        """Get current time"""
        try:
            current_time = datetime.now().strftime("%I:%M %p")
            return f"The current time is {current_time}"
        except Exception as e:
            logger.error(f"Get time error: {e}")
            return "I couldn't get the time"
    
    @staticmethod
    def get_date() -> str:
        """Get current date"""
        try:
            current_date = datetime.now().strftime("%A, %B %d, %Y")
            return f"Today is {current_date}"
        except Exception as e:
            logger.error(f"Get date error: {e}")
            return "I couldn't get the date"
    
    @staticmethod
    def get_day_info() -> str:
        """Get comprehensive day information"""
        try:
            now = datetime.now()
            info = []
            info.append(f"Today is {now.strftime('%A, %B %d, %Y')}")
            info.append(f"Current time: {now.strftime('%I:%M %p')}")
            info.append(f"Week: {now.strftime('%U')}")
            info.append(f"Day of year: {now.strftime('%j')}")
            
            # Calculate days until weekend
            days_until_weekend = (4 - now.weekday()) % 7
            if days_until_weekend == 0:
                info.append("It's Friday! Weekend is here!")
            elif days_until_weekend == 1:
                info.append("Weekend is tomorrow!")
            else:
                info.append(f"{days_until_weekend} days until the weekend")
            
            return "\n".join(info)
        except Exception as e:
            logger.error(f"Day info error: {e}")
            return "I couldn't get day information"
    
    # ==================== ENTERTAINMENT ====================
    
    @staticmethod
    def tell_joke() -> str:
        """Tell an advanced joke"""
        jokes = [
            "Why don't programmers like nature? It has too many bugs!",
            "Why did the AI go to school? To improve its neural network!",
            "What's an AI's favorite snack? Microchips!",
            "Why was the computer cold? It left its Windows open!",
            "I told my computer a joke about UDP, but I don't know if it got it.",
            "Why do programmers prefer dark mode? Because light attracts bugs!",
            "What do you call a programmer from Finland? Nerdic!",
            "Why did the developer go broke? Because he used up all his cache!",
            "How many programmers does it take to change a light bulb? None, that's a hardware problem!",
            "Why do Java developers wear glasses? Because they don't C#!",
            "What's a programmer's favorite hangout place? Foo Bar!",
            "Why did the functions stop calling each other? Because they had constant arguments!",
            "What do you call 8 hobbits? A hobbyte!",
            "There are 10 types of people in the world: those who understand binary and those who don't.",
            "Why did the database administrator leave his wife? She had one-to-many relationships!",
            "A SQL query walks into a bar, walks up to two tables and asks: 'Can I join you?'",
            "Why do programmers always mix up Halloween and Christmas? Because Oct 31 equals Dec 25!",
            "What's the object-oriented way to become wealthy? Inheritance!",
            "Why did the Python programmer not respond to the Ruby programmer? He didn't get the message!",
            "How do you comfort a JavaScript bug? You console it!"
        ]
        return random.choice(jokes)
    
    @staticmethod
    def tell_fact() -> str:
        """Tell an interesting fact"""
        facts = [
            "The first computer programmer was Ada Lovelace in the 1840s.",
            "The first computer bug was an actual moth found in a computer in 1947.",
            "The first 1GB hard drive weighed over 500 pounds and cost $40,000 in 1980.",
            "The first webcam was created at Cambridge University to monitor a coffee pot.",
            "The first email was sent in 1971 by Ray Tomlinson to himself.",
            "The QWERTY keyboard layout was designed to slow down typing to prevent typewriter jams.",
            "The first computer mouse was made of wood in 1964.",
            "The first domain name ever registered was Symbolics.com in 1985.",
            "The first YouTube video was uploaded on April 23, 2005.",
            "The first iPhone was released on June 29, 2007."
        ]
        return random.choice(facts)
    
    @staticmethod
    def play_music(query: str) -> str:
        """Play music on YouTube"""
        try:
            if query:
                url = f"https://www.youtube.com/results?search_query={query.replace(' ', '+')}"
                webbrowser.open(url)
                return f"Playing {query} on YouTube"
            return "What would you like me to play?"
        except Exception as e:
            logger.error(f"Play music error: {e}")
            return "I couldn't open YouTube"
    
    @staticmethod
    def play_video(query: str) -> str:
        """Play video on YouTube"""
        try:
            if query:
                url = f"https://www.youtube.com/results?search_query={query.replace(' ', '+')}"
                webbrowser.open(url)
                return f"Searching for {query} videos on YouTube"
            return "What video would you like to watch?"
        except Exception as e:
            logger.error(f"Play video error: {e}")
            return "I couldn't open YouTube"
    
    # ==================== WEB & SEARCH ====================
    
    @staticmethod
    def search_web(query: str) -> str:
        """Search the web"""
        try:
            if query:
                url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
                webbrowser.open(url)
                return f"Searching for {query}"
            return "What would you like me to search for?"
        except Exception as e:
            logger.error(f"Web search error: {e}")
            return "I couldn't open the browser"
    
    @staticmethod
    def search_images(query: str) -> str:
        """Search for images"""
        try:
            if query:
                url = f"https://www.google.com/search?q={query.replace(' ', '+')}&tbm=isch"
                webbrowser.open(url)
                return f"Searching for images of {query}"
            return "What images would you like to see?"
        except Exception as e:
            logger.error(f"Image search error: {e}")
            return "I couldn't search for images"
    
    @staticmethod
    def search_maps(location: str) -> str:
        """Search location on maps"""
        try:
            if location:
                url = f"https://www.google.com/maps/search/{location.replace(' ', '+')}"
                webbrowser.open(url)
                return f"Opening maps for {location}"
            return "Which location would you like to see?"
        except Exception as e:
            logger.error(f"Maps search error: {e}")
            return "I couldn't open maps"
    
    @staticmethod
    def open_website(url: str) -> str:
        """Open a website"""
        try:
            if url:
                if not url.startswith('http'):
                    url = f"https://{url}"
                webbrowser.open(url)
                return f"Opening {url}"
            return "Which website would you like to visit?"
        except Exception as e:
            logger.error(f"Open website error: {e}")
            return "I couldn't open that website"
    
    # ==================== PRODUCTIVITY ====================
    
    @staticmethod
    def take_screenshot(filename: Optional[str] = None) -> str:
        """Take a screenshot"""
        try:
            if not filename:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"screenshot_{timestamp}.png"
            
            screenshot = pyautogui.screenshot()
            screenshot.save(filename)
            return f"Screenshot saved as {filename}"
        except Exception as e:
            logger.error(f"Screenshot error: {e}")
            return "I couldn't take a screenshot"
    
    @staticmethod
    def take_note(note: str) -> str:
        """Take a note"""
        try:
            if note:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"note_{timestamp}.txt"
                
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(f"Note taken at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}:\n\n")
                    f.write(note)
                
                return f"Note saved as {filename}"
            return "What would you like me to note?"
        except Exception as e:
            logger.error(f"Take note error: {e}")
            return "I couldn't save the note"
    
    @staticmethod
    def create_reminder(reminder: str, time_str: str = None) -> str:
        """Create a reminder"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"reminder_{timestamp}.txt"
            
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(f"Reminder created at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}:\n\n")
                f.write(reminder)
                if time_str:
                    f.write(f"\n\nScheduled for: {time_str}")
            
            return f"Reminder created: {reminder}"
        except Exception as e:
            logger.error(f"Create reminder error: {e}")
            return "I couldn't create the reminder"
    
    @staticmethod
    def calculate(expression: str) -> str:
        """Calculate mathematical expression"""
        try:
            if expression:
                # Clean expression
                expression = expression.replace('x', '*').replace('×', '*')
                expression = expression.replace('÷', '/').replace('plus', '+')
                expression = expression.replace('minus', '-').replace('times', '*')
                expression = expression.replace('divided by', '/')
                
                result = eval(expression)
                return f"The result is {result}"
            return "What would you like me to calculate?"
        except Exception as e:
            logger.error(f"Calculate error: {e}")
            return "I couldn't calculate that expression"
    
    # ==================== COMMUNICATION ====================
    
    @staticmethod
    def open_email() -> str:
        """Open email"""
        try:
            webbrowser.open("https://gmail.com")
            return "Opening your email"
        except Exception as e:
            logger.error(f"Email error: {e}")
            return "I couldn't open email"
    
    @staticmethod
    def open_calendar() -> str:
        """Open calendar"""
        try:
            webbrowser.open("https://calendar.google.com")
            return "Opening your calendar"
        except Exception as e:
            logger.error(f"Calendar error: {e}")
            return "I couldn't open calendar"
    
    @staticmethod
    def open_messages() -> str:
        """Open messages"""
        try:
            webbrowser.open("https://messages.google.com")
            return "Opening your messages"
        except Exception as e:
            logger.error(f"Messages error: {e}")
            return "I couldn't open messages"
    
    # ==================== MEDIA & CONTENT ====================
    
    @staticmethod
    def get_weather() -> str:
        """Open weather website"""
        try:
            webbrowser.open("https://www.weather.com")
            return "Opening weather information"
        except Exception as e:
            logger.error(f"Weather error: {e}")
            return "I couldn't open the weather"
    
    @staticmethod
    def get_news() -> str:
        """Open news website"""
        try:
            webbrowser.open("https://news.google.com")
            return "Opening latest news"
        except Exception as e:
            logger.error(f"News error: {e}")
            return "I couldn't open the news"
    
    @staticmethod
    def translate(text: str) -> str:
        """Open Google Translate"""
        try:
            if text:
                url = f"https://translate.google.com/?text={text.replace(' ', '+')}"
                webbrowser.open(url)
                return f"Translating: {text}"
            return "What would you like me to translate?"
        except Exception as e:
            logger.error(f"Translate error: {e}")
            return "I couldn't open translator"
    
    # ==================== SYSTEM INFORMATION ====================
    
    @staticmethod
    def get_system_info() -> str:
        """Get comprehensive system information"""
        try:
            info = []
            info.append(f"System: {platform.system()} {platform.release()}")
            info.append(f"Version: {platform.version()}")
            info.append(f"Machine: {platform.machine()}")
            info.append(f"Processor: {platform.processor()}")
            info.append(f"CPU Cores: {psutil.cpu_count()}")
            info.append(f"CPU Usage: {psutil.cpu_percent()}%")
            
            memory = psutil.virtual_memory()
            info.append(f"Total RAM: {memory.total / (1024**3):.1f} GB")
            info.append(f"Available RAM: {memory.available / (1024**3):.1f} GB")
            info.append(f"Memory Usage: {memory.percent}%")
            
            disk = psutil.disk_usage('/')
            info.append(f"Total Disk: {disk.total / (1024**3):.1f} GB")
            info.append(f"Free Disk: {disk.free / (1024**3):.1f} GB")
            info.append(f"Disk Usage: {disk.percent}%")
            
            return "\n".join(info)
        except Exception as e:
            logger.error(f"System info error: {e}")
            return "I couldn't get system information"
    
    @staticmethod
    def get_battery_status() -> str:
        """Get detailed battery status"""
        try:
            battery = psutil.sensors_battery()
            if battery:
                percent = battery.percent
                plugged = "plugged in" if battery.power_plugged else "not plugged in"
                
                if battery.secsleft != -1:
                    hours = battery.secsleft // 3600
                    minutes = (battery.secsleft % 3600) // 60
                    time_left = f"{hours}h {minutes}m remaining"
                else:
                    time_left = "calculating..."
                
                return f"Battery is at {percent}%, {plugged}. {time_left}"
            else:
                return "No battery detected - running on AC power"
        except Exception as e:
            logger.error(f"Battery status error: {e}")
            return "I couldn't get battery status"
    
    @staticmethod
    def get_network_info() -> str:
        """Get network information"""
        try:
            import socket
            hostname = socket.gethostname()
            ip_address = socket.gethostbyname(hostname)
            
            info = []
            info.append(f"Hostname: {hostname}")
            info.append(f"IP Address: {ip_address}")
            
            # Get network stats
            net_io = psutil.net_io_counters()
            info.append(f"Bytes Sent: {net_io.bytes_sent / (1024**2):.1f} MB")
            info.append(f"Bytes Received: {net_io.bytes_recv / (1024**2):.1f} MB")
            
            return "\n".join(info)
        except Exception as e:
            logger.error(f"Network info error: {e}")
            return "I couldn't get network information"
    
    # ==================== WINDOW & APP CONTROL ====================
    
    @staticmethod
    def close_window() -> str:
        """Close current window"""
        try:
            if platform.system() == "Windows":
                pyautogui.hotkey('alt', 'f4')
                return "Closing current window"
            else:
                return "Window closing is only available on Windows"
        except Exception as e:
            logger.error(f"Close window error: {e}")
            return "I couldn't close the window"
    
    @staticmethod
    def minimize_window() -> str:
        """Minimize current window"""
        try:
            if platform.system() == "Windows":
                pyautogui.hotkey('win', 'down')
                return "Minimizing window"
            else:
                return "Window minimizing is only available on Windows"
        except Exception as e:
            logger.error(f"Minimize window error: {e}")
            return "I couldn't minimize the window"
    
    @staticmethod
    def maximize_window() -> str:
        """Maximize current window"""
        try:
            if platform.system() == "Windows":
                pyautogui.hotkey('win', 'up')
                return "Maximizing window"
            else:
                return "Window maximizing is only available on Windows"
        except Exception as e:
            logger.error(f"Maximize window error: {e}")
            return "I couldn't maximize the window"
    
    @staticmethod
    def switch_window() -> str:
        """Switch to next window"""
        try:
            if platform.system() == "Windows":
                pyautogui.hotkey('alt', 'tab')
                return "Switching window"
            else:
                return "Window switching is only available on Windows"
        except Exception as e:
            logger.error(f"Switch window error: {e}")
            return "I couldn't switch windows"
    
    # ==================== SYSTEM CONTROL ====================
    
    @staticmethod
    def set_volume(level: Optional[str]) -> str:
        """Set system volume"""
        try:
            if not level:
                return "What volume level would you like? (0-100)"
            
            volume = int(level)
            volume = max(0, min(100, volume))
            
            if platform.system() == "Windows":
                # This is a placeholder - actual implementation would use Windows API
                return f"Volume set to {volume}%"
            else:
                return "Volume control is only available on Windows"
        except Exception as e:
            logger.error(f"Set volume error: {e}")
            return "I couldn't set the volume"
    
    @staticmethod
    def lock_computer() -> str:
        """Lock the computer"""
        try:
            if platform.system() == "Windows":
                subprocess.run(['rundll32.exe', 'user32.dll,LockWorkStation'])
                return "Locking computer"
            else:
                return "Computer locking is only available on Windows"
        except Exception as e:
            logger.error(f"Lock computer error: {e}")
            return "I couldn't lock the computer"
    
    @staticmethod
    def shutdown_computer(delay: int = 60) -> str:
        """Shutdown computer with delay"""
        try:
            if platform.system() == "Windows":
                subprocess.run(['shutdown', '/s', '/t', str(delay)])
                return f"Computer will shutdown in {delay} seconds"
            else:
                return "Shutdown is only available on Windows"
        except Exception as e:
            logger.error(f"Shutdown error: {e}")
            return "I couldn't shutdown the computer"
    
    @staticmethod
    def restart_computer(delay: int = 60) -> str:
        """Restart computer with delay"""
        try:
            if platform.system() == "Windows":
                subprocess.run(['shutdown', '/r', '/t', str(delay)])
                return f"Computer will restart in {delay} seconds"
            else:
                return "Restart is only available on Windows"
        except Exception as e:
            logger.error(f"Restart error: {e}")
            return "I couldn't restart the computer"
    
    @staticmethod
    def cancel_shutdown() -> str:
        """Cancel scheduled shutdown/restart"""
        try:
            if platform.system() == "Windows":
                subprocess.run(['shutdown', '/a'])
                return "Shutdown/restart cancelled"
            else:
                return "Cancel shutdown is only available on Windows"
        except Exception as e:
            logger.error(f"Cancel shutdown error: {e}")
            return "I couldn't cancel the shutdown"
    
    # ==================== APPLICATIONS ====================
    
    @staticmethod
    def open_task_manager() -> str:
        """Open task manager"""
        try:
            if platform.system() == "Windows":
                subprocess.Popen('taskmgr.exe')
                return "Opening Task Manager"
            else:
                return "Task Manager is only available on Windows"
        except Exception as e:
            logger.error(f"Open task manager error: {e}")
            return "I couldn't open Task Manager"
    
    @staticmethod
    def open_control_panel() -> str:
        """Open control panel"""
        try:
            if platform.system() == "Windows":
                subprocess.Popen('control.exe')
                return "Opening Control Panel"
            else:
                return "Control Panel is only available on Windows"
        except Exception as e:
            logger.error(f"Open control panel error: {e}")
            return "I couldn't open Control Panel"
    
    @staticmethod
    def open_settings() -> str:
        """Open Windows settings"""
        try:
            if platform.system() == "Windows":
                subprocess.Popen('start ms-settings:', shell=True)
                return "Opening Windows Settings"
            else:
                return "Settings is only available on Windows"
        except Exception as e:
            logger.error(f"Open settings error: {e}")
            return "I couldn't open Settings"
    
    @staticmethod
    def open_file_explorer() -> str:
        """Open file explorer"""
        try:
            if platform.system() == "Windows":
                subprocess.Popen('explorer.exe')
                return "Opening File Explorer"
            else:
                return "File Explorer is only available on Windows"
        except Exception as e:
            logger.error(f"Open file explorer error: {e}")
            return "I couldn't open File Explorer"
    
    @staticmethod
    def open_notepad() -> str:
        """Open notepad"""
        try:
            if platform.system() == "Windows":
                subprocess.Popen('notepad.exe')
                return "Opening Notepad"
            else:
                return "Notepad is only available on Windows"
        except Exception as e:
            logger.error(f"Open notepad error: {e}")
            return "I couldn't open Notepad"
    
    @staticmethod
    def open_calculator() -> str:
        """Open calculator"""
        try:
            if platform.system() == "Windows":
                subprocess.Popen('calc.exe')
                return "Opening Calculator"
            else:
                return "Calculator is only available on Windows"
        except Exception as e:
            logger.error(f"Open calculator error: {e}")
            return "I couldn't open Calculator"
    
    # ==================== ADVANCED FEATURES ====================
    
    def analyze_screen(self) -> str:
        """Analyze current screen"""
        try:
            if not self.screen:
                return "Screen control not available"
            
            analysis = self.screen.analyze_screen()
            
            info = []
            info.append(f"Screen brightness: {analysis.get('brightness', 0):.1f}")
            info.append(f"Dominant color: {analysis.get('dominant_color', 'unknown')}")
            info.append(f"Text detected: {'Yes' if analysis.get('has_text') else 'No'}")
            info.append(f"Word count: {analysis.get('word_count', 0)}")
            
            return "\n".join(info)
        except Exception as e:
            logger.error(f"Screen analysis error: {e}")
            return "I couldn't analyze the screen"
    
    def analyze_image(self, image_path: str) -> str:
        """Analyze an image with AI"""
        try:
            if not self.ai:
                return "AI vision not available"
            
            result = self.ai.analyze_image(image_path)
            return result
        except Exception as e:
            logger.error(f"Image analysis error: {e}")
            return "I couldn't analyze that image"
    
    def generate_code(self, description: str, language: str = "python") -> str:
        """Generate code from description"""
        try:
            if not self.ai:
                return "AI code generation not available"
            
            code = self.ai.generate_code(description, language)
            
            # Save to file
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"generated_code_{timestamp}.{language}"
            
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(code)
            
            return f"Code generated and saved as {filename}"
        except Exception as e:
            logger.error(f"Code generation error: {e}")
            return "I couldn't generate code"
    
    # ==================== FILE OPERATIONS ====================
    
    @staticmethod
    def create_file(filename: str, content: str = "") -> str:
        """Create a new file"""
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(content)
            return f"File created: {filename}"
        except Exception as e:
            logger.error(f"Create file error: {e}")
            return "I couldn't create the file"
    
    @staticmethod
    def read_file(filename: str) -> str:
        """Read file contents"""
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                content = f.read()
            return f"File contents:\n{content[:500]}..."
        except Exception as e:
            logger.error(f"Read file error: {e}")
            return "I couldn't read that file"
    
    @staticmethod
    def delete_file(filename: str) -> str:
        """Delete a file"""
        try:
            os.remove(filename)
            return f"File deleted: {filename}"
        except Exception as e:
            logger.error(f"Delete file error: {e}")
            return "I couldn't delete that file"
    
    @staticmethod
    def list_files(directory: str = ".") -> str:
        """List files in directory"""
        try:
            files = os.listdir(directory)
            if files:
                return f"Files in {directory}:\n" + "\n".join(files[:20])
            return f"No files found in {directory}"
        except Exception as e:
            logger.error(f"List files error: {e}")
            return "I couldn't list files"
    
    # ==================== QUICK ACTIONS ====================
    
    @staticmethod
    def copy_text() -> str:
        """Copy selected text"""
        try:
            pyautogui.hotkey('ctrl', 'c')
            return "Text copied to clipboard"
        except Exception as e:
            logger.error(f"Copy error: {e}")
            return "I couldn't copy text"
    
    @staticmethod
    def paste_text() -> str:
        """Paste from clipboard"""
        try:
            pyautogui.hotkey('ctrl', 'v')
            return "Text pasted"
        except Exception as e:
            logger.error(f"Paste error: {e}")
            return "I couldn't paste text"
    
    @staticmethod
    def undo() -> str:
        """Undo last action"""
        try:
            pyautogui.hotkey('ctrl', 'z')
            return "Undone"
        except Exception as e:
            logger.error(f"Undo error: {e}")
            return "I couldn't undo"
    
    @staticmethod
    def redo() -> str:
        """Redo last action"""
        try:
            pyautogui.hotkey('ctrl', 'y')
            return "Redone"
        except Exception as e:
            logger.error(f"Redo error: {e}")
            return "I couldn't redo"
    
    @staticmethod
    def select_all() -> str:
        """Select all"""
        try:
            pyautogui.hotkey('ctrl', 'a')
            return "All selected"
        except Exception as e:
            logger.error(f"Select all error: {e}")
            return "I couldn't select all"
    
    @staticmethod
    def save_file() -> str:
        """Save current file"""
        try:
            pyautogui.hotkey('ctrl', 's')
            return "File saved"
        except Exception as e:
            logger.error(f"Save error: {e}")
            return "I couldn't save"
    
    # ==================== BROWSER CONTROL ====================
    
    @staticmethod
    def new_tab() -> str:
        """Open new browser tab"""
        try:
            pyautogui.hotkey('ctrl', 't')
            return "New tab opened"
        except Exception as e:
            logger.error(f"New tab error: {e}")
            return "I couldn't open a new tab"
    
    @staticmethod
    def close_tab() -> str:
        """Close current browser tab"""
        try:
            pyautogui.hotkey('ctrl', 'w')
            return "Tab closed"
        except Exception as e:
            logger.error(f"Close tab error: {e}")
            return "I couldn't close the tab"
    
    @staticmethod
    def refresh_page() -> str:
        """Refresh current page"""
        try:
            pyautogui.hotkey('ctrl', 'r')
            return "Page refreshed"
        except Exception as e:
            logger.error(f"Refresh error: {e}")
            return "I couldn't refresh the page"
    
    @staticmethod
    def go_back() -> str:
        """Go back in browser"""
        try:
            pyautogui.hotkey('alt', 'left')
            return "Going back"
        except Exception as e:
            logger.error(f"Go back error: {e}")
            return "I couldn't go back"
    
    @staticmethod
    def go_forward() -> str:
        """Go forward in browser"""
        try:
            pyautogui.hotkey('alt', 'right')
            return "Going forward"
        except Exception as e:
            logger.error(f"Go forward error: {e}")
            return "I couldn't go forward"
    
    # ==================== SOCIAL MEDIA ====================
    
    @staticmethod
    def open_youtube() -> str:
        """Open YouTube"""
        try:
            webbrowser.open("https://www.youtube.com")
            return "Opening YouTube"
        except Exception as e:
            return "I couldn't open YouTube"
    
    @staticmethod
    def open_twitter() -> str:
        """Open Twitter/X"""
        try:
            webbrowser.open("https://twitter.com")
            return "Opening Twitter"
        except Exception as e:
            return "I couldn't open Twitter"
    
    @staticmethod
    def open_facebook() -> str:
        """Open Facebook"""
        try:
            webbrowser.open("https://www.facebook.com")
            return "Opening Facebook"
        except Exception as e:
            return "I couldn't open Facebook"
    
    @staticmethod
    def open_instagram() -> str:
        """Open Instagram"""
        try:
            webbrowser.open("https://www.instagram.com")
            return "Opening Instagram"
        except Exception as e:
            return "I couldn't open Instagram"
    
    @staticmethod
    def open_linkedin() -> str:
        """Open LinkedIn"""
        try:
            webbrowser.open("https://www.linkedin.com")
            return "Opening LinkedIn"
        except Exception as e:
            return "I couldn't open LinkedIn"
    
    @staticmethod
    def open_github() -> str:
        """Open GitHub"""
        try:
            webbrowser.open("https://github.com")
            return "Opening GitHub"
        except Exception as e:
            return "I couldn't open GitHub"
    
    # ==================== LEARNING & EDUCATION ====================
    
    @staticmethod
    def open_wikipedia(topic: str = "") -> str:
        """Open Wikipedia"""
        try:
            if topic:
                url = f"https://en.wikipedia.org/wiki/{topic.replace(' ', '_')}"
            else:
                url = "https://www.wikipedia.org"
            webbrowser.open(url)
            return f"Opening Wikipedia{' for ' + topic if topic else ''}"
        except Exception as e:
            return "I couldn't open Wikipedia"
    
    @staticmethod
    def search_stackoverflow(query: str) -> str:
        """Search Stack Overflow"""
        try:
            if query:
                url = f"https://stackoverflow.com/search?q={query.replace(' ', '+')}"
                webbrowser.open(url)
                return f"Searching Stack Overflow for {query}"
            return "What would you like to search on Stack Overflow?"
        except Exception as e:
            return "I couldn't search Stack Overflow"
    
    # ==================== UTILITIES ====================
    
    @staticmethod
    def get_help() -> str:
        """Get help and list capabilities"""
        help_text = """
I can help you with many things! Here are my main capabilities:

[CLIPBOARD] INFORMATION:
- Time, date, weather, news
- System info, battery, network

[MUSIC] ENTERTAINMENT:
- Tell jokes and facts
- Play music and videos

[WEB] WEB & SEARCH:
- Search Google, images, maps
- Open any website
- Translate text

[EMAIL] PRODUCTIVITY:
- Email, calendar, messages
- Screenshots, notes, reminders
- Calculator

[SYSTEM] SYSTEM CONTROL:
- Volume, window management
- Lock, shutdown, restart
- Task manager, settings

[LAUNCH] APPLICATIONS:
- Open any app
- Browser control
- File operations

[DESIGN] ADVANCED (PRO MAX):
- Screen analysis
- Image analysis
- Code generation
- Focus mode
- Goal tracking

Just say "Safwaan" followed by your command!
        """
        return help_text.strip()