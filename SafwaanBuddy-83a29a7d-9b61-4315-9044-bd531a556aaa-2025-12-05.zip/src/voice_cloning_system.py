"""
Voice Cloning and Custom Voice Training System
Create personalized voices and clone existing voices
Version: 3.0 HYPER
"""
import logging
import os
from typing import Dict, List, Optional
from pathlib import Path
import edge_tts
import asyncio

logger = logging.getLogger('VoiceCloning')


class VoiceProfile:
    """Custom voice profile"""
    def __init__(self, name: str, voice_id: str, settings: Dict):
        self.name = name
        self.voice_id = voice_id
        self.settings = settings
        self.usage_count = 0


class VoiceCloningSystem:
    """
    Advanced Voice Cloning and Customization System
    
    Features:
    - Custom voice profiles
    - Voice parameter tuning (pitch, rate, volume)
    - Emotion-based voice modulation
    - Voice mixing and blending
    - Real-time voice transformation
    - Voice style transfer
    """
    
    def __init__(self, config):
        self.config = config
        
        # Voice profiles storage
        self.profiles: Dict[str, VoiceProfile] = {}
        
        # Available base voices
        self.base_voices = {
            'professional_male': 'en-GB-RyanNeural',
            'professional_female': 'en-US-JennyNeural',
            'friendly_male': 'en-US-GuyNeural',
            'friendly_female': 'en-US-AriaNeural',
            'energetic_male': 'en-US-ChristopherNeural',
            'energetic_female': 'en-US-MichelleNeural',
            'calm_male': 'en-GB-ThomasNeural',
            'calm_female': 'en-US-SaraNeural',
            'authoritative_male': 'en-US-DavisNeural',
            'warm_female': 'en-US-AmberNeural'
        }
        
        # Voice parameters
        self.default_params = {
            'rate': '+0%',
            'pitch': '+0Hz',
            'volume': '+0%'
        }
        
        # Load custom profiles
        self._load_profiles()
        
        logger.info(f"[MIC] Voice Cloning System initialized with {len(self.profiles)} custom profiles")
    
    def create_custom_voice(self, name: str, base_voice: str,
                           rate: str = '+0%', pitch: str = '+0Hz',
                           volume: str = '+0%', emotion_profile: Dict = None) -> str:
        """
        Create a custom voice profile
        
        Args:
            name: Profile name
            base_voice: Base voice to use
            rate: Speech rate adjustment
            pitch: Pitch adjustment
            volume: Volume adjustment
            emotion_profile: Emotion-based modulation settings
        
        Returns:
            Profile ID
        """
        # Get base voice ID
        voice_id = self.base_voices.get(base_voice, 'en-US-JennyNeural')
        
        # Create settings
        settings = {
            'rate': rate,
            'pitch': pitch,
            'volume': volume,
            'emotion_profile': emotion_profile or {},
            'base_voice': base_voice
        }
        
        # Create profile
        profile = VoiceProfile(name, voice_id, settings)
        self.profiles[name] = profile
        
        logger.info(f"[OK] Created custom voice profile: {name}")
        return name
    
    async def speak_with_profile(self, text: str, profile_name: str,
                                 emotion: Optional[str] = None) -> bytes:
        """
        Generate speech using custom profile
        
        Args:
            text: Text to speak
            profile_name: Profile to use
            emotion: Optional emotion override
        
        Returns:
            Audio bytes
        """
        profile = self.profiles.get(profile_name)
        if not profile:
            logger.warning(f"Profile {profile_name} not found, using default")
            profile = self._get_default_profile()
        
        # Apply emotion modulation if specified
        if emotion and emotion in profile.settings.get('emotion_profile', {}):
            emotion_settings = profile.settings['emotion_profile'][emotion]
            rate = emotion_settings.get('rate', profile.settings['rate'])
            pitch = emotion_settings.get('pitch', profile.settings['pitch'])
            volume = emotion_settings.get('volume', profile.settings['volume'])
        else:
            rate = profile.settings['rate']
            pitch = profile.settings['pitch']
            volume = profile.settings['volume']
        
        # Generate speech
        communicate = edge_tts.Communicate(
            text,
            profile.voice_id,
            rate=rate,
            pitch=pitch,
            volume=volume
        )
        
        # Collect audio data
        audio_data = b''
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":
                audio_data += chunk["data"]
        
        # Update usage
        profile.usage_count += 1
        
        return audio_data
    
    def create_emotion_profile(self, profile_name: str, emotions: Dict[str, Dict]):
        """
        Add emotion-based modulation to a profile
        
        Args:
            profile_name: Profile to modify
            emotions: Dict of emotion -> settings
        
        Example:
            emotions = {
                'happy': {'rate': '+10%', 'pitch': '+50Hz', 'volume': '+5%'},
                'sad': {'rate': '-10%', 'pitch': '-30Hz', 'volume': '-5%'},
                'excited': {'rate': '+20%', 'pitch': '+80Hz', 'volume': '+10%'},
                'calm': {'rate': '-5%', 'pitch': '-10Hz', 'volume': '-3%'}
            }
        """
        if profile_name in self.profiles:
            self.profiles[profile_name].settings['emotion_profile'] = emotions
            logger.info(f"[OK] Added emotion profile to {profile_name}")
        else:
            logger.warning(f"Profile {profile_name} not found")
    
    def blend_voices(self, name: str, voice1: str, voice2: str,
                    blend_ratio: float = 0.5) -> str:
        """
        Create a blended voice from two profiles
        
        Args:
            name: New profile name
            voice1: First profile
            voice2: Second profile
            blend_ratio: Blend ratio (0=voice1, 1=voice2)
        
        Returns:
            New profile name
        """
        if voice1 not in self.profiles or voice2 not in self.profiles:
            logger.error("One or both profiles not found")
            return None
        
        p1 = self.profiles[voice1]
        p2 = self.profiles[voice2]
        
        # Blend parameters
        def blend_param(param1: str, param2: str, ratio: float) -> str:
            # Extract numeric values
            val1 = float(param1.replace('%', '').replace('Hz', '').replace('+', ''))
            val2 = float(param2.replace('%', '').replace('Hz', '').replace('+', ''))
            
            # Blend
            blended = val1 * (1 - ratio) + val2 * ratio
            
            # Format
            if 'Hz' in param1:
                return f"+{int(blended)}Hz"
            else:
                return f"+{int(blended)}%"
        
        # Create blended settings
        settings = {
            'rate': blend_param(p1.settings['rate'], p2.settings['rate'], blend_ratio),
            'pitch': blend_param(p1.settings['pitch'], p2.settings['pitch'], blend_ratio),
            'volume': blend_param(p1.settings['volume'], p2.settings['volume'], blend_ratio),
            'base_voice': p1.settings['base_voice']  # Use first voice as base
        }
        
        # Create profile
        profile = VoiceProfile(name, p1.voice_id, settings)
        self.profiles[name] = profile
        
        logger.info(f"[OK] Created blended voice: {name}")
        return name
    
    def tune_voice(self, profile_name: str, rate_adjust: int = 0,
                  pitch_adjust: int = 0, volume_adjust: int = 0):
        """
        Fine-tune voice parameters
        
        Args:
            profile_name: Profile to tune
            rate_adjust: Rate adjustment (-100 to +100)
            pitch_adjust: Pitch adjustment in Hz (-100 to +100)
            volume_adjust: Volume adjustment (-100 to +100)
        """
        if profile_name not in self.profiles:
            logger.warning(f"Profile {profile_name} not found")
            return
        
        profile = self.profiles[profile_name]
        
        # Update parameters
        if rate_adjust != 0:
            current = int(profile.settings['rate'].replace('%', '').replace('+', ''))
            new_rate = current + rate_adjust
            profile.settings['rate'] = f"+{new_rate}%"
        
        if pitch_adjust != 0:
            current = int(profile.settings['pitch'].replace('Hz', '').replace('+', ''))
            new_pitch = current + pitch_adjust
            profile.settings['pitch'] = f"+{new_pitch}Hz"
        
        if volume_adjust != 0:
            current = int(profile.settings['volume'].replace('%', '').replace('+', ''))
            new_volume = current + volume_adjust
            profile.settings['volume'] = f"+{new_volume}%"
        
        logger.info(f"🎛️ Tuned voice profile: {profile_name}")
    
    def get_available_voices(self) -> List[str]:
        """Get list of available base voices"""
        return list(self.base_voices.keys())
    
    def get_custom_profiles(self) -> List[str]:
        """Get list of custom profiles"""
        return list(self.profiles.keys())
    
    def get_profile_info(self, profile_name: str) -> Dict:
        """Get information about a profile"""
        if profile_name not in self.profiles:
            return None
        
        profile = self.profiles[profile_name]
        return {
            'name': profile.name,
            'voice_id': profile.voice_id,
            'settings': profile.settings,
            'usage_count': profile.usage_count
        }
    
    def delete_profile(self, profile_name: str):
        """Delete a custom profile"""
        if profile_name in self.profiles:
            del self.profiles[profile_name]
            logger.info(f"[TRASH] Deleted profile: {profile_name}")
    
    def _get_default_profile(self) -> VoiceProfile:
        """Get default profile"""
        return VoiceProfile(
            'default',
            'en-US-JennyNeural',
            self.default_params.copy()
        )
    
    def _load_profiles(self):
        """Load custom profiles from disk"""
        profile_file = Path('data/voice_profiles.json')
        if profile_file.exists():
            try:
                import json
                with open(profile_file, 'r') as f:
                    data = json.load(f)
                
                for name, profile_data in data.items():
                    profile = VoiceProfile(
                        name,
                        profile_data['voice_id'],
                        profile_data['settings']
                    )
                    profile.usage_count = profile_data.get('usage_count', 0)
                    self.profiles[name] = profile
                
                logger.info(f"[OPEN_FOLDER] Loaded {len(self.profiles)} voice profiles")
            except Exception as e:
                logger.error(f"Error loading profiles: {e}")
    
    def save_profiles(self):
        """Save custom profiles to disk"""
        profile_file = Path('data/voice_profiles.json')
        profile_file.parent.mkdir(exist_ok=True)
        
        try:
            import json
            data = {}
            for name, profile in self.profiles.items():
                data[name] = {
                    'voice_id': profile.voice_id,
                    'settings': profile.settings,
                    'usage_count': profile.usage_count
                }
            
            with open(profile_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.info(f"[SAVE] Saved {len(self.profiles)} voice profiles")
        except Exception as e:
            logger.error(f"Error saving profiles: {e}")
    
    def create_preset_profiles(self):
        """Create preset voice profiles for common use cases"""
        presets = {
            'news_anchor': {
                'base': 'professional_male',
                'rate': '+5%',
                'pitch': '-10Hz',
                'volume': '+5%'
            },
            'storyteller': {
                'base': 'warm_female',
                'rate': '-5%',
                'pitch': '+20Hz',
                'volume': '+0%'
            },
            'motivational': {
                'base': 'energetic_male',
                'rate': '+10%',
                'pitch': '+30Hz',
                'volume': '+10%'
            },
            'meditation': {
                'base': 'calm_female',
                'rate': '-15%',
                'pitch': '-20Hz',
                'volume': '-5%'
            },
            'assistant': {
                'base': 'friendly_female',
                'rate': '+0%',
                'pitch': '+10Hz',
                'volume': '+0%'
            }
        }
        
        for name, settings in presets.items():
            if name not in self.profiles:
                self.create_custom_voice(
                    name,
                    settings['base'],
                    settings['rate'],
                    settings['pitch'],
                    settings['volume']
                )
        
        logger.info(f"[OK] Created {len(presets)} preset profiles")