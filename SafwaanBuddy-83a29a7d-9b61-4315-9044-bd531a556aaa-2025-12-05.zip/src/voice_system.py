"""
Voice System for SafwaanBuddy
Handles text-to-speech with edge-tts and multiple voice personalities
"""
import asyncio
import edge_tts
import pygame
import threading
import time
import logging
from pathlib import Path
from typing import Optional
import queue

logger = logging.getLogger('SafwaanBuddy.Voice')


class VoiceSystem:
    """Advanced voice system with multiple personalities"""
    
    def __init__(self, config_manager):
        self.config = config_manager
        self.voice_settings = config_manager.get_voice_settings()
        self.current_personality = 'friendly'
        
        # Create temp directory for audio files
        self.temp_dir = Path("temp_audio")
        self.temp_dir.mkdir(exist_ok=True)
        
        # Initialize pygame mixer for audio playback
        try:
            pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)
            logger.info("[OK] Pygame mixer initialized")
        except Exception as e:
            logger.error(f"Pygame mixer initialization error: {e}")
        
        # Speech queue and state
        self.speech_queue = queue.Queue()
        self.is_speaking = False
        self.stop_event = threading.Event()
        
        # Emotion-based voice modulation
        self.emotion_settings = {
            'happy': {'rate': '+15%', 'pitch': '+10Hz', 'volume': '+20%'},
            'sad': {'rate': '-15%', 'pitch': '-10Hz', 'volume': '-10%'},
            'excited': {'rate': '+25%', 'pitch': '+15Hz', 'volume': '+30%'},
            'calm': {'rate': '-10%', 'pitch': '-5Hz', 'volume': '-5%'},
            'neutral': {'rate': '+0%', 'pitch': '+0Hz', 'volume': '+0%'},
            'angry': {'rate': '+10%', 'pitch': '+5Hz', 'volume': '+25%'},
            'confident': {'rate': '+5%', 'pitch': '+5Hz', 'volume': '+15%'}
        }
        
        logger.info("[OK] Voice System initialized")
    
    def speak(self, text: str, emotion: str = 'neutral', 
              personality: Optional[str] = None, blocking: bool = False,
              priority: bool = False):
        """
        Speak text with specified emotion and personality
        
        Args:
            text: Text to speak
            emotion: Emotion for voice modulation
            personality: Voice personality to use
            blocking: Wait for speech to complete
            priority: Interrupt current speech
        """
        if not text or not text.strip():
            return
        
        logger.info(f"[SPEAK] Speaking: {text[:50]}... [Emotion: {emotion}]")
        
        if priority and self.is_speaking:
            self.stop_speaking()
        
        speech_request = {
            'text': text,
            'emotion': emotion,
            'personality': personality or self.current_personality,
            'timestamp': time.time()
        }
        
        if blocking:
            self._speak_sync(speech_request)
        else:
            thread = threading.Thread(
                target=self._speak_sync,
                args=(speech_request,),
                daemon=True
            )
            thread.start()
    
    def _speak_sync(self, request: dict):
        """Synchronous speech execution"""
        try:
            self.is_speaking = True
            self.stop_event.clear()
            
            text = request['text']
            emotion = request['emotion']
            personality = request['personality']
            
            # Get voice for personality
            personalities = self.voice_settings.get('personalities', {})
            voice = personalities.get(personality, self.voice_settings['default_voice'])
            
            # Get emotion settings
            emotion_mod = self.emotion_settings.get(emotion, self.emotion_settings['neutral'])
            
            # Generate audio file
            timestamp = int(time.time() * 1000)
            audio_file = self.temp_dir / f"speech_{timestamp}.mp3"
            
            # Generate TTS
            asyncio.run(self._generate_tts(
                text, voice, str(audio_file),
                emotion_mod['rate'],
                emotion_mod['pitch'],
                emotion_mod['volume']
            ))
            
            # Play audio
            if audio_file.exists():
                self._play_audio(str(audio_file))
                
                # Clean up
                try:
                    audio_file.unlink()
                except:
                    pass
        
        except Exception as e:
            logger.error(f"Speech error: {e}")
        finally:
            self.is_speaking = False
    
    async def _generate_tts(self, text: str, voice: str, output: str,
                           rate: str, pitch: str, volume: str):
        """Generate TTS audio file using edge-tts"""
        try:
            communicate = edge_tts.Communicate(
                text, voice,
                rate=rate,
                pitch=pitch,
                volume=volume
            )
            await communicate.save(output)
            logger.debug(f"TTS generated: {output}")
        except Exception as e:
            logger.error(f"TTS generation error: {e}")
    
    def _play_audio(self, file_path: str):
        """Play audio file with interruption support"""
        try:
            pygame.mixer.music.load(file_path)
            pygame.mixer.music.play()
            
            # Wait for playback to complete or stop event
            while pygame.mixer.music.get_busy():
                if self.stop_event.is_set():
                    pygame.mixer.music.stop()
                    logger.info("Speech interrupted")
                    break
                time.sleep(0.05)
        
        except Exception as e:
            logger.error(f"Audio playback error: {e}")
    
    def stop_speaking(self):
        """Stop current speech"""
        self.stop_event.set()
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.stop()
        logger.info("Speech stopped")
    
    def set_personality(self, personality: str):
        """Change voice personality"""
        personalities = self.voice_settings.get('personalities', {})
        if personality in personalities:
            self.current_personality = personality
            logger.info(f"Voice personality changed to: {personality}")
        else:
            logger.warning(f"Unknown personality: {personality}")
    
    def get_available_personalities(self) -> list:
        """Get list of available voice personalities"""
        return list(self.voice_settings.get('personalities', {}).keys())
    
    def cleanup(self):
        """Clean up temporary files"""
        try:
            for file in self.temp_dir.glob("speech_*.mp3"):
                file.unlink()
            logger.info("Voice system cleaned up")
        except Exception as e:
            logger.error(f"Cleanup error: {e}")


class VoiceCloner:
    """Voice cloning system (placeholder for future implementation)"""
    
    def __init__(self):
        logger.info("Voice cloner initialized (placeholder)")
    
    def clone_voice(self, voice_samples: list, voice_name: str) -> bool:
        """Clone voice from samples (placeholder)"""
        logger.warning("Voice cloning not yet implemented")
        return False