"""
Windows 11 Compatible Logging System
Fixes Unicode encoding issues on Windows
Version: 3.0 HYPER ULTIMATE
"""
import logging
import sys
import os
from pathlib import Path


def setup_windows_logging(log_file: str = 'safwaan.log', level=logging.INFO):
    """
    Setup Windows 11 compatible logging
    Fixes Unicode encoding issues with emojis
    """
    
    # Force UTF-8 encoding for Windows console
    if sys.platform == 'win32':
        # Set console to UTF-8
        os.system('chcp 65001 >nul 2>&1')
        
        # Reconfigure stdout/stderr for UTF-8
        if hasattr(sys.stdout, 'reconfigure'):
            sys.stdout.reconfigure(encoding='utf-8')
        if hasattr(sys.stderr, 'reconfigure'):
            sys.stderr.reconfigure(encoding='utf-8')
    
    # Create formatters
    file_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    console_formatter = logging.Formatter(
        '%(levelname)s - %(message)s'
    )
    
    # File handler (UTF-8)
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(level)
    file_handler.setFormatter(file_formatter)
    
    # Console handler (UTF-8)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(console_formatter)
    
    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    root_logger.handlers.clear()
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)
    
    return root_logger


def get_logger(name: str) -> logging.Logger:
    """Get a logger with Windows 11 compatible settings"""
    return logging.getLogger(name)


# Safe emoji replacements for Windows
SAFE_EMOJIS = {
    '[OK]': '[OK]',
    '[ERROR]': '[ERROR]',
    '[WARNING]': '[WARNING]',
    '[AUDIO]': '[AUDIO]',
    '[MIC]': '[MIC]',
    '[AI]': '[AI]',
    '[VISION]': '[VISION]',
    '[WEB]': '[WEB]',
    '[BAR_CHART]': '[DATA]',
    '[TARGET]': '[TARGET]',
    '[LAUNCH]': '[LAUNCH]',
    '[SAVE]': '[SAVE]',
    '[HOT]': '[HOT]',
    '[FAST]': '[FAST]',
    '[DESIGN]': '[UI]',
    '[TOOL]': '[CONFIG]',
    '[NOTE]': '[NOTE]',
    '[EMOTION]': '[EMOTION]',
    '[STAR]': '[STAR]',
    '[CHAT]': '[CHAT]',
    '[SEARCH]': '[SEARCH]',
    '[MOBILE]': '[MOBILE]',
    '[DESKTOP]': '[DESKTOP]',
    '🛑': '[STOP]',
    '▶️': '[PLAY]',
    '⏸️': '[PAUSE]',
    '🔄': '[REFRESH]',
    '[SPARKLE]': '[SPARKLE]',
    '[CELEBRATE]': '[CELEBRATE]',
    '[THUMBS_UP]': '[GOOD]',
    '👎': '[BAD]',
    '🧹': '[CLEAN]',
    '[SECURE]': '[SECURE]',
    '[COLOR]': '[COLOR]',
    '[MUSIC]': '[MUSIC]',
    '[TRENDING_UP]': '[BAR_CHART]',
    '[IDEA]': '[IDEA]',
    '[NOTIFICATION]': '[NOTIFY]',
    '[ALARM]': '[ALARM]',
    '[CALENDAR]': '[CALENDAR]',
    '[EMAIL]': '[EMAIL]',
    '[LINK]': '[LINK]',
    '[OPEN_FOLDER]': '[FOLDER]',
    '[PAGE]': '[FILE]',
    '[FRAME]': '[IMAGE]',
    '[VIDEO]': '[VIDEO]',
    '[GAME]': '[GAME]',
    '[HOME]': '[HOME]',
    '[TEMP]': '[TEMP]',
    '[SYSTEM]': '[SYSTEM]',
    '[KEYBOARD]': '[KEYBOARD]',
    '[MOUSE]': '[MOUSE]',
    '[PLUGIN]': '[PLUGIN]',
    '[TEST]': '[TEST]',
    '[EDUCATION]': '[LEARN]',
    '[BOT]': '[BOT]',
    '👤': '[USER]',
    '[GLOBE]': '[WORLD]',
    '[TIME]': '[TIME]',
    '[LOCATION]': '[LOCATION]',
    '[BATTERY]': '[BATTERY]',
    '📶': '[SIGNAL]',
    '[LOCKED]': '[LOCK]',
    '[UNLOCKED]': '[UNLOCK]',
    '➕': '[ADD]',
    '➖': '[REMOVE]',
    '✖️': '[MULTIPLY]',
    '➗': '[DIVIDE]',
    '🔢': '[NUMBER]',
    '🔤': '[TEXT]',
    '🆕': '[NEW]',
    '🆙': '[UP]',
    '🆗': '[OK]',
    '🆘': '[SOS]',
    '[STAR]': '[STAR]',
    '🌙': '[MOON]',
    '☀️': '[SUN]',
    '⛅': '[CLOUD]',
    '🌧️': '[RAIN]',
    '⛈️': '[STORM]',
    '[COLOR]': '[RAINBOW]',
    '❄️': '[SNOW]',
    '[HOT]': '[HOT]',
    '💧': '[WATER]',
    '🌊': '[WAVE]',
    '🏔️': '[MOUNTAIN]',
    '🌲': '[TREE]',
    '🌺': '[FLOWER]',
    '🍎': '[APPLE]',
    '🍕': '[PIZZA]',
    '☕': '[COFFEE]',
    '🍰': '[CAKE]',
    '🎂': '[BIRTHDAY]',
    '[GIFT]': '[GIFT]',
    '🎈': '[BALLOON]',
    '[PARTY]': '[CONFETTI]',
    '🎆': '[FIREWORKS]',
    '🎇': '[SPARKLER]'
}


def safe_log(logger: logging.Logger, level: int, message: str):
    """
    Log message with Windows 11 compatible emoji replacement
    
    Args:
        logger: Logger instance
        level: Logging level (logging.INFO, logging.ERROR, etc.)
        message: Message to log
    """
    # Replace emojis with safe text
    safe_message = message
    for emoji, replacement in SAFE_EMOJIS.items():
        safe_message = safe_message.replace(emoji, replacement)
    
    logger.log(level, safe_message)


def info(logger: logging.Logger, message: str):
    """Log info message (Windows 11 safe)"""
    safe_log(logger, logging.INFO, message)


def error(logger: logging.Logger, message: str):
    """Log error message (Windows 11 safe)"""
    safe_log(logger, logging.ERROR, message)


def warning(logger: logging.Logger, message: str):
    """Log warning message (Windows 11 safe)"""
    safe_log(logger, logging.WARNING, message)


def debug(logger: logging.Logger, message: str):
    """Log debug message (Windows 11 safe)"""
    safe_log(logger, logging.DEBUG, message)