"""
Workflow Automation Engine
Create and execute complex automation workflows
Version: 3.0 HYPER
"""
import logging
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass
from enum import Enum
import json
from pathlib import Path
import time

logger = logging.getLogger('WorkflowEngine')


class ActionType(Enum):
    """Workflow action types"""
    VOICE_COMMAND = "voice_command"
    SYSTEM_COMMAND = "system_command"
    WAIT = "wait"
    CONDITION = "condition"
    LOOP = "loop"
    NOTIFICATION = "notification"
    FILE_OPERATION = "file_operation"
    WEB_ACTION = "web_action"


@dataclass
class WorkflowAction:
    """Single workflow action"""
    type: ActionType
    name: str
    parameters: Dict[str, Any]
    condition: Optional[str] = None
    on_success: Optional[str] = None
    on_failure: Optional[str] = None


@dataclass
class Workflow:
    """Complete workflow definition"""
    id: str
    name: str
    description: str
    actions: List[WorkflowAction]
    triggers: List[str]
    enabled: bool = True
    created_at: str = ""
    last_run: Optional[str] = None
    run_count: int = 0


class WorkflowAutomationEngine:
    """
    Advanced Workflow Automation Engine
    
    Features:
    - Visual workflow builder
    - Conditional logic
    - Loops and iterations
    - Error handling
    - Scheduled execution
    - Event-driven triggers
    - Workflow templates
    - Import/export workflows
    """
    
    def __init__(self, config, voice_system, skills):
        self.config = config
        self.voice = voice_system
        self.skills = skills
        
        # Workflow storage
        self.workflows: Dict[str, Workflow] = {}
        
        # Workflow directory
        self.workflow_dir = Path('workflows')
        self.workflow_dir.mkdir(exist_ok=True)
        
        # Execution state
        self.running_workflows = {}
        
        # Load workflows
        self._load_workflows()
        
        logger.info(f"[FAST] Workflow Automation Engine initialized with {len(self.workflows)} workflows")
    
    def create_workflow(self, name: str, description: str, 
                       actions: List[Dict]) -> str:
        """
        Create a new workflow
        
        Args:
            name: Workflow name
            description: Workflow description
            actions: List of action definitions
        
        Returns:
            Workflow ID
        """
        import uuid
        from datetime import datetime
        
        workflow_id = str(uuid.uuid4())
        
        # Convert action dicts to WorkflowAction objects
        workflow_actions = []
        for action_dict in actions:
            action = WorkflowAction(
                type=ActionType(action_dict['type']),
                name=action_dict['name'],
                parameters=action_dict.get('parameters', {}),
                condition=action_dict.get('condition'),
                on_success=action_dict.get('on_success'),
                on_failure=action_dict.get('on_failure')
            )
            workflow_actions.append(action)
        
        # Create workflow
        workflow = Workflow(
            id=workflow_id,
            name=name,
            description=description,
            actions=workflow_actions,
            triggers=action_dict.get('triggers', []),
            created_at=datetime.now().isoformat()
        )
        
        # Store workflow
        self.workflows[workflow_id] = workflow
        
        # Save to disk
        self._save_workflow(workflow)
        
        logger.info(f"[OK] Created workflow: {name} ({workflow_id})")
        return workflow_id
    
    def execute_workflow(self, workflow_id: str, 
                        context: Dict = None) -> Dict[str, Any]:
        """
        Execute a workflow
        
        Args:
            workflow_id: Workflow to execute
            context: Execution context
        
        Returns:
            Execution results
        """
        if workflow_id not in self.workflows:
            logger.error(f"Workflow not found: {workflow_id}")
            return {'success': False, 'error': 'Workflow not found'}
        
        workflow = self.workflows[workflow_id]
        
        if not workflow.enabled:
            logger.warning(f"Workflow disabled: {workflow.name}")
            return {'success': False, 'error': 'Workflow disabled'}
        
        logger.info(f"▶️ Executing workflow: {workflow.name}")
        
        context = context or {}
        results = []
        
        try:
            for i, action in enumerate(workflow.actions):
                logger.debug(f"Executing action {i+1}/{len(workflow.actions)}: {action.name}")
                
                # Check condition
                if action.condition and not self._evaluate_condition(action.condition, context):
                    logger.debug(f"Skipping action due to condition: {action.condition}")
                    continue
                
                # Execute action
                result = self._execute_action(action, context)
                results.append(result)
                
                # Update context
                context[f'action_{i}_result'] = result
                
                # Handle success/failure
                if result.get('success'):
                    if action.on_success:
                        logger.debug(f"Success handler: {action.on_success}")
                else:
                    if action.on_failure:
                        logger.debug(f"Failure handler: {action.on_failure}")
                        break
            
            # Update workflow stats
            workflow.run_count += 1
            workflow.last_run = time.time()
            
            logger.info(f"[OK] Workflow completed: {workflow.name}")
            
            return {
                'success': True,
                'workflow_id': workflow_id,
                'actions_executed': len(results),
                'results': results
            }
            
        except Exception as e:
            logger.error(f"Error executing workflow: {e}")
            return {
                'success': False,
                'error': str(e),
                'actions_executed': len(results)
            }
    
    def _execute_action(self, action: WorkflowAction, context: Dict) -> Dict[str, Any]:
        """Execute a single action"""
        try:
            if action.type == ActionType.VOICE_COMMAND:
                # Execute voice command
                command = action.parameters.get('command', '')
                response = self.skills.execute_command(command)
                return {'success': True, 'response': response}
            
            elif action.type == ActionType.SYSTEM_COMMAND:
                # Execute system command
                import subprocess
                cmd = action.parameters.get('command', '')
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                return {'success': result.returncode == 0, 'output': result.stdout}
            
            elif action.type == ActionType.WAIT:
                # Wait for specified time
                duration = action.parameters.get('duration', 1)
                time.sleep(duration)
                return {'success': True, 'waited': duration}
            
            elif action.type == ActionType.NOTIFICATION:
                # Show notification
                message = action.parameters.get('message', '')
                self.voice.speak(message)
                return {'success': True, 'message': message}
            
            elif action.type == ActionType.FILE_OPERATION:
                # Perform file operation
                operation = action.parameters.get('operation', '')
                path = action.parameters.get('path', '')
                # Implement file operations
                return {'success': True, 'operation': operation}
            
            else:
                logger.warning(f"Unsupported action type: {action.type}")
                return {'success': False, 'error': 'Unsupported action type'}
            
        except Exception as e:
            logger.error(f"Error executing action: {e}")
            return {'success': False, 'error': str(e)}
    
    def _evaluate_condition(self, condition: str, context: Dict) -> bool:
        """Evaluate a condition"""
        try:
            # Simple condition evaluation
            # In production, use a proper expression evaluator
            return eval(condition, {"__builtins__": {}}, context)
        except:
            return False
    
    def create_preset_workflows(self):
        """Create preset workflow templates"""
        
        # Morning Routine
        self.create_workflow(
            name="Morning Routine",
            description="Start your day right",
            actions=[
                {
                    'type': 'voice_command',
                    'name': 'Check Weather',
                    'parameters': {'command': 'what is the weather'}
                },
                {
                    'type': 'voice_command',
                    'name': 'Read News',
                    'parameters': {'command': 'latest news'}
                },
                {
                    'type': 'voice_command',
                    'name': 'Play Music',
                    'parameters': {'command': 'play morning music'}
                }
            ]
        )
        
        # Work Mode
        self.create_workflow(
            name="Work Mode",
            description="Focus on work",
            actions=[
                {
                    'type': 'system_command',
                    'name': 'Close Distractions',
                    'parameters': {'command': 'taskkill /F /IM chrome.exe'}
                },
                {
                    'type': 'notification',
                    'name': 'Work Mode Active',
                    'parameters': {'message': 'Work mode activated. Focus time!'}
                }
            ]
        )
        
        # Evening Routine
        self.create_workflow(
            name="Evening Routine",
            description="Wind down for the day",
            actions=[
                {
                    'type': 'voice_command',
                    'name': 'Play Relaxing Music',
                    'parameters': {'command': 'play relaxing music'}
                },
                {
                    'type': 'notification',
                    'name': 'Good Night',
                    'parameters': {'message': 'Good night! Sleep well!'}
                }
            ]
        )
        
        logger.info("[OK] Created preset workflows")
    
    def list_workflows(self) -> List[Dict]:
        """Get list of all workflows"""
        return [
            {
                'id': w.id,
                'name': w.name,
                'description': w.description,
                'actions_count': len(w.actions),
                'enabled': w.enabled,
                'run_count': w.run_count
            }
            for w in self.workflows.values()
        ]
    
    def enable_workflow(self, workflow_id: str):
        """Enable a workflow"""
        if workflow_id in self.workflows:
            self.workflows[workflow_id].enabled = True
            logger.info(f"[OK] Enabled workflow: {workflow_id}")
    
    def disable_workflow(self, workflow_id: str):
        """Disable a workflow"""
        if workflow_id in self.workflows:
            self.workflows[workflow_id].enabled = False
            logger.info(f"⏸️ Disabled workflow: {workflow_id}")
    
    def delete_workflow(self, workflow_id: str):
        """Delete a workflow"""
        if workflow_id in self.workflows:
            workflow = self.workflows[workflow_id]
            del self.workflows[workflow_id]
            
            # Delete file
            workflow_file = self.workflow_dir / f"{workflow_id}.json"
            if workflow_file.exists():
                workflow_file.unlink()
            
            logger.info(f"[TRASH] Deleted workflow: {workflow.name}")
    
    def _save_workflow(self, workflow: Workflow):
        """Save workflow to disk"""
        try:
            workflow_file = self.workflow_dir / f"{workflow.id}.json"
            
            # Convert to dict
            workflow_dict = {
                'id': workflow.id,
                'name': workflow.name,
                'description': workflow.description,
                'actions': [
                    {
                        'type': a.type.value,
                        'name': a.name,
                        'parameters': a.parameters,
                        'condition': a.condition,
                        'on_success': a.on_success,
                        'on_failure': a.on_failure
                    }
                    for a in workflow.actions
                ],
                'triggers': workflow.triggers,
                'enabled': workflow.enabled,
                'created_at': workflow.created_at,
                'run_count': workflow.run_count
            }
            
            # Save to file
            with open(workflow_file, 'w') as f:
                json.dump(workflow_dict, f, indent=2)
            
            logger.debug(f"[SAVE] Saved workflow: {workflow.name}")
            
        except Exception as e:
            logger.error(f"Error saving workflow: {e}")
    
    def _load_workflows(self):
        """Load workflows from disk"""
        try:
            for workflow_file in self.workflow_dir.glob('*.json'):
                with open(workflow_file, 'r') as f:
                    data = json.load(f)
                
                # Convert to Workflow object
                actions = []
                for action_dict in data['actions']:
                    action = WorkflowAction(
                        type=ActionType(action_dict['type']),
                        name=action_dict['name'],
                        parameters=action_dict['parameters'],
                        condition=action_dict.get('condition'),
                        on_success=action_dict.get('on_success'),
                        on_failure=action_dict.get('on_failure')
                    )
                    actions.append(action)
                
                workflow = Workflow(
                    id=data['id'],
                    name=data['name'],
                    description=data['description'],
                    actions=actions,
                    triggers=data.get('triggers', []),
                    enabled=data.get('enabled', True),
                    created_at=data.get('created_at', ''),
                    run_count=data.get('run_count', 0)
                )
                
                self.workflows[workflow.id] = workflow
            
            logger.info(f"[OPEN_FOLDER] Loaded {len(self.workflows)} workflows")
            
        except Exception as e:
            logger.error(f"Error loading workflows: {e}")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get workflow statistics"""
        return {
            'total_workflows': len(self.workflows),
            'enabled_workflows': sum(1 for w in self.workflows.values() if w.enabled),
            'total_runs': sum(w.run_count for w in self.workflows.values()),
            'running_workflows': len(self.running_workflows)
        }