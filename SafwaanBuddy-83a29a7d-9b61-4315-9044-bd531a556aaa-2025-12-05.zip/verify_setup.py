"""
SafwaanBuddy Setup Verification Script
Checks if all dependencies and configurations are correct
"""
import sys
import os
from pathlib import Path

def print_header(text):
    """Print formatted header"""
    print("\n" + "="*70)
    print(f"  {text}")
    print("="*70)

def check_python_version():
    """Check Python version"""
    print("\n🐍 Checking Python version...")
    version = sys.version_info
    
    if version.major >= 3 and version.minor >= 11:
        print(f"  [OK] Python {version.major}.{version.minor}.{version.micro} - OK")
        return True
    else:
        print(f"  [ERROR] Python {version.major}.{version.minor}.{version.micro} - Need 3.11+")
        return False

def check_dependencies():
    """Check if all dependencies are installed"""
    print("\n[PACKAGE] Checking dependencies...")
    
    required = [
        ('PyQt6', 'PyQt6'),
        ('speech_recognition', 'SpeechRecognition'),
        ('edge_tts', 'edge-tts'),
        ('google.generativeai', 'google-generativeai'),
        ('pygame', 'pygame'),
        ('pyautogui', 'pyautogui'),
        ('psutil', 'psutil'),
        ('PIL', 'Pillow')
    ]
    
    all_ok = True
    
    for module_name, package_name in required:
        try:
            __import__(module_name)
            print(f"  [OK] {package_name} - Installed")
        except ImportError:
            print(f"  [ERROR] {package_name} - NOT installed")
            all_ok = False
    
    return all_ok

def check_api_key():
    """Check if API key is configured"""
    print("\n[KEY2] Checking API key configuration...")
    
    if not os.path.exists('.env'):
        print("  [ERROR] .env file not found")
        print("  ℹ️  Copy .env.template to .env and add your API key")
        return False
    
    with open('.env', 'r') as f:
        content = f.read()
    
    if 'GEMINI_API_KEY=' in content:
        if 'your_gemini_api_key_here' in content:
            print("  [WARNING]  .env file exists but API key not configured")
            print("  ℹ️  Edit .env and add your Gemini API key")
            return False
        else:
            print("  [OK] API key configured")
            return True
    else:
        print("  [ERROR] GEMINI_API_KEY not found in .env")
        return False

def check_files():
    """Check if all required files exist"""
    print("\n[FOLDER] Checking project files...")
    
    required_files = [
        'main.py',
        'safwaan_ultimate.py',
        'requirements.txt',
        'config.json',
        '.env.template',
        'src/config_manager.py',
        'src/database_manager.py',
        'src/voice_system.py',
        'src/realistic_voice.py',
        'src/listener.py',
        'src/ai_brain.py',
        'src/advanced_brain.py',
        'src/hologram_ui.py',
        'src/screen_control.py',
        'src/proactive_assistant.py',
        'src/skills/basic_skills.py',
        'src/skills/advanced_skills.py'
    ]
    
    all_ok = True
    
    for file in required_files:
        if os.path.exists(file):
            print(f"  [OK] {file}")
        else:
            print(f"  [ERROR] {file} - MISSING")
            all_ok = False
    
    return all_ok

def check_microphone():
    """Check if microphone is available"""
    print("\n[MIC] Checking microphone...")
    
    try:
        import speech_recognition as sr
        recognizer = sr.Recognizer()
        
        mics = sr.Microphone.list_microphone_names()
        if mics:
            print(f"  [OK] Found {len(mics)} microphone(s)")
            for i, mic in enumerate(mics[:3]):
                print(f"     {i}: {mic}")
            return True
        else:
            print("  [ERROR] No microphones found")
            return False
    except Exception as e:
        print(f"  [ERROR] Error checking microphone: {e}")
        return False

def check_audio_output():
    """Check if audio output is available"""
    print("\n[AUDIO] Checking audio output...")
    
    try:
        import pygame
        pygame.mixer.init()
        print("  [OK] Audio output available")
        pygame.mixer.quit()
        return True
    except Exception as e:
        print(f"  [ERROR] Audio output error: {e}")
        return False

def main():
    """Main verification"""
    print_header("SAFWAANBUDDY SETUP VERIFICATION")
    
    print("\nThis script will verify your SafwaanBuddy installation.")
    print("Please wait while we check everything...\n")
    
    results = {
        'Python Version': check_python_version(),
        'Dependencies': check_dependencies(),
        'API Key': check_api_key(),
        'Project Files': check_files(),
        'Microphone': check_microphone(),
        'Audio Output': check_audio_output()
    }
    
    # Summary
    print_header("VERIFICATION SUMMARY")
    
    all_passed = all(results.values())
    
    for check, passed in results.items():
        status = "[OK] PASS" if passed else "[ERROR] FAIL"
        print(f"  {check}: {status}")
    
    print("\n" + "="*70)
    
    if all_passed:
        print("\n[CELEBRATE] ALL CHECKS PASSED! [CELEBRATE]")
        print("\nYour SafwaanBuddy is ready to use!")
        print("\nNext steps:")
        print("  1. Run: python main.py (Standard)")
        print("  2. Or run: python safwaan_ultimate.py (ULTIMATE)")
        print("  3. Say 'Safwaan' to activate")
        print("  4. Enjoy your AI assistant!")
    else:
        print("\n[WARNING]  SOME CHECKS FAILED")
        print("\nPlease fix the issues above before running SafwaanBuddy.")
        print("\nCommon fixes:")
        print("  • Install dependencies: pip install -r requirements.txt")
        print("  • Configure API key: Edit .env file")
        print("  • Check microphone: Windows Sound settings")
        print("  • Install Python 3.11+: python.org")
    
    print("\n" + "="*70)
    print("\nFor detailed help, see:")
    print("  • SETUP_GUIDE.md - Installation instructions")
    print("  • QUICKSTART.md - Quick start guide")
    print("  • README.md - Complete documentation")
    print("\n")

if __name__ == "__main__":
    main()
    input("\nPress Enter to exit...")