"""
Web Control Panel Backend Server
Flask API for SafwaanBuddy control panel
Version: 3.0 HYPER
"""
from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
from flask_socketio import SocketIO, emit
import logging
import threading
import time
from pathlib import Path

logger = logging.getLogger('WebPanel')

app = Flask(__name__, 
           static_folder='static',
           template_folder='templates')
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*")

# Global reference to SafwaanBuddy instance
safwaan_instance = None


def start_server(safwaan):
    """Start the web control panel server"""
    global safwaan_instance
    safwaan_instance = safwaan
    
    try:
        port = safwaan.config.get('web_panel.port', 8080)
        host = safwaan.config.get('web_panel.host', 'localhost')
        
        logger.info(f"[WEB] Starting web control panel on http://{host}:{port}")
        
        socketio.run(app, host=host, port=port, debug=False, allow_unsafe_werkzeug=True)
        
    except Exception as e:
        logger.error(f"Error starting web server: {e}")


# ============================================================================
# API ROUTES
# ============================================================================

@app.route('/')
def index():
    """Serve main dashboard"""
    return render_template('index.html')


@app.route('/api/status')
def get_status():
    """Get system status"""
    if not safwaan_instance:
        return jsonify({'error': 'System not initialized'}), 500
    
    try:
        stats = safwaan_instance.get_stats()
        
        return jsonify({
            'status': 'online',
            'uptime': stats['uptime'],
            'commands_processed': stats['commands_processed'],
            'success_rate': stats['success_rate'],
            'avg_response_time': stats['avg_response_time'],
            'memory_count': stats['memory_count'],
            'plugin_count': stats['plugin_count'],
            'workflow_count': stats['workflow_count']
        })
    except Exception as e:
        logger.error(f"Error getting status: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/stats')
def get_stats():
    """Get detailed statistics"""
    if not safwaan_instance:
        return jsonify({'error': 'System not initialized'}), 500
    
    try:
        stats = safwaan_instance.get_stats()
        return jsonify(stats)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/voice/test', methods=['POST'])
def test_voice():
    """Test voice synthesis"""
    if not safwaan_instance:
        return jsonify({'error': 'System not initialized'}), 500
    
    try:
        data = request.json
        text = data.get('text', 'This is a test of the voice system.')
        
        # Speak in background thread
        threading.Thread(
            target=safwaan_instance.voice.speak,
            args=(text,),
            daemon=True
        ).start()
        
        return jsonify({'success': True, 'message': 'Voice test started'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/command/execute', methods=['POST'])
def execute_command():
    """Execute a voice command"""
    if not safwaan_instance:
        return jsonify({'error': 'System not initialized'}), 500
    
    try:
        data = request.json
        command = data.get('command', '')
        
        if not command:
            return jsonify({'error': 'No command provided'}), 400
        
        # Process command in background
        threading.Thread(
            target=safwaan_instance.process_voice_command,
            args=(command,),
            daemon=True
        ).start()
        
        return jsonify({'success': True, 'message': 'Command queued'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/memory/search', methods=['POST'])
def search_memory():
    """Search neural memory"""
    if not safwaan_instance:
        return jsonify({'error': 'System not initialized'}), 500
    
    try:
        data = request.json
        query = data.get('query', '')
        top_k = data.get('top_k', 5)
        
        memories = safwaan_instance.memory.retrieve_similar(query, top_k)
        
        results = [
            {
                'content': m.content,
                'type': m.memory_type,
                'importance': m.importance,
                'timestamp': m.timestamp.isoformat()
            }
            for m in memories
        ]
        
        return jsonify({'results': results})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/plugins/list')
def list_plugins():
    """List all plugins"""
    if not safwaan_instance:
        return jsonify({'error': 'System not initialized'}), 500
    
    try:
        plugins = []
        for name, plugin in safwaan_instance.plugin_system.plugins.items():
            plugins.append({
                'name': name,
                'version': plugin.version,
                'author': plugin.author,
                'description': plugin.description,
                'commands': plugin.get_commands()
            })
        
        return jsonify({'plugins': plugins})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/workflows/list')
def list_workflows():
    """List all workflows"""
    if not safwaan_instance:
        return jsonify({'error': 'System not initialized'}), 500
    
    try:
        workflows = []
        for wf_id, workflow in safwaan_instance.workflow_engine.workflows.items():
            workflows.append({
                'id': wf_id,
                'name': workflow.name,
                'description': workflow.description,
                'enabled': workflow.enabled,
                'run_count': workflow.run_count,
                'last_run': workflow.last_run
            })
        
        return jsonify({'workflows': workflows})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/config', methods=['GET', 'POST'])
def manage_config():
    """Get or update configuration"""
    if not safwaan_instance:
        return jsonify({'error': 'System not initialized'}), 500
    
    try:
        if request.method == 'GET':
            # Return current config
            config = safwaan_instance.config.get_all()
            return jsonify(config)
        
        elif request.method == 'POST':
            # Update config
            data = request.json
            for key, value in data.items():
                safwaan_instance.config.set(key, value)
            
            return jsonify({'success': True, 'message': 'Configuration updated'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ============================================================================
# WEBSOCKET EVENTS
# ============================================================================

@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    logger.info("[PLUGIN] Client connected to WebSocket")
    emit('status', {'message': 'Connected to SafwaanBuddy'})


@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    logger.info("[PLUGIN] Client disconnected from WebSocket")


@socketio.on('request_stats')
def handle_stats_request():
    """Send real-time stats to client"""
    if safwaan_instance:
        stats = safwaan_instance.get_stats()
        emit('stats_update', stats)


# Background task to send periodic updates
def background_stats_updater():
    """Send stats updates to all connected clients"""
    while True:
        time.sleep(2)  # Update every 2 seconds
        
        if safwaan_instance:
            stats = safwaan_instance.get_stats()
            socketio.emit('stats_update', stats)


# Start background updater
threading.Thread(target=background_stats_updater, daemon=True).start()


if __name__ == '__main__':
    print("[WARNING]  This server should be started from safwaan_hyper_ultimate.py")
    print("Run: python safwaan_hyper_ultimate.py")