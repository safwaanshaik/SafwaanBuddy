#!/usr/bin/env python3
"""
🚀 Safwaan Buddy Enhanced - QUICK START
One-click deployment of the ultra-advanced AI assistant
"""

import os
import sys
import subprocess
import webbrowser
from pathlib import Path

def main():
    print("🌟 SAFWAAN BUDDY ULTRA-ENHANCED - QUICK START")
    print("=" * 60)
    print()
    print("🤖 Features Included:")
    print("   🧠 Super-Intelligent AI with Emotional Intelligence")
    print("   🗣️ Natural Human-like Speech in 16+ Languages")
    print("   💻 Complete Laptop System Control")
    print("   🖥️ Screen Interaction & Form Filling (OCR)")
    print("   🌐 Web Automation & Auto-Software Installation")
    print("   🎨 Jarvis-Style Visual Interface")
    print("   ⚙️ Advanced System Administration")
    print()
    print("📦 Quick Installation Options:")
    print()

    print("1️⃣  Auto-Install (Recommended)")
    print("    python auto_installer.py")
    print()

    print("2️⃣  Manual Quick Start")
    print("    pip install -r requirements.txt")
    print("    python run_safwaan_buddy.py")
    print()

    print("3️⃣  Test with Minimal Setup")
    print("    pip install PyQt6 pyttsx3 requests")
    print("    python run_safwaan_buddy.py")
    print()

    print("🎯 Voice Commands to Try:")
    print('   • "Hey Buddy, what can you do?"')
    print('   • "Take a screenshot"')
    print('   • "Fill out this form"')
    print('   • "Search for and install VS Code"')
    print('   • "Tell me a joke in Spanish"')
    print('   • "Show me system information"')
    print()

    print("📁 Files Created:")
    current_dir = Path(".")
    for file in current_dir.glob("*"):
        if file.is_file() and file.suffix in ['.py', '.md', '.txt']:
            print(f"   📄 {file.name}")

    print()
    print("🚀 Ready to launch your ultra-advanced AI assistant!")
    print("💡 The future of AI assistants is here - experience it now!")
    print()

    choice = input("Launch installation? (y/n): ").lower().strip()
    if choice in ['y', 'yes', '']:
        # Launch the auto-installer
        try:
            subprocess.run([sys.executable, "auto_installer.py"], check=True)
        except:
            print("⚠️ Auto-installer not found. Please navigate to the SafwaanBuddy_Ultra_Enhanced directory and run:")
            print("   python auto_installer.py")

if __name__ == "__main__":
    main()