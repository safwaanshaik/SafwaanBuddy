# 🤖 Safwaan Buddy - Jarvis-Style Voice Assistant

[![Python Version](https://img.shields.io/badge/python-3.9+-blue.svg)](https://python.org)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/platform-Windows-lightgrey.svg)](https://www.microsoft.com/windows)

**Safwaan Buddy** is an advanced, always-available personal automation assistant designed with inspiration from Jarvis (Iron Man's AI). Unlike basic chatbots, it combines human-like voice interaction, conversational task execution, real Python automation, and UI manipulation for powerful Windows workflows.

## ✨ Key Features

- **🎙️ Voice-Responsive & Conversational:**
  Responds to spoken or typed commands in natural language, enabling hands-free operation and real conversations.

- **🖱️ UI Automation:**
  Can fill out forms, type text, click buttons, or create/open files and apps on Windows — all via simple conversational instructions.

- **⚙️ Code & Command Generation:**
  Generates and executes Python scripts and system commands dynamically to achieve tasks beyond basic macros.

- **📊 System Control & Monitoring:**
  Monitors files, folders, system resources (CPU, disk, memory) and can alert or respond proactively.

- **🔊 Human-Like Voice:**
  Speaks responses using advanced text-to-speech, aiming for a natural, helpful, and "buddy-like" conversational presence.

- **🔌 Extensible Plugin System:**
  Plugin architecture allows custom functionality and automation workflows.

- **🔒 Secure Memory:**
  Encrypted SQLite database stores conversations, preferences, and learned information securely.

- **🤖 AI Integration:**
  Supports both OpenAI GPT and local LLM integration for intelligent conversations.

## 🚀 Quick Start

### Prerequisites

- **Python 3.9+** with pip
- **Windows 10/11** with audio input device
- **Microphone** for voice input
- **Speakers/headphones** for audio output
- **Administrative privileges** (for UI automation)

### Automated Installation

```bash
# Clone the repository
git clone https://github.com/safwaan/safwaan-buddy.git
cd safwaan-buddy

# Run the automated installation script
python scripts/install.py
```

### Manual Installation

```bash
# 1. Create virtual environment
python -m venv venv
venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Configure environment
copy .env.example .env
# Edit .env with your configuration

# 4. Run the application
python src/main.py
```

## ⚙️ Configuration

### Environment Variables

Create a `.env` file from `.env.example` and configure:

```env
# Required for AI features
OPENAI_API_KEY=your_openai_api_key_here

# Security (auto-generated if not provided)
BUDDY_KEY=your_encryption_key_here

# Voice settings
TTS_PROVIDER=pyttsx3
VOICE_RATE=150
WAKE_WORDS=buddy,safwaan buddy

# Local LLM (optional)
LOCAL_LLM_URL=http://localhost:11434/api/generate
LOCAL_LLM_MODEL=llama2
```

### First-Time Setup

1. **Audio Configuration:** The installer will test your microphone and speakers
2. **Wake Word Training:** Say "buddy" or "safwaan buddy" a few times to calibrate
3. **Permission Setup:** Grant administrative privileges for UI automation
4. **Plugin Selection:** Choose which plugins to enable during setup

## 🎯 Usage Examples

### Voice Commands

```bash
# Wake the assistant
"Hey Buddy..." or "Safwaan Buddy..."

# System information
"What's my system status?"
"How much memory do I have?"

# Application control
"Open notepad"
"Launch Chrome"
"Close calculator"

# Automation
"Type 'Hello World'"
"Click at coordinates 100, 200"
"Fill form with name: John"

# Notes and memory
"Save note meeting: Discuss project timeline"
"Recall note meeting"
"List all my notes"

# AI conversation
"What's the weather like today?"
"Help me write Python code"
"Explain machine learning"
```

### GUI Interaction

- **Type commands** in the input field and press Enter
- **Click 🎤 Listen** to use voice input
- **View conversation history** in the chat display
- **Monitor system resources** in real-time
- **Access memory/history** via control buttons

## 🏗️ Architecture

```
src/
├── core/              # Core functionality
│   ├── memory.py      # Encrypted memory management
│   ├── voice_processor.py  # Speech processing
│   ├── ui_automation.py    # UI control
│   ├── command_parser.py   # Intent recognition
│   └── plugin_manager.py   # Plugin system
├── gui/               # User interface
│   ├── main_window.py # Main PyQt6 interface
│   └── styles.py      # Theming and styling
├── ai/                # AI integration
│   ├── providers.py   # AI service providers
│   └── prompts.py     # Prompt templates
├── utils/             # Utilities
│   ├── logger.py      # Logging system
│   ├── system_monitor.py  # System monitoring
│   └── helpers.py     # Helper functions
├── plugins/           # Extensible plugins
│   ├── system.py      # System-related plugins
│   ├── notes.py       # Note management
│   └── automation.py  # Automation workflows
└── main.py            # Application entry point
```

## 🔌 Plugin Development

Create custom plugins by extending the plugin system:

```python
# src/plugins/custom_plugin.py
from core.plugin_manager import PluginManager

def custom_function(param1: str, param2: str = "default") -> str:
    """Custom plugin functionality"""
    return f"Processed: {param1} with {param2}"

# Register plugin
PluginManager.register("custom_command", custom_function)
```

### Built-in Plugins

- **System:** CPU, RAM, disk monitoring; process management
- **Notes:** Save, recall, search, organize notes
- **Automation:** Workflow automation and macro recording
- **Clipboard:** Read/write clipboard operations
- **File Operations:** File monitoring and batch operations

## 🛠️ Development

### Development Setup

```bash
# Install development dependencies
pip install -r requirements.txt

# Install in development mode
pip install -e .

# Run tests
pytest

# Code formatting
black src/
flake8 src/
```

### Project Structure

- **Modular Architecture:** Separated concerns with clear interfaces
- **Event-Driven:** Asynchronous voice processing and UI updates
- **Plugin-Based:** Extensible functionality without core modifications
- **Secure Design:** Encrypted storage and secure configuration

## 📊 Performance

### System Requirements

- **Memory:** < 200MB during normal operation
- **CPU:** < 10% during idle listening
- **Startup Time:** < 5 seconds
- **Response Time:** < 2 seconds for voice commands

### Optimization Features

- **Background Processing:** Non-blocking voice recognition
- **Resource Monitoring:** Automatic resource usage tracking
- **Smart Caching:** Frequently used data cached in memory
- **Graceful Degradation:** Fallback options when services unavailable

## 🔒 Security

### Data Protection

- **AES-256 Encryption:** All stored data encrypted with Fernet
- **Secure Key Management:** Environment-based credential storage
- **Privacy-First:** Optional data collection and processing
- **Local Processing:** Voice and AI processing can run entirely offline

### Permissions

- **UI Automation:** Requires administrative privileges for screen control
- **File Access:** Controlled access to user-specified directories
- **Network:** Optional network access for AI services
- **Microphone:** Required only during voice input sessions

## 🔧 Troubleshooting

### Common Issues

**Microphone not detected:**
```bash
# Test audio devices
python scripts/setup_microphone.py

# Check Windows privacy settings
# Settings > Privacy > Microphone > Allow apps to access
```

**Voice commands not recognized:**
- Ensure quiet environment during wake word detection
- Check microphone volume and position
- Try different wake words or phrases
- Recalibrate voice recognition

**UI automation not working:**
- Run as Administrator
- Check Windows security settings
- Ensure target applications are accessible

**High CPU usage:**
- Disable unused plugins
- Adjust voice recognition sensitivity
- Reduce system monitoring frequency

### Debug Mode

Enable debug logging in `.env`:

```env
BUDDY_LOG_LEVEL=DEBUG
```

Check logs in `data/buddy.log` for detailed error information.

## 📚 Documentation

- **[Installation Guide](docs/installation.md)** - Detailed setup instructions
- **[Plugin Development](docs/plugins.md)** - Creating custom plugins
- **[API Reference](docs/api.md)** - Complete API documentation
- **[Troubleshooting](docs/troubleshooting.md)** - Common issues and solutions
- **[Contributing](CONTRIBUTING.md)** - Development contribution guide

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for:

- Code style and standards
- Pull request process
- Issue reporting guidelines
- Development workflow

### Ways to Contribute

- 🐛 Report bugs and issues
- 💡 Suggest new features
- 🔌 Develop plugins
- 📖 Improve documentation
- 🧪 Add tests
- 🌍 Translate to other languages

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **OpenAI** - GPT API for intelligent conversations
- **Google** - Speech Recognition API
- **PyQt6** - Cross-platform GUI framework
- **pyautogui** - UI automation capabilities
- **cryptography** - Secure encryption library

## 📞 Support

- **[GitHub Issues](https://github.com/safwaan/safwaan-buddy/issues)** - Bug reports and feature requests
- **[Discord Community](https://discord.gg/safwaan-buddy)** - Live chat and support
- **[Documentation Wiki](https://github.com/safwaan/safwaan-buddy/wiki)** - Community-maintained docs

---

<div align="center">
  <strong>Made with ❤️ by Safwaan</strong><br>
  <em>Your personal AI assistant for Windows</em>
</div>