#!/usr/bin/env python3
"""
Build script for Safwaan Buddy
Creates a single executable with all enhanced features using PyInstaller.
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

def install_dependencies():
    """Install required dependencies for building."""
    print("Installing build dependencies...")
    dependencies = [
        "pyinstaller>=5.0",
        "pyqt6",
        "pyttsx3",
        "speechrecognition",
        "psutil",
        "cryptography",
        "pyautogui",
        "requests",
        "pillow",
        "numpy",
        "scipy"
    ]

    for dep in dependencies:
        try:
            print(f"Installing {dep}...")
            subprocess.run([sys.executable, "-m", "pip", "install", dep],
                         check=True, capture_output=True)
            print(f"✓ {dep} installed")
        except subprocess.CalledProcessError:
            print(f"✗ Failed to install {dep}")

def create_spec_file():
    """Create PyInstaller spec file for Safwaan Buddy."""
    spec_content = '''# -*- mode: python ; coding: utf-8 -*-

import sys
from pathlib import Path

# Add src directory to Python path
src_path = Path(SPECPATH).parent / "src"
if str(src_path) not in sys.path:
    sys.path.insert(0, str(src_path))

block_cipher = None

a = Analysis(
    [str(src_path / "main.py")],
    pathex=[str(src_path)],
    binaries=[],
    datas=[
        # Include configuration files
        ("config", "config"),
        ("data", "data"),

        # Include GUI resources
        (str(src_path / "gui"), "gui"),

        # Include plugin files
        ("src/plugins", "plugins"),

        # Include scripts
        ("scripts", "scripts"),

        # Include static assets
        ("static", "static"),
    ],
    hiddenimports=[
        # Core modules
        "src.core.natural_speech",
        "src.core.system_control",
        "src.core.ai_personality",
        "src.core.memory",
        "src.core.voice_processor",
        "src.core.command_parser",
        "src.core.plugin_manager",
        "src.core.ui_automation",

        # GUI modules
        "src.gui.main_window",
        "src.gui.styles",

        # Utility modules
        "src.utils.logger",
        "src.utils.helpers",
        "src.utils.system_monitor",

        # Required packages
        "PyQt6.QtCore",
        "PyQt6.QtWidgets",
        "PyQt6.QtGui",
        "pyttsx3",
        "speech_recognition",
        "psutil",
        "cryptography",
        "pyautogui",
        "requests",
        "pillow",
        "numpy",
        "scipy",

        # Windows-specific modules
        "winreg",
        "ctypes",
        "win32api",
        "win32con",

        # Platform-specific
        "platform",
        "sys",
        "os",
        "json",
        "yaml",
        "configparser",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="SafwaanBuddy",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,  # Set to True for debugging
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,  # Add icon path if you have one
    version_file=None,  # Add version file if you have one
)
'''

    with open("SafwaanBuddy.spec", "w", encoding="utf-8") as f:
        f.write(spec_content)

    print("✓ Created SafwaanBuddy.spec file")

def build_executable():
    """Build the executable using PyInstaller."""
    print("Building Safwaan Buddy executable...")
    print("This may take several minutes...")

    # Clean previous builds
    for folder in ["build", "dist"]:
        if Path(folder).exists():
            shutil.rmtree(folder)

    # Build the executable
    try:
        result = subprocess.run([
            sys.executable, "-m", "PyInstaller",
            "--clean",
            "--log-level=INFO",
            "SafwaanBuddy.spec"
        ], check=True, capture_output=False, text=True)

        print("✓ Build completed successfully!")

        # Check if executable was created
        exe_path = Path("dist") / "SafwaanBuddy.exe" if os.name == "nt" else Path("dist") / "SafwaanBuddy"
        if exe_path.exists():
            print(f"✓ Executable created: {exe_path.absolute()}")
            print(f"✓ File size: {exe_path.stat().st_size / (1024*1024):.1f} MB")
            return True
        else:
            print("✗ Executable not found after build")
            return False

    except subprocess.CalledProcessError as e:
        print(f"✗ Build failed: {e}")
        return False

def create_installer():
    """Create a simple installer for the application."""
    print("Creating installer package...")

    # Create distribution folder
    dist_folder = Path("SafwaanBuddy_Release")
    if dist_folder.exists():
        shutil.rmtree(dist_folder)

    dist_folder.mkdir()

    # Copy executable
    exe_source = Path("dist") / ("SafwaanBuddy.exe" if os.name == "nt" else "SafwaanBuddy")
    if exe_source.exists():
        exe_dest = dist_folder / exe_source.name
        shutil.copy2(exe_source, exe_dest)
        print(f"✓ Copied executable to {exe_dest}")

    # Create README
    readme_content = """# Safwaan Buddy - Enhanced AI Voice Assistant

## Features
- 🤖 **Super-Intelligent AI**: Advanced learning and reasoning capabilities
- 🗣️ **Natural Speech**: Human-like conversation with emotional intelligence
- 💻 **Complete Laptop Control**: Full system administration and automation
- 🌍 **Multilingual**: Support for 16+ languages with cultural adaptations
- ⚙️ **Advanced Features**: File operations, network control, UI automation

## System Requirements
- Windows 10/11 (Recommended) or Linux/macOS
- 4GB RAM minimum, 8GB recommended
- 500MB free disk space
- Microphone for voice commands (optional)

## Quick Start
1. Double-click `SafwaanBuddy.exe` to launch
2. Grant administrator permissions for full functionality
3. Say "Hey Buddy" or click the microphone to start
4. Enjoy your advanced AI assistant!

## Commands
- **System Control**: "Open Chrome", "Close Notepad", "Volume 50"
- **File Operations**: "Create file report.txt", "Copy file.txt to desktop"
- **Information**: "What's the weather?", "Tell me about AI"
- **Entertainment**: "Tell me a joke", "Play some music"
- **System Info**: "Show system status", "Network speed test"

## Support
For issues and updates, check the documentation.

---
Enhanced by Advanced AI Technology © 2024
"""

    with open(dist_folder / "README.txt", "w", encoding="utf-8") as f:
        f.write(readme_content)

    # Create batch file for Windows
    if os.name == "nt":
        batch_content = """@echo off
echo Starting Safwaan Buddy...
echo.
echo Please ensure you have administrator privileges for full functionality.
echo.

:: Check if running as admin
net session >nul 2>&1
if %errorLevel% == 0 (
    echo Running with administrator privileges
) else (
    echo WARNING: Running without administrator privileges
    echo Some features may be limited
    echo.
)

:: Launch Safwaan Buddy
SafwaanBuddy.exe

pause
"""

        with open(dist_folder / "Start Safwaan Buddy.bat", "w", encoding="utf-8") as f:
            f.write(batch_content)

        print("✓ Created launcher batch file")

    print(f"✓ Release package created: {dist_folder.absolute()}")

    # Create zip archive
    archive_name = "SafwaanBuddy_v1.0_Enhanced"
    shutil.make_archive(archive_name, 'zip', dist_folder)
    print(f"✓ Created archive: {archive_name}.zip")

def main():
    """Main build process."""
    print("🚀 Building Enhanced Safwaan Buddy")
    print("=" * 50)

    # Check if we're in the right directory
    if not Path("src/main.py").exists():
        print("✗ Error: src/main.py not found")
        print("Please run this script from the voice-assistant root directory")
        sys.exit(1)

    # Step 1: Install dependencies
    install_dependencies()
    print()

    # Step 2: Create spec file
    create_spec_file()
    print()

    # Step 3: Build executable
    if build_executable():
        print()
        # Step 4: Create installer
        create_installer()

        print("\n🎉 Build completed successfully!")
        print("\n📦 Created files:")
        print("  - dist/SafwaanBuddy.exe (Main executable)")
        print("  - SafwaanBuddy_Release/ (Distribution folder)")
        print("  - SafwaanBuddy_v1.0_Enhanced.zip (Archive)")
        print("\n🚀 Ready to distribute!")
    else:
        print("\n❌ Build failed. Please check the errors above.")
        sys.exit(1)

if __name__ == "__main__":
    main()