#!/usr/bin/env python3
"""
Complete installation and setup script for Safwaan Buddy Enhanced
"""

import sys
import os
import subprocess
import json
from pathlib import Path

def run_command(command, description, check=True):
    """Run a command and handle errors."""
    print(f"🔄 {description}...")
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True, check=check)
        if result.stdout:
            print(f"✅ {description}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed: {description}")
        if e.stderr:
            print(f"   Error: {e.stderr}")
        return False

def install_dependencies():
    """Install required dependencies."""
    print("\n📦 Installing dependencies...")

    # Install essential packages
    essential_packages = [
        "pyqt6", "pyttsx3", "speechrecognition", "psutil",
        "cryptography", "pyautogui", "requests", "pillow",
        "numpy", "scipy", "pyinstaller"
    ]

    for package in essential_packages:
        run_command(
            f"{sys.executable} -m pip install {package}",
            f"Installing {package}",
            check=False
        )

def create_directories():
    """Create necessary directories."""
    directories = [
        "config", "data", "logs", "static/icons", "static/sounds"
    ]

    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
        print(f"📁 Created directory: {directory}")

def create_config():
    """Create default configuration."""
    config_dir = Path("config")
    config_dir.mkdir(exist_ok=True)

    default_config = {
        "agent_name": "Safwaan Buddy",
        "wake_words": ["buddy", "safwaan buddy", "hey buddy"],
        "voice_rate": 150,
        "voice_volume": 1.0,
        "enable_wake_word_detection": True,
        "enable_voice_input": True,
        "enable_system_monitoring": True,
        "gui_theme": "dark",
        "window_width": 1200,
        "window_height": 900,
        "enable_ai_personality": True,
        "enable_natural_speech": True,
        "enable_system_control": True,
        "enable_multilingual": True,
        "default_language": "english",
        "emotional_intelligence": True,
        "personality_formality": 0.3,
        "personality_enthusiasm": 0.7,
        "personality_empathy": 0.8
    }

    config_file = config_dir / "default.json"
    with open(config_file, 'w') as f:
        json.dump(default_config, f, indent=4)
    print(f"⚙️ Created configuration: {config_file}")

def create_launchers():
    """Create launcher scripts."""

    # Create Windows launcher
    if os.name == 'nt':
        batch_content = """@echo off
title Safwaan Buddy Enhanced
echo.
echo 🚀 Safwaan Buddy Enhanced - AI Voice Assistant
echo ==============================================
echo.
echo Features:
echo 🧠 Natural speech with emotional intelligence
echo 💻 Complete laptop system control
echo 🌍 Multilingual support (16+ languages)
echo ⚙️ Advanced AI personality and learning
echo.
echo Starting application...
echo.

python run_safwaan_buddy.py

if %errorLevel% neq 0 (
    echo.
    echo ❌ Application encountered an error
    echo.
)

pause
"""
        with open("Start Safwaan Buddy.bat", 'w') as f:
            f.write(batch_content)
        print("🚀 Created Windows launcher: Start Safwaan Buddy.bat")

def main():
    """Main installation function."""
    print("🎯 Safwaan Buddy Enhanced - Complete Installation")
    print("=" * 50)

    # Install dependencies
    install_dependencies()

    # Create directories
    create_directories()

    # Create configuration
    create_config()

    # Create launchers
    create_launchers()

    print("\n🎉 Installation completed!")
    print("\n📋 To run Safwaan Buddy Enhanced:")
    print("1. Run: python run_safwaan_buddy.py")
    print("2. Or double-click: Start Safwaan Buddy.bat")
    print("\n✨ Features:")
    print("🧠 Natural speech with emotional intelligence")
    print("💻 Complete laptop system control")
    print("🌍 Multilingual support (16+ languages)")
    print("⚙️ Advanced AI personality and learning")

if __name__ == "__main__":
    main()