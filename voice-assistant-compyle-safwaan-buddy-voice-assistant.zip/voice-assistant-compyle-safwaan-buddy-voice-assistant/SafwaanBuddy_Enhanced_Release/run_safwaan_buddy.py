#!/usr/bin/env python3
"""
Portable launcher for Safwaan Buddy Enhanced
Can run the application directly or be packaged with dependencies.
"""

import sys
import os
from pathlib import Path

def check_dependencies():
    """Check if required dependencies are available."""
    required_modules = [
        'PyQt6', 'pyttsx3', 'speechrecognition', 'psutil',
        'cryptography', 'pyautogui', 'requests', 'pillow', 'numpy', 'scipy'
    ]

    missing_modules = []
    for module in required_modules:
        try:
            __import__(module)
        except ImportError:
            missing_modules.append(module)

    if missing_modules:
        print("❌ Missing required dependencies:")
        for module in missing_modules:
            print(f"   - {module}")
        print("\n📦 To install dependencies, run:")
        print("   pip install -r requirements.txt")
        return False

    return True

def setup_paths():
    """Setup Python paths for the application."""
    # Get current script directory
    current_dir = Path(__file__).parent

    # Add src directory to path
    src_dir = current_dir / "src"
    if str(src_dir) not in sys.path:
        sys.path.insert(0, str(src_dir))

    return current_dir

def main():
    """Main launcher function."""
    print("🚀 Safwaan Buddy Enhanced - Portable Launcher")
    print("=" * 50)

    # Setup paths
    current_dir = setup_paths()

    # Check dependencies
    if not check_dependencies():
        input("\nPress Enter to exit...")
        return

    print("✅ All dependencies found")
    print("🎯 Starting Safwaan Buddy Enhanced...")

    try:
        # Import and run the main application
        from main import main as app_main

        print("🤖 Launching Enhanced AI Assistant with:")
        print("   🧠 Natural speech with emotional intelligence")
        print("   💻 Complete laptop system control")
        print("   🌍 Multilingual support (16+ languages)")
        print("   ⚙️ Advanced AI personality and learning")
        print()

        # Run the application
        app_main()

    except KeyboardInterrupt:
        print("\n\n👋 Safwaan Buddy stopped by user")
    except Exception as e:
        print(f"\n❌ Error starting Safwaan Buddy: {e}")
        print("\n🔍 Troubleshooting:")
        print("   1. Make sure all dependencies are installed")
        print("   2. Check that src/main.py exists")
        print("   3. Try running as administrator for full features")
        input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()