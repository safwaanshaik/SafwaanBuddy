#!/usr/bin/env python3
"""
Safwaan Buddy - Jarvis-Style Voice Assistant Setup Script
"""

from setuptools import setup, find_packages
import os

# Read README file
def read_readme():
    readme_path = os.path.join(os.path.dirname(__file__), 'README.md')
    if os.path.exists(readme_path):
        with open(readme_path, 'r', encoding='utf-8') as f:
            return f.read()
    return "Safwaan Buddy - Jarvis-Style Voice Assistant"

# Read requirements
def read_requirements():
    requirements_path = os.path.join(os.path.dirname(__file__), 'requirements.txt')
    requirements = []
    if os.path.exists(requirements_path):
        with open(requirements_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and not line.startswith('pytest'):
                    requirements.append(line)
    return requirements

setup(
    name="safwaan-buddy",
    version="1.0.0",
    author="Safwaan",
    author_email="safwaan@example.com",
    description="Jarvis-Style Voice Assistant for Windows",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/safwaan/safwaan-buddy",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: End Users/Desktop",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Multimedia :: Sound/Audio :: Speech",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Desktop Environment",
    ],
    python_requires=">=3.9",
    install_requires=read_requirements(),
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-qt>=4.2.0",
            "black>=22.0.0",
            "flake8>=5.0.0",
            "mypy>=1.0.0",
        ],
        "advanced-tts": [
            "edge-tts>=6.1.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "safwaan-buddy=main:main",
        ],
    },
    include_package_data=True,
    package_data={
        "": ["*.json", "*.css", "*.md"],
    },
    zip_safe=False,
    keywords="voice assistant jarvis automation windows gui",
    project_urls={
        "Bug Reports": "https://github.com/safwaan/safwaan-buddy/issues",
        "Source": "https://github.com/safwaan/safwaan-buddy",
        "Documentation": "https://github.com/safwaan/safwaan-buddy/wiki",
    },
)