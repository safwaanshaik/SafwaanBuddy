"""
Safwaan Buddy - Jarvis-Style Voice Assistant
Main application package
"""

__version__ = "1.0.0"
__author__ = "Safwaan"
__description__ = "Advanced personal automation assistant with voice interaction"

# Import main components for easy access
from .config import get_config
from .core import *
from .gui import *
from .ai import *
from .utils import *

__all__ = [
    "get_config",
    # Core modules
    "MemoryManager",
    "VoiceProcessor",
    "UIAutomation",
    "AICommandParser",
    "PluginManager",
    # GUI
    "SafwaanBuddyGUI",
    "ThemeManager",
    # AI
    "generate_ai_response",
    "is_ai_available",
    # Utils
    "get_logger",
    "get_system_monitor"
]