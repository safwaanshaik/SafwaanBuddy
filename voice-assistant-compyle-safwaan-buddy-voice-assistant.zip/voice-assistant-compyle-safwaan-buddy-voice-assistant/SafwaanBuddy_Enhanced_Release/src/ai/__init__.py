"""
AI integration modules for Safwaan Buddy
"""

from .providers import (
    BaseAIProvider, OpenAIProvider, LocalLLMProvider,
    AIProviderManager, AIResponse, get_ai_manager,
    generate_ai_response, is_ai_available
)
from .prompts import (
    PromptManager, ConversationContext, get_prompt_manager,
    build_ai_prompt, update_conversation
)

__all__ = [
    # AI Providers
    "BaseAIProvider",
    "OpenAIProvider",
    "LocalLLMProvider",
    "AIProviderManager",
    "AIResponse",
    "get_ai_manager",
    "generate_ai_response",
    "is_ai_available",

    # Prompts and Context
    "PromptManager",
    "ConversationContext",
    "get_prompt_manager",
    "build_ai_prompt",
    "update_conversation"
]