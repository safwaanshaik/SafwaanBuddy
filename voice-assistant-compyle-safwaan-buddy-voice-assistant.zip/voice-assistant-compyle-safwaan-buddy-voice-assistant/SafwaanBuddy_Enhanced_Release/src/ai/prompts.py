#!/usr/bin/env python3
"""
AI Prompt Templates and Context Management for Safwaan Buddy
Provides system prompts, conversation templates, and context management.
"""

from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass
import json

from utils.logger import get_logger

logger = get_logger("ai_prompts")


@dataclass
class ConversationContext:
    """Context for AI conversations."""
    session_id: str
    user_name: Optional[str] = None
    conversation_history: List[Dict[str, str]] = None
    user_preferences: Dict[str, Any] = None
    current_task: Optional[str] = None
    last_intent: Optional[str] = None
    system_status: Dict[str, Any] = None

    def __post_init__(self):
        if self.conversation_history is None:
            self.conversation_history = []
        if self.user_preferences is None:
            self.user_preferences = {}


class PromptManager:
    """Manages AI prompts and conversation context."""

    def __init__(self):
        """Initialize prompt manager."""
        self.system_prompts = self._load_system_prompts()
        self.conversation_contexts: Dict[str, ConversationContext] = {}

    def _load_system_prompts(self) -> Dict[str, str]:
        """Load system prompts."""
        return {
            "default": """You are Safwaan Buddy, an advanced AI assistant designed to help users with voice commands and automation tasks.

Key characteristics:
- Friendly, helpful, and conversational
- Concise and to the point
- Capable of understanding natural language commands
- Knowledgeable about system operations and automation
- Always ready to assist with practical tasks

Your capabilities include:
- System monitoring and control
- Voice command interpretation
- Application management
- Note-taking and information retrieval
- UI automation (when requested)
- General assistance and conversation

Always respond in a natural, helpful manner and keep responses concise unless detailed explanations are requested.""",

            "technical": """You are Safwaan Buddy, a technical AI assistant specializing in system operations, automation, and development tasks.

Your expertise includes:
- System monitoring and performance analysis
- Application management and troubleshooting
- Command-line operations and scripting
- File system operations
- Process management
- Technical problem-solving

Provide precise, technical answers when appropriate, but maintain a helpful conversational tone.""",

            "creative": """You are Safwaan Buddy, a creative AI assistant with expertise in content creation, brainstorming, and problem-solving.

Your creative capabilities include:
- Content generation and editing
- Brainstorming and idea generation
- Creative writing assistance
- Problem-solving with innovative approaches
- Design thinking and planning

Be imaginative and helpful, offering creative solutions and ideas when appropriate.""",

            "minimal": """Safwaan Buddy: Concise AI assistant.
- Short, direct responses
- Focus on practical solutions
- Minimal elaboration unless requested"""
        }

    def get_system_prompt(self, style: str = "default", context: ConversationContext = None) -> str:
        """Get system prompt with optional context."""
        base_prompt = self.system_prompts.get(style, self.system_prompts["default"])

        if context:
            # Add context-specific information
            context_additions = []

            if context.user_name:
                context_additions.append(f"User's name: {context.user_name}")

            if context.current_task:
                context_additions.append(f"Current task: {context.current_task}")

            if context.last_intent:
                context_additions.append(f"Last user intent: {context.last_intent}")

            if context.user_preferences:
                prefs_text = ", ".join([f"{k}: {v}" for k, v in context.user_preferences.items()])
                context_additions.append(f"User preferences: {prefs_text}")

            if context.system_status:
                status_text = ", ".join([f"{k}: {v}" for k, v in context.system_status.items()])
                context_additions.append(f"System status: {status_text}")

            if context_additions:
                context_section = "\n\nCurrent Context:\n" + "\n".join(f"- {addition}" for addition in context_additions)
                base_prompt += context_section

        return base_prompt

    def build_conversation_prompt(self, user_input: str, context: ConversationContext,
                                 style: str = "default", include_history: bool = True,
                                 max_history: int = 5) -> str:
        """Build complete prompt for AI conversation."""
        system_prompt = self.get_system_prompt(style, context)

        # Build conversation history
        conversation_text = ""

        if include_history and context.conversation_history:
            recent_history = context.conversation_history[-max_history:]
            for entry in recent_history:
                conversation_text += f"User: {entry.get('user', '')}\n"
                conversation_text += f"Assistant: {entry.get('assistant', '')}\n\n"

        # Add current user input
        conversation_text += f"User: {user_input}\nAssistant: "

        return f"{system_prompt}\n\nConversation History:\n{conversation_text}"

    def create_context(self, session_id: str, user_name: str = None) -> ConversationContext:
        """Create new conversation context."""
        context = ConversationContext(
            session_id=session_id,
            user_name=user_name,
            conversation_history=[],
            user_preferences={},
            current_task=None,
            last_intent=None,
            system_status={}
        )

        self.conversation_contexts[session_id] = context
        logger.debug(f"Created context for session: {session_id}")
        return context

    def get_context(self, session_id: str) -> Optional[ConversationContext]:
        """Get conversation context by session ID."""
        return self.conversation_contexts.get(session_id)

    def update_context(self, session_id: str, user_input: str = None,
                       assistant_response: str = None, intent: str = None,
                       task: str = None, system_status: Dict[str, Any] = None):
        """Update conversation context."""
        context = self.get_context(session_id)
        if not context:
            return

        if user_input and assistant_response:
            context.conversation_history.append({
                "user": user_input,
                "assistant": assistant_response,
                "timestamp": datetime.now().isoformat(),
                "intent": intent
            })

            # Keep history manageable
            if len(context.conversation_history) > 50:
                context.conversation_history = context.conversation_history[-50:]

        if intent:
            context.last_intent = intent

        if task:
            context.current_task = task

        if system_status:
            context.system_status.update(system_status)

    def add_user_preference(self, session_id: str, key: str, value: Any):
        """Add user preference to context."""
        context = self.get_context(session_id)
        if context:
            context.user_preferences[key] = value

    def get_user_preference(self, session_id: str, key: str, default: Any = None) -> Any:
        """Get user preference from context."""
        context = self.get_context(session_id)
        if context:
            return context.user_preferences.get(key, default)
        return default

    def clear_context(self, session_id: str):
        """Clear conversation context."""
        if session_id in self.conversation_contexts:
            del self.conversation_contexts[session_id]
            logger.debug(f"Cleared context for session: {session_id}")

    def cleanup_old_contexts(self, max_age_hours: int = 24):
        """Clean up old conversation contexts."""
        cutoff_time = datetime.now() - timedelta(hours=max_age_hours)
        sessions_to_remove = []

        for session_id, context in self.conversation_contexts.items():
            # Check last activity time from conversation history
            if context.conversation_history:
                last_entry = context.conversation_history[-1]
                last_time = datetime.fromisoformat(last_entry.get("timestamp", datetime.now().isoformat()))
                if last_time < cutoff_time:
                    sessions_to_remove.append(session_id)

        for session_id in sessions_to_remove:
            self.clear_context(session_id)
            logger.debug(f"Cleaned up old context: {session_id}")

    def get_context_summary(self, session_id: str) -> Dict[str, Any]:
        """Get summary of conversation context."""
        context = self.get_context(session_id)
        if not context:
            return {"error": "Context not found"}

        return {
            "session_id": context.session_id,
            "user_name": context.user_name,
            "conversation_count": len(context.conversation_history),
            "current_task": context.current_task,
            "last_intent": context.last_intent,
            "user_preferences": context.user_preferences,
            "system_status": context.system_status,
            "last_activity": (
                context.conversation_history[-1].get("timestamp") if context.conversation_history else None
            )
        }

    def export_context(self, session_id: str) -> Optional[str]:
        """Export conversation context to JSON."""
        context = self.get_context(session_id)
        if not context:
            return None

        try:
            export_data = {
                "session_id": context.session_id,
                "user_name": context.user_name,
                "conversation_history": context.conversation_history,
                "user_preferences": context.user_preferences,
                "current_task": context.current_task,
                "last_intent": context.last_intent,
                "system_status": context.system_status,
                "exported_at": datetime.now().isoformat()
            }

            return json.dumps(export_data, indent=2)
        except Exception as e:
            logger.error(f"Failed to export context for session {session_id}: {e}")
            return None

    def import_context(self, session_id: str, json_data: str) -> bool:
        """Import conversation context from JSON."""
        try:
            data = json.loads(json_data)

            context = ConversationContext(
                session_id=session_id,
                user_name=data.get("user_name"),
                conversation_history=data.get("conversation_history", []),
                user_preferences=data.get("user_preferences", {}),
                current_task=data.get("current_task"),
                last_intent=data.get("last_intent"),
                system_status=data.get("system_status", {})
            )

            self.conversation_contexts[session_id] = context
            logger.info(f"Imported context for session: {session_id}")
            return True

        except Exception as e:
            logger.error(f"Failed to import context for session {session_id}: {e}")
            return False

    def get_usage_statistics(self) -> Dict[str, Any]:
        """Get prompt manager usage statistics."""
        total_contexts = len(self.conversation_contexts)
        total_conversations = sum(
            len(ctx.conversation_history) for ctx in self.conversation_contexts.values()
        )

        return {
            "active_sessions": total_contexts,
            "total_conversations": total_conversations,
            "average_conversations_per_session": (
                total_conversations / total_contexts if total_contexts > 0 else 0
            ),
            "available_system_prompts": list(self.system_prompts.keys())
        }


# Global prompt manager instance
_prompt_manager = None


def get_prompt_manager() -> PromptManager:
    """Get the global prompt manager instance."""
    global _prompt_manager
    if _prompt_manager is None:
        _prompt_manager = PromptManager()
    return _prompt_manager


def build_ai_prompt(user_input: str, session_id: str, style: str = "default",
                   include_history: bool = True, max_history: int = 5) -> str:
    """Build AI prompt with context."""
    manager = get_prompt_manager()
    context = manager.get_context(session_id)

    if not context:
        context = manager.create_context(session_id)

    return manager.build_conversation_prompt(
        user_input, context, style, include_history, max_history
    )


def update_conversation(session_id: str, user_input: str, assistant_response: str,
                       intent: str = None, task: str = None):
    """Update conversation context."""
    manager = get_prompt_manager()
    manager.update_context(session_id, user_input, assistant_response, intent, task)