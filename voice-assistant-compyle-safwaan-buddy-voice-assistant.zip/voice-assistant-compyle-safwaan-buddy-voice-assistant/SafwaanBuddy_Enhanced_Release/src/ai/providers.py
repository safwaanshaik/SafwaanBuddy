#!/usr/bin/env python3
"""
AI Service Providers for Safwaan Buddy
Handles integration with OpenAI, local LLMs, and other AI services.
"""

import json
import requests
from typing import Dict, List, Any, Optional
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime

from config import get_config
from utils.logger import get_logger
from utils.helpers import retry_on_failure

logger = get_logger("ai_providers")


@dataclass
class AIResponse:
    """Response from AI service."""
    text: str
    provider: str
    model: str
    confidence: float = 0.0
    tokens_used: int = 0
    response_time: float = 0.0
    metadata: Dict[str, Any] = None


class BaseAIProvider(ABC):
    """Base class for AI service providers."""

    def __init__(self, name: str):
        self.name = name
        self.logger = get_logger(f"ai_{name.lower()}")

    @abstractmethod
    def is_available(self) -> bool:
        """Check if the provider is available and configured."""
        pass

    @abstractmethod
    def generate_response(self, prompt: str, context: str = None,
                         max_tokens: int = 300, temperature: float = 0.7) -> AIResponse:
        """Generate AI response."""
        pass

    @abstractmethod
    def get_models(self) -> List[str]:
        """Get list of available models."""
        pass


class OpenAIProvider(BaseAIProvider):
    """OpenAI GPT provider."""

    def __init__(self):
        super().__init__("OpenAI")
        self.config = get_config()
        self.api_key = self.config.get("openai_api_key")
        self.client = None

        if self.api_key:
            try:
                from openai import OpenAI
                self.client = OpenAI(api_key=self.api_key)
                self.logger.info("OpenAI client initialized")
            except ImportError:
                self.logger.warning("OpenAI library not installed")
            except Exception as e:
                self.logger.error(f"Failed to initialize OpenAI client: {e}")

    def is_available(self) -> bool:
        """Check if OpenAI is available."""
        return (self.client is not None and
                self.api_key and
                len(self.api_key) > 10)

    @retry_on_failure(max_retries=3, delay=1.0)
    def generate_response(self, prompt: str, context: str = None,
                         max_tokens: int = 300, temperature: float = 0.7) -> AIResponse:
        """Generate response using OpenAI GPT."""
        if not self.is_available():
            return AIResponse(
                text="OpenAI service is not available. Please configure API key.",
                provider="OpenAI",
                model="gpt-3.5-turbo",
                confidence=0.0
            )

        start_time = datetime.now()

        try:
            # Build conversation context
            messages = [
                {
                    "role": "system",
                    "content": "You are Safwaan Buddy, a helpful AI assistant. Keep responses concise and friendly."
                }
            ]

            if context:
                messages.append({
                    "role": "system",
                    "content": f"Context from previous conversations:\n{context}"
                })

            messages.append({
                "role": "user",
                "content": prompt
            })

            # Make API call
            response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=messages,
                max_tokens=max_tokens,
                temperature=temperature
            )

            response_time = (datetime.now() - start_time).total_seconds()

            if response.choices and response.choices[0].message:
                text = response.choices[0].message.content.strip()
                tokens_used = response.usage.total_tokens if response.usage else 0

                return AIResponse(
                    text=text,
                    provider="OpenAI",
                    model="gpt-3.5-turbo",
                    confidence=0.9,
                    tokens_used=tokens_used,
                    response_time=response_time,
                    metadata={
                        "finish_reason": response.choices[0].finish_reason,
                        "prompt_tokens": response.usage.prompt_tokens if response.usage else 0
                    }
                )
            else:
                return AIResponse(
                    text="No response generated",
                    provider="OpenAI",
                    model="gpt-3.5-turbo",
                    confidence=0.0,
                    response_time=response_time
                )

        except Exception as e:
            response_time = (datetime.now() - start_time).total_seconds()
            self.logger.error(f"OpenAI API error: {e}")
            return AIResponse(
                text=f"OpenAI service error: {str(e)}",
                provider="OpenAI",
                model="gpt-3.5-turbo",
                confidence=0.0,
                response_time=response_time
            )

    def get_models(self) -> List[str]:
        """Get available OpenAI models."""
        return ["gpt-3.5-turbo", "gpt-4", "gpt-4-turbo"]


class LocalLLMProvider(BaseAIProvider):
    """Local LLM provider for offline AI capabilities."""

    def __init__(self):
        super().__init__("LocalLLM")
        self.config = get_config()
        self.base_url = self.config.get("local_llm_url", "http://localhost:11434/api/generate")
        self.model = self.config.get("local_llm_model", "llama2")
        self.use_local_llm = self.config.get("use_local_llm", False)

    def is_available(self) -> bool:
        """Check if local LLM is available."""
        if not self.use_local_llm:
            return False

        try:
            response = requests.get(f"{self.base_url.replace('/api/generate', '/api/tags')}", timeout=5)
            return response.status_code == 200
        except:
            return False

    @retry_on_failure(max_retries=2, delay=1.0)
    def generate_response(self, prompt: str, context: str = None,
                         max_tokens: int = 300, temperature: float = 0.7) -> AIResponse:
        """Generate response using local LLM."""
        if not self.is_available():
            return AIResponse(
                text="Local LLM service is not available. Please check if the service is running.",
                provider="LocalLLM",
                model=self.model,
                confidence=0.0
            )

        start_time = datetime.now()

        try:
            # Build prompt with context
            full_prompt = f"You are Safwaan Buddy, a helpful AI assistant.\n\n"

            if context:
                full_prompt += f"Context:\n{context}\n\n"

            full_prompt += f"User: {prompt}\nAssistant: "

            # Prepare request payload
            payload = {
                "model": self.model,
                "prompt": full_prompt,
                "stream": False,
                "options": {
                    "temperature": temperature,
                    "num_predict": max_tokens,
                    "top_p": 0.9,
                    "top_k": 40
                }
            }

            # Make API call
            response = requests.post(
                self.base_url,
                json=payload,
                timeout=30
            )
            response.raise_for_status()

            response_time = (datetime.now() - start_time).total_seconds()

            # Parse response
            result = response.json()
            text = result.get("response", "").strip()

            if text:
                # Remove any prompt remnants
                if "Assistant:" in text:
                    text = text.split("Assistant:")[-1].strip()

                return AIResponse(
                    text=text,
                    provider="LocalLLM",
                    model=self.model,
                    confidence=0.8,
                    response_time=response_time,
                    metadata={
                        "total_duration": result.get("total_duration", 0),
                        "prompt_eval_count": result.get("prompt_eval_count", 0),
                        "eval_count": result.get("eval_count", 0)
                    }
                )
            else:
                return AIResponse(
                    text="No response generated",
                    provider="LocalLLM",
                    model=self.model,
                    confidence=0.0,
                    response_time=response_time
                )

        except Exception as e:
            response_time = (datetime.now() - start_time).total_seconds()
            self.logger.error(f"Local LLM error: {e}")
            return AIResponse(
                text=f"Local LLM service error: {str(e)}",
                provider="LocalLLM",
                model=self.model,
                confidence=0.0,
                response_time=response_time
            )

    def get_models(self) -> List[str]:
        """Get available local models."""
        if not self.is_available():
            return []

        try:
            response = requests.get(f"{self.base_url.replace('/api/generate', '/api/tags')}", timeout=5)
            if response.status_code == 200:
                data = response.json()
                return [model["name"] for model in data.get("models", [])]
        except:
            pass

        return [self.model]


class AIProviderManager:
    """Manages multiple AI providers and handles fallbacks."""

    def __init__(self):
        """Initialize AI provider manager."""
        self.config = get_config()
        self.providers = {}
        self.primary_provider = None

        # Initialize providers
        self._initialize_providers()

    def _initialize_providers(self):
        """Initialize available AI providers."""
        # Initialize OpenAI provider
        openai_provider = OpenAIProvider()
        if openai_provider.is_available():
            self.providers["openai"] = openai_provider
            if not self.primary_provider:
                self.primary_provider = "openai"
            self.logger.info("OpenAI provider initialized")

        # Initialize Local LLM provider
        local_provider = LocalLLMProvider()
        if local_provider.is_available():
            self.providers["local"] = local_provider
            if not self.primary_provider:
                self.primary_provider = "local"
            self.logger.info("Local LLM provider initialized")

        self.logger.info(f"Initialized {len(self.providers)} AI providers")

    def generate_response(self, prompt: str, context: str = None,
                         provider: str = None, max_tokens: int = 300,
                         temperature: float = 0.7) -> AIResponse:
        """Generate AI response with fallback support."""
        target_provider = provider or self.primary_provider

        if not self.providers:
            return AIResponse(
                text="No AI providers available. Please configure an AI service.",
                provider="None",
                model="N/A",
                confidence=0.0
            )

        # Try specified provider first
        if target_provider and target_provider in self.providers:
            response = self.providers[target_provider].generate_response(
                prompt, context, max_tokens, temperature
            )
            if response.confidence > 0:
                return response

        # Fallback to other providers
        for name, provider in self.providers.items():
            if name != target_provider:
                response = provider.generate_response(
                    prompt, context, max_tokens, temperature
                )
                if response.confidence > 0:
                    self.logger.info(f"Fallback to {name} provider successful")
                    return response

        return AIResponse(
            text="All AI providers are currently unavailable.",
            provider="None",
            model="N/A",
            confidence=0.0
        )

    def is_available(self) -> bool:
        """Check if any AI provider is available."""
        return len(self.providers) > 0

    def get_provider_status(self) -> Dict[str, Dict[str, Any]]:
        """Get status of all providers."""
        status = {}

        for name, provider in self.providers.items():
            status[name] = {
                "available": provider.is_available(),
                "models": provider.get_models()
            }

        return status

    def get_provider(self, name: str) -> Optional[BaseAIProvider]:
        """Get specific provider by name."""
        return self.providers.get(name)

    def add_provider(self, name: str, provider: BaseAIProvider):
        """Add a new provider."""
        self.providers[name] = provider
        if provider.is_available() and not self.primary_provider:
            self.primary_provider = name

    def set_primary_provider(self, name: str) -> bool:
        """Set primary provider."""
        if name in self.providers and self.providers[name].is_available():
            self.primary_provider = name
            self.logger.info(f"Primary provider set to: {name}")
            return True
        return False

    def get_recommendations(self) -> str:
        """Get recommendations for AI setup."""
        recommendations = []

        if not self.providers:
            recommendations.append("No AI providers are configured.")
            recommendations.append("• Set OPENAI_API_KEY in your .env file for OpenAI integration")
            recommendations.append("• Set up a local LLM service (Ollama) for offline capabilities")
        else:
            available_providers = list(self.providers.keys())
            recommendations.append(f"Available providers: {', '.join(available_providers)}")

            if len(self.providers) == 1:
                recommendations.append("Consider setting up additional providers for redundancy")

        return "\n".join(recommendations)


# Global AI provider manager instance
_ai_manager = None


def get_ai_manager() -> AIProviderManager:
    """Get the global AI provider manager instance."""
    global _ai_manager
    if _ai_manager is None:
        _ai_manager = AIProviderManager()
    return _ai_manager


def generate_ai_response(prompt: str, context: str = None,
                        provider: str = None, max_tokens: int = 300,
                        temperature: float = 0.7) -> AIResponse:
    """Generate AI response using the configured providers."""
    manager = get_ai_manager()
    return manager.generate_response(prompt, context, provider, max_tokens, temperature)


def is_ai_available() -> bool:
    """Check if any AI provider is available."""
    manager = get_ai_manager()
    return manager.is_available()