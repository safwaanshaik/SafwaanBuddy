#!/usr/bin/env python3
"""
Configuration Management for Safwaan Buddy
Handles loading and managing configuration from environment variables and config files.
"""

import os
import json
from typing import Dict, Any, Optional
from pathlib import Path
from cryptography.fernet import Fernet


class ConfigManager:
    """Centralized configuration management for Safwaan Buddy."""

    def __init__(self):
        self.config_dir = Path(os.getenv("BUDDY_CONFIG_DIR", "config"))
        self.data_dir = Path(os.getenv("BUDDY_DATA_DIR", "data"))
        self.plugins_dir = Path(os.getenv("BUDDY_PLUGINS_DIR", "src/plugins"))

        # Ensure directories exist
        self.config_dir.mkdir(exist_ok=True)
        self.data_dir.mkdir(exist_ok=True)

        self._config = {}
        self._load_configuration()

    def _load_configuration(self):
        """Load configuration from multiple sources in priority order."""
        # 1. Load default configuration
        self._config = self._get_default_config()

        # 2. Load from config/default.json if exists
        default_config_file = self.config_dir / "default.json"
        if default_config_file.exists():
            try:
                with open(default_config_file, 'r', encoding='utf-8') as f:
                    file_config = json.load(f)
                self._config.update(file_config)
            except Exception as e:
                print(f"Warning: Could not load default config: {e}")

        # 3. Load from config/user.json if exists (user overrides)
        user_config_file = self.config_dir / "user.json"
        if user_config_file.exists():
            try:
                with open(user_config_file, 'r', encoding='utf-8') as f:
                    user_config = json.load(f)
                self._config.update(user_config)
            except Exception as e:
                print(f"Warning: Could not load user config: {e}")

        # 4. Override with environment variables
        self._load_environment_overrides()

        # 5. Process and validate configuration
        self._process_configuration()

    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration values."""
        return {
            "agent_name": "Safwaan Buddy",
            "wake_words": ["buddy", "safwaan buddy"],
            "openai_api_key": "",
            "use_local_llm": False,
            "local_llm_url": "http://localhost:11434/api/generate",
            "local_llm_model": "llama2",
            "tts_provider": "pyttsx3",
            "voice_rate": 150,
            "voice_volume": 1.0,
            "memory_db": str(self.data_dir / "buddy_brain.db"),
            "encryption_key": self._generate_encryption_key(),
            "log_level": "INFO",
            "max_conversation_history": 50,
            "plugin_timeout": 30,
            "gui_theme": "dark",
            "window_width": 1000,
            "window_height": 800,
            "enable_wake_word_detection": True,
            "enable_voice_input": True,
            "enable_ui_automation": True,
            "enable_system_monitoring": True,
            "enable_plugin_system": True,
            "system_monitor_interval": 2.0,
            "voice_recognition_timeout": 5.0,
            "voice_phrase_time_limit": 10.0,
            "ai_max_tokens": 300,
            "ai_temperature": 0.7,

            # Enhanced AI Personality Features
            "enable_ai_personality": True,
            "enable_natural_speech": True,
            "enable_system_control": True,
            "enable_multilingual": True,
            "default_language": "english",
            "emotional_intelligence": True,
            "adaptive_learning": True,
            "creativity_engine": True,
            "reasoning_engine": True,
            "personality_formality": 0.3,
            "personality_enthusiasm": 0.7,
            "personality_empathy": 0.8,
            "conversation_context_limit": 20,
            "knowledge_base_path": str(self.data_dir / "knowledge_base.json"),

            # System Control Features
            "admin_privileges_required": False,
            "allow_file_operations": True,
            "allow_system_commands": True,
            "allow_network_operations": True,
            "allow_app_control": True,
            "system_command_timeout": 30,
            "file_operation_size_limit": 104857600,  # 100MB
            "network_operations_enabled": True,

            # Natural Speech Features
            "speech_enhancement": True,
            "emotional_response": True,
            "context_awareness": True,
            "natural_pauses": True,
            "voice_inflection": True,
            "multilingual_support": True,
            "supported_languages": [
                "english", "spanish", "french", "german", "chinese",
                "japanese", "arabic", "russian", "hindi", "portuguese",
                "italian", "korean", "dutch", "swedish", "polish", "turkish"
            ]
        }

    def _load_environment_overrides(self):
        """Load configuration from environment variables."""
        env_mappings = {
            "OPENAI_API_KEY": "openai_api_key",
            "BUDDY_KEY": "encryption_key",
            "LOCAL_LLM_URL": "local_llm_url",
            "LOCAL_LLM_MODEL": "local_llm_model",
            "BUDDY_LOG_LEVEL": "log_level",
            "BUDDY_DATA_DIR": "data_dir",
            "BUDDY_PLUGINS_DIR": "plugins_dir",
            "TTS_PROVIDER": "tts_provider",
            "VOICE_RATE": "voice_rate",
            "VOICE_VOLUME": "voice_volume",
            "WAKE_WORDS": "wake_words",
            "MEMORY_DB": "memory_db",
            "MAX_CONVERSATION_HISTORY": "max_conversation_history",
            "PLUGIN_TIMEOUT": "plugin_timeout",
            "GUI_THEME": "gui_theme",
            "WINDOW_WIDTH": "window_width",
            "WINDOW_HEIGHT": "window_height",
            "ENABLE_WAKE_WORD_DETECTION": "enable_wake_word_detection",
            "ENABLE_VOICE_INPUT": "enable_voice_input",
            "ENABLE_UI_AUTOMATION": "enable_ui_automation",
            "ENABLE_SYSTEM_MONITORING": "enable_system_monitoring",
            "ENABLE_PLUGIN_SYSTEM": "enable_plugin_system",
            "SYSTEM_MONITOR_INTERVAL": "system_monitor_interval",
            "VOICE_RECOGNITION_TIMEOUT": "voice_recognition_timeout",
            "VOICE_PHRASE_TIME_LIMIT": "voice_phrase_time_limit",
            "AI_MAX_TOKENS": "ai_max_tokens",
            "AI_TEMPERATURE": "ai_temperature",
        }

        for env_var, config_key in env_mappings.items():
            env_value = os.getenv(env_var)
            if env_value is not None:
                # Type conversion based on the key
                if config_key in ["enable_wake_word_detection", "enable_voice_input",
                                 "enable_ui_automation", "enable_system_monitoring",
                                 "enable_plugin_system", "use_local_llm"]:
                    self._config[config_key] = env_value.lower() in ("true", "1", "yes", "on")
                elif config_key in ["voice_rate", "voice_volume", "max_conversation_history",
                                   "plugin_timeout", "window_width", "window_height",
                                   "system_monitor_interval", "voice_recognition_timeout",
                                   "voice_phrase_time_limit", "ai_max_tokens", "ai_temperature"]:
                    try:
                        self._config[config_key] = float(env_value)
                        if config_key in ["max_conversation_history", "plugin_timeout",
                                         "window_width", "window_height", "ai_max_tokens"]:
                            self._config[config_key] = int(self._config[config_key])
                    except ValueError:
                        print(f"Warning: Invalid numeric value for {config_key}: {env_value}")
                elif config_key == "wake_words":
                    self._config[config_key] = [w.strip() for w in env_value.split(",")]
                elif config_key in ["data_dir", "plugins_dir", "memory_db"]:
                    self._config[config_key] = env_value
                else:
                    self._config[config_key] = env_value

    def _process_configuration(self):
        """Process and validate configuration values."""
        # Generate encryption key if not provided
        if not self._config["encryption_key"]:
            self._config["encryption_key"] = self._generate_encryption_key()

        # Validate paths
        self._config["memory_db"] = str(Path(self._config["memory_db"]).resolve())
        self.data_dir = Path(self._config.get("data_dir", "data")).resolve()
        self.plugins_dir = Path(self._config.get("plugins_dir", "src/plugins")).resolve()

        # Ensure directories exist
        self.data_dir.mkdir(exist_ok=True)
        self.plugins_dir.mkdir(exist_ok=True)

        # Validate numeric ranges
        self._config["voice_rate"] = max(50, min(400, int(self._config["voice_rate"])))
        self._config["voice_volume"] = max(0.0, min(1.0, float(self._config["voice_volume"])))
        self._config["window_width"] = max(800, min(1920, int(self._config["window_width"])))
        self._config["window_height"] = max(600, min(1080, int(self._config["window_height"])))
        self._config["system_monitor_interval"] = max(0.5, float(self._config["system_monitor_interval"]))

        # Validate wake words
        if not self._config["wake_words"]:
            self._config["wake_words"] = ["buddy"]

        # Validate TTS provider
        valid_tts_providers = ["pyttsx3", "edge-tts"]
        if self._config["tts_provider"] not in valid_tts_providers:
            self._config["tts_provider"] = "pyttsx3"
            print(f"Warning: Invalid TTS provider, using pyttsx3")

    def _generate_encryption_key(self) -> str:
        """Generate a new encryption key."""
        return Fernet.generate_key().decode()

    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value by key."""
        return self._config.get(key, default)

    def set(self, key: str, value: Any):
        """Set configuration value."""
        self._config[key] = value

    def get_all(self) -> Dict[str, Any]:
        """Get all configuration values."""
        return self._config.copy()

    def save_user_config(self, config_data: Dict[str, Any]):
        """Save user configuration to file."""
        user_config_file = self.config_dir / "user.json"
        try:
            with open(user_config_file, 'w', encoding='utf-8') as f:
                json.dump(config_data, f, indent=2, ensure_ascii=False)
            # Reload configuration
            self._load_configuration()
            return True
        except Exception as e:
            print(f"Error saving user config: {e}")
            return False

    def create_default_configs(self):
        """Create default configuration files."""
        # Create default.json with base configuration
        default_config = {
            "agent_name": "Safwaan Buddy",
            "wake_words": ["buddy", "safwaan buddy"],
            "tts_provider": "pyttsx3",
            "voice_rate": 150,
            "voice_volume": 1.0,
            "log_level": "INFO",
            "gui_theme": "dark",
            "window_width": 1000,
            "window_height": 800,
            "enable_wake_word_detection": True,
            "enable_voice_input": True,
            "enable_ui_automation": True,
            "enable_system_monitoring": True,
            "enable_plugin_system": True,
        }

        default_config_file = self.config_dir / "default.json"
        try:
            with open(default_config_file, 'w', encoding='utf-8') as f:
                json.dump(default_config, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error creating default config: {e}")

        # Create plugins configuration
        plugins_config = {
            "enabled_plugins": [
                "system_stats",
                "get_time",
                "open_app",
                "save_note",
                "recall_note",
                "list_notes",
                "type_text",
                "clipboard"
            ],
            "plugin_settings": {
                "system_stats": {"refresh_interval": 5},
                "get_time": {"format": "%Y-%m-%d %H:%M:%S"},
                "open_app": {"timeout": 10},
                "notes": {"auto_save": True}
            }
        }

        plugins_config_file = self.config_dir / "plugins.json"
        try:
            with open(plugins_config_file, 'w', encoding='utf-8') as f:
                json.dump(plugins_config, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error creating plugins config: {e}")

    def validate_ai_config(self) -> Dict[str, Any]:
        """Validate AI configuration and return status."""
        status = {
            "openai_configured": bool(self.get("openai_api_key")),
            "local_llm_configured": self.get("use_local_llm") and bool(self.get("local_llm_url")),
            "any_ai_available": False,
            "recommended_provider": None
        }

        if status["openai_configured"]:
            status["any_ai_available"] = True
            status["recommended_provider"] = "openai"
        elif status["local_llm_configured"]:
            status["any_ai_available"] = True
            status["recommended_provider"] = "local"

        return status

    def get_theme_config(self) -> Dict[str, Any]:
        """Get theme-specific configuration."""
        theme_name = self.get("gui_theme", "dark")
        theme_file = self.config_dir / "themes" / f"{theme_name}.json"

        if theme_file.exists():
            try:
                with open(theme_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"Warning: Could not load theme {theme_name}: {e}")

        # Return default dark theme
        return {
            "name": "dark",
            "background_color": "#0a0e27",
            "primary_color": "#00d9ff",
            "secondary_color": "#00ff88",
            "accent_color": "#0f3460",
            "text_color": "#ffffff",
            "border_color": "#1a5f7f",
            "error_color": "#ff4444",
            "warning_color": "#ffaa00",
            "success_color": "#00ff88"
        }


# Global configuration instance
CONFIG = ConfigManager()

# Export the configuration for easy access
def get_config() -> ConfigManager:
    """Get the global configuration instance."""
    return CONFIG