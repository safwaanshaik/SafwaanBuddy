"""
Core modules for Safwaan Buddy
"""

from .memory import MemoryManager
from .voice_processor import (
    VoiceProcessor, WakeWordListener, SpeechRecognitionEngine,
    AdvancedTTSEngine, VoiceEvent
)
from .ui_automation import UIAutomation, SafetyLevel, AutomationResult, AutomationError
from .command_parser import (
    AICommandParser, IntentType, ParsedIntent, CommandPattern
)
from .plugin_manager import (
    PluginManager, BasePlugin, PluginInfo, PluginResult
)

__all__ = [
    # Memory management
    "MemoryManager",

    # Voice processing
    "VoiceProcessor",
    "WakeWordListener",
    "SpeechRecognitionEngine",
    "AdvancedTTSEngine",
    "VoiceEvent",

    # UI automation
    "UIAutomation",
    "SafetyLevel",
    "AutomationResult",
    "AutomationError",

    # Command parsing
    "AICommandParser",
    "IntentType",
    "ParsedIntent",
    "CommandPattern",

    # Plugin system
    "PluginManager",
    "BasePlugin",
    "PluginInfo",
    "PluginResult"
]