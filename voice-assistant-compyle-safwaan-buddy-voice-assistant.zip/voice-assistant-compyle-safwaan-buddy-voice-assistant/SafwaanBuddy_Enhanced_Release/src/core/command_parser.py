#!/usr/bin/env python3
"""
Command Parsing and Intent Recognition for Safwaan Buddy
Handles parsing user input into structured commands with confidence scoring.
"""

import re
import json
from typing import Dict, List, Any, Optional, Tuple, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime

from config import get_config
from utils.logger import get_logger
from utils.helpers import extract_numbers, parse_time_string

logger = get_logger("command_parser")


class IntentType(Enum):
    """Enumeration of supported intent types."""
    SYSTEM_STATUS = "system_status"
    TIME = "time"
    OPEN_APP = "open_app"
    CLOSE_APP = "close_app"
    SAVE_NOTE = "save_note"
    RECALL_NOTE = "recall_note"
    LIST_NOTES = "list_notes"
    DELETE_NOTE = "delete_note"
    TYPE_TEXT = "type"
    CLICK = "click"
    CLIPBOARD = "clipboard"
    SCREENSHOT = "screenshot"
    SEARCH_WEB = "search_web"
    WEATHER = "weather"
    CALCULATOR = "calculator"
    REMINDER = "reminder"
    GENERAL_QUERY = "general_query"
    UNKNOWN = "unknown"


@dataclass
class ParsedIntent:
    """Data class representing a parsed intent."""
    intent: IntentType
    confidence: float
    parameters: Dict[str, Any] = field(default_factory=dict)
    original_text: str = ""
    extracted_entities: Dict[str, List[str]] = field(default_factory=dict)
    alternatives: List[IntentType] = field(default_factory=list)
    requires_confirmation: bool = False
    execution_context: Dict[str, Any] = field(default_factory=dict)


class CommandPattern:
    """Represents a command pattern with regex and parameter extraction."""

    def __init__(self, pattern: str, intent: IntentType, parameters: Dict[str, str] = None,
                 confidence_modifier: float = 0.0):
        """
        Initialize command pattern.

        Args:
            pattern: Regex pattern to match
            intent: Intent type this pattern represents
            parameters: Parameter extraction configuration
            confidence_modifier: Confidence score modifier
        """
        self.pattern = re.compile(pattern, re.IGNORECASE | re.DOTALL)
        self.intent = intent
        self.parameters = parameters or {}
        self.confidence_modifier = confidence_modifier

    def match(self, text: str) -> Optional[Tuple[re.Match, Dict[str, Any]]]:
        """Match text against pattern and extract parameters."""
        match = self.pattern.search(text)
        if match:
            # Extract parameters based on pattern configuration
            extracted_params = {}
            for param_name, param_config in self.parameters.items():
                if isinstance(param_config, str):
                    # Simple group reference
                    extracted_params[param_name] = match.group(param_config).strip() if match.group(param_config) else None
                elif isinstance(param_config, dict):
                    # Complex parameter extraction
                    group_name = param_config.get("group")
                    default_value = param_config.get("default")
                    transform = param_config.get("transform")

                    value = match.group(group_name) if group_name else match.group(0)
                    if value:
                        value = value.strip()

                        # Apply transformation if specified
                        if transform:
                            if transform == "lower":
                                value = value.lower()
                            elif transform == "upper":
                                value = value.upper()
                            elif transform == "title":
                                value = value.title()
                            elif transform == "numbers":
                                value = extract_numbers(value)
                            elif transform == "time":
                                value = parse_time_string(value)
                        extracted_params[param_name] = value
                    elif default_value is not None:
                        extracted_params[param_name] = default_value

            return match, extracted_params

        return None


class AICommandParser:
    """Advanced command parser with intent recognition and confidence scoring."""

    def __init__(self):
        """Initialize the command parser."""
        self.config = get_config()
        self.callbacks: Dict[IntentType, List[Callable]] = {}
        self.confidence_threshold = 0.3

        # Initialize command patterns
        self.patterns = self._init_patterns()

        # Statistics
        self.parse_count = 0
        self.intent_counts: Dict[IntentType, int] = {intent: 0 for intent in IntentType}

        logger.info("AICommandParser initialized")

    def _init_patterns(self) -> List[CommandPattern]:
        """Initialize command patterns for intent recognition."""
        patterns = []

        # System status patterns
        patterns.extend([
            CommandPattern(
                r"(?:system|status|stats|resource).*(?:info|status|check)",
                IntentType.SYSTEM_STATUS,
                confidence_modifier=0.2
            ),
            CommandPattern(
                r"(?:cpu|memory|ram|disk).*(?:usage|percent|how much)",
                IntentType.SYSTEM_STATUS,
                confidence_modifier=0.3
            ),
            CommandPattern(
                r"(?:what's|how).*(?:my).*(?:system|computer).*(?:status|doing)",
                IntentType.SYSTEM_STATUS,
                confidence_modifier=0.2
            ),
        ])

        # Time patterns
        patterns.extend([
            CommandPattern(
                r"(?:what|what's).*(?:the)?\s*time",
                IntentType.TIME,
                confidence_modifier=0.4
            ),
            CommandPattern(
                r"(?:tell me|what).*(?:the)?\s*(?:current|date|time)",
                IntentType.TIME,
                confidence_modifier=0.3
            ),
            CommandPattern(
                r"(?:check|show).*(?:time|date)",
                IntentType.TIME,
                confidence_modifier=0.2
            ),
        ])

        # Application patterns
        patterns.extend([
            CommandPattern(
                r"(?:open|launch|start|run).+?(?:app|application)?\s*([a-zA-Z0-9\s\.\-_]+)",
                IntentType.OPEN_APP,
                parameters={"app_name": {"group": 1, "transform": "strip"}},
                confidence_modifier=0.3
            ),
            CommandPattern(
                r"(?:start|run).+?([a-zA-Z0-9\s\.\-_]+)",
                IntentType.OPEN_APP,
                parameters={"app_name": {"group": 1, "transform": "strip"}},
                confidence_modifier=0.2
            ),
            CommandPattern(
                r"(?:close|exit|quit).+?(?:app|application)?\s*([a-zA-Z0-9\s\.\-_]+)",
                IntentType.CLOSE_APP,
                parameters={"app_name": {"group": 1, "transform": "strip"}},
                confidence_modifier=0.3
            ),
        ])

        # Note patterns
        patterns.extend([
            CommandPattern(
                r"(?:save|create|make).+(?:note|memo).+?([a-zA-Z0-9\s]+)[:]\s*(.+)",
                IntentType.SAVE_NOTE,
                parameters={
                    "title": {"group": 1, "transform": "strip"},
                    "content": {"group": 2, "transform": "strip"}
                },
                confidence_modifier=0.4
            ),
            CommandPattern(
                r"(?:remember|note).+?([a-zA-Z0-9\s]+)[:]\s*(.+)",
                IntentType.SAVE_NOTE,
                parameters={
                    "title": {"group": 1, "transform": "strip"},
                    "content": {"group": 2, "transform": "strip"}
                },
                confidence_modifier=0.3
            ),
            CommandPattern(
                r"(?:recall|get|find|show).+(?:note|memo).+?([a-zA-Z0-9\s]+)",
                IntentType.RECALL_NOTE,
                parameters={"title": {"group": 1, "transform": "strip"}},
                confidence_modifier=0.3
            ),
            CommandPattern(
                r"(?:list|show).+(?:all\s*)?(?:notes|memos)",
                IntentType.LIST_NOTES,
                confidence_modifier=0.4
            ),
            CommandPattern(
                r"(?:delete|remove).+(?:note|memo).+?([a-zA-Z0-9\s]+)",
                IntentType.DELETE_NOTE,
                parameters={"title": {"group": 1, "transform": "strip"}},
                confidence_modifier=0.3
            ),
        ])

        # UI Automation patterns
        patterns.extend([
            CommandPattern(
                r"(?:type|write|enter).+?([a-zA-Z0-9\s\.\!\?\,\;]+)",
                IntentType.TYPE_TEXT,
                parameters={"text": {"group": 1, "transform": "strip"}},
                confidence_modifier=0.3
            ),
            CommandPattern(
                r"(?:click|press).+(?:at|coordinates?)\s*(\d+)[\s,]*(\d+)",
                IntentType.CLICK,
                parameters={
                    "x": {"group": 1, "transform": "numbers"},
                    "y": {"group": 2, "transform": "numbers"}
                },
                confidence_modifier=0.4
            ),
            CommandPattern(
                r"(?:double\s*click|double-click).+(?:at|coordinates?)\s*(\d+)[\s,]*(\d+)",
                IntentType.CLICK,
                parameters={
                    "x": {"group": 1, "transform": "numbers"},
                    "y": {"group": 2, "transform": "numbers"},
                    "double_click": {"default": True}
                },
                confidence_modifier=0.4
            ),
        ])

        # Clipboard patterns
        patterns.extend([
            CommandPattern(
                r"(?:get|read|show).+(?:clipboard)",
                IntentType.CLIPBOARD,
                parameters={"action": {"default": "read"}},
                confidence_modifier=0.3
            ),
            CommandPattern(
                r"(?:copy|set).+(?:clipboard).+?([a-zA-Z0-9\s\.\!\?\,\;]+)",
                IntentType.CLIPBOARD,
                parameters={
                    "action": {"default": "write"},
                    "text": {"group": 1, "transform": "strip"}
                },
                confidence_modifier=0.3
            ),
        ])

        # Screenshot patterns
        patterns.extend([
            CommandPattern(
                r"(?:take|capture|save).+(?:screenshot|screen\s*shot|screen)",
                IntentType.SCREENSHOT,
                confidence_modifier=0.4
            ),
            CommandPattern(
                r"(?:screenshot|screen\s*shot).+(?:of|at)\s*(\d+)[\s,]*(\d+)",
                IntentType.SCREENSHOT,
                parameters={
                    "x": {"group": 1, "transform": "numbers"},
                    "y": {"group": 2, "transform": "numbers"},
                    "region": {"default": True}
                },
                confidence_modifier=0.3
            ),
        ])

        # Web search patterns
        patterns.extend([
            CommandPattern(
                r"(?:search|google|look\s*up).+(?:for)?\s*(.+)",
                IntentType.SEARCH_WEB,
                parameters={"query": {"group": 1, "transform": "strip"}},
                confidence_modifier=0.3
            ),
            CommandPattern(
                r"(?:what|who|where|when|why|how).+(?:is|are|was|were)\s*(.+)",
                IntentType.SEARCH_WEB,
                parameters={"query": {"group": 1, "transform": "strip"}},
                confidence_modifier=0.2
            ),
        ])

        # Calculator patterns
        patterns.extend([
            CommandPattern(
                r"(?:calculate|compute|what\s*is).+?([\d\+\-\*\/\(\)\s\.]+)",
                IntentType.CALCULATOR,
                parameters={"expression": {"group": 1, "transform": "strip"}},
                confidence_modifier=0.4
            ),
            CommandPattern(
                r"^([\d\+\-\*\/\(\)\s\.]+)(?:\s*=|\?|equals)",
                IntentType.CALCULATOR,
                parameters={"expression": {"group": 1, "transform": "strip"}},
                confidence_modifier=0.3
            ),
        ])

        # Reminder patterns
        patterns.extend([
            CommandPattern(
                r"(?:remind|reminder).+?(?:me|to).+?([a-zA-Z0-9\s]+).+?(?:in|at)\s*(.+)",
                IntentType.REMINDER,
                parameters={
                    "title": {"group": 1, "transform": "strip"},
                    "time": {"group": 2, "transform": "strip"}
                },
                confidence_modifier=0.4
            ),
            CommandPattern(
                r"(?:set|create).+(?:reminder|alarm).+?([a-zA-Z0-9\s]+)",
                IntentType.REMINDER,
                parameters={"title": {"group": 1, "transform": "strip"}},
                confidence_modifier=0.3
            ),
        ])

        return patterns

    def parse_intent(self, user_input: str, context: Dict[str, Any] = None) -> ParsedIntent:
        """
        Parse user input and determine intent.

        Args:
            user_input: User input text
            context: Optional context information

        Returns:
            ParsedIntent object with intent and extracted parameters
        """
        if not user_input or not user_input.strip():
            return ParsedIntent(
                intent=IntentType.UNKNOWN,
                confidence=0.0,
                original_text=user_input
            )

        self.parse_count += 1
        user_input = user_input.strip()

        # Try to match against patterns
        matches = []

        for pattern in self.patterns:
            result = pattern.match(user_input)
            if result:
                match, params = result
                confidence = self._calculate_confidence(match, pattern, user_input)
                matches.append((pattern, confidence, params))

        # Sort by confidence
        matches.sort(key=lambda x: x[1], reverse=True)

        if matches and matches[0][1] >= self.confidence_threshold:
            best_pattern, confidence, params = matches[0]
            intent = best_pattern.intent

            # Extract alternatives
            alternatives = [m[0].intent for m in matches[1:3] if m[1] >= self.confidence_threshold]

            # Determine if confirmation is required
            requires_confirmation = confidence < 0.7 or intent == IntentType.DELETE_NOTE

            parsed_intent = ParsedIntent(
                intent=intent,
                confidence=confidence,
                parameters=params,
                original_text=user_input,
                alternatives=alternatives,
                requires_confirmation=requires_confirmation,
                execution_context=context or {}
            )

            # Extract entities
            parsed_intent.extracted_entities = self._extract_entities(user_input)

            # Update statistics
            self.intent_counts[intent] += 1

            logger.debug(f"Parsed intent: {intent.value} (confidence: {confidence:.2f})")
            return parsed_intent

        # No confident matches found
        logger.debug(f"No confident intent found for: {user_input[:50]}...")
        return ParsedIntent(
            intent=IntentType.GENERAL_QUERY,
            confidence=0.1,
            original_text=user_input,
            extracted_entities=self._extract_entities(user_input)
        )

    def _calculate_confidence(self, match: re.Match, pattern: CommandPattern,
                            original_text: str) -> float:
        """Calculate confidence score for a pattern match."""
        base_confidence = 0.5

        # Adjust based on match length vs pattern length
        match_length = len(match.group(0))
        text_length = len(original_text)
        length_ratio = match_length / text_length if text_length > 0 else 0

        # Higher confidence for longer matches (more specific)
        if length_ratio > 0.8:
            base_confidence += 0.3
        elif length_ratio > 0.6:
            base_confidence += 0.2
        elif length_ratio > 0.4:
            base_confidence += 0.1

        # Add pattern-specific modifier
        base_confidence += pattern.confidence_modifier

        # Boost confidence for complete matches
        if match.start() == 0 and match.end() == len(original_text):
            base_confidence += 0.2

        # Ensure confidence is within bounds
        return max(0.0, min(1.0, base_confidence))

    def _extract_entities(self, text: str) -> Dict[str, List[str]]:
        """Extract entities from text (numbers, times, etc.)."""
        entities = {}

        # Extract numbers
        numbers = extract_numbers(text)
        if numbers:
            entities["numbers"] = numbers

        # Extract potential time expressions
        time_words = ["today", "tomorrow", "yesterday", "now", "later", "soon",
                     "morning", "afternoon", "evening", "night"]
        found_times = [word for word in time_words if word.lower() in text.lower()]
        if found_times:
            entities["time_expressions"] = found_times

        # Extract application names (simple heuristic)
        common_apps = ["notepad", "chrome", "firefox", "excel", "word", "powerpoint",
                      "calculator", "paint", "explorer", "terminal", "cmd", "photoshop"]
        found_apps = [app for app in common_apps if app.lower() in text.lower()]
        if found_apps:
            entities["applications"] = found_apps

        # Extract file extensions
        file_extensions = re.findall(r'\.([a-zA-Z0-9]{2,5})\b', text)
        if file_extensions:
            entities["file_extensions"] = file_extensions

        return entities

    def register_callback(self, intent: IntentType, callback: Callable):
        """Register callback for specific intent."""
        if intent not in self.callbacks:
            self.callbacks[intent] = []
        self.callbacks[intent].append(callback)
        logger.debug(f"Registered callback for intent: {intent.value}")

    def unregister_callback(self, intent: IntentType, callback: Callable):
        """Unregister callback for specific intent."""
        if intent in self.callbacks and callback in self.callbacks[intent]:
            self.callbacks[intent].remove(callback)
            logger.debug(f"Unregistered callback for intent: {intent.value}")

    def execute_intent(self, parsed_intent: ParsedIntent) -> Any:
        """Execute callbacks for the parsed intent."""
        intent = parsed_intent.intent
        if intent in self.callbacks:
            results = []
            for callback in self.callbacks[intent]:
                try:
                    result = callback(parsed_intent)
                    results.append(result)
                except Exception as e:
                    logger.error(f"Error executing intent callback for {intent.value}: {e}")
            return results
        return None

    def get_suggestions(self, partial_text: str, limit: int = 5) -> List[str]:
        """Get command suggestions based on partial input."""
        suggestions = []

        # Suggest based on pattern prefixes
        for pattern in self.patterns:
            pattern_str = pattern.pattern.pattern
            # Extract key phrases from patterns
            key_phrases = re.findall(r'\b\w+\b', pattern_str)[:3]
            if key_phrases:
                suggestion = " ".join(key_phrases)
                if suggestion.lower().startswith(partial_text.lower()):
                    suggestions.append(suggestion)

        # Add general suggestions
        general_suggestions = [
            "What time is it?",
            "Open notepad",
            "Save note meeting: Discuss project",
            "Type Hello World",
            "Take screenshot"
        ]

        for suggestion in general_suggestions:
            if suggestion.lower().startswith(partial_text.lower()):
                suggestions.append(suggestion)

        return suggestions[:limit]

    def get_intent_statistics(self) -> Dict[str, Any]:
        """Get parsing statistics."""
        total_intents = sum(self.intent_counts.values())

        return {
            "total_parses": self.parse_count,
            "intent_distribution": {
                intent.value: count for intent, count in self.intent_counts.items()
            },
            "most_common_intent": max(self.intent_counts.items(), key=lambda x: x[1])[0].value if total_intents > 0 else None,
            "confidence_threshold": self.confidence_threshold,
            "pattern_count": len(self.patterns)
        }

    def add_custom_pattern(self, pattern: str, intent: IntentType,
                          parameters: Dict[str, str] = None,
                          confidence_modifier: float = 0.0):
        """Add a custom command pattern."""
        command_pattern = CommandPattern(pattern, intent, parameters, confidence_modifier)
        self.patterns.append(command_pattern)
        logger.info(f"Added custom pattern for {intent.value}")

    def set_confidence_threshold(self, threshold: float):
        """Set minimum confidence threshold."""
        self.confidence_threshold = max(0.0, min(1.0, threshold))
        logger.info(f"Confidence threshold set to {self.confidence_threshold}")

    def get_supported_intents(self) -> List[Dict[str, Any]]:
        """Get list of supported intents with examples."""
        intents = []

        for intent in IntentType:
            if intent == IntentType.UNKNOWN:
                continue

            # Get examples for this intent
            examples = []
            for pattern in self.patterns:
                if pattern.intent == intent:
                    # Generate example from pattern
                    examples.append(f"Example: {pattern.pattern.pattern[:50]}...")

            intents.append({
                "intent": intent.value,
                "description": intent.value.replace("_", " ").title(),
                "examples": examples[:3]  # Limit to 3 examples
            })

        return intents