#!/usr/bin/env python3
"""
Memory Management and Encrypted Storage for Safwaan Buddy
Handles encrypted SQLite database storage for conversations, facts, preferences, and tasks.
"""

import sqlite3
import threading
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from contextlib import contextmanager
from cryptography.fernet import Fernet, InvalidToken

from config import get_config
from utils.logger import get_logger
from utils.helpers import safe_file_operation, read_file_safe, write_file_safe, create_backup

logger = get_logger("memory")


class MemoryManager:
    """Encrypted memory management system for Safwaan Buddy."""

    def __init__(self, db_path: Optional[str] = None):
        """
        Initialize MemoryManager with database path and encryption.

        Args:
            db_path: Path to SQLite database file (optional, uses config default)
        """
        self.config = get_config()
        self.db_path = Path(db_path or self.config.get("memory_db", "data/buddy_brain.db"))

        # Ensure database directory exists
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        # Initialize encryption
        self._init_encryption()

        # Thread safety
        self._lock = threading.RLock()

        # Initialize database
        self.init_db()

        logger.info(f"MemoryManager initialized with database: {self.db_path}")

    def _init_encryption(self):
        """Initialize encryption cipher suite."""
        try:
            encryption_key = self.config.get("encryption_key")
            if not encryption_key:
                raise ValueError("No encryption key configured")

            # Ensure key is properly encoded
            if isinstance(encryption_key, str):
                key_bytes = encryption_key.encode()
            else:
                key_bytes = encryption_key

            self.cipher_suite = Fernet(key_bytes)
            logger.debug("Encryption initialized successfully")

        except Exception as e:
            logger.error(f"Failed to initialize encryption: {e}")
            raise

    def init_db(self):
        """Initialize database tables if they don't exist."""
        with self._lock:
            try:
                with sqlite3.connect(self.db_path) as conn:
                    cursor = conn.cursor()

                    # Facts table - for learned information
                    cursor.execute('''
                        CREATE TABLE IF NOT EXISTS facts (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            key TEXT UNIQUE NOT NULL,
                            value TEXT NOT NULL,
                            category TEXT DEFAULT 'general',
                            tags TEXT,
                            confidence REAL DEFAULT 1.0,
                            created_at TEXT NOT NULL,
                            updated_at TEXT NOT NULL,
                            access_count INTEGER DEFAULT 0,
                            last_accessed TEXT
                        )
                    ''')

                    # Conversations table - for chat history
                    cursor.execute('''
                        CREATE TABLE IF NOT EXISTS conversations (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            session_id TEXT,
                            user_input TEXT NOT NULL,
                            agent_response TEXT NOT NULL,
                            intent TEXT,
                            confidence REAL,
                            context TEXT,
                            emotion TEXT,
                            created_at TEXT NOT NULL,
                            duration_ms INTEGER,
                            user_rating INTEGER
                        )
                    ''')

                    # Preferences table - for user settings
                    cursor.execute('''
                        CREATE TABLE IF NOT EXISTS preferences (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            key TEXT UNIQUE NOT NULL,
                            value TEXT NOT NULL,
                            category TEXT DEFAULT 'general',
                            created_at TEXT NOT NULL,
                            updated_at TEXT NOT NULL
                        )
                    ''')

                    # Tasks table - for task execution history
                    cursor.execute('''
                        CREATE TABLE IF NOT EXISTS tasks (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            task_name TEXT NOT NULL,
                            task_type TEXT,
                            status TEXT NOT NULL,
                            result TEXT,
                            error_message TEXT,
                            parameters TEXT,
                            started_at TEXT,
                            completed_at TEXT,
                            duration_ms INTEGER,
                            user_input TEXT
                        )
                    ''')

                    # Files table - for file monitoring and operations
                    cursor.execute('''
                        CREATE TABLE IF NOT EXISTS files (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            file_path TEXT UNIQUE NOT NULL,
                            file_hash TEXT,
                            last_modified TEXT,
                            file_size INTEGER,
                            file_type TEXT,
                            tags TEXT,
                            notes TEXT,
                            created_at TEXT NOT NULL,
                            last_accessed TEXT
                        )
                    ''')

                    # Reminders table - for scheduled reminders
                    cursor.execute('''
                        CREATE TABLE IF NOT EXISTS reminders (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            title TEXT NOT NULL,
                            description TEXT,
                            reminder_time TEXT NOT NULL,
                            status TEXT DEFAULT 'pending',
                            priority INTEGER DEFAULT 1,
                            created_at TEXT NOT NULL,
                            completed_at TEXT,
                            recurring_pattern TEXT
                        )
                    ''')

                    # Analytics table - for usage statistics
                    cursor.execute('''
                        CREATE TABLE IF NOT EXISTS analytics (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            event_type TEXT NOT NULL,
                            event_data TEXT,
                            session_id TEXT,
                            created_at TEXT NOT NULL
                        )
                    ''')

                    # Create indexes for better performance
                    indexes = [
                        "CREATE INDEX IF NOT EXISTS idx_facts_key ON facts(key)",
                        "CREATE INDEX IF NOT EXISTS idx_facts_category ON facts(category)",
                        "CREATE INDEX IF NOT EXISTS idx_facts_created ON facts(created_at)",
                        "CREATE INDEX IF NOT EXISTS idx_conversations_session ON conversations(session_id)",
                        "CREATE INDEX IF NOT EXISTS idx_conversations_created ON conversations(created_at)",
                        "CREATE INDEX IF NOT EXISTS idx_conversations_intent ON conversations(intent)",
                        "CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status)",
                        "CREATE INDEX IF NOT EXISTS idx_tasks_created ON tasks(started_at)",
                        "CREATE INDEX IF NOT EXISTS idx_files_path ON files(file_path)",
                        "CREATE INDEX IF NOT EXISTS idx_reminders_time ON reminders(reminder_time)",
                        "CREATE INDEX IF NOT EXISTS idx_analytics_event ON analytics(event_type)",
                        "CREATE INDEX IF NOT EXISTS idx_analytics_created ON analytics(created_at)"
                    ]

                    for index_sql in indexes:
                        cursor.execute(index_sql)

                    conn.commit()
                    logger.info("Database initialized successfully")

            except Exception as e:
                logger.error(f"Failed to initialize database: {e}")
                raise

    @contextmanager
    def _get_connection(self):
        """Get database connection with proper error handling."""
        with self._lock:
            try:
                conn = sqlite3.connect(
                    self.db_path,
                    timeout=30.0,
                    check_same_thread=False
                )
                conn.row_factory = sqlite3.Row
                yield conn
                conn.close()
            except Exception as e:
                logger.error(f"Database connection error: {e}")
                raise

    def _encrypt(self, data: str) -> str:
        """Encrypt data using Fernet encryption."""
        if not data:
            return data
        try:
            encrypted_bytes = self.cipher_suite.encrypt(data.encode('utf-8'))
            return encrypted_bytes.decode('utf-8')
        except Exception as e:
            logger.error(f"Encryption failed: {e}")
            raise

    def _decrypt(self, encrypted_data: str) -> str:
        """Decrypt data using Fernet encryption."""
        if not encrypted_data:
            return encrypted_data
        try:
            decrypted_bytes = self.cipher_suite.decrypt(encrypted_data.encode('utf-8'))
            return decrypted_bytes.decode('utf-8')
        except InvalidToken:
            logger.error("Invalid encryption token - data may be corrupted")
            return ""
        except Exception as e:
            logger.error(f"Decryption failed: {e}")
            raise

    # FACTS MANAGEMENT
    def save_fact(self, key: str, value: str, category: str = "general",
                  tags: List[str] = None, confidence: float = 1.0) -> bool:
        """Save a fact to the encrypted database."""
        try:
            encrypted_value = self._encrypt(value)
            tags_json = json.dumps(tags or [])
            now = datetime.now().isoformat()

            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO facts
                    (key, value, category, tags, confidence, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?,
                        COALESCE((SELECT created_at FROM facts WHERE key = ?), ?),
                        ?)
                ''', (key, encrypted_value, category, tags_json, confidence, key, now, now))

                conn.commit()
                logger.debug(f"Fact saved: {key} ({category})")
                return True

        except Exception as e:
            logger.error(f"Failed to save fact {key}: {e}")
            return False

    def recall_fact(self, key: str) -> Optional[str]:
        """Recall a fact by key."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT value, access_count FROM facts WHERE key = ?
                ''', (key,))
                result = cursor.fetchone()

                if result:
                    # Update access statistics
                    cursor.execute('''
                        UPDATE facts
                        SET access_count = access_count + 1, last_accessed = ?
                        WHERE key = ?
                    ''', (datetime.now().isoformat(), key))
                    conn.commit()

                    return self._decrypt(result['value'])
                return None

        except Exception as e:
            logger.error(f"Failed to recall fact {key}: {e}")
            return None

    def search_facts(self, query: str = "", category: str = None,
                    limit: int = 20) -> List[Dict[str, Any]]:
        """Search facts by query and/or category."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()

                base_query = '''
                    SELECT key, category, tags, confidence, created_at,
                           updated_at, access_count, last_accessed
                    FROM facts WHERE 1=1
                '''
                params = []

                if query:
                    base_query += ' AND key LIKE ?'
                    params.append(f'%{query}%')

                if category:
                    base_query += ' AND category = ?'
                    params.append(category)

                base_query += ' ORDER BY access_count DESC, updated_at DESC LIMIT ?'
                params.append(limit)

                cursor.execute(base_query, params)
                results = []

                for row in cursor.fetchall():
                    # Get decrypted value
                    value = self.recall_fact(row['key'])
                    results.append({
                        'key': row['key'],
                        'value': value,
                        'category': row['category'],
                        'tags': json.loads(row['tags']) if row['tags'] else [],
                        'confidence': row['confidence'],
                        'created_at': row['created_at'],
                        'updated_at': row['updated_at'],
                        'access_count': row['access_count'],
                        'last_accessed': row['last_accessed']
                    })

                return results

        except Exception as e:
            logger.error(f"Failed to search facts: {e}")
            return []

    def delete_fact(self, key: str) -> bool:
        """Delete a fact by key."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('DELETE FROM facts WHERE key = ?', (key,))
                conn.commit()
                return cursor.rowcount > 0

        except Exception as e:
            logger.error(f"Failed to delete fact {key}: {e}")
            return False

    # CONVERSATION MANAGEMENT
    def save_conversation(self, user_input: str, agent_response: str,
                         intent: str = "general", confidence: float = None,
                         context: Dict = None, session_id: str = None,
                         duration_ms: int = None) -> bool:
        """Save a conversation to the encrypted database."""
        try:
            encrypted_input = self._encrypt(user_input)
            encrypted_response = self._encrypt(agent_response)
            context_json = json.dumps(context) if context else None
            now = datetime.now().isoformat()

            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO conversations
                    (session_id, user_input, agent_response, intent, confidence,
                     context, created_at, duration_ms)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (session_id, encrypted_input, encrypted_response, intent,
                      confidence, context_json, now, duration_ms))

                conn.commit()
                logger.debug(f"Conversation saved: {intent}")
                return True

        except Exception as e:
            logger.error(f"Failed to save conversation: {e}")
            return False

    def get_recent_conversations(self, n: int = 10, session_id: str = None) -> List[Dict[str, Any]]:
        """Get recent conversations."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                query = '''
                    SELECT user_input, agent_response, intent, confidence,
                           context, created_at, duration_ms, user_rating
                    FROM conversations
                '''
                params = []

                if session_id:
                    query += ' WHERE session_id = ?'
                    params.append(session_id)

                query += ' ORDER BY created_at DESC LIMIT ?'
                params.append(n)

                cursor.execute(query, params)
                results = []

                for row in cursor.fetchall():
                    results.append({
                        "user": self._decrypt(row['user_input']),
                        "agent": self._decrypt(row['agent_response']),
                        "intent": row['intent'],
                        "confidence": row['confidence'],
                        "context": json.loads(row['context']) if row['context'] else None,
                        "timestamp": row['created_at'],
                        "duration_ms": row['duration_ms'],
                        "user_rating": row['user_rating']
                    })

                return results

        except Exception as e:
            logger.error(f"Failed to get recent conversations: {e}")
            return []

    # PREFERENCES MANAGEMENT
    def save_preference(self, key: str, value: str, category: str = "general") -> bool:
        """Save a user preference."""
        try:
            encrypted_value = self._encrypt(value)
            now = datetime.now().isoformat()

            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO preferences
                    (key, value, category, created_at, updated_at)
                    VALUES (?, ?, ?,
                        COALESCE((SELECT created_at FROM preferences WHERE key = ?), ?),
                        ?)
                ''', (key, encrypted_value, category, key, now, now))

                conn.commit()
                logger.debug(f"Preference saved: {key}")
                return True

        except Exception as e:
            logger.error(f"Failed to save preference {key}: {e}")
            return False

    def get_preference(self, key: str) -> Optional[str]:
        """Get a user preference by key."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT value FROM preferences WHERE key = ?', (key,))
                result = cursor.fetchone()

                if result:
                    return self._decrypt(result['value'])
                return None

        except Exception as e:
            logger.error(f"Failed to get preference {key}: {e}")
            return None

    # TASK MANAGEMENT
    def log_task(self, task_name: str, status: str = "started",
                result: str = None, error_message: str = None,
                parameters: Dict = None, started_at: str = None,
                completed_at: str = None, user_input: str = None) -> bool:
        """Log a task execution."""
        try:
            started_at = started_at or datetime.now().isoformat()
            if completed_at and started_at:
                duration = int((datetime.fromisoformat(completed_at) -
                               datetime.fromisoformat(started_at)).total_seconds() * 1000)
            else:
                duration = None

            parameters_json = json.dumps(parameters) if parameters else None

            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO tasks
                    (task_name, status, result, error_message, parameters,
                     started_at, completed_at, duration_ms, user_input)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (task_name, status, result, error_message, parameters_json,
                      started_at, completed_at, duration_ms, user_input))

                conn.commit()
                logger.debug(f"Task logged: {task_name} ({status})")
                return True

        except Exception as e:
            logger.error(f"Failed to log task {task_name}: {e}")
            return False

    def get_task_history(self, task_name: str = None, status: str = None,
                        limit: int = 20) -> List[Dict[str, Any]]:
        """Get task execution history."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                query = '''
                    SELECT task_name, task_type, status, result, error_message,
                           parameters, started_at, completed_at, duration_ms,
                           user_input
                    FROM tasks WHERE 1=1
                '''
                params = []

                if task_name:
                    query += ' AND task_name LIKE ?'
                    params.append(f'%{task_name}%')

                if status:
                    query += ' AND status = ?'
                    params.append(status)

                query += ' ORDER BY started_at DESC LIMIT ?'
                params.append(limit)

                cursor.execute(query, params)
                results = []

                for row in cursor.fetchall():
                    results.append({
                        'task_name': row['task_name'],
                        'task_type': row['task_type'],
                        'status': row['status'],
                        'result': row['result'],
                        'error_message': row['error_message'],
                        'parameters': json.loads(row['parameters']) if row['parameters'] else None,
                        'started_at': row['started_at'],
                        'completed_at': row['completed_at'],
                        'duration_ms': row['duration_ms'],
                        'user_input': row['user_input']
                    })

                return results

        except Exception as e:
            logger.error(f"Failed to get task history: {e}")
            return []

    # ANALYTICS AND STATISTICS
    def log_event(self, event_type: str, event_data: Dict = None,
                  session_id: str = None) -> bool:
        """Log an analytics event."""
        try:
            event_data_json = json.dumps(event_data) if event_data else None

            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO analytics (event_type, event_data, session_id, created_at)
                    VALUES (?, ?, ?, ?)
                ''', (event_type, event_data_json, session_id, datetime.now().isoformat()))

                conn.commit()
                return True

        except Exception as e:
            logger.error(f"Failed to log event {event_type}: {e}")
            return False

    def get_memory_stats(self) -> Dict[str, Any]:
        """Get memory usage statistics."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()

                stats = {}

                # Count records in each table
                tables = ['facts', 'conversations', 'preferences', 'tasks', 'files', 'reminders', 'analytics']
                for table in tables:
                    cursor.execute(f'SELECT COUNT(*) as count FROM {table}')
                    stats[f'{table}_count'] = cursor.fetchone()['count']

                # Database file size
                if self.db_path.exists():
                    stats['database_size_bytes'] = self.db_path.stat().st_size
                    stats['database_size_mb'] = round(stats['database_size_bytes'] / (1024 * 1024), 2)

                # Most accessed facts
                cursor.execute('''
                    SELECT key, access_count FROM facts
                    WHERE access_count > 0
                    ORDER BY access_count DESC LIMIT 5
                ''')
                stats['most_accessed_facts'] = [
                    {'key': row['key'], 'access_count': row['access_count']}
                    for row in cursor.fetchall()
                ]

                # Recent activity
                cursor.execute('''
                    SELECT COUNT(*) as count FROM conversations
                    WHERE created_at > datetime('now', '-1 day')
                ''')
                stats['conversations_today'] = cursor.fetchone()['count']

                return stats

        except Exception as e:
            logger.error(f"Failed to get memory stats: {e}")
            return {'error': str(e)}

    # DATABASE MAINTENANCE
    def create_backup(self, backup_dir: str = None) -> Optional[Path]:
        """Create a backup of the memory database."""
        return create_backup(self.db_path, backup_dir)

    def cleanup_old_data(self, days_to_keep: int = 90) -> Dict[str, int]:
        """Clean up old data to prevent database bloat."""
        try:
            cutoff_date = (datetime.now() - timedelta(days=days_to_keep)).isoformat()
            deleted_counts = {}

            with self._get_connection() as conn:
                cursor = conn.cursor()

                # Clean old analytics
                cursor.execute('DELETE FROM analytics WHERE created_at < ?', (cutoff_date,))
                deleted_counts['analytics'] = cursor.rowcount

                # Clean old completed tasks
                cursor.execute('''
                    DELETE FROM tasks
                    WHERE status IN ('completed', 'failed') AND started_at < ?
                ''', (cutoff_date,))
                deleted_counts['tasks'] = cursor.rowcount

                # Clean old reminders
                cursor.execute('''
                    DELETE FROM reminders
                    WHERE status = 'completed' AND completed_at < ?
                ''', (cutoff_date,))
                deleted_counts['reminders'] = cursor.rowcount

                conn.commit()
                logger.info(f"Cleaned up old data: {deleted_counts}")
                return deleted_counts

        except Exception as e:
            logger.error(f"Failed to cleanup old data: {e}")
            return {}

    def close(self):
        """Close database connections and cleanup."""
        # In this implementation, connections are handled with context managers
        logger.info("MemoryManager closed")