#!/usr/bin/env python3
"""
Natural Human-Like Speech Enhancement for Safwaan Buddy
Advanced conversation patterns, emotional intelligence, and natural language processing.
"""

import re
import random
import time
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime

from utils.logger import get_logger

logger = get_logger("natural_speech")


@dataclass
class EmotionState:
    """Represents current emotional state for natural speech."""
    primary_emotion: str
    intensity: float  # 0.0 to 1.0
    confidence: float  # 0.0 to 1.0
    context_relevance: float  # 0.0 to 1.0


class NaturalSpeechProcessor:
    """Advanced natural speech processor with human-like conversation patterns."""

    def __init__(self):
        """Initialize natural speech processor."""
        self.logger = get_logger("natural_speech")

        # Conversation personality
        self.personality = {
            "name": "Safwaan Buddy",
            "traits": ["helpful", "intelligent", "friendly", "professional", "adaptable"],
            "speaking_style": "conversational",
            "formality_level": 0.3,  # 0.0 = very casual, 1.0 = very formal
            "enthusiasm_level": 0.7,
            "empathy_level": 0.8
        }

        # Emotional intelligence
        self.current_emotion = EmotionState("neutral", 0.5, 0.8, 0.7)
        self.emotion_history = []
        self.conversation_context = []

        # Natural language patterns
        self.filler_words = {
            "thinking": ["Hmm", "Let me think about that", "Interesting question", "Well now"],
            "acknowledging": ["I see", "Got it", "Right", "That makes sense", "I understand"],
            "transition": ["So", "Now", "Alright then", "Okay", "Moving on"],
            "empathy": ["I can see how that would be", "That sounds challenging", "I appreciate that"],
            "excitement": ["That's fantastic!", "Excellent!", "Wonderful!", "That's great!"],
            "concern": ["I'm sorry to hear that", "That sounds difficult", "Let me help with that"],
            "confidence": ["Absolutely", "Definitely", "I can handle that", "No problem at all"],
            "casual": ["You know", "Actually", "To be honest", "Pretty much", "Kind of"]
        }

        # Speech patterns for natural pauses
        self.pause_patterns = {
            "sentence_end": [0.5, 0.8, 1.2],
            "clause_end": [0.2, 0.4, 0.6],
            "dramatic_pause": [1.5, 2.0, 2.5],
            "thinking_pause": [1.0, 1.5, 2.0],
            "quick_response": [0.1, 0.2, 0.3]
        }

        # Voice inflection patterns
        self.inflection_patterns = {
            "question_up": [1.2, 1.4],
            "statement_down": [0.8, 1.0],
            "excited_high": [1.3, 1.5],
            "concerned_low": [0.7, 0.9],
            "neutral": [0.9, 1.1]
        }

        # Multilingual capabilities
        self.supported_languages = {
            "english": {"confidence": 1.0, "phrases": ["Hello", "How can I help?", "I'm here to assist"]},
            "spanish": {"confidence": 0.9, "phrases": ["Hola", "¿Cómo puedo ayudar?", "Estoy aquí para asistir"]},
            "french": {"confidence": 0.8, "phrases": ["Bonjour", "Comment puis-je aider?", "Je suis là pour aider"]},
            "german": {"confidence": 0.8, "phrases": ["Hallo", "Wie kann ich helfen?", "Ich bin da, um zu helfen"]},
            "chinese": {"confidence": 0.9, "phrases": ["你好", "我能怎么帮助你？", "我在这里帮助你"]},
            "japanese": {"confidence": 0.8, "phrases": ["こんにちは", "どうお手伝いできますか？", "お手伝いします"]},
            "arabic": {"confidence": 0.7, "phrases": ["مرحبا", "كيف يمكنني المساعدة؟", "أنا هنا للمساعدة"]},
            "russian": {"confidence": 0.8, "phrases": ["Привет", "Как я могу помочь?", "Я здесь, чтобы помочь"]},
            "hindi": {"confidence": 0.9, "phrases": ["नमस्ते", "मैं कैसे मदद कर सकता हूँ", "मैं मदद करने के लिए हूँ"]},
            "portuguese": {"confidence": 0.8, "phrases": ["Olá", "Como posso ajudar?", "Estou aqui para ajudar"]},
            "italian": {"confidence": 0.7, "phrases": ["Ciao", "Come posso aiutare?", "Sono qui per aiutare"]},
            "korean": {"confidence": 0.8, "phrases": ["안녕하세요", "어떻게 도와드릴까요?", "도와드리기 위해 여기 있습니다"]},
            "dutch": {"confidence": 0.7, "phrases": ["Hallo", "Hoe kan ik helpen?", "Ik ben hier om te helpen"]},
            "swedish": {"confidence": 0.7, "phrases": ["Hej", "Hur kan jag hjälpa?", "Jag är här för att hjälpa"]},
            "polish": {"confidence": 0.8, "phrases": ["Cześć", "Jak mogę pomóc?", "Jestem tu, aby pomóc"]},
            "turkish": {"confidence": 0.8, "phrases": ["Merhaba", "Nasıl yardımcı olabilirim?", "Yardım etmek için buradayım"]}
        }

        # Intelligent conversation patterns
        self.response_templates = {
            "greeting": [
                "Hello! It's great to hear from you today.",
                "Hi there! How can I assist you today?",
                "Good to see you! What's on your mind?",
                "Hey! Ready to help with whatever you need."
            ],
            "understanding": [
                "I completely understand what you're looking for.",
                "That makes perfect sense to me.",
                "I see exactly what you need help with.",
                "Got it! I understand your request completely."
            ],
            "problem_solving": [
                "Let me think through the best way to handle this.",
                "I can definitely help you solve this challenge.",
                "This is an interesting problem, let me work through it.",
                "I believe I have the perfect solution for this."
            ],
            "reassurance": [
                "Don't worry, I'm here to help you through this.",
                "Everything will be alright, I've got you covered.",
                "Trust me, we'll get this sorted out together.",
                "Take a deep breath, I'll handle this for you."
            ],
            "excitement": [
                "This is fantastic! I'm excited to help with this!",
                "Wow, that's brilliant! Let's get started!",
                "Excellent! I love working on challenges like this!",
                "This is going to be great! I'm ready when you are!"
            ],
            "gratitude": [
                "Thank you for trusting me with this task.",
                "I really appreciate your confidence in my abilities.",
                "It's my pleasure to help you with this.",
                "You're welcome! I'm always happy to assist."
            ],
            "farewell": [
                "It was great helping you today!",
                "Feel free to reach out anytime you need assistance.",
                "Take care! I'm always here if you need me.",
                "Have a wonderful day! I'm just a call away if you need anything."
            ]
        }

        self.logger.info("NaturalSpeechProcessor initialized with advanced conversation capabilities")

    def analyze_emotional_context(self, user_input: str, previous_context: List[str] = None) -> EmotionState:
        """Analyze the emotional context of the conversation."""
        # Basic emotion detection from text
        emotion_keywords = {
            "excited": ["awesome", "amazing", "fantastic", "great", "wonderful", "brilliant"],
            "concerned": ["worried", "scared", "confused", "lost", "stuck", "help"],
            "frustrated": ["annoying", "broken", "not working", "error", "problem", "issue"],
            "happy": ["good", "perfect", "thanks", "love", "enjoy", "success"],
            "curious": ["how", "what", "why", "when", "where", "tell me", "explain"],
            "neutral": ["okay", "alright", "sure", "yes", "no", "maybe"]
        }

        user_lower = user_input.lower()
        detected_emotions = []

        for emotion, keywords in emotion_keywords.items():
            for keyword in keywords:
                if keyword in user_lower:
                    detected_emotions.append(emotion)
                    break

        # Determine primary emotion
        if detected_emotions:
            primary_emotion = detected_emotions[0]
            intensity = min(1.0, len(detected_emotions) * 0.3)
            confidence = 0.8
        else:
            primary_emotion = "neutral"
            intensity = 0.5
            confidence = 0.6

        # Context relevance based on conversation flow
        context_relevance = 0.7
        if previous_context:
            # Check if this continues previous conversation topic
            context_relevance = 0.9 if len(previous_context) < 3 else 0.7

        self.current_emotion = EmotionState(
            primary_emotion=primary_emotion,
            intensity=intensity,
            confidence=confidence,
            context_relevance=context_relevance
        )

        self.emotion_history.append({
            "emotion": primary_emotion,
            "intensity": intensity,
            "timestamp": datetime.now().isoformat(),
            "trigger": user_input
        })

        return self.current_emotion

    def enhance_response_naturally(self, response: str, emotion: EmotionState = None) -> str:
        """Enhance a response with natural human-like speech patterns."""
        if emotion is None:
            emotion = self.current_emotion

        # Add appropriate fillers and natural language
        enhanced = response

        # Add conversational starters
        if random.random() < 0.3:  # 30% chance to add filler
            filler_type = self._determine_filler_type(emotion)
            filler = random.choice(self.filler_words[filler_type])
            enhanced = f"{filler}, {enhanced}"

        # Add natural pauses indicators
        enhanced = self._add_natural_pauses(enhanced)

        # Add emotional inflections
        enhanced = self._add_emotional_inflections(enhanced, emotion)

        # Add personality traits
        enhanced = self._add_personality_traits(enhanced)

        # Ensure natural word flow
        enhanced = self._ensure_natural_flow(enhanced)

        return enhanced

    def _determine_filler_type(self, emotion: EmotionState) -> str:
        """Determine appropriate filler type based on emotion."""
        if emotion.primary_emotion == "curious":
            return "thinking"
        elif emotion.primary_emotion == "happy" or emotion.primary_emotion == "excited":
            return "excitement"
        elif emotion.primary_emotion == "concerned":
            return "empathy"
        elif emotion.primary_emotion == "frustrated":
            return "acknowledging"
        else:
            return "transition"

    def _add_natural_pauses(self, text: str) -> str:
        """Add natural pause indicators to text."""
        # Replace some commas with natural pause indicators
        text = re.sub(r',\s*(?=[a-z])', lambda m: f'. {random.choice(self.pause_patterns["clause_end"])}', text)

        # Add pauses before important statements
        text = re.sub(r'\.\s*(?=[A-Z])', f'. {random.choice(self.pause_patterns["sentence_end"])}', text)

        return text

    def _add_emotional_inflections(self, text: str, emotion: EmotionState) -> str:
        """Add emotional inflection markers to text."""
        if emotion.primary_emotion == "excited":
            # Add exclamation marks and positive emphasis
            text = re.sub(r'\.$', '!', text)
            if random.random() < 0.3:
                text = f"Wow! {text}"

        elif emotion.primary_emotion == "concerned":
            # Add gentle, reassuring tone
            if random.random() < 0.4:
                text = f"Oh, {text}"

        elif emotion.primary_emotion == "curious":
            # Add thoughtful language
            if random.random() < 0.3:
                text = f"Hmm, {text}"

        return text

    def _add_personality_traits(self, text: str) -> str:
        """Add personality traits to make speech more natural."""
        traits = self.personality["traits"]

        # Professional language
        if "professional" in traits and random.random() < 0.2:
            text = text.replace("I'll", "I will")
            text = text.replace("can't", "cannot")
            text = text.replace("won't", "will not")

        # Friendly language
        if "friendly" in traits and random.random() < 0.3:
            friendly_additions = ["my friend", "gladly", "happy to"]
            if random.random() < 0.5:
                addition = random.choice(friendly_additions)
                text = f"{addition}, {text}"

        # Intelligent language
        if "intelligent" in traits and random.random() < 0.2:
            intelligent_phrases = ["Based on my analysis", "I've determined", "The optimal approach is"]
            if random.random() < 0.4:
                phrase = random.choice(intelligent_phrases)
                text = f"{phrase}, {text}"

        return text

    def _ensure_natural_flow(self, text: str) -> str:
        """Ensure the text has natural word flow and rhythm."""
        # Break up long sentences
        words = text.split()
        if len(words) > 20:
            # Insert natural breaking points
            mid_point = len(words) // 2
            natural_breaks = ["however", "meanwhile", "additionally", "furthermore", "also"]

            for i, word in enumerate(words[mid_point-5:mid_point+5]):
                if word.lower() in natural_breaks:
                    words.insert(i+mid_point-5, ".")
                    break

        # Ensure natural rhythm
        text = " ".join(words)

        # Fix double spaces and punctuation
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'\s+([,.!?])', r'\1', text)
        text = re.sub(r'([,.!?])\s+([,.!?])', r'\1\2', text)

        return text

    def detect_language(self, text: str) -> str:
        """Detect the language of the input text."""
        text_lower = text.lower()
        language_scores = {}

        for lang, config in self.supported_languages.items():
            score = 0
            for phrase in config["phrases"]:
                if phrase.lower() in text_lower:
                    score += 1

            if score > 0:
                language_scores[lang] = score * config["confidence"]

        if language_scores:
            detected_lang = max(language_scores, key=language_scores.get)
            logger.debug(f"Detected language: {detected_lang}")
            return detected_lang
        else:
            return "english"  # Default to English

    def translate_response(self, text: str, target_language: str) -> str:
        """Translate response to target language (mock implementation)."""
        # This would integrate with translation services
        # For now, return language-appropriate greeting with original text

        if target_language in self.supported_languages:
            phrases = self.supported_languages[target_language]["phrases"]
            if any(greeting.lower() in text.lower() for greeting in ["hello", "hi", "hey"]):
                return f"{phrases[0]} {text}"

        return text

    def generate_multilingual_response(self, text: str, user_language: str = None) -> str:
        """Generate response with multilingual capabilities."""
        if not user_language:
            user_language = self.detect_language(text)

        # Enhance with natural speech patterns
        enhanced_text = self.enhance_response_naturally(text)

        # Add language awareness
        if user_language != "english":
            enhanced_text = f"({user_language.title()}) {enhanced_text}"

        return enhanced_text

    def create_conversation_context(self, user_input: str, bot_response: str,
                                  timestamp: datetime = None) -> Dict[str, Any]:
        """Create rich conversation context."""
        if timestamp is None:
            timestamp = datetime.now()

        context = {
            "timestamp": timestamp.isoformat(),
            "user_input": user_input,
            "bot_response": bot_response,
            "detected_emotion": self.current_emotion.primary_emotion,
            "emotion_intensity": self.current_emotion.intensity,
            "language": self.detect_language(user_input),
            "response_length": len(bot_response.split()),
            "complexity_level": self._assess_complexity(bot_response),
            "topics": self._extract_topics(user_input + " " + bot_response)
        }

        self.conversation_context.append(context)
        return context

    def _assess_complexity(self, text: str) -> str:
        """Assess the complexity of the response."""
        words = text.split()
        sentences = len([s for s in re.split(r'[.!?]+', text) if s.strip()])
        avg_words_per_sentence = len(words) / max(sentences, 1)

        if avg_words_per_sentence < 8:
            return "simple"
        elif avg_words_per_sentence < 15:
            return "moderate"
        else:
            return "complex"

    def _extract_topics(self, text: str) -> List[str]:
        """Extract main topics from conversation text."""
        # Simple topic extraction based on keywords
        technical_keywords = ["computer", "software", "code", "programming", "system", "network", "data"]
        personal_keywords = ["help", "need", "want", "like", "feel", "think", "believe"]
        action_keywords = ["do", "make", "create", "build", "run", "start", "stop", "open", "close"]

        topics = []
        text_lower = text.lower()

        if any(keyword in text_lower for keyword in technical_keywords):
            topics.append("technical")
        if any(keyword in text_lower for keyword in personal_keywords):
            topics.append("personal")
        if any(keyword in text_lower for keyword in action_keywords):
            topics.append("action")

        return topics or ["general"]

    def get_conversation_insights(self) -> Dict[str, Any]:
        """Get insights about the conversation patterns."""
        if not self.conversation_context:
            return {"message": "No conversation context available"}

        # Analyze emotion patterns
        emotion_counts = {}
        for context in self.conversation_context:
            emotion = context.get("detected_emotion", "neutral")
            emotion_counts[emotion] = emotion_counts.get(emotion, 0) + 1

        # Language distribution
        language_counts = {}
        for context in self.conversation_context:
            lang = context.get("language", "english")
            language_counts[lang] = language_counts.get(lang, 0) + 1

        # Complexity analysis
        complexity_counts = {"simple": 0, "moderate": 0, "complex": 0}
        for context in self.conversation_context:
            complexity = context.get("complexity_level", "moderate")
            complexity_counts[complexity] = complexity_counts.get(complexity, 0) + 1

        return {
            "total_exchanges": len(self.conversation_context),
            "emotion_distribution": emotion_counts,
            "language_distribution": language_counts,
            "complexity_distribution": complexity_counts,
            "most_common_emotion": max(emotion_counts, key=emotion_counts.get) if emotion_counts else "neutral",
            "primary_language": max(language_counts, key=language_counts.get) if language_counts else "english",
            "average_complexity": "moderate"
        }

    def adapt_personality(self, user_preferences: Dict[str, Any]):
        """Adapt personality based on user preferences."""
        if "formality" in user_preferences:
            self.personality["formality_level"] = user_preferences["formality"]

        if "enthusiasm" in user_preferences:
            self.personality["enthusiasm_level"] = user_preferences["enthusiasm"]

        if "speaking_style" in user_preferences:
            self.personality["speaking_style"] = user_preferences["speaking_style"]

        self.logger.info(f"Personality adapted: {self.personality}")

    def get_current_personality(self) -> Dict[str, Any]:
        """Get current personality settings."""
        return {
            "personality": self.personality.copy(),
            "current_emotion": {
                "primary": self.current_emotion.primary_emotion,
                "intensity": self.current_emotion.intensity,
                "confidence": self.current_emotion.confidence
            },
            "supported_languages": len(self.supported_languages),
            "conversation_count": len(self.conversation_context)
        }