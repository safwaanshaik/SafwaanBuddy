#!/usr/bin/env python3
"""
Plugin System Architecture for Safwaan Buddy
Manages dynamic plugin loading, execution, and error isolation.
"""

import os
import sys
import json
import importlib
import inspect
import threading
import time
from typing import Dict, List, Any, Optional, Callable, Union
from pathlib import Path
from dataclasses import dataclass
from abc import ABC, abstractmethod
from datetime import datetime

from config import get_config
from utils.logger import get_logger
from utils.helpers import read_file_safe, write_file_safe, merge_dicts

logger = get_logger("plugin_manager")


@dataclass
class PluginInfo:
    """Information about a loaded plugin."""
    name: str
    version: str
    description: str
    author: str
    file_path: str
    class_name: str
    functions: List[str]
    enabled: bool
    loaded_at: datetime
    last_used: Optional[datetime] = None
    usage_count: int = 0
    error_count: int = 0
    last_error: Optional[str] = None


@dataclass
class PluginResult:
    """Result from plugin execution."""
    success: bool
    plugin_name: str
    function_name: str
    data: Any = None
    error_message: str = ""
    execution_time: float = 0.0
    timestamp: datetime = None


class BasePlugin(ABC):
    """Base class for all plugins."""

    def __init__(self, name: str):
        self.name = name
        self.version = "1.0.0"
        self.description = "Base plugin"
        self.author = "Unknown"
        self.enabled = True

    @abstractmethod
    def get_functions(self) -> Dict[str, Callable]:
        """Return dictionary of plugin functions."""
        pass

    def get_info(self) -> Dict[str, Any]:
        """Get plugin information."""
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "author": self.author,
            "enabled": self.enabled
        }

    def on_load(self):
        """Called when plugin is loaded."""
        pass

    def on_unload(self):
        """Called when plugin is unloaded."""
        pass

    def on_enable(self):
        """Called when plugin is enabled."""
        self.enabled = True

    def on_disable(self):
        """Called when plugin is disabled."""
        self.enabled = False


class PluginManager:
    """Manages plugin loading, execution, and lifecycle."""

    def __init__(self, memory_manager=None):
        """Initialize plugin manager."""
        self.memory_manager = memory_manager
        self.config = get_config()
        self.plugins: Dict[str, PluginInfo] = {}
        self.plugin_instances: Dict[str, BasePlugin] = {}
        self.plugin_functions: Dict[str, Callable] = {}
        self.execution_history: List[PluginResult] = []
        self.callbacks: Dict[str, List[Callable]] = {}

        # Configuration
        self.plugins_dir = Path(self.config.get("plugins_dir", "src/plugins"))
        self.plugin_timeout = self.config.get("plugin_timeout", 30)
        self.enabled = self.config.get("enable_plugin_system", True)

        # Threading for plugin execution
        self.execution_lock = threading.RLock()

        # Load built-in plugins
        self._load_builtin_plugins()

        # Load external plugins if enabled
        if self.enabled:
            self._load_external_plugins()

        logger.info(f"PluginManager initialized with {len(self.plugins)} plugins")

    def _load_builtin_plugins(self):
        """Load built-in plugin functions."""
        builtin_functions = {
            # System functions
            "system_stats": self._plugin_system_stats,
            "get_time": self._plugin_get_time,
            "open_app": self._plugin_open_app,
            "close_app": self._plugin_close_app,

            # Note functions
            "save_note": self._plugin_save_note,
            "recall_note": self._plugin_recall_note,
            "list_notes": self._plugin_list_notes,
            "delete_note": self._plugin_delete_note,
            "search_notes": self._plugin_search_notes,

            # UI Automation functions
            "type_text": self._plugin_type_text,
            "click": self._plugin_click,
            "double_click": self._plugin_double_click,
            "right_click": self._plugin_right_click,
            "scroll": self._plugin_scroll,

            # Clipboard functions
            "clipboard_read": self._plugin_clipboard_read,
            "clipboard_write": self._plugin_clipboard_write,

            # File functions
            "create_file": self._plugin_create_file,
            "read_file": self._plugin_read_file,
            "delete_file": self._plugin_delete_file,
            "list_directory": self._plugin_list_directory,

            # Calculator functions
            "calculate": self._plugin_calculate,

            # Reminder functions
            "set_reminder": self._plugin_set_reminder,
            "list_reminders": self._plugin_list_reminders,

            # Screenshot functions
            "screenshot": self._plugin_screenshot,
        }

        # Register built-in functions
        for name, func in builtin_functions.items():
            self.register_function(name, func)

        logger.info(f"Loaded {len(builtin_functions)} built-in functions")

    def _load_external_plugins(self):
        """Load external plugins from plugins directory."""
        if not self.plugins_dir.exists():
            logger.warning(f"Plugins directory does not exist: {self.plugins_dir}")
            return

        # Add plugins directory to Python path
        if str(self.plugins_dir) not in sys.path:
            sys.path.insert(0, str(self.plugins_dir))

        # Discover and load plugin files
        for plugin_file in self.plugins_dir.glob("*.py"):
            if plugin_file.name.startswith("__"):
                continue

            try:
                self._load_plugin_file(plugin_file)
            except Exception as e:
                logger.error(f"Failed to load plugin file {plugin_file}: {e}")

        logger.info(f"Loaded {len([p for p in self.plugins.values() if not p.name.startswith('_')])} external plugins")

    def _load_plugin_file(self, plugin_file: Path):
        """Load a single plugin file."""
        try:
            # Get module name from file
            module_name = plugin_file.stem

            # Import the module
            spec = importlib.util.spec_from_file_location(module_name, plugin_file)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            # Find plugin classes
            for name, obj in inspect.getmembers(module, inspect.isclass):
                if (issubclass(obj, BasePlugin) and obj != BasePlugin and
                        obj.__module__ == module.__name__):

                    # Instantiate plugin
                    plugin_instance = obj()
                    plugin_info = self._create_plugin_info(plugin_instance, plugin_file)

                    # Store plugin
                    self.plugins[plugin_instance.name] = plugin_info
                    self.plugin_instances[plugin_instance.name] = plugin_instance

                    # Register plugin functions
                    functions = plugin_instance.get_functions()
                    for func_name, func in functions.items():
                        full_name = f"{plugin_instance.name}.{func_name}"
                        self.plugin_functions[full_name] = func

                    # Call plugin on_load
                    try:
                        plugin_instance.on_load()
                        logger.info(f"Loaded plugin: {plugin_instance.name}")
                    except Exception as e:
                        logger.error(f"Error in plugin {plugin_instance.name} on_load: {e}")

                    break  # Only load first plugin class per file

        except Exception as e:
            logger.error(f"Failed to load plugin file {plugin_file}: {e}")
            raise

    def _create_plugin_info(self, plugin: BasePlugin, plugin_file: Path) -> PluginInfo:
        """Create PluginInfo from plugin instance."""
        functions = list(plugin.get_functions().keys())

        return PluginInfo(
            name=plugin.name,
            version=plugin.version,
            description=plugin.description,
            author=plugin.author,
            file_path=str(plugin_file),
            class_name=plugin.__class__.__name__,
            functions=functions,
            enabled=plugin.enabled,
            loaded_at=datetime.now()
        )

    def register_function(self, name: str, func: Callable):
        """Register a function."""
        self.plugin_functions[name] = func
        logger.debug(f"Registered function: {name}")

    def unregister_function(self, name: str) -> bool:
        """Unregister a function."""
        if name in self.plugin_functions:
            del self.plugin_functions[name]
            logger.debug(f"Unregistered function: {name}")
            return True
        return False

    def execute(self, plugin_name: str, *args, **kwargs) -> PluginResult:
        """
        Execute a plugin function.

        Args:
            plugin_name: Name of plugin function (can include namespace)
            *args: Positional arguments
            **kwargs: Keyword arguments

        Returns:
            PluginResult with execution outcome
        """
        if not self.enabled:
            return PluginResult(
                success=False,
                plugin_name=plugin_name,
                function_name="unknown",
                error_message="Plugin system is disabled"
            )

        start_time = time.time()
        timestamp = datetime.now()

        # Handle namespaced function names
        if "." in plugin_name:
            namespace, function_name = plugin_name.split(".", 1)
        else:
            namespace, function_name = "_builtin", plugin_name

        with self.execution_lock:
            try:
                # Check if function exists
                if plugin_name not in self.plugin_functions:
                    # Try to find alternative function names
                    alternatives = [name for name in self.plugin_functions.keys()
                                  if name.endswith(function_name)]
                    if alternatives:
                        plugin_name = alternatives[0]
                        logger.info(f"Using alternative function: {plugin_name}")
                    else:
                        raise ValueError(f"Plugin function '{plugin_name}' not found")

                func = self.plugin_functions[plugin_name]

                # Execute function with timeout
                result = self._execute_with_timeout(func, args, kwargs, self.plugin_timeout)

                execution_time = time.time() - start_time

                # Update plugin statistics
                if namespace in self.plugins:
                    self.plugins[namespace].usage_count += 1
                    self.plugins[namespace].last_used = timestamp
                    self.plugins[namespace].error_count = 0  # Reset error count on success

                # Create success result
                plugin_result = PluginResult(
                    success=True,
                    plugin_name=namespace,
                    function_name=function_name,
                    data=result,
                    execution_time=execution_time,
                    timestamp=timestamp
                )

                # Store in history
                self.execution_history.append(plugin_result)
                if len(self.execution_history) > 1000:  # Keep last 1000 results
                    self.execution_history = self.execution_history[-1000:]

                # Notify callbacks
                self._notify_callbacks("plugin_executed", plugin_result)

                logger.info(f"Plugin executed: {plugin_name} ({execution_time:.3f}s)")
                return plugin_result

            except Exception as e:
                execution_time = time.time() - start_time
                error_message = str(e)

                # Update plugin error statistics
                if namespace in self.plugins:
                    self.plugins[namespace].error_count += 1
                    self.plugins[namespace].last_error = error_message

                # Create error result
                plugin_result = PluginResult(
                    success=False,
                    plugin_name=namespace,
                    function_name=function_name,
                    error_message=error_message,
                    execution_time=execution_time,
                    timestamp=timestamp
                )

                # Store in history
                self.execution_history.append(plugin_result)

                # Notify callbacks
                self._notify_callbacks("plugin_error", plugin_result)

                logger.error(f"Plugin execution failed: {plugin_name} - {error_message}")
                return plugin_result

    def _execute_with_timeout(self, func: Callable, args: tuple, kwargs: dict, timeout: float):
        """Execute function with timeout in a separate thread."""
        result_container = []
        exception_container = []

        def target():
            try:
                result_container.append(func(*args, **kwargs))
            except Exception as e:
                exception_container.append(e)

        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()
        thread.join(timeout)

        if thread.is_alive():
            raise TimeoutError(f"Plugin execution timed out after {timeout} seconds")

        if exception_container:
            raise exception_container[0]

        if result_container:
            return result_container[0]

        raise RuntimeError("Plugin execution returned no result")

    def reload_plugin(self, plugin_name: str) -> bool:
        """Reload a plugin."""
        if plugin_name not in self.plugins:
            logger.error(f"Plugin '{plugin_name}' not found")
            return False

        try:
            plugin_info = self.plugins[plugin_name]
            plugin_file = Path(plugin_info.file_path)

            if not plugin_file.exists():
                logger.error(f"Plugin file not found: {plugin_file}")
                return False

            # Unload plugin
            self.unload_plugin(plugin_name)

            # Reload plugin file
            self._load_plugin_file(plugin_file)

            logger.info(f"Reloaded plugin: {plugin_name}")
            return True

        except Exception as e:
            logger.error(f"Failed to reload plugin '{plugin_name}': {e}")
            return False

    def unload_plugin(self, plugin_name: str) -> bool:
        """Unload a plugin."""
        if plugin_name not in self.plugins:
            return False

        try:
            plugin_instance = self.plugin_instances.get(plugin_name)
            if plugin_instance:
                # Call plugin on_unload
                try:
                    plugin_instance.on_unload()
                except Exception as e:
                    logger.error(f"Error in plugin {plugin_name} on_unload: {e}")

                # Remove plugin functions
                functions = plugin_instance.get_functions()
                for func_name in functions.keys():
                    full_name = f"{plugin_name}.{func_name}"
                    if full_name in self.plugin_functions:
                        del self.plugin_functions[full_name]

                # Remove plugin
                del self.plugin_instances[plugin_name]
                del self.plugins[plugin_name]

                logger.info(f"Unloaded plugin: {plugin_name}")
                return True

        except Exception as e:
            logger.error(f"Failed to unload plugin '{plugin_name}': {e}")
            return False

        return False

    def enable_plugin(self, plugin_name: str) -> bool:
        """Enable a plugin."""
        if plugin_name not in self.plugins:
            return False

        try:
            plugin_instance = self.plugin_instances.get(plugin_name)
            if plugin_instance:
                plugin_instance.on_enable()
                self.plugins[plugin_name].enabled = True
                logger.info(f"Enabled plugin: {plugin_name}")
                return True
        except Exception as e:
            logger.error(f"Failed to enable plugin '{plugin_name}': {e}")

        return False

    def disable_plugin(self, plugin_name: str) -> bool:
        """Disable a plugin."""
        if plugin_name not in self.plugins:
            return False

        try:
            plugin_instance = self.plugin_instances.get(plugin_name)
            if plugin_instance:
                plugin_instance.on_disable()
                self.plugins[plugin_name].enabled = False
                logger.info(f"Disabled plugin: {plugin_name}")
                return True
        except Exception as e:
            logger.error(f"Failed to disable plugin '{plugin_name}': {e}")

        return False

    def get_plugin_info(self, plugin_name: str = None) -> Union[Dict[str, Any], List[Dict[str, Any]]]:
        """Get information about plugins."""
        if plugin_name:
            if plugin_name not in self.plugins:
                return {"error": f"Plugin '{plugin_name}' not found"}

            info = self.plugins[plugin_name]
            return {
                "name": info.name,
                "version": info.version,
                "description": info.description,
                "author": info.author,
                "functions": info.functions,
                "enabled": info.enabled,
                "loaded_at": info.loaded_at.isoformat(),
                "last_used": info.last_used.isoformat() if info.last_used else None,
                "usage_count": info.usage_count,
                "error_count": info.error_count,
                "last_error": info.last_error
            }
        else:
            return [self.get_plugin_info(name) for name in self.plugins.keys()]

    def get_available_functions(self) -> List[Dict[str, Any]]:
        """Get list of all available functions."""
        functions = []

        for name, func in self.plugin_functions.items():
            try:
                # Get function signature
                sig = inspect.signature(func)
                parameters = []
                for param_name, param in sig.parameters.items():
                    param_info = {
                        "name": param_name,
                        "default": str(param.default) if param.default != inspect.Parameter.empty else None,
                        "type": str(param.annotation) if param.annotation != inspect.Parameter.empty else "any"
                    }
                    parameters.append(param_info)

                # Get function docstring
                docstring = inspect.getdoc(func) or "No description available"

                functions.append({
                    "name": name,
                    "description": docstring,
                    "parameters": parameters
                })

            except Exception as e:
                logger.warning(f"Failed to get info for function {name}: {e}")
                functions.append({
                    "name": name,
                    "description": "Failed to get function information",
                    "parameters": []
                })

        return functions

    def get_execution_history(self, limit: int = 50, plugin_name: str = None) -> List[Dict[str, Any]]:
        """Get plugin execution history."""
        history = self.execution_history

        # Filter by plugin name if specified
        if plugin_name:
            history = [result for result in history if result.plugin_name == plugin_name]

        # Get latest results
        history = history[-limit:] if limit > 0 else history

        # Convert to dict format
        return [
            {
                "success": result.success,
                "plugin_name": result.plugin_name,
                "function_name": result.function_name,
                "error_message": result.error_message,
                "execution_time": result.execution_time,
                "timestamp": result.timestamp.isoformat()
            }
            for result in history
        ]

    def get_statistics(self) -> Dict[str, Any]:
        """Get plugin system statistics."""
        total_executions = len(self.execution_history)
        successful_executions = sum(1 for result in self.execution_history if result.success)

        return {
            "enabled": self.enabled,
            "total_plugins": len(self.plugins),
            "enabled_plugins": sum(1 for plugin in self.plugins.values() if plugin.enabled),
            "total_functions": len(self.plugin_functions),
            "total_executions": total_executions,
            "successful_executions": successful_executions,
            "success_rate": (successful_executions / max(total_executions, 1)) * 100,
            "most_used_plugin": self._get_most_used_plugin(),
            "recent_errors": [result for result in self.execution_history[-10:] if not result.success]
        }

    def _get_most_used_plugin(self) -> Optional[str]:
        """Get the most used plugin."""
        if not self.plugins:
            return None

        return max(self.plugins.items(), key=lambda x: x[1].usage_count)[0]

    def add_callback(self, event: str, callback: Callable):
        """Add callback for plugin events."""
        if event not in self.callbacks:
            self.callbacks[event] = []
        self.callbacks[event].append(callback)

    def remove_callback(self, event: str, callback: Callable):
        """Remove callback for plugin events."""
        if event in self.callbacks and callback in self.callbacks[event]:
            self.callbacks[event].remove(callback)

    def _notify_callbacks(self, event: str, data: Any):
        """Notify callbacks for plugin events."""
        if event in self.callbacks:
            for callback in self.callbacks[event]:
                try:
                    callback(event, data)
                except Exception as e:
                    logger.error(f"Error in plugin callback: {e}")

    def export_configuration(self) -> Dict[str, Any]:
        """Export plugin configuration."""
        return {
            "enabled": self.enabled,
            "plugin_timeout": self.plugin_timeout,
            "plugins": {name: {"enabled": info.enabled} for name, info in self.plugins.items()}
        }

    def import_configuration(self, config: Dict[str, Any]):
        """Import plugin configuration."""
        self.enabled = config.get("enabled", self.enabled)
        self.plugin_timeout = config.get("plugin_timeout", self.plugin_timeout)

        plugin_configs = config.get("plugins", {})
        for plugin_name, plugin_config in plugin_configs.items():
            if plugin_name in self.plugins:
                enabled = plugin_config.get("enabled", True)
                if enabled:
                    self.enable_plugin(plugin_name)
                else:
                    self.disable_plugin(plugin_name)

    # Built-in plugin implementations
    def _plugin_system_stats(self) -> str:
        """Get system statistics."""
        try:
            import psutil
            stats = {
                "cpu": f"{psutil.cpu_percent()}%",
                "ram": f"{psutil.virtual_memory().percent}%",
                "disk": f"{psutil.disk_usage('/').percent}%",
            }
            return json.dumps(stats, indent=2)
        except ImportError:
            return "System monitoring not available (psutil not installed)"

    def _plugin_get_time(self) -> str:
        """Get current time."""
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def _plugin_open_app(self, app_name: str = "notepad") -> str:
        """Open an application."""
        try:
            import subprocess
            subprocess.Popen(app_name)
            return f"Launched {app_name}"
        except Exception as e:
            return f"Failed to launch {app_name}: {e}"

    def _plugin_close_app(self, app_name: str) -> str:
        """Close an application."""
        try:
            import psutil
            for proc in psutil.process_iter(['name']):
                if app_name.lower() in proc.info['name'].lower():
                    proc.terminate()
                    return f"Closed {app_name}"
            return f"{app_name} not found running"
        except Exception as e:
            return f"Failed to close {app_name}: {e}"

    def _plugin_save_note(self, title: str, content: str) -> str:
        """Save a note."""
        if not self.memory_manager:
            return "Memory manager not available"

        try:
            self.memory_manager.save_fact(f"note_{title}", content, "notes")
            return f"Note '{title}' saved successfully"
        except Exception as e:
            return f"Failed to save note: {e}"

    def _plugin_recall_note(self, title: str) -> str:
        """Recall a note."""
        if not self.memory_manager:
            return "Memory manager not available"

        try:
            content = self.memory_manager.recall_fact(f"note_{title}")
            return content if content else f"No note found: {title}"
        except Exception as e:
            return f"Failed to recall note: {e}"

    def _plugin_list_notes(self) -> str:
        """List all notes."""
        if not self.memory_manager:
            return "Memory manager not available"

        try:
            facts = self.memory_manager.recall_all_facts()
            notes = [k.replace("note_", "") for k in facts if k.startswith("note_")]
            return json.dumps({"saved_notes": notes}, indent=2)
        except Exception as e:
            return f"Failed to list notes: {e}"

    def _plugin_delete_note(self, title: str) -> str:
        """Delete a note."""
        if not self.memory_manager:
            return "Memory manager not available"

        try:
            success = self.memory_manager.delete_fact(f"note_{title}")
            return f"Note '{title}' deleted" if success else f"Note '{title}' not found"
        except Exception as e:
            return f"Failed to delete note: {e}"

    def _plugin_search_notes(self, query: str) -> str:
        """Search notes."""
        if not self.memory_manager:
            return "Memory manager not available"

        try:
            results = self.memory_manager.search_facts(query, category="notes")
            return json.dumps({"results": results}, indent=2)
        except Exception as e:
            return f"Failed to search notes: {e}"

    def _plugin_type_text(self, text: str) -> str:
        """Type text (placeholder - requires UI automation)."""
        return f"Would type: {text}"

    def _plugin_click(self, x: int, y: int) -> str:
        """Click at coordinates (placeholder - requires UI automation)."""
        return f"Would click at ({x}, {y})"

    def _plugin_double_click(self, x: int, y: int) -> str:
        """Double click at coordinates (placeholder - requires UI automation)."""
        return f"Would double-click at ({x}, {y})"

    def _plugin_right_click(self, x: int, y: int) -> str:
        """Right click at coordinates (placeholder - requires UI automation)."""
        return f"Would right-click at ({x}, {y})"

    def _plugin_scroll(self, clicks: int) -> str:
        """Scroll (placeholder - requires UI automation)."""
        return f"Would scroll {clicks} clicks"

    def _plugin_clipboard_read(self) -> str:
        """Read clipboard."""
        try:
            import pyperclip
            return f"Clipboard: {pyperclip.paste()}"
        except ImportError:
            return "Clipboard not available (pyperclip not installed)"

    def _plugin_clipboard_write(self, text: str) -> str:
        """Write to clipboard."""
        try:
            import pyperclip
            pyperclip.copy(text)
            return f"Copied to clipboard: {text[:50]}..."
        except ImportError:
            return "Clipboard not available (pyperclip not installed)"

    def _plugin_create_file(self, path: str, content: str = "") -> str:
        """Create a file."""
        try:
            from utils.helpers import write_file_safe
            success = write_file_safe(path, content)
            return f"File created: {path}" if success else f"Failed to create file: {path}"
        except Exception as e:
            return f"Failed to create file: {e}"

    def _plugin_read_file(self, path: str) -> str:
        """Read a file."""
        try:
            from utils.helpers import read_file_safe
            content = read_file_safe(path)
            return content if content is not None else f"Failed to read file: {path}"
        except Exception as e:
            return f"Failed to read file: {e}"

    def _plugin_delete_file(self, path: str) -> str:
        """Delete a file."""
        try:
            from pathlib import Path
            Path(path).unlink()
            return f"File deleted: {path}"
        except Exception as e:
            return f"Failed to delete file: {e}"

    def _plugin_list_directory(self, path: str = ".") -> str:
        """List directory contents."""
        try:
            from pathlib import Path
            files = [str(p) for p in Path(path).iterdir()]
            return json.dumps({"files": files}, indent=2)
        except Exception as e:
            return f"Failed to list directory: {e}"

    def _plugin_calculate(self, expression: str) -> str:
        """Calculate mathematical expression."""
        try:
            # Safe evaluation of mathematical expressions
            allowed_names = {
                "__builtins__": {},
                "abs": abs, "round": round, "min": min, "max": max,
                "sum": sum, "len": len, "pow": pow
            }
            result = eval(expression, allowed_names, {})
            return f"Result: {result}"
        except Exception as e:
            return f"Calculation error: {e}"

    def _plugin_set_reminder(self, title: str, time: str) -> str:
        """Set a reminder (placeholder)."""
        return f"Reminder set: {title} at {time}"

    def _plugin_list_reminders(self) -> str:
        """List reminders (placeholder)."""
        return json.dumps({"reminders": []}, indent=2)

    def _plugin_screenshot(self, filename: str = None) -> str:
        """Take screenshot (placeholder - requires UI automation)."""
        return "Screenshot functionality not implemented"