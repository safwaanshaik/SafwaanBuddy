#!/usr/bin/env python3
"""
Complete Laptop System Control for Safwaan Buddy
Comprehensive system administration, file operations, and laptop control capabilities.
"""

import os
import sys
import subprocess
import json
import shutil
import psutil
import platform
import ctypes
import winreg
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
from dataclasses import dataclass

from utils.logger import get_logger
from utils.helpers import run_command_safely, is_admin

logger = get_logger("system_control")


@dataclass
class SystemInfo:
    """Complete system information."""
    os_info: Dict[str, str]
    hardware_info: Dict[str, Any]
    network_info: Dict[str, Any]
    software_info: Dict[str, Any]
    security_info: Dict[str, Any]
    performance_info: Dict[str, float]


class SystemControlManager:
    """Complete laptop system control and administration."""

    def __init__(self):
        """Initialize system control manager."""
        self.platform = platform.system()
        self.is_admin = is_admin()
        self.admin_actions_log = []
        self.system_restrictions = {}

        # Initialize system information
        self.system_info = self._get_complete_system_info()

        logger.info(f"SystemControlManager initialized for {self.platform}")
        logger.info(f"Administrative privileges: {self.is_admin}")

    def _get_complete_system_info(self) -> SystemInfo:
        """Get complete system information."""
        # OS Information
        os_info = {
            "platform": platform.system(),
            "platform_release": platform.release(),
            "platform_version": platform.version(),
            "architecture": platform.machine(),
            "hostname": platform.node(),
            "processor": platform.processor(),
            "python_version": platform.python_version(),
            "boot_time": datetime.fromtimestamp(psutil.boot_time()).isoformat()
        }

        # Hardware Information
        hardware_info = {
            "cpu_count": psutil.cpu_count(logical=True),
            "cpu_physical": psutil.cpu_count(logical=False),
            "cpu_freq": psutil.cpu_freq()._asdict() if psutil.cpu_freq() else None,
            "memory_total": psutil.virtual_memory().total,
            "memory_available": psutil.virtual_memory().available,
            "disk_partitions": [
                {
                    "device": partition.device,
                    "mountpoint": partition.mountpoint,
                    "fstype": partition.fstype
                } for partition in psutil.disk_partitions()
            ],
            "battery": self._get_battery_info(),
            "temperature": self._get_temperature_info(),
            "sensors": self._get_sensor_info()
        }

        # Network Information
        network_info = {
            "interfaces": self._get_network_interfaces(),
            "connections": self._get_network_connections(),
            "io_stats": psutil.net_io_counters()._asdict(),
            "wifi_networks": self._get_wifi_networks(),
            "mac_addresses": self._get_mac_addresses()
        }

        # Software Information
        software_info = {
            "installed_programs": self._get_installed_programs(),
            "running_processes": self._get_running_processes(),
            "services": self._get_services(),
            "startup_programs": self._get_startup_programs(),
            "scheduled_tasks": self._get_scheduled_tasks(),
            "environment_variables": dict(os.environ)
        }

        # Security Information
        security_info = {
            "firewall_status": self._get_firewall_status(),
            "antivirus_status": self._get_antivirus_status(),
            "user_accounts": self._get_user_accounts(),
            "shared_folders": self._get_shared_folders(),
            "system_updates": self._get_system_updates(),
            "security_patches": self._get_security_patches()
        }

        # Performance Information
        performance_info = {
            "cpu_percent": psutil.cpu_percent(interval=1),
            "memory_percent": psutil.virtual_memory().percent,
            "disk_usage": self._get_disk_usage_percent(),
            "network_usage": self._get_network_usage()
        }

        return SystemInfo(
            os_info=os_info,
            hardware_info=hardware_info,
            network_info=network_info,
            software_info=software_info,
            security_info=security_info,
            performance_info=performance_info
        )

    def execute_system_command(self, command: str, admin_required: bool = False,
                              timeout: int = 30, capture_output: bool = True) -> Dict[str, Any]:
        """Execute a system command with proper permissions and logging."""
        # Log the command
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "command": command,
            "admin_required": admin_required,
            "user": os.getenv("USERNAME", "unknown"),
            "platform": self.platform
        }

        try:
            # Check if admin is required and available
            if admin_required and not self.is_admin:
                return {
                    "success": False,
                    "error": "Administrative privileges required for this command",
                    "admin_required": True
                }

            # Execute the command
            result = run_command_safely(
                command,
                timeout=timeout,
                capture_output=capture_output,
                shell=True
            )

            # Log the result
            log_entry.update({
                "success": result["success"],
                "returncode": result.get("returncode"),
                "duration": result.get("duration", 0)
            })

            self.admin_actions_log.append(log_entry)
            return result

        except Exception as e:
            log_entry.update({
                "success": False,
                "error": str(e)
            })
            self.admin_actions_log.append(log_entry)

            return {
                "success": False,
                "error": str(e)
            }

    # File Operations
    def create_file(self, path: str, content: str = "", encoding: str = "utf-8") -> Dict[str, Any]:
        """Create a file with specified content."""
        try:
            file_path = Path(path)
            file_path.parent.mkdir(parents=True, exist_ok=True)

            with open(file_path, 'w', encoding=encoding) as f:
                f.write(content)

            return {
                "success": True,
                "message": f"File created: {path}",
                "path": str(file_path),
                "size": len(content.encode(encoding))
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def read_file(self, path: str, encoding: str = "utf-8") -> Dict[str, Any]:
        """Read file contents."""
        try:
            with open(path, 'r', encoding=encoding) as f:
                content = f.read()

            return {
                "success": True,
                "content": content,
                "size": len(content.encode(encoding)),
                "encoding": encoding
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def write_file(self, path: str, content: str, encoding: str = "utf-8") -> Dict[str, Any]:
        """Write content to a file."""
        return self.create_file(path, content, encoding)

    def copy_file(self, source: str, destination: str) -> Dict[str, Any]:
        """Copy a file."""
        try:
            shutil.copy2(source, destination)
            return {
                "success": True,
                "message": f"File copied from {source} to {destination}"
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def move_file(self, source: str, destination: str) -> Dict[str, Any]:
        """Move a file."""
        try:
            shutil.move(source, destination)
            return {
                "success": True,
                "message": f"File moved from {source} to {destination}"
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def delete_file(self, path: str) -> Dict[str, Any]:
        """Delete a file."""
        try:
            Path(path).unlink()
            return {"success": True, "message": f"File deleted: {path}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def create_directory(self, path: str) -> Dict[str, Any]:
        """Create a directory."""
        try:
            Path(path).mkdir(parents=True, exist_ok=True)
            return {"success": True, "message": f"Directory created: {path}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def delete_directory(self, path: str, recursive: bool = False) -> Dict[str, Any]:
        """Delete a directory."""
        try:
            dir_path = Path(path)
            if recursive:
                shutil.rmtree(dir_path)
            else:
                dir_path.rmdir()
            return {"success": True, "message": f"Directory deleted: {path}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def list_directory(self, path: str = ".", show_hidden: bool = False) -> Dict[str, Any]:
        """List directory contents."""
        try:
            dir_path = Path(path)
            if not dir_path.exists():
                return {"success": False, "error": f"Directory not found: {path}"}

            items = []
            for item in dir_path.iterdir():
                if not show_hidden and item.name.startswith('.'):
                    continue

                item_info = {
                    "name": item.name,
                    "path": str(item),
                    "is_file": item.is_file(),
                    "is_directory": item.is_dir(),
                    "size": item.stat().st_size if item.is_file() else 0,
                    "modified": item.stat().st_mtime,
                    "permissions": oct(item.stat().st_mode)[-3:]
                }
                items.append(item_info)

            return {
                "success": True,
                "items": items,
                "count": len(items),
                "path": str(dir_path)
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    # Application Control
    def install_program(self, installer_path: str, silent: bool = True) -> Dict[str, Any]:
        """Install a program."""
        try:
            if self.platform == "Windows":
                if installer_path.endswith('.exe'):
                    if silent:
                        command = f'"{installer_path}" /S'
                    else:
                        command = f'"{installer_path}"'
                else:
                    return {"success": False, "error": "Unsupported installer format"}

                result = self.execute_system_command(command)
                return result
            else:
                return {"success": False, "error": "Platform not supported"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def uninstall_program(self, program_name: str) -> Dict[str, Any]:
        """Uninstall a program."""
        try:
            if self.platform == "Windows":
                # Try Windows uninstaller
                uninstall_string = self._find_windows_uninstall_string(program_name)
                if uninstall_string:
                    result = self.execute_system_command(uninstall_string)
                    return result
                else:
                    return {"success": False, "error": f"Program not found: {program_name}"}
            else:
                return {"success": False, "error": "Platform not supported"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def open_application(self, app_name: str) -> Dict[str, Any]:
        """Open an application."""
        try:
            if self.platform == "Windows":
                # Try to find application in common locations
                app_paths = [
                    f"C:\\Program Files\\{app_name}\\{app_name}.exe",
                    f"C:\\Program Files (x86)\\{app_name}\\{app_name}.exe",
                    f"C:\\Windows\\System32\\{app_name}.exe"
                ]

                for app_path in app_paths:
                    if Path(app_path).exists():
                        subprocess.Popen([app_path])
                        return {"success": True, "message": f"Opened {app_name}"}

                # Try system PATH
                result = self.execute_system_command(app_name, capture_output=False)
                return result
            else:
                result = self.execute_system_command(app_name, capture_output=False)
                return result
        except Exception as e:
            return {"success": False, "error": str(e)}

    def close_application(self, app_name: str, force: bool = False) -> Dict[str, Any]:
        """Close an application."""
        try:
            terminated = False
            for proc in psutil.process_iter(['pid', 'name']):
                if app_name.lower() in proc.info['name'].lower():
                    if force:
                        proc.kill()
                    else:
                        proc.terminate()
                    terminated = True
                    break

            if terminated:
                return {"success": True, "message": f"Closed {app_name}"}
            else:
                return {"success": False, "error": f"Application not found: {app_name}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # System Settings Control
    def set_volume(self, level: int) -> Dict[str, Any]:
        """Set system volume level (0-100)."""
        try:
            if self.platform == "Windows":
                # Use PowerShell to set volume
                command = f"powershell -Command \"(New-Object -comObject WScript.Shell).SendKeys([char]175); (New-Object -comObject WScript.Shell).SendKeys('{level}'); (New-Object -comObject WScript.Shell).SendKeys([char]175)\""
                result = self.execute_system_command(command)
                return result
            else:
                return {"success": False, "error": "Platform not supported"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def set_brightness(self, level: int) -> Dict[str, Any]:
        """Set screen brightness (0-100)."""
        try:
            if self.platform == "Windows":
                # Use PowerShell to set brightness
                command = f"powershell -Command \"(Get-WmiObject -Namespace root/wmi -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1, {level})\""
                result = self.execute_system_command(command)
                return result
            else:
                return {"success": False, "error": "Platform not supported"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def toggle_wifi(self, enable: bool = None) -> Dict[str, Any]:
        """Toggle or get Wi-Fi status."""
        try:
            if self.platform == "Windows":
                if enable is True:
                    command = "netsh interface set interface \"Wi-Fi\" enable"
                elif enable is False:
                    command = "netsh interface set interface \"Wi-Fi\" disable"
                else:
                    command = "netsh interface show interface \"Wi-Fi\""

                result = self.execute_system_command(command)
                return result
            else:
                return {"success": False, "error": "Platform not supported"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def create_system_restore_point(self, description: str) -> Dict[str, Any]:
        """Create a system restore point."""
        try:
            if self.platform == "Windows" and self.is_admin:
                # PowerShell command to create restore point
                command = f"powershell -Command \"Checkpoint-Computer -Description '{description}'\""
                result = self.execute_system_command(command)
                return result
            else:
                return {"success": False, "error": "Requires Windows and admin privileges"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def run_system_update(self, check_only: bool = False) -> Dict[str, Any]:
        """Run system updates."""
        try:
            if self.platform == "Windows":
                if check_only:
                    command = "wuauclt /detectnow"
                else:
                    command = "wuauclt /detectnow && wuauclt /updatenow"
            else:
                return {"success": False, "error": "Platform not supported"}

            result = self.execute_system_command(command, timeout=300)
            return result
        except Exception as e:
            return {"success": False, "error": str(e)}

    # Network Configuration
    def get_network_interfaces(self) -> Dict[str, Any]:
        """Get detailed network interface information."""
        return {"success": True, "interfaces": self._get_network_interfaces()}

    def connect_to_wifi(self, ssid: str, password: str = "") -> Dict[str, Any]:
        """Connect to Wi-Fi network."""
        try:
            if self.platform == "Windows":
                if password:
                    profile = f'netsh wlan add profile filename="temp_profile.xml" interface="Wi-Fi"'
                    # Create profile XML and connect
                    command = f'netsh wlan connect name="{ssid}"'
                else:
                    command = f'netsh wlan connect name="{ssid}"'

                result = self.execute_system_command(command)
                return result
            else:
                return {"success": False, "error": "Platform not supported"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # User Management
    def create_user_account(self, username: str, password: str, admin: bool = False) -> Dict[str, Any]:
        """Create a new user account."""
        try:
            if self.platform == "Windows" and self.is_admin:
                if admin:
                    command = f"net user {username} {password} /add /active:yes /expires:never"
                    # Add to administrators group
                    command += f" && net localgroup Administrators {username} /add"
                else:
                    command = f"net user {username} {password} /add /active:yes /expires:never"

                result = self.execute_system_command(command)
                return result
            else:
                return {"success": False, "error": "Requires Windows and admin privileges"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def change_user_password(self, username: str, new_password: str) -> Dict[str, Any]:
        """Change user password."""
        try:
            if self.platform == "Windows" and self.is_admin:
                command = f"net user {username} {new_password}"
                result = self.execute_system_command(command)
                return result
            else:
                return {"success": False, "error": "Requires Windows and admin privileges"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # Security Functions
    def scan_for_viruses(self, path: str = None) -> Dict[str, Any]:
        """Scan for viruses (requires Windows Defender or other antivirus)."""
        try:
            if path:
                command = f"powershell -Command \"Start-MpScan -ScanPath '{path}' -ScanType CustomScan\""
            else:
                command = "powershell -Command \"Start-MpScan -ScanType QuickScan\""

            result = self.execute_system_command(command, timeout=300)
            return result
        except Exception as e:
            return {"success": False, "error": str(e)}

    def configure_firewall(self, action: str, rule: Dict[str, Any] = None) -> Dict[str, Any]:
        """Configure Windows Firewall."""
        try:
            if self.platform == "Windows" and self.is_admin:
                if action == "add_rule" and rule:
                    rule_name = rule.get("name", "New Rule")
                    rule_action = rule.get("action", "allow")
                    program = rule.get("program", "any")
                    protocol = rule.get("protocol", "any")
                    local_port = rule.get("local_port", "any")
                    remote_port = rule.get("remote_port", "any")
                    local_address = rule.get("local_address", "any")
                    remote_address = rule.get("remote_address", "any")

                    command = f"netsh advfirewall firewall add rule name=\"{rule_name}\" dir=in action={rule_action} program=\"{program}\" protocol={protocol} localport={local_port} remoteport={remote_port} localaddress={local_address} remoteaddress={remote_address}"
                else:
                    return {"success": False, "error": "Invalid firewall action"}

                result = self.execute_system_command(command)
                return result
            else:
                return {"success": False, "error": "Requires Windows and admin privileges"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # Advanced Functions
    def schedule_task(self, task_name: str, command: str, trigger: str,
                       time: str = None) -> Dict[str, Any]:
        """Schedule a task."""
        try:
            if self.platform == "Windows":
                if trigger == "daily":
                    trigger_type = f"/DAILY /SC START /ST {time or '09:00'}"
                elif trigger == "weekly":
                    trigger_type = "/WEEKLY /SC START"
                elif trigger == "startup":
                    trigger_type = "/SC ONSTART"
                else:
                    return {"success": False, "error": "Invalid trigger type"}

                command = f'schtasks /create /tn "{task_name}" /tr "{command}" {trigger_type}'
                result = self.execute_system_command(command)
                return result
            else:
                return {"success": False, "error": "Platform not supported"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_system_logs(self, log_type: str = "system", lines: int = 100) -> Dict[str, Any]:
        """Get system logs."""
        try:
            if self.platform == "Windows":
                if log_type == "system":
                    command = f"Get-EventLog -LogName System -Newest {lines}"
                elif log_type == "application":
                    command = f"Get-EventLog -LogName Application -Newest {lines}"
                elif log_type == "security":
                    command = f"Get-EventLog -LogName Security -Newest {lines}"
                else:
                    return {"success": False, "error": "Invalid log type"}

                result = self.execute_system_command(f"powershell -Command \"{command}\"")
                return result
            else:
                return {"success": False, "error": "Platform not supported"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # Helper methods
    def _get_battery_info(self) -> Optional[Dict[str, Any]]:
        """Get battery information."""
        if hasattr(psutil, "sensors_battery"):
            battery = psutil.sensors_battery()
            if battery:
                return {
                    "percent": battery.percent,
                    "power_plugged": battery.power_plugged,
                    "seconds_left": battery.secsleft
                }
        return None

    def _get_temperature_info(self) -> Dict[str, Any]:
        """Get temperature information."""
        if hasattr(psutil, "sensors_temperatures"):
            temps = psutil.sensors_temperatures()
            return {f"{name}_{label}": temp.current for name, entries in temps.items() for label, temp in entries.items()}
        return {}

    def _get_sensor_info(self) -> Dict[str, Any]:
        """Get sensor information."""
        if hasattr(psutil, "sensors_fans"):
            fans = psutil.sensors_fans()
            return {f"{name}_{label}": fan.current for name, entries in fans.items() for label, fan in entries.items()}
        return {}

    def _get_network_interfaces(self) -> Dict[str, Any]:
        """Get network interface information."""
        interfaces = {}
        for name, addrs in psutil.net_if_addrs().items():
            interfaces[name] = {
                "addresses": [{"family": addr.family.name, "address": addr.address, "netmask": addr.netmask} for addr in addrs],
                "stats": psutil.net_if_stats(name)._asdict()
            }
        return interfaces

    def _get_network_connections(self) -> List[Dict[str, Any]]:
        """Get network connections."""
        connections = []
        for conn in psutil.net_connections():
            connections.append({
                "local_address": f"{conn.laddr.ip}:{conn.laddr.port}",
                "remote_address": f"{conn.raddr.ip}:{conn.raddr.port}" if conn.raddr else None,
                "status": conn.status,
                "pid": conn.pid
            })
        return connections

    def _get_wifi_networks(self) -> List[str]:
        """Get available Wi-Fi networks."""
        try:
            if self.platform == "Windows":
                result = self.execute_system_command("netsh wlan show networks", capture_output=True)
                if result["success"]:
                    networks = []
                    for line in result.get("stdout", "").split('\n'):
                        if "SSID" in line:
                            ssid = line.split(':')[-1].strip()
                            if ssid:
                                networks.append(ssid)
                    return networks
        except Exception:
            pass
        return []

    def _get_mac_addresses(self) -> Dict[str, str]:
        """Get MAC addresses for network interfaces."""
        mac_addresses = {}
        for name, addrs in psutil.net_if_addrs().items():
            for addr in addrs:
                if addr.family == psutil.AF_LINK:
                    mac_addresses[name] = addr.address
                    break
        return mac_addresses

    def _get_installed_programs(self) -> List[Dict[str, Any]]:
        """Get list of installed programs."""
        programs = []
        try:
            if self.platform == "Windows":
                # Get from registry
                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall")
                try:
                    for i in range(winreg.QueryInfoKey(key)[0]):
                        try:
                            subkey_name = winreg.EnumKey(key, i)
                            subkey = winreg.OpenKey(key, subkey_name)
                            try:
                                name = winreg.QueryValueEx(subkey, "DisplayName")[0]
                                version = winreg.QueryValueEx(subkey, "DisplayVersion")[0]
                                programs.append({
                                    "name": name,
                                    "version": version,
                                    "key_name": subkey_name
                                })
                            except (FileNotFoundError, OSError):
                                continue
                            finally:
                                winreg.CloseKey(subkey)
                        except OSError:
                            continue
                finally:
                    winreg.CloseKey(key)
        except Exception:
            pass
        return programs

    def _get_running_processes(self) -> List[Dict[str, Any]]:
        """Get running processes."""
        processes = []
        for proc in psutil.process_iter(['pid', 'name', 'username', 'cpu_percent', 'memory_percent']):
            try:
                processes.append({
                    "pid": proc.info['pid'],
                    "name": proc.info['name'],
                    "username": proc.info.get('username', 'N/A'),
                    "cpu_percent": proc.info.get('cpu_percent', 0),
                    "memory_percent": proc.info.get('memory_percent', 0)
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return processes

    def _get_services(self) -> List[Dict[str, Any]]:
        """Get system services."""
        services = []
        try:
            if self.platform == "Windows":
                result = self.execute_system_command("sc query type= service state= all", capture_output=True)
                if result["success"]:
                    for line in result.get("stdout", "").split('\n'):
                        if line.startswith('SERVICE_NAME:'):
                            services.append({"name": line.split(':')[-1].strip()})
        except Exception:
            pass
        return services

    def _get_startup_programs(self) -> List[Dict[str, Any]]:
        """Get startup programs."""
        startup = []
        try:
            if self.platform == "Windows":
                # Check registry startup locations
                for reg_path in [
                    r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
                    r"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce"
                ]:
                    try:
                        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, reg_path)
                        try:
                            for i in range(winreg.QueryInfoKey(key)[0]):
                                try:
                                    name, value, _ = winreg.EnumValue(key, i)
                                    startup.append({"name": name, "path": value, "hive": "HKLM"})
                                except OSError:
                                    continue
                        finally:
                            winreg.CloseKey(key)
                    except OSError:
                        continue
        except Exception:
            pass
        return startup

    def _get_scheduled_tasks(self) -> List[Dict[str, Any]]:
        """Get scheduled tasks."""
        tasks = []
        try:
            if self.platform == "Windows":
                result = self.execute_system_command("schtasks /query /fo LIST", capture_output=True)
                if result["success"]:
                    lines = result.get("stdout", "").split('\n')
                    for line in lines:
                        if line and not line.startswith('TaskName'):
                            parts = line.split()
                            if len(parts) >= 2:
                                tasks.append({"name": parts[0], "status": parts[1]})
        except Exception:
            pass
        return tasks

    def _get_firewall_status(self) -> Dict[str, Any]:
        """Get firewall status."""
        try:
            if self.platform == "Windows":
                result = self.execute_system_command("netsh advfirewall show allprofiles", capture_output=True)
                return {"enabled": "on" in result.get("stdout", "").lower()}
        except Exception:
            pass
        return {"enabled": False}

    def _get_antivirus_status(self) -> Dict[str, Any]:
        """Get antivirus status."""
        try:
            if self.platform == "Windows":
                result = self.execute_system_command("powershell -Command \"Get-MpComputerStatus\"", capture_output=True)
                return {"enabled": result["success"]}
        except Exception:
            pass
        return {"enabled": False}

    def _get_user_accounts(self) -> List[Dict[str, Any]]:
        """Get user accounts."""
        users = []
        try:
            if self.platform == "Windows":
                result = self.execute_system_command("net user", capture_output=True)
                if result["success"]:
                    lines = result.get("stdout", "").split('\n')
                    for line in lines:
                        if line and not line.startswith('-') and not line.startswith('The command completed'):
                            parts = line.split()
                            if len(parts) >= 1:
                                users.append({"username": parts[0]})
        except Exception:
            pass
        return users

    def _get_shared_folders(self) -> List[Dict[str, Any]]:
        """Get shared folders."""
        shared = []
        try:
            if self.platform == "Windows":
                result = self.execute_system_command("net share", capture_output=True)
                if result["success"]:
                    lines = result.get("stdout", "").split('\n')
                    for line in lines:
                        if line and not line.startswith('-') and not line.startswith('The command completed'):
                            parts = line.split()
                            if len(parts) >= 3:
                                shared.append({
                                    "name": parts[0],
                                    "path": parts[1],
                                    "type": parts[2]
                                })
        except Exception:
            pass
        return shared

    def _get_system_updates(self) -> Dict[str, Any]:
        """Get system update information."""
        try:
            if self.platform == "Windows":
                result = self.execute_system_command("wuauclt /detectnow /showwindow", capture_output=True)
                return {"update_check": "completed"}
        except Exception:
            pass
        return {"update_check": "not_available"}

    def _get_security_patches(self) -> List[Dict[str, Any]]:
        """Get security patches."""
        patches = []
        try:
            if self.platform == "Windows":
                result = self.execute_system_command("wmic qfe list", capture_output=True)
                if result["success"]:
                    lines = result.get("stdout", "").split('\n')
                    for line in lines:
                        if line and 'KB' in line:
                            parts = line.split()
                            for part in parts:
                                if part.startswith('KB'):
                                    patches.append({"kb": part})
        except Exception:
            pass
        return patches

    def _get_disk_usage_percent(self) -> Dict[str, float]:
        """Get disk usage percentages."""
        usage = {}
        for partition in psutil.disk_partitions():
            try:
                disk = psutil.disk_usage(partition.mountpoint)
                usage[partition.device] = (disk.used / disk.total) * 100
            except Exception:
                continue
        return usage

    def _get_network_usage(self) -> Dict[str, Any]:
        """Get network usage."""
        net_io = psutil.net_io_counters()
        return {
            "bytes_sent": net_io.bytes_sent,
            "bytes_recv": net_io.bytes_recv,
            "packets_sent": net_io.packets_sent,
            "packets_recv": net_io.packets_recv,
            "error_in": net_io.errin,
            "error_out": net_io.errout,
            "drop_in": net_io.dropin,
            "drop_out": net_io.dropout
        }

    def _find_windows_uninstall_string(self, program_name: str) -> Optional[str]:
        """Find Windows uninstall string for a program."""
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall")
            try:
                for i in range(winreg.QueryInfoKey(key)[0]):
                    try:
                        subkey_name = winreg.EnumKey(key, i)
                        subkey = winreg.OpenKey(key, subkey_name)
                        try:
                            display_name = winreg.QueryValueEx(subkey, "DisplayName")[0]
                            if program_name.lower() in display_name.lower():
                                uninstall_string = winreg.QueryValueEx(subkey, "UninstallString")[0]
                                return uninstall_string
                        except FileNotFoundError:
                            continue
                        finally:
                            winreg.CloseKey(subkey)
                    except OSError:
                        continue
            finally:
                winreg.CloseKey(key)
        except Exception:
            pass
        return None

    def get_action_log(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get action log."""
        return self.admin_actions_log[-limit:] if limit > 0 else self.admin_actions_log

    def clear_action_log(self) -> bool:
        """Clear action log."""
        try:
            self.admin_actions_log.clear()
            return True
        except Exception:
            return False

    def export_system_info(self, format: str = "json") -> Dict[str, Any]:
        """Export system information."""
        try:
            if format.lower() == "json":
                return {
                    "success": True,
                    "data": {
                        "os_info": self.system_info.os_info,
                        "hardware_info": self.system_info.hardware_info,
                        "network_info": self.system_info.network_info,
                        "software_info": self.system_info.software_info,
                        "security_info": self.system_info.security_info,
                        "performance_info": self.system_info.performance_info
                    }
                }
            else:
                return {"success": False, "error": f"Format {format} not supported"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # Additional methods for integration with main application
    def launch_application(self, app_name: str) -> Dict[str, Any]:
        """Launch application (alias for open_application)."""
        return self.open_application(app_name)

    def get_system_overview(self) -> Dict[str, Any]:
        """Get system overview with key metrics."""
        try:
            overview = {
                "os": f"{self.system_info.os_info['platform']} {self.system_info.os_info['platform_release']}",
                "cpu_count": self.system_info.hardware_info['cpu_count'],
                "memory_total": f"{self.system_info.hardware_info['memory_total'] / (1024**3):.1f} GB",
                "cpu_usage": f"{self.system_info.performance_info['cpu_percent']:.1f}%",
                "memory_usage": f"{self.system_info.performance_info['memory_percent']:.1f}%",
                "hostname": self.system_info.os_info['hostname'],
                "uptime": str(datetime.now() - datetime.fromtimestamp(psutil.boot_time())).split('.')[0]
            }

            return {
                "success": True,
                "message": f"System: {overview['os']}, CPU: {overview['cpu_count']} cores, Memory: {overview['memory_total']}, CPU Usage: {overview['cpu_usage']}, Memory Usage: {overview['memory_usage']}"
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_running_processes(self) -> Dict[str, Any]:
        """Get list of running processes."""
        try:
            processes = self._get_running_processes()[:20]  # Limit to first 20
            process_list = [f"{p['name']} (PID: {p['pid']}, CPU: {p.get('cpu_percent', 0):.1f}%)" for p in processes]

            return {
                "success": True,
                "message": f"Running processes:\n" + "\n".join(process_list)
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_system_services(self) -> Dict[str, Any]:
        """Get system services status."""
        try:
            services = self._get_services()[:10]  # Limit to first 10
            service_list = [f"- {s['name']}" for s in services]

            return {
                "success": True,
                "message": f"System services:\n" + "\n".join(service_list) if service_list else "No services found"
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_hardware_info(self) -> Dict[str, Any]:
        """Get hardware information."""
        try:
            hw = self.system_info.hardware_info
            info = [
                f"CPU: {hw['cpu_count']} cores ({hw.get('cpu_count', 'Unknown')} physical)",
                f"Memory: {hw['memory_total'] / (1024**3):.1f} GB total",
                f"Disk partitions: {len(hw['disk_partitions'])}",
                f"Battery: {hw.get('battery', {}).get('percent', 'N/A')}% available" if hw.get('battery') else "No battery"
            ]

            return {
                "success": True,
                "message": "Hardware information:\n" + "\n".join(info)
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def ping_host(self, target: str) -> Dict[str, Any]:
        """Ping a host."""
        try:
            command = f"ping -n 4 {target}" if self.platform == "Windows" else f"ping -c 4 {target}"
            result = self.execute_system_command(command)

            if result["success"]:
                return {
                    "success": True,
                    "message": f"Ping to {target} completed successfully"
                }
            else:
                return {
                    "success": False,
                    "error": f"Ping to {target} failed: {result.get('error', 'Unknown error')}"
                }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def scan_network(self) -> Dict[str, Any]:
        """Scan local network."""
        try:
            if self.platform == "Windows":
                command = "arp -a"
            else:
                command = "arp -n"

            result = self.execute_system_command(command)

            if result["success"]:
                return {
                    "success": True,
                    "message": "Network scan completed. Check ARP table for connected devices."
                }
            else:
                return {
                    "success": False,
                    "error": f"Network scan failed: {result.get('error', 'Unknown error')}"
                }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def measure_network_speed(self) -> Dict[str, Any]:
        """Measure network speed (basic implementation)."""
        try:
            # Get current network stats and wait a moment
            net_io1 = psutil.net_io_counters()
            import time
            time.sleep(1)
            net_io2 = psutil.net_io_counters()

            bytes_sent_diff = net_io2.bytes_sent - net_io1.bytes_sent
            bytes_recv_diff = net_io2.bytes_recv - net_io1.bytes_recv

            return {
                "success": True,
                "message": f"Network speed: {bytes_sent_diff} bytes/s sent, {bytes_recv_diff} bytes/s received"
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_network_info(self) -> Dict[str, Any]:
        """Get network information."""
        try:
            interfaces = self.system_info.network_info['interfaces']
            interface_list = []

            for name, info in interfaces.items():
                status = "UP" if info['stats']['isup'] else "DOWN"
                interface_list.append(f"- {name}: {status}")

            return {
                "success": True,
                "message": f"Network interfaces:\n" + "\n".join(interface_list)
            }
        except Exception as e:
            return {"success": False, "error": str(e)}