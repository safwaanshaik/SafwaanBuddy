#!/usr/bin/env python3
"""
UI Automation Module for Safwaan Buddy
Provides cross-platform UI automation capabilities with safety features.
"""

import time
import subprocess
import threading
from typing import Dict, List, Any, Optional, Tuple, Callable
from pathlib import Path
from dataclasses import dataclass
from enum import Enum

import pyautogui
import pyperclip

from config import get_config
from utils.logger import get_logger
from utils.helpers import validate_coordinates, is_admin, format_duration

logger = get_logger("ui_automation")


class AutomationError(Exception):
    """Custom exception for UI automation errors."""
    pass


class SafetyLevel(Enum):
    """Safety levels for UI automation."""
    SAFE = "safe"           # Basic operations only
    NORMAL = "normal"       # Standard operations with confirmation
    ADVANCED = "advanced"   # All operations with minimal restrictions


@dataclass
class AutomationResult:
    """Result of an automation operation."""
    success: bool
    operation: str
    message: str
    data: Any = None
    execution_time: float = 0.0
    screenshot_path: Optional[str] = None


class UIAutomation:
    """Advanced UI automation with safety features and error handling."""

    def __init__(self, safety_level: SafetyLevel = SafetyLevel.NORMAL):
        """
        Initialize UI automation.

        Args:
            safety_level: Safety level for automation operations
        """
        self.safety_level = safety_level
        self.config = get_config()
        self.operation_history: List[Dict[str, Any]] = []
        self.screenshot_dir = Path("data/screenshots")

        # Safety settings
        self.confirm_dangerous_operations = safety_level != SafetyLevel.ADVANCED
        self.operation_timeout = 30.0
        self.max_execution_time = 300.0  # 5 minutes max per operation
        self.enabled = self.config.get("enable_ui_automation", True)

        # PyAutoGUI configuration
        pyautogui.PAUSE = 0.1  # Small pause between operations
        pyautogui.FAILSAFE = True  # Move mouse to corner to abort

        # Ensure screenshot directory exists
        self.screenshot_dir.mkdir(parents=True, exist_ok=True)

        # Statistics
        self.operation_count = 0
        self.success_count = 0
        self.error_count = 0

        logger.info(f"UIAutomation initialized with safety level: {safety_level.value}")

    def _check_enabled(self) -> bool:
        """Check if UI automation is enabled."""
        if not self.enabled:
            logger.warning("UI automation is disabled")
            return False
        return True

    def _log_operation(self, operation: str, success: bool, execution_time: float,
                      message: str, data: Any = None):
        """Log operation details."""
        self.operation_count += 1

        if success:
            self.success_count += 1
        else:
            self.error_count += 1

        operation_record = {
            "timestamp": time.time(),
            "operation": operation,
            "success": success,
            "execution_time": execution_time,
            "message": message,
            "data": data
        }

        self.operation_history.append(operation_record)

        # Keep only last 100 operations
        if len(self.operation_history) > 100:
            self.operation_history = self.operation_history[-100:]

        logger.info(f"Operation {operation}: {'SUCCESS' if success else 'FAILED'} "
                   f"({execution_time:.2f}s) - {message}")

    def _execute_with_timeout(self, operation: Callable, operation_name: str,
                             timeout: float = None, *args, **kwargs) -> Any:
        """Execute operation with timeout and safety checks."""
        if not self._check_enabled():
            return AutomationResult(
                success=False,
                operation=operation_name,
                message="UI automation is disabled"
            )

        timeout = timeout or self.operation_timeout
        start_time = time.time()

        try:
            # Execute operation in thread with timeout
            result_container = []

            def operation_wrapper():
                result_container.append(operation(*args, **kwargs))

            thread = threading.Thread(target=operation_wrapper)
            thread.daemon = True
            thread.start()
            thread.join(timeout=timeout)

            if thread.is_alive():
                # Operation timed out
                execution_time = time.time() - start_time
                error_msg = f"Operation {operation_name} timed out after {timeout}s"
                self._log_operation(operation_name, False, execution_time, error_msg)
                return AutomationResult(
                    success=False,
                    operation=operation_name,
                    message=error_msg,
                    execution_time=execution_time
                )

            execution_time = time.time() - start_time
            result = result_container[0] if result_container else None

            # Create success result
            success_msg = f"Operation {operation_name} completed successfully"
            self._log_operation(operation_name, True, execution_time, success_msg, result)

            return AutomationResult(
                success=True,
                operation=operation_name,
                message=success_msg,
                data=result,
                execution_time=execution_time
            )

        except Exception as e:
            execution_time = time.time() - start_time
            error_msg = f"Operation {operation_name} failed: {str(e)}"
            self._log_operation(operation_name, False, execution_time, error_msg)
            return AutomationResult(
                success=False,
                operation=operation_name,
                message=error_msg,
                execution_time=execution_time
            )

    def type_text(self, text: str, delay: float = 0.05, interval: float = 0.01) -> AutomationResult:
        """
        Type text into currently focused window.

        Args:
            text: Text to type
            delay: Initial delay before typing
            interval: Delay between keystrokes
        """
        def operation():
            if not text.strip():
                raise AutomationError("Cannot type empty text")

            # Add initial delay
            if delay > 0:
                time.sleep(delay)

            # Type the text with interval
            pyautogui.typewrite(text, interval=interval)

            return f"Typed {len(text)} characters"

        return self._execute_with_timeout(operation, "type_text", timeout=len(text) * 0.1 + 5)

    def press_key(self, key: str, presses: int = 1, interval: float = 0.1) -> AutomationResult:
        """
        Press keyboard key(s).

        Args:
            key: Key to press (e.g., 'enter', 'ctrl+c')
            presses: Number of times to press
            interval: Interval between presses
        """
        def operation():
            if not key.strip():
                raise AutomationError("Invalid key specified")

            pyautogui.press(key, presses=presses, interval=interval)
            return f"Pressed {key} {presses} time(s)"

        return self._execute_with_timeout(operation, "press_key", timeout=5)

    def hotkey(self, *keys, interval: float = 0.1) -> AutomationResult:
        """
        Press multiple keys together (hotkey combination).

        Args:
            *keys: Keys to press together
            interval: Interval between key presses
        """
        def operation():
            if not keys or len(keys) < 2:
                raise AutomationError("Hotkey requires at least 2 keys")

            key_combo = '+'.join(keys)
            pyautogui.hotkey(*keys, interval=interval)
            return f"Pressed hotkey: {key_combo}"

        return self._execute_with_timeout(operation, "hotkey", timeout=5)

    def click(self, x: int, y: int, button: str = "left", clicks: int = 1,
              interval: float = 0.1) -> AutomationResult:
        """
        Click at specific coordinates.

        Args:
            x: X coordinate
            y: Y coordinate
            button: Mouse button ('left', 'right', 'middle')
            clicks: Number of clicks
            interval: Interval between clicks
        """
        def operation():
            # Validate coordinates
            screen_width, screen_height = pyautogui.size()
            if not validate_coordinates(x, y, (screen_width, screen_height)):
                raise AutomationError(f"Invalid coordinates: ({x}, {y})")

            # Move to position and click
            pyautogui.moveTo(x, y, duration=0.3)
            pyautogui.click(x, y, button=button, clicks=clicks, interval=interval)

            return f"Clicked at ({x}, {y}) with {button} button"

        return self._execute_with_timeout(operation, "click", timeout=5)

    def double_click(self, x: int, y: int, interval: float = 0.1) -> AutomationResult:
        """Double click at specific coordinates."""
        return self.click(x, y, clicks=2, interval=interval)

    def right_click(self, x: int, y: int) -> AutomationResult:
        """Right click at specific coordinates."""
        return self.click(x, y, button="right")

    def move_mouse(self, x: int, y: int, duration: float = 0.3) -> AutomationResult:
        """
        Move mouse to specific coordinates.

        Args:
            x: X coordinate
            y: Y coordinate
            duration: Movement duration in seconds
        """
        def operation():
            # Validate coordinates
            screen_width, screen_height = pyautogui.size()
            if not validate_coordinates(x, y, (screen_width, screen_height)):
                raise AutomationError(f"Invalid coordinates: ({x}, {y})")

            pyautogui.moveTo(x, y, duration=duration)
            return f"Moved mouse to ({x}, {y})"

        return self._execute_with_timeout(operation, "move_mouse", timeout=5)

    def drag(self, start_x: int, start_y: int, end_x: int, end_y: int,
             duration: float = 0.5, button: str = "left") -> AutomationResult:
        """
        Drag mouse from start to end position.

        Args:
            start_x: Starting X coordinate
            start_y: Starting Y coordinate
            end_x: Ending X coordinate
            end_y: Ending Y coordinate
            duration: Drag duration
            button: Mouse button to use
        """
        def operation():
            # Validate coordinates
            screen_width, screen_height = pyautogui.size()
            if not all(validate_coordinates(x, y, (screen_width, screen_height))
                      for x, y in [(start_x, start_y), (end_x, end_y)]):
                raise AutomationError("Invalid drag coordinates")

            pyautogui.dragTo(end_x, end_y, duration=duration, button=button)
            return f"Dragged from ({start_x}, {start_y}) to ({end_x}, {end_y})"

        return self._execute_with_timeout(operation, "drag", timeout=10)

    def scroll(self, clicks: int, x: Optional[int] = None, y: Optional[int] = None) -> AutomationResult:
        """
        Scroll mouse wheel.

        Args:
            clicks: Number of scroll clicks (positive for up, negative for down)
            x: X coordinate to scroll at (optional)
            y: Y coordinate to scroll at (optional)
        """
        def operation():
            if x is not None and y is not None:
                screen_width, screen_height = pyautogui.size()
                if not validate_coordinates(x, y, (screen_width, screen_height)):
                    raise AutomationError(f"Invalid scroll coordinates: ({x}, {y})")

                pyautogui.scroll(clicks, x=x, y=y)
                return f"Scrolled {clicks} clicks at ({x}, {y})"
            else:
                pyautogui.scroll(clicks)
                return f"Scrolled {clicks} clicks"

        return self._execute_with_timeout(operation, "scroll", timeout=5)

    def get_clipboard(self) -> AutomationResult:
        """Get current clipboard contents."""
        def operation():
            try:
                clipboard_content = pyperclip.paste()
                return clipboard_content
            except Exception as e:
                raise AutomationError(f"Failed to get clipboard: {e}")

        return self._execute_with_timeout(operation, "get_clipboard", timeout=3)

    def set_clipboard(self, text: str) -> AutomationResult:
        """Set clipboard contents."""
        def operation():
            if not text.strip():
                raise AutomationError("Cannot set empty clipboard content")

            try:
                pyperclip.copy(text)
                return f"Copied {len(text)} characters to clipboard"
            except Exception as e:
                raise AutomationError(f"Failed to set clipboard: {e}")

        return self._execute_with_timeout(operation, "set_clipboard", timeout=3)

    def launch_app(self, app_name: str, wait_time: float = 3.0) -> AutomationResult:
        """
        Launch an application.

        Args:
            app_name: Application name or path
            wait_time: Time to wait for app to launch
        """
        def operation():
            try:
                # Try to launch as a direct path first
                app_path = Path(app_name)
                if app_path.exists():
                    subprocess.Popen([str(app_path)])
                else:
                    # Try to launch by name
                    subprocess.Popen(app_name, shell=True)

                # Wait for application to start
                if wait_time > 0:
                    time.sleep(wait_time)

                return f"Launched {app_name}"

            except Exception as e:
                raise AutomationError(f"Failed to launch {app_name}: {e}")

        return self._execute_with_timeout(operation, "launch_app", timeout=wait_time + 5)

    def fill_form(self, field_values: Dict[str, str], submit_key: str = "enter") -> AutomationResult:
        """
        Fill form fields with values.

        Args:
            field_values: Dictionary of field labels/indices and values
            submit_key: Key to press after filling (or None to not submit)
        """
        def operation():
            if not field_values:
                raise AutomationError("No field values provided")

            filled_fields = 0

            for field_label, value in field_values.items():
                if not value.strip():
                    continue

                # Type the value
                pyautogui.typewrite(value, interval=0.02)
                filled_fields += 1

                # Press tab to move to next field (except for last field)
                if field_label != list(field_values.keys())[-1]:
                    pyautogui.press('tab')
                    time.sleep(0.1)

            # Submit form if requested
            if submit_key:
                pyautogui.press(submit_key)

            return f"Filled {filled_fields} fields"

        return self._execute_with_timeout(operation, "fill_form", timeout=30)

    def screenshot(self, filename: Optional[str] = None, region: Optional[Tuple[int, int, int, int]] = None) -> AutomationResult:
        """
        Take a screenshot.

        Args:
            filename: Optional filename (auto-generated if None)
            region: Optional region to capture (x, y, width, height)
        """
        def operation():
            try:
                # Generate filename if not provided
                if not filename:
                    timestamp = int(time.time())
                    filename = f"screenshot_{timestamp}.png"

                filepath = self.screenshot_dir / filename

                # Take screenshot
                if region:
                    screenshot = pyautogui.screenshot(region=region)
                else:
                    screenshot = pyautogui.screenshot()

                # Save screenshot
                screenshot.save(str(filepath))
                return str(filepath)

            except Exception as e:
                raise AutomationError(f"Failed to take screenshot: {e}")

        return self._execute_with_timeout(operation, "screenshot", timeout=10)

    def get_mouse_position(self) -> AutomationResult:
        """Get current mouse position."""
        def operation():
            x, y = pyautogui.position()
            return {"x": x, "y": y}

        return self._execute_with_timeout(operation, "get_mouse_position", timeout=1)

    def get_screen_size(self) -> AutomationResult:
        """Get screen dimensions."""
        def operation():
            width, height = pyautogui.size()
            return {"width": width, "height": height}

        return self._execute_with_timeout(operation, "get_screen_size", timeout=1)

    def find_color_on_screen(self, color: Tuple[int, int, int], region: Optional[Tuple[int, int, int, int]] = None) -> AutomationResult:
        """
        Find a specific color on screen.

        Args:
            color: RGB color tuple to find
            region: Optional region to search in
        """
        def operation():
            try:
                if region:
                    x, y = pyautogui.locateOnScreen(color, region=region)
                else:
                    x, y = pyautogui.locateOnScreen(color)

                return {"x": x, "y": y} if x and y else None

            except Exception as e:
                raise AutomationError(f"Failed to find color: {e}")

        return self._execute_with_timeout(operation, "find_color", timeout=10)

    def emergency_stop(self) -> AutomationResult:
        """Emergency stop - move mouse to corner and clear any ongoing operations."""
        def operation():
            try:
                # Move mouse to corner (failsafe)
                pyautogui.moveTo(0, 0, duration=0.1)
                return "Emergency stop executed"
            except Exception as e:
                raise AutomationError(f"Emergency stop failed: {e}")

        return self._execute_with_timeout(operation, "emergency_stop", timeout=2)

    # Advanced automation methods
    def wait_for_image(self, image_path: str, timeout: float = 10.0, confidence: float = 0.9) -> AutomationResult:
        """
        Wait for an image to appear on screen.

        Args:
            image_path: Path to image file
            timeout: Maximum time to wait
            confidence: Matching confidence level
        """
        def operation():
            image_file = Path(image_path)
            if not image_file.exists():
                raise AutomationError(f"Image file not found: {image_path}")

            start_time = time.time()
            while time.time() - start_time < timeout:
                try:
                    location = pyautogui.locateOnScreen(str(image_file), confidence=confidence)
                    if location:
                        return {
                            "found": True,
                            "location": {
                                "left": location.left,
                                "top": location.top,
                                "width": location.width,
                                "height": location.height
                            },
                            "center": (location.left + location.width // 2,
                                     location.top + location.height // 2)
                        }
                except:
                    pass

                time.sleep(0.5)

            return {"found": False}

        return self._execute_with_timeout(operation, "wait_for_image", timeout=timeout + 2)

    def record_macro(self, actions: List[Dict[str, Any]], filename: Optional[str] = None) -> AutomationResult:
        """
        Execute a recorded macro.

        Args:
            actions: List of action dictionaries
            filename: Optional filename to save macro
        """
        def operation():
            if not actions:
                raise AutomationError("No actions provided for macro")

            executed_actions = 0

            for action in actions:
                action_type = action.get("type")
                params = action.get("params", {})

                if action_type == "click":
                    self.click(**params)
                elif action_type == "type":
                    self.type_text(**params)
                elif action_type == "press":
                    self.press_key(**params)
                elif action_type == "hotkey":
                    self.hotkey(**params)
                elif action_type == "scroll":
                    self.scroll(**params)
                else:
                    logger.warning(f"Unknown macro action type: {action_type}")

                executed_actions += 1

            # Save macro to file if filename provided
            if filename:
                import json
                macro_file = Path("data/macros") / filename
                macro_file.parent.mkdir(exist_ok=True)

                with open(macro_file, 'w') as f:
                    json.dump(actions, f, indent=2)

            return f"Executed {executed_actions} actions"

        return self._execute_with_timeout(operation, "record_macro", timeout=60)

    def get_statistics(self) -> Dict[str, Any]:
        """Get automation statistics."""
        success_rate = (self.success_count / max(self.operation_count, 1)) * 100

        return {
            "enabled": self.enabled,
            "safety_level": self.safety_level.value,
            "operation_count": self.operation_count,
            "success_count": self.success_count,
            "error_count": self.error_count,
            "success_rate": f"{success_rate:.1f}%",
            "recent_operations": self.operation_history[-10:],
            "screenshot_directory": str(self.screenshot_dir),
            "confirm_dangerous": self.confirm_dangerous_operations
        }

    def set_safety_level(self, level: SafetyLevel):
        """Set safety level."""
        self.safety_level = level
        self.confirm_dangerous_operations = level != SafetyLevel.ADVANCED
        logger.info(f"Safety level changed to: {level.value}")

    def enable(self):
        """Enable UI automation."""
        self.enabled = True
        logger.info("UI automation enabled")

    def disable(self):
        """Disable UI automation."""
        self.enabled = False
        logger.info("UI automation disabled")

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.emergency_stop()