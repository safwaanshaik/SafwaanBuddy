#!/usr/bin/env python3
"""
Voice Processing Components for Safwaan Buddy
Handles wake word detection, speech-to-text, and text-to-speech functionality.
"""

import threading
import queue
import time
from typing import List, Callable, Optional, Dict, Any
from dataclasses import dataclass

import speech_recognition as sr
import pyttsx3

from config import get_config
from utils.logger import get_logger
from utils.helpers import retry_on_failure, format_duration

logger = get_logger("voice")


@dataclass
class VoiceEvent:
    """Data class for voice-related events."""
    event_type: str
    data: Any
    timestamp: float
    confidence: Optional[float] = None


class WakeWordListener:
    """Continuous wake word detection using speech recognition."""

    def __init__(self, wake_words: List[str], on_trigger: Callable[[], None]):
        """
        Initialize wake word listener.

        Args:
            wake_words: List of wake words to detect
            on_trigger: Callback function when wake word detected
        """
        self.wake_words = [w.lower() for w in wake_words]
        self.on_trigger = on_trigger
        self.listening = False
        self.recognizer = sr.Recognizer()
        self.microphone = None
        self.callbacks: List[Callable[[VoiceEvent], None]] = []

        # Configuration
        self.config = get_config()
        self.timeout = self.config.get("voice_recognition_timeout", 5.0)
        self.phrase_time_limit = self.config.get("voice_phrase_time_limit", 5.0)
        self.energy_threshold = 300
        self.dynamic_energy_threshold = True

        # Statistics
        self.detection_count = 0
        self.false_positive_count = 0
        self.last_detection_time = 0

        logger.info(f"WakeWordListener initialized with words: {self.wake_words}")

    def add_callback(self, callback: Callable[[VoiceEvent], None]):
        """Add callback for voice events."""
        self.callbacks.append(callback)

    def _notify_callbacks(self, event: VoiceEvent):
        """Notify all registered callbacks."""
        for callback in self.callbacks:
            try:
                callback(event)
            except Exception as e:
                logger.error(f"Error in wake word callback: {e}")

    def start(self):
        """Start wake word detection in background thread."""
        if self.listening:
            logger.warning("Wake word detection already running")
            return

        self.listening = True
        self.thread = threading.Thread(target=self._listen_loop, daemon=True)
        self.thread.start()

        logger.info("Wake word detection started")

    def stop(self):
        """Stop wake word detection."""
        if not self.listening:
            return

        self.listening = False

        if hasattr(self, 'thread') and self.thread.is_alive():
            self.thread.join(timeout=2.0)

        logger.info("Wake word detection stopped")

    def _init_microphone(self):
        """Initialize and configure microphone."""
        try:
            if self.microphone is None:
                self.microphone = sr.Microphone()

            with self.microphone as source:
                # Adjust for ambient noise
                self.recognizer.adjust_for_ambient_noise(source, duration=1.0)

                # Set energy threshold
                if not self.dynamic_energy_threshold:
                    self.recognizer.energy_threshold = self.energy_threshold

            logger.debug("Microphone initialized successfully")

        except Exception as e:
            logger.error(f"Failed to initialize microphone: {e}")
            raise

    @retry_on_failure(max_retries=3, delay=0.5)
    def _listen_loop(self):
        """Main wake word detection loop."""
        try:
            self._init_microphone()

            with self.microphone as source:
                logger.info("Listening for wake words...")

                while self.listening:
                    try:
                        # Listen for audio
                        audio = self.recognizer.listen(
                            source,
                            timeout=self.timeout,
                            phrase_time_limit=self.phrase_time_limit
                        )

                        # Recognize speech
                        text = self.recognizer.recognize_google(audio).lower()
                        logger.debug(f"Heard: {text}")

                        # Check for wake words
                        if self._contains_wake_word(text):
                            self._handle_wake_word_detection(text)

                    except sr.WaitTimeoutError:
                        # Normal timeout, continue listening
                        continue
                    except sr.UnknownValueError:
                        # Speech not understood, continue
                        continue
                    except sr.RequestError as e:
                        logger.error(f"Speech recognition service error: {e}")
                        time.sleep(1.0)  # Wait before retrying
                        continue
                    except Exception as e:
                        logger.error(f"Unexpected error in wake word detection: {e}")
                        time.sleep(0.5)
                        continue

        except Exception as e:
            logger.error(f"Wake word listener failed: {e}")
            self.listening = False

    def _contains_wake_word(self, text: str) -> bool:
        """Check if text contains any wake words."""
        for wake_word in self.wake_words:
            if wake_word in text:
                return True
        return False

    def _handle_wake_word_detection(self, text: str):
        """Handle wake word detection."""
        self.detection_count += 1
        self.last_detection_time = time.time()

        logger.info(f"Wake word detected: {text}")

        # Notify callbacks
        event = VoiceEvent(
            event_type="wake_word_detected",
            data={"text": text, "wake_words": self.wake_words},
            timestamp=time.time(),
            confidence=1.0
        )
        self._notify_callbacks(event)

        # Trigger main callback
        try:
            self.on_trigger()
        except Exception as e:
            logger.error(f"Error in wake word trigger callback: {e}")

    def get_statistics(self) -> Dict[str, Any]:
        """Get wake word detection statistics."""
        return {
            "detection_count": self.detection_count,
            "false_positive_count": self.false_positive_count,
            "accuracy_rate": (self.detection_count - self.false_positive_count) / max(self.detection_count, 1),
            "last_detection_time": self.last_detection_time,
            "listening": self.listening,
            "wake_words": self.wake_words
        }


class SpeechRecognitionEngine:
    """Speech-to-text engine for command input."""

    def __init__(self, on_result: Callable[[str], None]):
        """
        Initialize speech recognition engine.

        Args:
            on_result: Callback function when speech is recognized
        """
        self.on_result = on_result
        self.listening = False
        self.recognizer = sr.Recognizer()
        self.microphone = None
        self.callbacks: List[Callable[[VoiceEvent], None]] = []

        # Configuration
        self.config = get_config()
        self.timeout = self.config.get("voice_recognition_timeout", 5.0)
        self.phrase_time_limit = self.config.get("voice_phrase_time_limit", 10.0)

        # Statistics
        self.recognition_count = 0
        self.success_count = 0
        self.error_count = 0

        logger.info("SpeechRecognitionEngine initialized")

    def add_callback(self, callback: Callable[[VoiceEvent], None]):
        """Add callback for speech events."""
        self.callbacks.append(callback)

    def _notify_callbacks(self, event: VoiceEvent):
        """Notify all registered callbacks."""
        for callback in self.callbacks:
            try:
                callback(event)
            except Exception as e:
                logger.error(f"Error in speech recognition callback: {e}")

    def start(self):
        """Start speech recognition in background thread."""
        if self.listening:
            logger.warning("Speech recognition already running")
            return

        self.listening = True
        self.thread = threading.Thread(target=self._listen_loop, daemon=True)
        self.thread.start()

        logger.info("Speech recognition started")

    def stop(self):
        """Stop speech recognition."""
        if not self.listening:
            return

        self.listening = False

        if hasattr(self, 'thread') and self.thread.is_alive():
            self.thread.join(timeout=2.0)

        logger.info("Speech recognition stopped")

    def _init_microphone(self):
        """Initialize microphone for speech recognition."""
        try:
            if self.microphone is None:
                self.microphone = sr.Microphone()

            with self.microphone as source:
                # Adjust for ambient noise
                self.recognizer.adjust_for_ambient_noise(source, duration=1.0)

            logger.debug("Speech recognition microphone initialized")

        except Exception as e:
            logger.error(f"Failed to initialize speech recognition microphone: {e}")
            raise

    def recognize_single_phrase(self) -> Optional[str]:
        """Recognize a single phrase (blocking)."""
        try:
            self._init_microphone()

            with self.microphone as source:
                logger.info("Listening for command...")
                audio = self.recognizer.listen(
                    source,
                    timeout=self.timeout,
                    phrase_time_limit=self.phrase_time_limit
                )

                # Recognize speech
                text = self.recognizer.recognize_google(audio)
                self.recognition_count += 1
                self.success_count += 1

                logger.info(f"Recognized: {text}")

                # Notify callbacks
                event = VoiceEvent(
                    event_type="speech_recognized",
                    data={"text": text},
                    timestamp=time.time(),
                    confidence=0.8  # Default confidence
                )
                self._notify_callbacks(event)

                return text

        except sr.WaitTimeoutError:
            logger.debug("Speech recognition timeout")
            return None
        except sr.UnknownValueError:
            logger.warning("Speech not understood")
            self.error_count += 1
            return None
        except sr.RequestError as e:
            logger.error(f"Speech recognition service error: {e}")
            self.error_count += 1
            return None
        except Exception as e:
            logger.error(f"Error in speech recognition: {e}")
            self.error_count += 1
            return None

    def _listen_loop(self):
        """Continuous speech recognition loop."""
        try:
            self._init_microphone()

            with self.microphone as source:
                logger.info("Speech recognition loop started")

                while self.listening:
                    try:
                        # Listen for audio
                        audio = self.recognizer.listen(
                            source,
                            timeout=self.timeout,
                            phrase_time_limit=self.phrase_time_limit
                        )

                        # Recognize speech
                        text = self.recognizer.recognize_google(audio)
                        self.recognition_count += 1
                        self.success_count += 1

                        logger.info(f"Speech recognized: {text}")

                        # Notify callbacks
                        event = VoiceEvent(
                            event_type="speech_recognized",
                            data={"text": text},
                            timestamp=time.time(),
                            confidence=0.8
                        )
                        self._notify_callbacks(event)

                        # Call main callback
                        try:
                            self.on_result(text)
                        except Exception as e:
                            logger.error(f"Error in speech result callback: {e}")

                    except sr.WaitTimeoutError:
                        # Normal timeout, continue listening
                        continue
                    except sr.UnknownValueError:
                        # Speech not understood, continue
                        self.error_count += 1
                        continue
                    except sr.RequestError as e:
                        logger.error(f"Speech recognition service error: {e}")
                        time.sleep(1.0)
                        continue
                    except Exception as e:
                        logger.error(f"Unexpected error in speech recognition: {e}")
                        time.sleep(0.5)
                        continue

        except Exception as e:
            logger.error(f"Speech recognition loop failed: {e}")
            self.listening = False

    def get_statistics(self) -> Dict[str, Any]:
        """Get speech recognition statistics."""
        total = max(self.recognition_count, 1)
        return {
            "recognition_count": self.recognition_count,
            "success_count": self.success_count,
            "error_count": self.error_count,
            "success_rate": self.success_count / total,
            "listening": self.listening
        }


class AdvancedTTSEngine:
    """Advanced text-to-speech engine with queuing and multiple voices."""

    def __init__(self, voice_rate: int = 150, volume: float = 1.0):
        """
        Initialize TTS engine.

        Args:
            voice_rate: Speech rate (words per minute)
            volume: Speech volume (0.0 to 1.0)
        """
        self.voice_rate = voice_rate
        self.volume = volume

        # Initialize pyttsx3 engine
        self.engine = pyttsx3.init()
        self._configure_engine()

        # Speech queue and processing
        self.speech_queue = queue.Queue()
        self.processing = False
        self.callbacks: List[Callable[[VoiceEvent], None]] = []

        # Statistics
        self.total_speech_count = 0
        self.total_speech_time = 0.0

        # Start processing thread
        self._start_processing_thread()

        logger.info("AdvancedTTSEngine initialized")

    def _configure_engine(self):
        """Configure the TTS engine."""
        try:
            # Set voice rate
            self.engine.setProperty('rate', self.voice_rate)

            # Set volume
            self.engine.setProperty('volume', max(0.0, min(1.0, self.volume)))

            # Get available voices
            voices = self.engine.getProperty('voices')
            logger.info(f"Available voices: {len(voices)}")

            # Set default voice (first available)
            if voices:
                self.engine.setProperty('voice', voices[0].id)

        except Exception as e:
            logger.error(f"Failed to configure TTS engine: {e}")

    def add_callback(self, callback: Callable[[VoiceEvent], None]):
        """Add callback for TTS events."""
        self.callbacks.append(callback)

    def _notify_callbacks(self, event: VoiceEvent):
        """Notify all registered callbacks."""
        for callback in self.callbacks:
            try:
                callback(event)
            except Exception as e:
                logger.error(f"Error in TTS callback: {e}")

    def _start_processing_thread(self):
        """Start the speech processing thread."""
        self.processing = True
        self.thread = threading.Thread(target=self._process_queue, daemon=True)
        self.thread.start()
        logger.debug("TTS processing thread started")

    def _process_queue(self):
        """Process speech queue in background."""
        while self.processing:
            try:
                # Get text from queue (blocking)
                text = self.speech_queue.get(timeout=0.1)

                if text is None:  # Poison pill
                    break

                # Speak the text
                start_time = time.time()
                self._speak_text(text)
                duration = time.time() - start_time

                # Update statistics
                self.total_speech_count += 1
                self.total_speech_time += duration

                # Notify callbacks
                event = VoiceEvent(
                    event_type="speech_completed",
                    data={"text": text, "duration": duration},
                    timestamp=time.time()
                )
                self._notify_callbacks(event)

                self.speech_queue.task_done()

            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Error processing speech: {e}")
                continue

        logger.debug("TTS processing thread stopped")

    def _speak_text(self, text: str):
        """Speak text using the TTS engine."""
        try:
            self.engine.say(text)
            self.engine.runAndWait()

        except Exception as e:
            logger.error(f"Failed to speak text: {e}")

    def speak(self, text: str):
        """Queue text for speech synthesis."""
        if not text or not text.strip():
            return

        # Clean and validate text
        text = text.strip()
        if len(text) > 1000:  # Limit text length
            text = text[:1000] + "..."

        try:
            self.speech_queue.put(text, timeout=1.0)

            # Notify callbacks
            event = VoiceEvent(
                event_type="speech_queued",
                data={"text": text, "queue_size": self.speech_queue.qsize()},
                timestamp=time.time()
            )
            self._notify_callbacks(event)

        except queue.Full:
            logger.warning("Speech queue is full, skipping text")

    def speak_immediate(self, text: str):
        """Speak text immediately (bypasses queue)."""
        if not text or not text.strip():
            return

        try:
            # Clear queue first
            self._clear_queue()
            self.speak(text)

        except Exception as e:
            logger.error(f"Failed to speak immediate text: {e}")

    def _clear_queue(self):
        """Clear the speech queue."""
        try:
            while not self.speech_queue.empty():
                self.speech_queue.get_nowait()
                self.speech_queue.task_done()
        except queue.Empty:
            pass

    def stop_speech(self):
        """Stop current speech and clear queue."""
        try:
            self._clear_queue()
            self.engine.stop()
            logger.info("Speech stopped")

        except Exception as e:
            logger.error(f"Failed to stop speech: {e}")

    def set_voice_rate(self, rate: int):
        """Set voice rate."""
        self.voice_rate = max(50, min(400, rate))
        self.engine.setProperty('rate', self.voice_rate)
        logger.info(f"Voice rate set to {self.voice_rate}")

    def set_volume(self, volume: float):
        """Set speech volume."""
        self.volume = max(0.0, min(1.0, volume))
        self.engine.setProperty('volume', self.volume)
        logger.info(f"Volume set to {self.volume}")

    def get_available_voices(self) -> List[Dict[str, str]]:
        """Get list of available voices."""
        try:
            voices = []
            for voice in self.engine.getProperty('voices'):
                voices.append({
                    'id': voice.id,
                    'name': voice.name,
                    'gender': getattr(voice, 'gender', 'unknown'),
                    'languages': getattr(voice, 'languages', [])
                })
            return voices

        except Exception as e:
            logger.error(f"Failed to get available voices: {e}")
            return []

    def set_voice(self, voice_id: str) -> bool:
        """Set voice by ID."""
        try:
            self.engine.setProperty('voice', voice_id)
            logger.info(f"Voice set to {voice_id}")
            return True

        except Exception as e:
            logger.error(f"Failed to set voice: {e}")
            return False

    def get_statistics(self) -> Dict[str, Any]:
        """Get TTS statistics."""
        avg_time = self.total_speech_time / max(self.total_speech_count, 1)

        return {
            "total_speech_count": self.total_speech_count,
            "total_speech_time": self.total_speech_time,
            "average_speech_time": avg_time,
            "queue_size": self.speech_queue.qsize(),
            "processing": self.processing,
            "voice_rate": self.voice_rate,
            "volume": self.volume
        }

    def shutdown(self):
        """Shutdown TTS engine gracefully."""
        self.processing = False
        self._clear_queue()

        # Send poison pill to stop processing thread
        try:
            self.speech_queue.put(None, timeout=1.0)
        except queue.Full:
            pass

        if hasattr(self, 'thread') and self.thread.is_alive():
            self.thread.join(timeout=2.0)

        logger.info("TTS engine shutdown complete")


class VoiceProcessor:
    """Main voice processor that coordinates all voice components."""

    def __init__(self):
        """Initialize all voice processing components."""
        self.config = get_config()
        self.callbacks: List[Callable[[VoiceEvent], None]] = []

        # Initialize components
        wake_words = self.config.get("wake_words", ["buddy", "safwaan buddy"])

        self.wake_listener = WakeWordListener(
            wake_words, self._on_wake_word_detected
        )

        self.speech_recognizer = SpeechRecognitionEngine(
            self._on_speech_recognized
        )

        self.tts_engine = AdvancedTTSEngine(
            voice_rate=self.config.get("voice_rate", 150),
            volume=self.config.get("voice_volume", 1.0)
        )

        # State tracking
        self.wake_word_active = False
        self.last_activity_time = 0

        logger.info("VoiceProcessor initialized")

    def add_callback(self, callback: Callable[[VoiceEvent], None]):
        """Add callback for voice events."""
        self.callbacks.append(callback)
        self.wake_listener.add_callback(callback)
        self.speech_recognizer.add_callback(callback)
        self.tts_engine.add_callback(callback)

    def _notify_callbacks(self, event: VoiceEvent):
        """Notify all registered callbacks."""
        for callback in self.callbacks:
            try:
                callback(event)
            except Exception as e:
                logger.error(f"Error in voice processor callback: {e}")

    def _on_wake_word_detected(self):
        """Handle wake word detection."""
        self.wake_word_active = True
        self.last_activity_time = time.time()

        # Start speech recognition
        self.speech_recognizer.start()

        # Notify callbacks
        event = VoiceEvent(
            event_type="wake_word_activated",
            data={"active": True},
            timestamp=time.time()
        )
        self._notify_callbacks(event)

    def _on_speech_recognized(self, text: str):
        """Handle speech recognition result."""
        self.wake_word_active = False
        self.last_activity_time = time.time()

        # Stop speech recognition
        self.speech_recognizer.stop()

        # Notify callbacks
        event = VoiceEvent(
            event_type="command_recognized",
            data={"text": text},
            timestamp=time.time(),
            confidence=0.8
        )
        self._notify_callbacks(event)

    def start_wake_word_detection(self):
        """Start wake word detection."""
        self.wake_listener.start()
        logger.info("Wake word detection started")

    def stop_wake_word_detection(self):
        """Stop wake word detection."""
        self.wake_listener.stop()
        self.speech_recognizer.stop()
        logger.info("Voice processing stopped")

    def speak(self, text: str):
        """Speak text using TTS engine."""
        self.tts_engine.speak(text)

    def listen_for_command(self) -> Optional[str]:
        """Listen for a single command (blocking)."""
        return self.speech_recognizer.recognize_single_phrase()

    def is_active(self) -> bool:
        """Check if voice processor is active."""
        return self.wake_word_active

    def get_status(self) -> Dict[str, Any]:
        """Get current status of all voice components."""
        return {
            "wake_word_active": self.wake_word_active,
            "last_activity": self.last_activity_time,
            "wake_listener": self.wake_listener.get_statistics(),
            "speech_recognizer": self.speech_recognizer.get_statistics(),
            "tts_engine": self.tts_engine.get_statistics()
        }

    def shutdown(self):
        """Shutdown all voice components."""
        logger.info("Shutting down voice processor")
        self.stop_wake_word_detection()
        self.tts_engine.shutdown()