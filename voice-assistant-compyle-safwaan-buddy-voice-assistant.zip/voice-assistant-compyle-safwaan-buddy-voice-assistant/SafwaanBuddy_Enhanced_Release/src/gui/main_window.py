#!/usr/bin/env python3
"""
Main GUI Window for Safwaan Buddy
Comprehensive PyQt6 interface with voice controls, system monitoring, and conversation display.
"""

import sys
import json
from datetime import datetime
from typing import Optional, Dict, Any

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit, QGroupBox,
    QStatusBar, QApplication, QMessageBox, QDialog
)
from PyQt6.QtCore import QTimer, Qt, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QFont, QIcon, QPixmap

from .styles import get_theme_manager, apply_theme
from utils.logger import get_logger
from utils.system_monitor import get_system_monitor


class SystemMonitorThread(QThread):
    """Background thread for system monitoring updates."""
    stats_updated = pyqtSignal(dict)

    def __init__(self):
        super().__init__()
        self.running = False
        self.monitor = get_system_monitor()

    def run(self):
        """Run the system monitoring loop."""
        self.running = True
        while self.running:
            try:
                stats = self.monitor.get_summary()
                self.stats_updated.emit(stats)
                self.msleep(2000)  # Update every 2 seconds
            except Exception as e:
                print(f"System monitor error: {e}")
                self.msleep(5000)

    def stop(self):
        """Stop the monitoring thread."""
        self.running = False
        self.wait()


class SafwaanBuddyGUI(QMainWindow):
    """Main GUI window for Safwaan Buddy voice assistant."""

    def __init__(self, memory_manager=None, voice_processor=None,
                 command_parser=None, plugin_manager=None, ui_automation=None,
                 natural_speech=None, system_control=None, ai_personality=None):
        """Initialize the main window."""
        super().__init__()

        # Core components
        self.memory_manager = memory_manager
        self.voice_processor = voice_processor
        self.command_parser = command_parser
        self.plugin_manager = plugin_manager
        self.ui_automation = ui_automation

        # Enhanced components
        self.natural_speech = natural_speech
        self.system_control = system_control
        self.ai_personality = ai_personality

        # Initialize logger
        self.logger = get_logger("gui")

        # Initialize theme manager
        self.theme_manager = get_theme_manager()

        # Setup state
        self.listening_for_command = False
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")

        # Initialize UI
        self.init_ui()

        # Setup background systems
        self.setup_system_monitor()

        # Apply initial theme
        apply_theme(self, self.theme_manager.current_theme)

        self.logger.info("Safwaan Buddy GUI initialized")

    def init_ui(self):
        """Initialize the user interface."""
        self.setWindowTitle("🤖 Safwaan Buddy - Advanced AI Assistant")
        self.setGeometry(100, 100, 1000, 800)
        self.setMinimumSize(800, 600)

        # Create central widget and main layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setSpacing(10)
        main_layout.setContentsMargins(10, 10, 10, 10)

        # Create header
        self.create_header(main_layout)

        # Create status bar
        self.create_status_bar(main_layout)

        # Create system monitoring section
        self.create_system_monitor(main_layout)

        # Create conversation display
        self.create_conversation_display(main_layout)

        # Create input section
        self.create_input_section(main_layout)

        # Create event log
        self.create_event_log(main_layout)

        # Create control buttons
        self.create_control_buttons(main_layout)

        # Create menu bar
        self.create_menu_bar()

    def create_header(self, parent_layout):
        """Create the header section."""
        header = QLabel("🤖 SAFWAAN BUDDY")
        header.setProperty("header", "true")
        header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        parent_layout.addWidget(header)

    def create_status_bar(self, parent_layout):
        """Create the status bar section."""
        status_layout = QHBoxLayout()

        self.status_label = QLabel("🟢 Ready")
        self.status_label.setProperty("status", "true")
        self.status_label.setMinimumWidth(150)

        self.wake_status = QLabel("🎤 Listening for wake word...")
        self.wake_status.setProperty("warning", "true")
        self.wake_status.setMinimumWidth(200)

        status_layout.addWidget(self.status_label)
        status_layout.addStretch()
        status_layout.addWidget(self.wake_status)

        parent_layout.addLayout(status_layout)

    def create_system_monitor(self, parent_layout):
        """Create the system monitoring display."""
        stats_group = QGroupBox("System Status")
        stats_layout = QGridLayout()

        # Create labels for system stats
        self.cpu_label = QLabel("CPU: 0%")
        self.ram_label = QLabel("RAM: 0%")
        self.disk_label = QLabel("DISK: 0%")
        self.time_label = QLabel(datetime.now().strftime("%H:%M:%S"))
        self.uptime_label = QLabel("Uptime: 0:00")

        # Set monospace font for better alignment
        font = QFont("Consolas", 10)
        for label in [self.cpu_label, self.ram_label, self.disk_label, self.time_label, self.uptime_label]:
            label.setFont(font)

        # Add to grid layout
        stats_layout.addWidget(self.cpu_label, 0, 0)
        stats_layout.addWidget(self.ram_label, 0, 1)
        stats_layout.addWidget(self.disk_label, 0, 2)
        stats_layout.addWidget(self.time_label, 0, 3)
        stats_layout.addWidget(self.uptime_label, 0, 4)

        stats_group.setLayout(stats_layout)
        parent_layout.addWidget(stats_group)

    def create_conversation_display(self, parent_layout):
        """Create the conversation history display."""
        chat_group = QGroupBox("Conversation")
        chat_layout = QVBoxLayout()

        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        self.chat_display.setMaximumHeight(280)
        self.chat_display.setMinimumHeight(200)

        chat_layout.addWidget(self.chat_display)
        chat_group.setLayout(chat_layout)
        parent_layout.addWidget(chat_group)

    def create_input_section(self, parent_layout):
        """Create the command input section."""
        input_group = QGroupBox("Command Input")
        input_layout = QHBoxLayout()

        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("Type command or say 'Buddy'...")
        self.input_field.returnPressed.connect(self.process_command)

        self.voice_btn = QPushButton("🎤 Listen")
        self.voice_btn.clicked.connect(self.toggle_voice_input)

        self.send_btn = QPushButton("▶ Send")
        self.send_btn.clicked.connect(self.process_command)

        input_layout.addWidget(self.input_field)
        input_layout.addWidget(self.voice_btn)
        input_layout.addWidget(self.send_btn)

        input_group.setLayout(input_layout)
        parent_layout.addWidget(input_group)

    def create_event_log(self, parent_layout):
        """Create the event log display."""
        log_group = QGroupBox("Event Log")
        log_layout = QVBoxLayout()

        self.event_log = QTextEdit()
        self.event_log.setReadOnly(True)
        self.event_log.setMaximumHeight(120)
        self.event_log.setMinimumHeight(80)
        self.event_log.setFont(QFont("Consolas", 9))

        log_layout.addWidget(self.event_log)
        log_group.setLayout(log_layout)
        parent_layout.addWidget(log_group)

    def create_control_buttons(self, parent_layout):
        """Create the control buttons section."""
        btn_layout = QHBoxLayout()

        # Create buttons
        self.memory_btn = QPushButton("🧠 Memory")
        self.memory_btn.clicked.connect(self.show_memory)

        self.history_btn = QPushButton("📋 History")
        self.history_btn.clicked.connect(self.show_history)

        self.preferences_btn = QPushButton("⚙️ Preferences")
        self.preferences_btn.clicked.connect(self.show_preferences)

        self.clear_btn = QPushButton("🗑️ Clear")
        self.clear_btn.clicked.connect(self.clear_chat)

        self.plugins_btn = QPushButton("🔌 Plugins")
        self.plugins_btn.clicked.connect(self.show_plugins)

        self.about_btn = QPushButton("ℹ️ About")
        self.about_btn.clicked.connect(self.show_about)

        self.exit_btn = QPushButton("❌ Exit")
        self.exit_btn.clicked.connect(self.close)

        # Add buttons to layout
        buttons = [
            self.memory_btn, self.history_btn, self.preferences_btn,
            self.clear_btn, self.plugins_btn, self.about_btn, self.exit_btn
        ]

        for btn in buttons:
            btn.setMinimumWidth(100)
            btn_layout.addWidget(btn)

        parent_layout.addLayout(btn_layout)

    def create_menu_bar(self):
        """Create the menu bar."""
        menubar = self.menuBar()

        # File menu
        file_menu = menubar.addMenu("File")

        exit_action = file_menu.addAction("Exit")
        exit_action.triggered.connect(self.close)

        # Edit menu
        edit_menu = menubar.addMenu("Edit")

        clear_action = edit_menu.addAction("Clear Chat")
        clear_action.triggered.connect(self.clear_chat)

        # View menu
        view_menu = menubar.addMenu("View")

        theme_menu = view_menu.addMenu("Theme")
        for theme_name in self.theme_manager.get_available_themes():
            theme_action = theme_menu.addAction(theme_name.title())
            theme_action.triggered.connect(lambda checked, name=theme_name: self.change_theme(name))

        # Tools menu
        tools_menu = menubar.addMenu("Tools")

        mic_setup_action = tools_menu.addAction("Microphone Setup")
        mic_setup_action.triggered.connect(self.setup_microphone)

        # Help menu
        help_menu = menubar.addMenu("Help")

        about_action = help_menu.addAction("About")
        about_action.triggered.connect(self.show_about)

    def setup_system_monitor(self):
        """Setup the system monitoring thread."""
        self.monitor_thread = SystemMonitorThread()
        self.monitor_thread.stats_updated.connect(self.update_system_stats)
        self.monitor_thread.start()

    def update_system_stats(self, stats):
        """Update system statistics display."""
        try:
            self.cpu_label.setText(f"CPU: {stats.get('cpu', {}).get('percent', 'N/A')}%")
            self.ram_label.setText(f"RAM: {stats.get('memory', {}).get('percent', 'N/A')}%")
            self.disk_label.setText(f"DISK: {stats.get('disk', {}).get('percent', 'N/A')}%")
            self.time_label.setText(datetime.now().strftime("%H:%M:%S"))
            self.uptime_label.setText(f"Uptime: {stats.get('uptime', 'N/A')}")
        except Exception as e:
            self.logger.error(f"Error updating system stats: {e}")

    def process_command(self):
        """Process user command from input field."""
        user_input = self.input_field.text().strip()
        if not user_input:
            return

        self.input_field.clear()
        self.append_chat(f"👤 You: {user_input}")

        # Update status
        self.status_label.setText("🔄 Processing...")
        self.status_label.setProperty("status", "true")

        try:
            # Parse command
            if self.command_parser:
                parsed_intent = self.command_parser.parse_intent(user_input)

                # Log to memory
                if self.memory_manager:
                    self.memory_manager.save_conversation(
                        user_input, "", parsed_intent.intent.value,
                        self.session_id
                    )

                # Execute command
                response = self._execute_command(parsed_intent)

                # Save conversation
                if self.memory_manager:
                    self.memory_manager.save_conversation(
                        user_input, response, parsed_intent.intent.value,
                        self.session_id
                    )

                # Display response
                self.append_chat(f"🤖 Buddy: {response}")

                # Speak response if voice processor is available
                if self.voice_processor:
                    self.voice_processor.speak(response)
            else:
                response = "Command parser not available"
                self.append_chat(f"🤖 Buddy: {response}")

        except Exception as e:
            error_msg = f"Error processing command: {e}"
            self.logger.error(error_msg)
            self.append_chat(f"🤖 Buddy: {error_msg}")

        # Update status
        self.status_label.setText("🟢 Ready")
        self.status_label.setProperty("status", "true")

        # Log event
        self.log_event(f"Command processed: {user_input[:50]}...")

    def _execute_command(self, parsed_intent) -> str:
        """Execute the parsed command."""
        try:
            # Handle plugin execution
            if self.plugin_manager:
                # Map intents to plugin functions
                intent_handlers = {
                    "system_status": "system_stats",
                    "time": "get_time",
                    "open_app": lambda: self.plugin_manager.execute("open_app", parsed_intent.parameters.get("app", "notepad")),
                    "save_note": lambda: self.plugin_manager.execute("save_note",
                                       parsed_intent.parameters.get("title", ""),
                                       parsed_intent.parameters.get("content", "")),
                    "recall_note": lambda: self.plugin_manager.execute("recall_note",
                                        parsed_intent.parameters.get("title", "")),
                    "list_notes": "list_notes",
                    "type": lambda: self.plugin_manager.execute("type_text",
                                    parsed_intent.parameters.get("text", "")),
                    "clipboard": "clipboard_read",
                    "screenshot": "screenshot",
                }

                intent_name = parsed_intent.intent.value
                if intent_name in intent_handlers:
                    handler = intent_handlers[intent_name]
                    if callable(handler):
                        result = handler()
                    else:
                        result = self.plugin_manager.execute(handler)

                    if hasattr(result, 'data'):
                        return result.data if result.success else result.error_message or "Command failed"
                    else:
                        return str(result)

            # Handle UI automation commands
            if parsed_intent.intent.value == "click" and self.ui_automation:
                x = parsed_intent.parameters.get("x")
                y = parsed_intent.parameters.get("y")
                if x is not None and y is not None:
                    result = self.ui_automation.click(int(x), int(y))
                    return result.message if result.success else result.error_message

            # Handle general queries
            if parsed_intent.intent.value == "general_query":
                return f"I understand you're asking about: {parsed_intent.original_text}. AI integration would be implemented here."

            # Default response
            return f"I processed your {parsed_intent.intent.value} command."

        except Exception as e:
            self.logger.error(f"Error executing command: {e}")
            return f"Error executing command: {e}"

    def toggle_voice_input(self):
        """Toggle voice input mode."""
        if not self.listening_for_command:
            self.on_wake_word_detected()
        else:
            self.stop_voice_input()

    def on_wake_word_detected(self):
        """Handle wake word detection."""
        self.listening_for_command = True
        self.wake_status.setText("🔴 Listening for command...")
        self.wake_status.setProperty("error", "true")
        self.status_label.setText("🔴 Command Mode Active")
        self.status_label.setProperty("error", "true")

        # Start voice input listening if available
        if self.voice_processor:
            # This would start listening for a single command
            self.log_event("Voice command mode activated")

    def stop_voice_input(self):
        """Stop voice input mode."""
        self.listening_for_command = False
        self.wake_status.setText("🟢 Waiting for wake word...")
        self.wake_status.setProperty("warning", "true")
        self.status_label.setText("🟢 Ready")
        self.status_label.setProperty("status", "true")

    def on_command_recognized(self, text: str):
        """Handle recognized voice command."""
        self.input_field.setText(text)
        self.process_command()
        self.stop_voice_input()

    def append_chat(self, message: str):
        """Add message to chat display."""
        self.chat_display.append(message)
        # Scroll to bottom
        scrollbar = self.chat_display.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def log_event(self, message: str):
        """Add message to event log."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.event_log.append(f"[{timestamp}] {message}")
        # Keep only last 100 entries
        scrollbar = self.event_log.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def change_theme(self, theme_name: str):
        """Change the application theme."""
        self.theme_manager.set_theme(theme_name)
        apply_theme(self, theme_name)
        self.log_event(f"Theme changed to: {theme_name}")

    def show_memory(self):
        """Show memory dialog."""
        try:
            if self.memory_manager:
                facts = self.memory_manager.search_facts(limit=20)
                facts_text = "\n".join([f"• {fact.get('key', 'Unknown')}: {fact.get('value', '')[:100]}..."
                                       for fact in facts])
            else:
                facts_text = "Memory manager not available"

            dialog = QMessageBox(self)
            dialog.setWindowTitle("🧠 Buddy's Memory")
            dialog.setText(facts_text or "No memories stored yet")
            dialog.exec()
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to load memory: {e}")

    def show_history(self):
        """Show conversation history."""
        try:
            if self.memory_manager:
                history = self.memory_manager.get_recent_conversations(10)
                history_text = "\n---\n".join([
                    f"You: {h.get('user', '')}\nBuddy: {h.get('agent', '')}\n[{h.get('intent', 'general')}]"
                    for h in history
                ])
            else:
                history_text = "Memory manager not available"

            dialog = QMessageBox(self)
            dialog.setWindowTitle("📋 Recent Conversations")
            dialog.setText(history_text or "No history yet")
            dialog.exec()
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to load history: {e}")

    def show_preferences(self):
        """Show preferences dialog."""
        try:
            if self.command_parser:
                stats = self.command_parser.get_statistics()
                parser_text = f"Parser Stats: {json.dumps(stats, indent=2)}"
            else:
                parser_text = "Command parser not available"

            if self.plugin_manager:
                plugin_stats = self.plugin_manager.get_statistics()
                plugin_text = f"Plugin Stats: {json.dumps(plugin_stats, indent=2)}"
            else:
                plugin_text = "Plugin manager not available"

            dialog = QMessageBox(self)
            dialog.setWindowTitle("⚙️ Preferences & Statistics")
            dialog.setText(f"{parser_text}\n\n{plugin_text}")
            dialog.exec()
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to load preferences: {e}")

    def show_plugins(self):
        """Show plugin information."""
        try:
            if self.plugin_manager:
                plugins = self.plugin_manager.get_plugin_info()
                plugin_text = "\n".join([
                    f"• {p.get('name', 'Unknown')} v{p.get('version', 'N/A')} - {p.get('description', 'No description')}"
                    for p in plugins
                ])
            else:
                plugin_text = "Plugin manager not available"

            dialog = QMessageBox(self)
            dialog.setWindowTitle("🔌 Plugins")
            dialog.setText(plugin_text or "No plugins loaded")
            dialog.exec()
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to load plugins: {e}")

    def show_about(self):
        """Show about dialog."""
        about_text = """
🤖 Safwaan Buddy - Jarvis-Style Voice Assistant

Version: 1.0.0

An advanced personal automation assistant that combines:
• Voice interaction and speech recognition
• UI automation capabilities
• Memory management and learning
• Plugin system for extensibility
• System monitoring and control

Built with PyQt6, Python, and AI technologies.

© 2024 Safwaan Buddy Project
        """
        dialog = QMessageBox(self)
        dialog.setWindowTitle("ℹ️ About Safwaan Buddy")
        dialog.setText(about_text)
        dialog.exec()

    def setup_microphone(self):
        """Run microphone setup."""
        try:
            import subprocess
            subprocess.run([sys.executable, "scripts/setup_microphone.py"], check=True)
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to run microphone setup: {e}")

    def clear_chat(self):
        """Clear the chat display."""
        self.chat_display.clear()
        self.log_event("Chat cleared")

    def closeEvent(self, event):
        """Handle application close event."""
        self.logger.info("Application closing")

        # Stop monitoring thread
        if hasattr(self, 'monitor_thread'):
            self.monitor_thread.stop()

        # Stop voice processor
        if self.voice_processor:
            self.voice_processor.shutdown()

        # Close memory manager
        if self.memory_manager:
            self.memory_manager.close()

        event.accept()