#!/usr/bin/env python3
"""
GUI Styling and Themes for Safwaan Buddy
Provides Qt6 styling and theme management for the application interface.
"""

from typing import Dict, Any
from pathlib import Path
import json


class ThemeManager:
    """Manages GUI themes and styling."""

    def __init__(self):
        """Initialize theme manager."""
        self.themes_dir = Path(__file__).parent.parent.parent / "config" / "themes"
        self.themes_dir.mkdir(parents=True, exist_ok=True)

        # Load available themes
        self.themes = self._load_themes()
        self.current_theme = "dark"

    def _load_themes(self) -> Dict[str, Dict[str, str]]:
        """Load all available themes."""
        themes = {}

        # Load built-in dark theme
        themes["dark"] = self._get_dark_theme()

        # Load custom theme files
        for theme_file in self.themes_dir.glob("*.json"):
            try:
                with open(theme_file, 'r') as f:
                    theme_data = json.load(f)
                    themes[theme_data.get("name", theme_file.stem)] = theme_data
            except Exception as e:
                print(f"Warning: Failed to load theme {theme_file}: {e}")

        return themes

    def _get_dark_theme(self) -> Dict[str, str]:
        """Get built-in dark theme colors."""
        return {
            "name": "dark",
            "background_color": "#0a0e27",
            "secondary_background": "#1a1f3a",
            "primary_color": "#00d9ff",
            "secondary_color": "#00ff88",
            "accent_color": "#0f3460",
            "text_color": "#ffffff",
            "secondary_text": "#a0a0a0",
            "border_color": "#0f3460",
            "button_color": "#0f3460",
            "button_hover": "#1a5f7f",
            "success_color": "#00ff88",
            "warning_color": "#ffaa00",
            "error_color": "#ff4444",
            "input_background": "#1a1f3a",
            "input_border": "#0f3460",
            "shadow_color": "#000000",
        }

    def get_theme(self, theme_name: str = None) -> Dict[str, str]:
        """Get theme by name."""
        theme_name = theme_name or self.current_theme
        return self.themes.get(theme_name, self.themes["dark"])

    def set_theme(self, theme_name: str):
        """Set current theme."""
        if theme_name in self.themes:
            self.current_theme = theme_name
        else:
            print(f"Warning: Theme '{theme_name}' not found")

    def get_stylesheet(self, theme_name: str = None) -> str:
        """Generate Qt stylesheet for the specified theme."""
        theme = self.get_theme(theme_name)

        stylesheet = f"""
/* QMainWindow Styles */
QMainWindow {{
    background-color: {theme['background_color']};
    color: {theme['text_color']};
}}

/* QLabel Styles */
QLabel {{
    color: {theme['text_color']};
    font-family: 'Segoe UI', Arial, sans-serif;
}}

QLabel[header="true"] {{
    font-size: 22px;
    font-weight: bold;
    color: {theme['primary_color']};
    margin: 10px;
}}

QLabel[status="true"] {{
    color: {theme['success_color']};
    font-weight: bold;
}}

QLabel[warning="true"] {{
    color: {theme['warning_color']};
    font-weight: bold;
}}

QLabel[error="true"] {{
    color: {theme['error_color']};
    font-weight: bold;
}}

/* QLineEdit Styles */
QLineEdit {{
    background-color: {theme['input_background']};
    color: {theme['text_color']};
    border: 2px solid {theme['input_border']};
    padding: 8px;
    border-radius: 4px;
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 14px;
}}

QLineEdit:focus {{
    border-color: {theme['primary_color']};
    outline: none;
}}

/* QPushButton Styles */
QPushButton {{
    background-color: {theme['button_color']};
    color: {theme['text_color']};
    border: 2px solid {theme['primary_color']};
    padding: 10px 16px;
    font-weight: bold;
    border-radius: 4px;
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 14px;
    min-width: 80px;
}}

QPushButton:hover {{
    background-color: {theme['button_hover']};
    border-color: {theme['secondary_color']};
}}

QPushButton:pressed {{
    background-color: {theme['accent_color']};
    border-color: {theme['secondary_color']};
}}

QPushButton:disabled {{
    background-color: {theme['secondary_background']};
    color: {theme['secondary_text']};
    border-color: {theme['secondary_text']};
}}

/* QTextEdit Styles */
QTextEdit {{
    background-color: {theme['input_background']};
    color: {theme['text_color']};
    border: 1px solid {theme['input_border']};
    border-radius: 4px;
    font-family: 'Consolas', 'Courier New', monospace;
    font-size: 12px;
    padding: 8px;
}}

QTextEdit:focus {{
    border-color: {theme['primary_color']};
}}

/* QGroupBox Styles */
QGroupBox {{
    color: {theme['primary_color']};
    border: 2px solid {theme['border_color']};
    border-radius: 4px;
    padding: 10px;
    margin-top: 10px;
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 14px;
    font-weight: bold;
}}

QGroupBox::title {{
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 3px 0 3px;
    color: {theme['primary_color']};
}}

/* QProgressBar Styles */
QProgressBar {{
    border: 1px solid {theme['border_color']};
    border-radius: 4px;
    text-align: center;
    color: {theme['text_color']};
    background-color: {theme['secondary_background']};
}}

QProgressBar::chunk {{
    background-color: {theme['primary_color']};
    border-radius: 3px;
}}

/* QScrollBar Styles */
QScrollBar:vertical {{
    background-color: {theme['secondary_background']};
    width: 12px;
    border-radius: 6px;
}}

QScrollBar::handle:vertical {{
    background-color: {theme['border_color']};
    min-height: 20px;
    border-radius: 6px;
}}

QScrollBar::handle:vertical:hover {{
    background-color: {theme['button_hover']};
}}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    border: none;
    background: none;
}}

QScrollBar:horizontal {{
    background-color: {theme['secondary_background']};
    height: 12px;
    border-radius: 6px;
}}

QScrollBar::handle:horizontal {{
    background-color: {theme['border_color']};
    min-width: 20px;
    border-radius: 6px;
}}

QScrollBar::handle:horizontal:hover {{
    background-color: {theme['button_hover']};
}}

/* QTabWidget Styles */
QTabWidget::pane {{
    border: 1px solid {theme['border_color']};
    background-color: {theme['secondary_background']};
}}

QTabBar::tab {{
    background-color: {theme['button_color']};
    color: {theme['text_color']};
    padding: 8px 16px;
    border: 1px solid {theme['border_color']};
    border-bottom: none;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    margin-right: 2px;
}}

QTabBar::tab:selected {{
    background-color: {theme['secondary_background']};
    border-color: {theme['primary_color']};
}}

QTabBar::tab:hover {{
    background-color: {theme['button_hover']};
}}

/* QMenuBar and QMenu Styles */
QMenuBar {{
    background-color: {theme['secondary_background']};
    color: {theme['text_color']};
    border-bottom: 1px solid {theme['border_color']};
}}

QMenuBar::item {{
    padding: 4px 8px;
    background-color: transparent;
}}

QMenuBar::item:selected {{
    background-color: {theme['button_hover']};
}}

QMenu {{
    background-color: {theme['secondary_background']};
    color: {theme['text_color']};
    border: 1px solid {theme['border_color']};
}}

QMenu::item {{
    padding: 4px 16px;
}}

QMenu::item:selected {{
    background-color: {theme['button_hover']};
}}

/* QStatusBar Styles */
QStatusBar {{
    background-color: {theme['secondary_background']};
    color: {theme['text_color']};
    border-top: 1px solid {theme['border_color']};
}}

/* QSplitter Styles */
QSplitter::handle {{
    background-color: {theme['border_color']};
}}

QSplitter::handle:hover {{
    background-color: {theme['primary_color']}};
}}

/* QToolButton Styles */
QToolButton {{
    background-color: {theme['button_color']};
    color: {theme['text_color']};
    border: 1px solid {theme['border_color']};
    padding: 4px;
    border-radius: 3px;
}}

QToolButton:hover {{
    background-color: {theme['button_hover']};
    border-color: {theme['primary_color']};
}}

QToolButton:pressed {{
    background-color: {theme['accent_color']};
}}

/* QCheckBox and QRadioButton Styles */
QCheckBox, QRadioButton {{
    color: {theme['text_color']};
    spacing: 8px;
}}

QCheckBox::indicator, QRadioButton::indicator {{
    width: 16px;
    height: 16px;
    border: 2px solid {theme['border_color']};
    border-radius: 3px;
    background-color: {theme['secondary_background']};
}}

QCheckBox::indicator:checked, QRadioButton::indicator:checked {{
    background-color: {theme['primary_color']};
    border-color: {theme['primary_color']};
}}

/* QComboBox Styles */
QComboBox {{
    background-color: {theme['input_background']};
    color: {theme['text_color']};
    border: 2px solid {theme['input_border']};
    padding: 4px 8px;
    border-radius: 4px;
    min-width: 80px;
}}

QComboBox:focus {{
    border-color: {theme['primary_color']};
}}

QComboBox::drop-down {{
    border: none;
    width: 20px;
}}

QComboBox::down-arrow {{
    image: none;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 4px solid {theme['text_color']};
    width: 0;
    height: 0;
}}

QComboBox QAbstractItemView {{
    background-color: {theme['secondary_background']};
    color: {theme['text_color']};
    border: 1px solid {theme['border_color']};
    selection-background-color: {theme['button_hover']};
}}
"""
        return stylesheet

    def get_available_themes(self) -> list:
        """Get list of available theme names."""
        return list(self.themes.keys())

    def save_theme(self, theme_name: str, theme_data: Dict[str, str]):
        """Save theme to file."""
        theme_data["name"] = theme_name
        theme_file = self.themes_dir / f"{theme_name}.json"

        try:
            with open(theme_file, 'w') as f:
                json.dump(theme_data, f, indent=2)

            # Reload themes
            self.themes = self._load_themes()
            return True

        except Exception as e:
            print(f"Failed to save theme {theme_name}: {e}")
            return False

    def delete_theme(self, theme_name: str) -> bool:
        """Delete a theme (cannot delete built-in themes)."""
        if theme_name == "dark":
            return False  # Cannot delete built-in theme

        theme_file = self.themes_dir / f"{theme_name}.json"
        try:
            if theme_file.exists():
                theme_file.unlink()

            # Reload themes
            self.themes = self._load_themes()
            return True

        except Exception as e:
            print(f"Failed to delete theme {theme_name}: {e}")
            return False


# Global theme manager instance
_theme_manager = None


def get_theme_manager() -> ThemeManager:
    """Get the global theme manager instance."""
    global _theme_manager
    if _theme_manager is None:
        _theme_manager = ThemeManager()
    return _theme_manager


def get_stylesheet(theme_name: str = None) -> str:
    """Get stylesheet for the specified theme."""
    return get_theme_manager().get_stylesheet(theme_name)


def apply_theme(widget, theme_name: str = None):
    """Apply theme to a widget."""
    stylesheet = get_stylesheet(theme_name)
    widget.setStyleSheet(stylesheet)