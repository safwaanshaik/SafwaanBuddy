#!/usr/bin/env python3
"""
Main Entry Point for Safwaan Buddy
Initializes all components and launches the GUI application.
"""

import sys
import os
import signal
import argparse
from pathlib import Path
from typing import Optional

# Add current directory to path for imports
current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir))

# Import core components
try:
    from config import get_config, ConfigManager
    from utils.logger import setup_logging, get_logger
    from core.memory import MemoryManager
    from core.voice_processor import VoiceProcessor
    from core.command_parser import AICommandParser
    from core.plugin_manager import PluginManager
    from core.ui_automation import UIAutomation, SafetyLevel
    from utils.system_monitor import start_system_monitoring, stop_system_monitoring
    from utils.helpers import is_admin

    # Enhanced modules
    from core.natural_speech import NaturalSpeechProcessor, EmotionState
    from core.system_control import SystemControlManager
    from core.ai_personality import AdvancedAIPersonality
except ImportError as e:
    print(f"Error importing core components: {e}")
    print("Please run: python scripts/install.py")
    sys.exit(1)

# Import GUI components (Qt6)
try:
    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtCore import QTimer, QThread, pyqtSignal
    from gui.main_window import SafwaanBuddyGUI
except ImportError as e:
    print(f"Error importing GUI components: {e}")
    print("PyQt6 is required for the GUI. Please install it with: pip install PyQt6")
    sys.exit(1)


class SafwaanBuddyApp:
    """Main application class for Safwaan Buddy."""

    def __init__(self, debug: bool = False):
        """Initialize the application."""
        self.debug = debug
        self.app = None
        self.main_window = None

        # Initialize configuration
        self.config = get_config()

        # Setup logging
        log_level = "DEBUG" if debug else self.config.get("log_level", "INFO")
        setup_logging(log_level)
        self.logger = get_logger("main")

        # Core components
        self.memory_manager: Optional[MemoryManager] = None
        self.voice_processor: Optional[VoiceProcessor] = None
        self.command_parser: Optional[AICommandParser] = None
        self.plugin_manager: Optional[PluginManager] = None
        self.ui_automation: Optional[UIAutomation] = None

        # Enhanced components
        self.natural_speech: Optional[NaturalSpeechProcessor] = None
        self.system_control: Optional[SystemControlManager] = None
        self.ai_personality: Optional[AdvancedAIPersonality] = None

        self.logger.info("Safwaan Buddy application initialized with advanced AI capabilities")

    def initialize_components(self):
        """Initialize all core components."""
        self.logger.info("Initializing core components...")

        try:
            # Initialize memory manager
            self.memory_manager = MemoryManager()
            self.logger.info("Memory manager initialized")

            # Initialize plugin manager
            self.plugin_manager = PluginManager(self.memory_manager)
            self.logger.info("Plugin manager initialized")

            # Initialize command parser
            self.command_parser = AICommandParser()
            self._setup_command_handlers()
            self.logger.info("Command parser initialized")

            # Initialize voice processor
            self.voice_processor = VoiceProcessor()
            self._setup_voice_handlers()
            self.logger.info("Voice processor initialized")

            # Initialize UI automation
            safety_level = SafetyLevel.NORMAL
            if self.debug:
                safety_level = SafetyLevel.ADVANCED
            self.ui_automation = UIAutomation(safety_level=safety_level)
            self.logger.info("UI automation initialized")

            # Initialize enhanced components
            self.natural_speech = NaturalSpeechProcessor()
            self.logger.info("Natural speech processor initialized")

            self.system_control = SystemControlManager()
            self.logger.info("System control manager initialized")

            self.ai_personality = AdvancedAIPersonality()
            self.logger.info("Advanced AI personality initialized")

            # Start system monitoring if enabled
            if self.config.get("enable_system_monitoring", True):
                start_system_monitoring()
                self.logger.info("System monitoring started")

            self.logger.info("All core and enhanced components initialized successfully")

        except Exception as e:
            self.logger.error(f"Failed to initialize components: {e}")
            raise

    def _setup_command_handlers(self):
        """Setup command handlers for the command parser."""
        # Register handlers for different intents
        from core.command_parser import IntentType

        # System status
        self.command_parser.register_callback(IntentType.SYSTEM_STATUS, self._handle_system_status)

        # Time
        self.command_parser.register_callback(IntentType.TIME, self._handle_time)

        # Applications
        self.command_parser.register_callback(IntentType.OPEN_APP, self._handle_open_app)
        self.command_parser.register_callback(IntentType.CLOSE_APP, self._handle_close_app)

        # Notes
        self.command_parser.register_callback(IntentType.SAVE_NOTE, self._handle_save_note)
        self.command_parser.register_callback(IntentType.RECALL_NOTE, self._handle_recall_note)
        self.command_parser.register_callback(IntentType.LIST_NOTES, self._handle_list_notes)
        self.command_parser.register_callback(IntentType.DELETE_NOTE, self._handle_delete_note)

        # UI Automation
        self.command_parser.register_callback(IntentType.TYPE_TEXT, self._handle_type_text)
        self.command_parser.register_callback(IntentType.CLICK, self._handle_click)
        self.command_parser.register_callback(IntentType.CLIPBOARD, self._handle_clipboard)

        # Screenshots
        self.command_parser.register_callback(IntentType.SCREENSHOT, self._handle_screenshot)

        # Calculator
        self.command_parser.register_callback(IntentType.CALCULATOR, self._handle_calculator)

        # General queries
        self.command_parser.register_callback(IntentType.GENERAL_QUERY, self._handle_general_query)

        # System control commands
        self.command_parser.register_callback(IntentType.OPEN_APP, self._handle_system_control_app)
        self.command_parser.register_callback(IntentType.CLOSE_APP, self._handle_system_control_app)
        self.command_parser.register_callback("SYSTEM_COMMAND", self._handle_system_command)
        self.command_parser.register_callback("FILE_OPERATION", self._handle_file_operation)
        self.command_parser.register_callback("SYSTEM_INFO", self._handle_system_info)
        self.command_parser.register_callback("NETWORK", self._handle_network_command)

    def _setup_voice_handlers(self):
        """Setup voice event handlers."""
        from core.voice_processor import VoiceEvent, IntentType

        def voice_event_handler(event: VoiceEvent):
            """Handle voice events."""
            if event.event_type == "wake_word_detected":
                self.logger.info("Wake word detected, activating listening mode")
                if self.main_window:
                    self.main_window.on_wake_word_detected()

            elif event.event_type == "command_recognized":
                text = event.data.get("text", "")
                self.logger.info(f"Command recognized: {text}")
                if self.main_window:
                    self.main_window.on_command_recognized(text)

        self.voice_processor.add_callback(voice_event_handler)

    def _handle_system_status(self, parsed_intent):
        """Handle system status commands."""
        try:
            result = self.plugin_manager.execute("system_stats")
            return result.data if result.success else "Failed to get system status"
        except Exception as e:
            self.logger.error(f"Error handling system status: {e}")
            return f"Error: {e}"

    def _handle_time(self, parsed_intent):
        """Handle time commands."""
        try:
            result = self.plugin_manager.execute("get_time")
            return result.data if result.success else "Failed to get time"
        except Exception as e:
            self.logger.error(f"Error handling time: {e}")
            return f"Error: {e}"

    def _handle_open_app(self, parsed_intent):
        """Handle application opening commands."""
        try:
            app_name = parsed_intent.parameters.get("app_name", "notepad")
            result = self.plugin_manager.execute("open_app", app_name)
            return result.data if result.success else "Failed to open application"
        except Exception as e:
            self.logger.error(f"Error opening app: {e}")
            return f"Error: {e}"

    def _handle_close_app(self, parsed_intent):
        """Handle application closing commands."""
        try:
            app_name = parsed_intent.parameters.get("app_name", "")
            result = self.plugin_manager.execute("close_app", app_name)
            return result.data if result.success else "Failed to close application"
        except Exception as e:
            self.logger.error(f"Error closing app: {e}")
            return f"Error: {e}"

    def _handle_save_note(self, parsed_intent):
        """Handle note saving commands."""
        try:
            title = parsed_intent.parameters.get("title", "")
            content = parsed_intent.parameters.get("content", "")
            result = self.plugin_manager.execute("save_note", title, content)
            return result.data if result.success else "Failed to save note"
        except Exception as e:
            self.logger.error(f"Error saving note: {e}")
            return f"Error: {e}"

    def _handle_recall_note(self, parsed_intent):
        """Handle note recall commands."""
        try:
            title = parsed_intent.parameters.get("title", "")
            result = self.plugin_manager.execute("recall_note", title)
            return result.data if result.success else "Failed to recall note"
        except Exception as e:
            self.logger.error(f"Error recalling note: {e}")
            return f"Error: {e}"

    def _handle_list_notes(self, parsed_intent):
        """Handle note listing commands."""
        try:
            result = self.plugin_manager.execute("list_notes")
            return result.data if result.success else "Failed to list notes"
        except Exception as e:
            self.logger.error(f"Error listing notes: {e}")
            return f"Error: {e}"

    def _handle_delete_note(self, parsed_intent):
        """Handle note deletion commands."""
        try:
            title = parsed_intent.parameters.get("title", "")
            result = self.plugin_manager.execute("delete_note", title)
            return result.data if result.success else "Failed to delete note"
        except Exception as e:
            self.logger.error(f"Error deleting note: {e}")
            return f"Error: {e}"

    def _handle_type_text(self, parsed_intent):
        """Handle text typing commands."""
        try:
            text = parsed_intent.parameters.get("text", "")
            if not self.ui_automation:
                return "UI automation is disabled"

            result = self.ui_automation.type_text(text)
            return result.message if result.success else f"Error: {result.message}"
        except Exception as e:
            self.logger.error(f"Error typing text: {e}")
            return f"Error: {e}"

    def _handle_click(self, parsed_intent):
        """Handle click commands."""
        try:
            x = parsed_intent.parameters.get("x")
            y = parsed_intent.parameters.get("y")
            double_click = parsed_intent.parameters.get("double_click", False)

            if not self.ui_automation:
                return "UI automation is disabled"

            if double_click:
                result = self.ui_automation.double_click(x, y)
            else:
                result = self.ui_automation.click(x, y)

            return result.message if result.success else f"Error: {result.message}"
        except Exception as e:
            self.logger.error(f"Error handling click: {e}")
            return f"Error: {e}"

    def _handle_clipboard(self, parsed_intent):
        """Handle clipboard commands."""
        try:
            action = parsed_intent.parameters.get("action", "read")
            text = parsed_intent.parameters.get("text", "")

            if action == "read":
                result = self.plugin_manager.execute("clipboard_read")
                return result.data if result.success else "Failed to read clipboard"
            else:
                result = self.plugin_manager.execute("clipboard_write", text)
                return result.data if result.success else "Failed to write to clipboard"
        except Exception as e:
            self.logger.error(f"Error handling clipboard: {e}")
            return f"Error: {e}"

    def _handle_screenshot(self, parsed_intent):
        """Handle screenshot commands."""
        try:
            x = parsed_intent.parameters.get("x")
            y = parsed_intent.parameters.get("y")
            region = parsed_intent.parameters.get("region", False)

            if not self.ui_automation:
                return "UI automation is disabled"

            if x is not None and y is not None:
                result = self.ui_automation.screenshot(region=(x, y, 100, 100))
            else:
                result = self.ui_automation.screenshot()

            return result.message if result.success else f"Error: {result.message}"
        except Exception as e:
            self.logger.error(f"Error handling screenshot: {e}")
            return f"Error: {e}"

    def _handle_calculator(self, parsed_intent):
        """Handle calculator commands."""
        try:
            expression = parsed_intent.parameters.get("expression", "")
            result = self.plugin_manager.execute("calculate", expression)
            return result.data if result.success else "Failed to calculate"
        except Exception as e:
            self.logger.error(f"Error handling calculator: {e}")
            return f"Error: {e}"

    def _handle_general_query(self, parsed_intent):
        """Handle general AI queries with advanced AI personality."""
        try:
            user_input = parsed_intent.original_text

            # Get conversation context from memory
            context = []
            if self.memory_manager:
                recent_conversations = self.memory_manager.get_recent_conversations(5)
                context = [
                    {"user": conv['user'], "assistant": conv['agent']}
                    for conv in recent_conversations
                ]

            # Detect language using natural speech processor
            detected_language = self.natural_speech.detect_language(user_input) if self.natural_speech else "english"

            # Analyze emotional context
            emotion_state = self.natural_speech.analyze_emotional_context(
                user_input, [conv.get("user", "") for conv in context[-3:]]
            ) if self.natural_speech else EmotionState("neutral", 0.5, 0.8, 0.7)

            # Generate intelligent response using advanced AI personality
            if self.ai_personality:
                ai_response = self.ai_personality.analyze_and_respond(
                    user_input, context, detected_language
                )

                if ai_response["success"]:
                    response_text = ai_response["response"]

                    # Enhance response with natural speech patterns
                    if self.natural_speech:
                        enhanced_response = self.natural_speech.enhance_response_naturally(
                            response_text, emotion_state
                        )

                        # Create conversation context for natural speech
                        self.natural_speech.create_conversation_context(
                            user_input, enhanced_response
                        )

                        response_text = enhanced_response

                    # Store conversation in memory
                    if self.memory_manager:
                        self.memory_manager.store_conversation(
                            user_input, response_text,
                            {
                                "intent": "general_query",
                                "language": detected_language,
                                "emotion": emotion_state.primary_emotion,
                                "confidence": ai_response.get("confidence", 0.8)
                            }
                        )

                    return response_text
                else:
                    return f"I apologize, but I encountered an issue: {ai_response.get('error', 'Unknown error')}"

            # Fallback to simple response if AI personality is not available
            return f"I understand you're asking about: {user_input}. Let me help you with that."

        except Exception as e:
            self.logger.error(f"Error handling general query: {e}")
            return f"I apologize, but I encountered an error while processing your request: {e}"

    def _handle_system_control_app(self, parsed_intent):
        """Handle application control using system control manager."""
        try:
            if not self.system_control:
                return "System control manager is not available"

            app_name = parsed_intent.parameters.get("app_name", "")
            action = "open" if parsed_intent.intent_type == IntentType.OPEN_APP else "close"

            if action == "open":
                result = self.system_control.launch_application(app_name)
            else:
                result = self.system_control.close_application(app_name)

            if result["success"]:
                return result["message"]
            else:
                return f"Failed to {action} {app_name}: {result.get('error', 'Unknown error')}"

        except Exception as e:
            self.logger.error(f"Error in system control app handler: {e}")
            return f"Error: {e}"

    def _handle_system_command(self, parsed_intent):
        """Handle system commands using system control manager."""
        try:
            if not self.system_control:
                return "System control manager is not available"

            command = parsed_intent.parameters.get("command", "")
            admin_required = parsed_intent.parameters.get("admin_required", False)

            result = self.system_control.execute_system_command(
                command, admin_required=admin_required
            )

            if result["success"]:
                if result.get("stdout"):
                    return f"Command executed successfully. Output: {result['stdout']}"
                else:
                    return result["message"]
            else:
                return f"Command failed: {result.get('error', 'Unknown error')}"

        except Exception as e:
            self.logger.error(f"Error handling system command: {e}")
            return f"Error: {e}"

    def _handle_file_operation(self, parsed_intent):
        """Handle file operations using system control manager."""
        try:
            if not self.system_control:
                return "System control manager is not available"

            operation = parsed_intent.parameters.get("operation", "")
            source = parsed_intent.parameters.get("source", "")
            destination = parsed_intent.parameters.get("destination", "")
            content = parsed_intent.parameters.get("content", "")

            if operation == "create":
                result = self.system_control.create_file(source, content)
            elif operation == "read":
                result = self.system_control.read_file(source)
            elif operation == "copy":
                result = self.system_control.copy_file(source, destination)
            elif operation == "move":
                result = self.system_control.move_file(source, destination)
            elif operation == "delete":
                result = self.system_control.delete_file(source)
            else:
                return f"Unsupported file operation: {operation}"

            if result["success"]:
                if operation == "read":
                    return f"File content:\n{result.get('content', 'Empty file')}"
                else:
                    return result["message"]
            else:
                return f"File operation failed: {result.get('error', 'Unknown error')}"

        except Exception as e:
            self.logger.error(f"Error handling file operation: {e}")
            return f"Error: {e}"

    def _handle_system_info(self, parsed_intent):
        """Handle system information requests."""
        try:
            if not self.system_control:
                return "System control manager is not available"

            info_type = parsed_intent.parameters.get("type", "overview")

            if info_type == "overview":
                result = self.system_control.get_system_overview()
            elif info_type == "processes":
                result = self.system_control.get_running_processes()
            elif info_type == "services":
                result = self.system_control.get_system_services()
            elif info_type == "hardware":
                result = self.system_control.get_hardware_info()
            else:
                result = self.system_control.get_system_overview()

            if result["success"]:
                return result["message"]
            else:
                return f"Failed to get system information: {result.get('error', 'Unknown error')}"

        except Exception as e:
            self.logger.error(f"Error handling system info: {e}")
            return f"Error: {e}"

    def _handle_network_command(self, parsed_intent):
        """Handle network commands using system control manager."""
        try:
            if not self.system_control:
                return "System control manager is not available"

            action = parsed_intent.parameters.get("action", "")
            target = parsed_intent.parameters.get("target", "")

            if action == "ping":
                result = self.system_control.ping_host(target)
            elif action == "scan":
                result = self.system_control.scan_network()
            elif action == "speed":
                result = self.system_control.measure_network_speed()
            elif action == "info":
                result = self.system_control.get_network_info()
            else:
                return f"Unsupported network action: {action}"

            if result["success"]:
                return result["message"]
            else:
                return f"Network command failed: {result.get('error', 'Unknown error')}"

        except Exception as e:
            self.logger.error(f"Error handling network command: {e}")
            return f"Error: {e}"

    def run_gui(self) -> int:
        """Run the GUI application."""
        try:
            # Initialize Qt application
            self.app = QApplication(sys.argv)
            self.app.setApplicationName("Safwaan Buddy")
            self.app.setApplicationVersion("1.0.0")

            # Set application style
            self.app.setStyle("Fusion")

            # Create main window with enhanced components
            self.main_window = SafwaanBuddyGUI(
                self.memory_manager,
                self.voice_processor,
                self.command_parser,
                self.plugin_manager,
                self.ui_automation,
                self.natural_speech,
                self.system_control,
                self.ai_personality
            )

            # Setup signal handlers
            signal.signal(signal.SIGINT, self._signal_handler)
            signal.signal(signal.SIGTERM, self._signal_handler)

            # Show main window
            self.main_window.show()

            # Start voice processing if enabled
            if self.config.get("enable_wake_word_detection", True):
                self.voice_processor.start_wake_word_detection()

            self.logger.info("GUI application started")

            # Run the application
            return self.app.exec()

        except Exception as e:
            self.logger.error(f"GUI application failed: {e}")
            return 1

    def _signal_handler(self, signum, frame):
        """Handle shutdown signals."""
        self.logger.info(f"Received signal {signum}, shutting down...")
        self.shutdown()

    def shutdown(self):
        """Shutdown the application gracefully."""
        self.logger.info("Shutting down Safwaan Buddy...")

        try:
            # Stop voice processing
            if self.voice_processor:
                self.voice_processor.shutdown()

            # Stop system monitoring
            if self.config.get("enable_system_monitoring", True):
                stop_system_monitoring()

            # Close memory manager
            if self.memory_manager:
                self.memory_manager.close()

            # Close UI automation
            if self.ui_automation:
                self.ui_automation.disable()

            self.logger.info("Shutdown completed")

        except Exception as e:
            self.logger.error(f"Error during shutdown: {e}")

        # Quit Qt application if running
        if self.app:
            self.app.quit()


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Safwaan Buddy - Jarvis-Style Voice Assistant")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    parser.add_argument("--no-gui", action="store_true", help="Run without GUI (command line mode)")
    parser.add_argument("--version", action="version", version="Safwaan Buddy 1.0.0")

    args = parser.parse_args()

    # Check for administrative privileges for UI automation
    if not is_admin():
        print("Warning: Running without administrative privileges. UI automation features will be limited.")

    # Create and initialize application
    app = SafwaanBuddyApp(debug=args.debug)

    try:
        # Initialize components
        app.initialize_components()

        # Run in appropriate mode
        if args.no_gui:
            print("Running in command line mode...")
            print("Type 'help' for available commands or 'quit' to exit.")
            # TODO: Implement command line interface
            return 0
        else:
            # Run GUI application
            exit_code = app.run_gui()
            return exit_code

    except KeyboardInterrupt:
        print("\nInterrupted by user")
        app.shutdown()
        return 0
    except Exception as e:
        print(f"Application failed: {e}")
        if app.debug:
            import traceback
            traceback.print_exc()
        app.shutdown()
        return 1


if __name__ == "__main__":
    sys.exit(main())