"""
Built-in and external plugins for Safwaan Buddy
"""

# Import plugin base class from core
from core.plugin_manager import BasePlugin

# Import individual plugin modules
from .system import SystemPlugin
from .notes import NotesPlugin
from .automation import AutomationPlugin

__all__ = [
    "BasePlugin",
    "SystemPlugin",
    "NotesPlugin",
    "AutomationPlugin"
]