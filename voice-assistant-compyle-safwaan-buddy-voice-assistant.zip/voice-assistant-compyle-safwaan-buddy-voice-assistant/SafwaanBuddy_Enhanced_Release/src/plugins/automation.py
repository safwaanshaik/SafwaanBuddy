#!/usr/bin/env python3
"""
Automation and workflow plugins for Safwaan Buddy
Provides advanced automation sequences and macro recording.
"""

import json
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List

from core.plugin_manager import BasePlugin


class AutomationPlugin(BasePlugin):
    """Plugin for automation and workflow operations."""

    def __init__(self):
        super().__init__("automation")
        self.version = "1.0.0"
        self.description = "Advanced automation sequences and macro recording"
        self.author = "Safwaan Buddy"
        self.automation_dir = Path("data/automation")
        self.automation_dir.mkdir(parents=True, exist_ok=True)
        self.current_macro = []
        self.recording = False

    def get_functions(self) -> Dict[str, Any]:
        """Return dictionary of plugin functions."""
        return {
            "start_recording": self.start_recording,
            "stop_recording": self.stop_recording,
            "play_macro": self.play_macro,
            "save_macro": self.save_macro,
            "list_macros": self.list_macros,
            "delete_macro": self.delete_macro,
            "create_workflow": self.create_workflow,
            "execute_workflow": self.execute_workflow,
            "delay": self.delay_action,
            "conditional": self.conditional_action,
        }

    def start_recording(self) -> str:
        """Start recording a macro."""
        try:
            if self.recording:
                return "Already recording a macro"

            self.recording = True
            self.current_macro = []
            return "Started recording macro. Perform actions and then call stop_recording()"

        except Exception as e:
            return f"Error starting recording: {e}"

    def stop_recording(self) -> str:
        """Stop recording and return the recorded macro."""
        try:
            if not self.recording:
                return "Not currently recording"

            self.recording = False
            macro_data = {
                "name": f"macro_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                "actions": self.current_macro,
                "created_at": datetime.now().isoformat(),
                "action_count": len(self.current_macro)
            }

            self.current_macro = []
            return f"Stopped recording. Captured {macro_data['action_count']} actions"

        except Exception as e:
            return f"Error stopping recording: {e}"

    def play_macro(self, macro_name: str, repeat_count: int = 1) -> str:
        """Play a recorded macro."""
        try:
            macro_file = self.automation_dir / f"{macro_name}.json"

            if not macro_file.exists():
                return f"Error: Macro '{macro_name}' not found"

            with open(macro_file, 'r', encoding='utf-8') as f:
                macro_data = json.load(f)

            actions = macro_data.get("actions", [])
            if not actions:
                return f"Error: No actions found in macro '{macro_name}'"

            # Execute actions
            for repeat in range(repeat_count):
                for i, action in enumerate(actions):
                    try:
                        result = self._execute_action(action)
                        if not result.get("success", True):
                            return f"Error executing action {i+1}: {result.get('error', 'Unknown error')}"
                    except Exception as e:
                        return f"Error executing action {i+1}: {e}"

            return f"Macro '{macro_name}' executed successfully ({len(actions)} actions × {repeat_count} repeats)"

        except Exception as e:
            return f"Error playing macro: {e}"

    def save_macro(self, name: str, actions: List[Dict[str, Any]] = None) -> str:
        """Save a macro with given actions."""
        try:
            if not actions:
                actions = self.current_macro

            if not actions:
                return "Error: No actions to save"

            safe_name = self._sanitize_filename(name)
            macro_file = self.automation_dir / f"{safe_name}.json"

            macro_data = {
                "name": name,
                "actions": actions,
                "created_at": datetime.now().isoformat(),
                "action_count": len(actions)
            }

            with open(macro_file, 'w', encoding='utf-8') as f:
                json.dump(macro_data, f, indent=2, ensure_ascii=False)

            return f"Macro '{name}' saved with {len(actions)} actions"

        except Exception as e:
            return f"Error saving macro: {e}"

    def list_macros(self) -> str:
        """List all available macros."""
        try:
            macros = []

            for macro_file in self.automation_dir.glob("*.json"):
                try:
                    with open(macro_file, 'r', encoding='utf-8') as f:
                        macro_data = json.load(f)

                    macros.append({
                        "name": macro_data["name"],
                        "action_count": macro_data.get("action_count", 0),
                        "created_at": macro_data.get("created_at", "Unknown")
                    })
                except Exception:
                    continue

            if not macros:
                return "No macros found"

            # Sort by creation date (newest first)
            macros.sort(key=lambda x: x["created_at"], reverse=True)

            result = f"Found {len(macros)} macro{'s' if len(macros) != 1 else ''}:\n\n"
            for macro in macros:
                result += f"• {macro['name']}\n"
                result += f"  Actions: {macro['action_count']}\n"
                result += f"  Created: {macro['created_at'][:10]}\n\n"

            return result.strip()

        except Exception as e:
            return f"Error listing macros: {e}"

    def delete_macro(self, name: str) -> str:
        """Delete a macro."""
        try:
            safe_name = self._sanitize_filename(name)
            macro_file = self.automation_dir / f"{safe_name}.json"

            if not macro_file.exists():
                return f"Error: Macro '{name}' not found"

            macro_file.unlink()
            return f"Macro '{name}' deleted successfully"

        except Exception as e:
            return f"Error deleting macro: {e}"

    def create_workflow(self, name: str, steps: List[Dict[str, Any]]) -> str:
        """Create a workflow with multiple steps."""
        try:
            if not steps:
                return "Error: No steps provided for workflow"

            workflow_data = {
                "name": name,
                "steps": steps,
                "created_at": datetime.now().isoformat(),
                "step_count": len(steps)
            }

            safe_name = self._sanitize_filename(name)
            workflow_file = self.automation_dir / f"workflow_{safe_name}.json"

            with open(workflow_file, 'w', encoding='utf-8') as f:
                json.dump(workflow_data, f, indent=2, ensure_ascii=False)

            return f"Workflow '{name}' created with {len(steps)} steps"

        except Exception as e:
            return f"Error creating workflow: {e}"

    def execute_workflow(self, name: str) -> str:
        """Execute a workflow."""
        try:
            safe_name = self._sanitize_filename(name)
            workflow_file = self.automation_dir / f"workflow_{safe_name}.json"

            if not workflow_file.exists():
                return f"Error: Workflow '{name}' not found"

            with open(workflow_file, 'r', encoding='utf-8') as f:
                workflow_data = json.load(f)

            steps = workflow_data.get("steps", [])
            if not steps:
                return f"Error: No steps found in workflow '{name}'"

            # Execute workflow steps
            for i, step in enumerate(steps):
                try:
                    step_type = step.get("type")
                    step_data = step.get("data", {})

                    if step_type == "action":
                        result = self._execute_action(step_data)
                    elif step_type == "delay":
                        result = self._execute_delay(step_data)
                    elif step_type == "conditional":
                        result = self._execute_conditional(step_data)
                    elif step_type == "macro":
                        result = self.play_macro(step_data.get("macro_name"), step_data.get("repeat_count", 1))
                    else:
                        return f"Error: Unknown step type '{step_type}' at step {i+1}"

                    if not result.get("success", True):
                        return f"Error executing step {i+1}: {result.get('error', 'Unknown error')}"

                except Exception as e:
                    return f"Error executing step {i+1}: {e}"

            return f"Workflow '{name}' executed successfully ({len(steps)} steps)"

        except Exception as e:
            return f"Error executing workflow: {e}"

    def delay_action(self, seconds: float) -> str:
        """Add a delay action."""
        try:
            if self.recording:
                self.current_macro.append({
                    "type": "delay",
                    "data": {"seconds": seconds},
                    "timestamp": time.time()
                })
                return f"Added {seconds}s delay to recording"
            else:
                time.sleep(seconds)
                return f"Delayed for {seconds} seconds"

        except Exception as e:
            return f"Error with delay action: {e}"

    def conditional_action(self, condition: str, true_actions: List[Dict] = None, false_actions: List[Dict] = None) -> str:
        """Add a conditional action."""
        try:
            action_data = {
                "type": "conditional",
                "data": {
                    "condition": condition,
                    "true_actions": true_actions or [],
                    "false_actions": false_actions or []
                },
                "timestamp": time.time()
            }

            if self.recording:
                self.current_macro.append(action_data)
                return f"Added conditional action to recording"
            else:
                # Execute conditional immediately
                return self._execute_conditional(action_data["data"])

        except Exception as e:
            return f"Error with conditional action: {e}"

    def _execute_action(self, action: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a single action."""
        try:
            action_type = action.get("type")

            if action_type == "type":
                # This would integrate with UI automation
                text = action.get("data", {}).get("text", "")
                return {"success": True, "message": f"Would type: {text}"}

            elif action_type == "click":
                x = action.get("data", {}).get("x", 0)
                y = action.get("data", {}).get("y", 0)
                return {"success": True, "message": f"Would click at ({x}, {y})"}

            elif action_type == "key_press":
                key = action.get("data", {}).get("key", "")
                return {"success": True, "message": f"Would press key: {key}"}

            elif action_type == "open_app":
                app = action.get("data", {}).get("app", "")
                return {"success": True, "message": f"Would open app: {app}"}

            else:
                return {"success": False, "error": f"Unknown action type: {action_type}"}

        except Exception as e:
            return {"success": False, "error": str(e)}

    def _execute_delay(self, delay_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a delay."""
        try:
            seconds = delay_data.get("seconds", 0)
            time.sleep(seconds)
            return {"success": True, "message": f"Delayed for {seconds} seconds"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _execute_conditional(self, conditional_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a conditional statement."""
        try:
            condition = conditional_data.get("condition", "")
            true_actions = conditional_data.get("true_actions", [])
            false_actions = conditional_data.get("false_actions", [])

            # Simple condition evaluation (in real implementation, this would be more robust)
            condition_met = self._evaluate_condition(condition)

            actions_to_execute = true_actions if condition_met else false_actions

            for action in actions_to_execute:
                result = self._execute_action(action)
                if not result.get("success", True):
                    return result

            return {
                "success": True,
                "message": f"Conditional executed: {'true' if condition_met else 'false'} branch"
            }

        except Exception as e:
            return {"success": False, "error": str(e)}

    def _evaluate_condition(self, condition: str) -> bool:
        """Evaluate a simple condition."""
        try:
            # This is a very basic implementation
            # In a real system, you'd want a more robust expression evaluator
            condition = condition.strip().lower()

            # Simple keyword-based evaluation
            if "always" in condition:
                return True
            elif "never" in condition:
                return False
            else:
                # Default to true for unknown conditions
                return True

        except Exception:
            return True

    def _sanitize_filename(self, filename: str) -> str:
        """Sanitize filename for safe file system usage."""
        import re
        sanitized = re.sub(r'[<>:"/\\|?*]', '_', filename)
        sanitized = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', sanitized)
        sanitized = sanitized.strip(' .')

        if len(sanitized) > 100:
            sanitized = sanitized[:100]

        return sanitized or "untitled"