#!/usr/bin/env python3
"""
Note management plugins for Safwaan Buddy
Provides note creation, retrieval, searching, and organization.
"""

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List

from core.plugin_manager import BasePlugin


class NotesPlugin(BasePlugin):
    """Plugin for note management operations."""

    def __init__(self):
        super().__init__("notes")
        self.version = "1.0.0"
        self.description = "Advanced note management with tagging and search"
        self.author = "Safwaan Buddy"
        self.notes_dir = Path("data/notes")
        self.notes_dir.mkdir(parents=True, exist_ok=True)

    def get_functions(self) -> Dict[str, Any]:
        """Return dictionary of plugin functions."""
        return {
            "create_note": self.create_note,
            "get_note": self.get_note,
            "list_notes": self.list_notes,
            "search_notes": self.search_notes,
            "delete_note": self.delete_note,
            "add_tags": self.add_tags,
            "get_tags": self.get_tags,
            "export_notes": self.export_notes,
            "import_notes": self.import_notes,
        }

    def create_note(self, title: str, content: str, tags: List[str] = None) -> str:
        """Create a new note."""
        try:
            if not title.strip():
                return "Error: Note title cannot be empty"

            # Sanitize filename
            safe_title = self._sanitize_filename(title)
            note_file = self.notes_dir / f"{safe_title}.json"

            # Check if note already exists
            if note_file.exists():
                return f"Error: Note '{title}' already exists"

            note_data = {
                "title": title,
                "content": content,
                "tags": tags or [],
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "word_count": len(content.split()),
                "character_count": len(content)
            }

            with open(note_file, 'w', encoding='utf-8') as f:
                json.dump(note_data, f, indent=2, ensure_ascii=False)

            return f"Note '{title}' created successfully with {len(content)} characters"

        except Exception as e:
            return f"Error creating note: {e}"

    def get_note(self, title: str) -> str:
        """Get a note by title."""
        try:
            safe_title = self._sanitize_filename(title)
            note_file = self.notes_dir / f"{safe_title}.json"

            if not note_file.exists():
                return f"Error: Note '{title}' not found"

            with open(note_file, 'r', encoding='utf-8') as f:
                note_data = json.load(f)

            return f"Title: {note_data['title']}\nTags: {', '.join(note_data['tags'])}\nCreated: {note_data['created_at']}\n\n{note_data['content']}"

        except Exception as e:
            return f"Error getting note: {e}"

    def list_notes(self, tag: str = None, limit: int = 50) -> str:
        """List all notes, optionally filtered by tag."""
        try:
            notes = []
            for note_file in self.notes_dir.glob("*.json"):
                try:
                    with open(note_file, 'r', encoding='utf-8') as f:
                        note_data = json.load(f)

                    # Filter by tag if specified
                    if tag and tag.lower() not in [t.lower() for t in note_data.get("tags", [])]:
                        continue

                    notes.append({
                        "title": note_data["title"],
                        "tags": note_data.get("tags", []),
                        "created_at": note_data["created_at"],
                        "updated_at": note_data["updated_at"],
                        "word_count": note_data.get("word_count", 0),
                        "preview": note_data["content"][:100] + "..." if len(note_data["content"]) > 100 else note_data["content"]
                    })
                except Exception:
                    continue

            # Sort by creation date (newest first)
            notes.sort(key=lambda x: x["created_at"], reverse=True)

            # Limit results
            notes = notes[:limit]

            if not notes:
                return f"No notes found{' with tag: ' + tag if tag else ''}"

            # Format results
            result = f"Found {len(notes)} note{'s' if len(notes) != 1 else ''}:\n\n"
            for note in notes:
                result += f"• {note['title']}\n"
                result += f"  Tags: {', '.join(note['tags']) if note['tags'] else 'None'}\n"
                result += f"  Created: {note['created_at'][:10]}\n"
                result += f"  Preview: {note['preview']}\n\n"

            return result.strip()

        except Exception as e:
            return f"Error listing notes: {e}"

    def search_notes(self, query: str, search_content: bool = True) -> str:
        """Search notes by title and content."""
        try:
            if not query.strip():
                return "Error: Search query cannot be empty"

            query_lower = query.lower()
            matching_notes = []

            for note_file in self.notes_dir.glob("*.json"):
                try:
                    with open(note_file, 'r', encoding='utf-8') as f:
                        note_data = json.load(f)

                    # Search in title
                    title_match = query_lower in note_data["title"].lower()
                    content_match = search_content and query_lower in note_data["content"].lower()
                    tags_match = any(query_lower in tag.lower() for tag in note_data.get("tags", []))

                    if title_match or content_match or tags_match:
                        match_info = {
                            "title": note_data["title"],
                            "tags": note_data.get("tags", []),
                            "created_at": note_data["created_at"],
                            "title_match": title_match,
                            "content_match": content_match,
                            "tags_match": tags_match
                        }

                        if content_match:
                            # Extract context around match
                            content = note_data["content"]
                            match_index = content.lower().find(query_lower)
                            if match_index != -1:
                                start = max(0, match_index - 50)
                                end = min(len(content), match_index + 150)
                                context = content[start:end]
                                if start > 0:
                                    context = "..." + context
                                if end < len(content):
                                    context = context + "..."
                                match_info["context"] = context

                        matching_notes.append(match_info)

                except Exception:
                    continue

            if not matching_notes:
                return f"No notes found matching: {query}"

            # Format results
            result = f"Found {len(matching_notes)} note{'s' if len(matching_notes) != 1 else ''} matching '{query}':\n\n"
            for note in matching_notes:
                result += f"• {note['title']}\n"
                result += f"  Matched in: "
                matches = []
                if note["title_match"]:
                    matches.append("Title")
                if note["content_match"]:
                    matches.append("Content")
                if note["tags_match"]:
                    matches.append("Tags")
                result += ", ".join(matches)
                result += f"\n  Created: {note['created_at'][:10]}\n"
                if "context" in note:
                    result += f"  Context: {note['context']}\n"
                result += "\n"

            return result.strip()

        except Exception as e:
            return f"Error searching notes: {e}"

    def delete_note(self, title: str) -> str:
        """Delete a note."""
        try:
            safe_title = self._sanitize_filename(title)
            note_file = self.notes_dir / f"{safe_title}.json"

            if not note_file.exists():
                return f"Error: Note '{title}' not found"

            note_file.unlink()
            return f"Note '{title}' deleted successfully"

        except Exception as e:
            return f"Error deleting note: {e}"

    def add_tags(self, title: str, tags: List[str]) -> str:
        """Add tags to an existing note."""
        try:
            safe_title = self._sanitize_filename(title)
            note_file = self.notes_dir / f"{safe_title}.json"

            if not note_file.exists():
                return f"Error: Note '{title}' not found"

            with open(note_file, 'r', encoding='utf-8') as f:
                note_data = json.load(f)

            existing_tags = set(note_data.get("tags", []))
            new_tags = set(tags)

            note_data["tags"] = list(existing_tags.union(new_tags))
            note_data["updated_at"] = datetime.now().isoformat()

            with open(note_file, 'w', encoding='utf-8') as f:
                json.dump(note_data, f, indent=2, ensure_ascii=False)

            return f"Added {len(new_tags - existing_tags)} new tags to '{title}'"

        except Exception as e:
            return f"Error adding tags: {e}"

    def get_tags(self) -> str:
        """Get all tags used in notes."""
        try:
            all_tags = set()

            for note_file in self.notes_dir.glob("*.json"):
                try:
                    with open(note_file, 'r', encoding='utf-8') as f:
                        note_data = json.load(f)
                    all_tags.update(note_data.get("tags", []))
                except Exception:
                    continue

            if not all_tags:
                return "No tags found"

            tag_counts = {}
            for note_file in self.notes_dir.glob("*.json"):
                try:
                    with open(note_file, 'r', encoding='utf-8') as f:
                        note_data = json.load(f)
                    for tag in note_data.get("tags", []):
                        tag_counts[tag] = tag_counts.get(tag, 0) + 1
                except Exception:
                    continue

            # Sort by frequency
            sorted_tags = sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)

            result = f"Found {len(all_tags)} unique tags:\n\n"
            for tag, count in sorted_tags:
                result += f"• {tag} ({count} note{'s' if count != 1 else ''})\n"

            return result.strip()

        except Exception as e:
            return f"Error getting tags: {e}"

    def export_notes(self, format: str = "json", tag: str = None) -> str:
        """Export notes to specified format."""
        try:
            notes = []
            for note_file in self.notes_dir.glob("*.json"):
                try:
                    with open(note_file, 'r', encoding='utf-8') as f:
                        note_data = json.load(f)

                    # Filter by tag if specified
                    if tag and tag.lower() not in [t.lower() for t in note_data.get("tags", [])]:
                        continue

                    notes.append(note_data)
                except Exception:
                    continue

            if not notes:
                return f"No notes to export{' with tag: ' + tag if tag else ''}"

            export_data = {
                "exported_at": datetime.now().isoformat(),
                "total_notes": len(notes),
                "notes": notes
            }

            export_file = self.notes_dir / f"export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"

            with open(export_file, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)

            return f"Exported {len(notes)} notes to {export_file}"

        except Exception as e:
            return f"Error exporting notes: {e}"

    def import_notes(self, file_path: str) -> str:
        """Import notes from a file."""
        try:
            import_path = Path(file_path)
            if not import_path.exists():
                return f"Error: Import file not found: {file_path}"

            with open(import_path, 'r', encoding='utf-8') as f:
                import_data = json.load(f)

            if "notes" not in import_data:
                return "Error: Invalid import file format"

            imported_count = 0
            skipped_count = 0

            for note_data in import_data["notes"]:
                title = note_data.get("title", "")
                if not title:
                    skipped_count += 1
                    continue

                safe_title = self._sanitize_filename(title)
                note_file = self.notes_dir / f"{safe_title}.json"

                # Check if note already exists
                if note_file.exists():
                    skipped_count += 1
                    continue

                # Update import timestamp
                note_data["imported_at"] = datetime.now().isoformat()
                note_data["updated_at"] = datetime.now().isoformat()

                with open(note_file, 'w', encoding='utf-8') as f:
                    json.dump(note_data, f, indent=2, ensure_ascii=False)

                imported_count += 1

            return f"Import completed: {imported_count} notes imported, {skipped_count} skipped"

        except Exception as e:
            return f"Error importing notes: {e}"

    def _sanitize_filename(self, filename: str) -> str:
        """Sanitize filename for safe file system usage."""
        # Remove or replace invalid characters
        sanitized = re.sub(r'[<>:"/\\|?*]', '_', filename)
        sanitized = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', sanitized)
        sanitized = sanitized.strip(' .')

        # Limit length
        if len(sanitized) > 100:
            sanitized = sanitized[:100]

        return sanitized or "untitled"