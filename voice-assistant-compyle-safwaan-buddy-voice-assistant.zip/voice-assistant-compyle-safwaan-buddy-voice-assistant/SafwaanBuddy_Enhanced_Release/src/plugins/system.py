#!/usr/bin/env python3
"""
System-related plugins for Safwaan Buddy
Provides system monitoring, process management, and file operations.
"""

import os
import psutil
import subprocess
import platform
from pathlib import Path
from typing import Dict, Any

from core.plugin_manager import BasePlugin


class SystemPlugin(BasePlugin):
    """Plugin for system-related operations."""

    def __init__(self):
        super().__init__("system")
        self.version = "1.0.0"
        self.description = "System monitoring, process management, and file operations"
        self.author = "Safwaan Buddy"

    def get_functions(self) -> Dict[str, Any]:
        """Return dictionary of plugin functions."""
        return {
            "system_info": self.get_system_info,
            "process_list": self.get_process_list,
            "kill_process": self.kill_process,
            "disk_usage": self.get_disk_usage,
            "network_info": self.get_network_info,
            "battery_info": self.get_battery_info,
            "environment_vars": self.get_environment_vars,
            "platform_info": self.get_platform_info,
        }

    def get_system_info(self) -> str:
        """Get comprehensive system information."""
        try:
            info = {
                "platform": platform.system(),
                "platform_release": platform.release(),
                "platform_version": platform.version(),
                "architecture": platform.machine(),
                "processor": platform.processor(),
                "hostname": platform.node(),
                "cpu_count": psutil.cpu_count(),
                "cpu_freq": psutil.cpu_freq()._asdict() if psutil.cpu_freq() else None,
                "memory_total": f"{psutil.virtual_memory().total / (1024**3):.2f} GB",
                "memory_available": f"{psutil.virtual_memory().available / (1024**3):.2f} GB",
                "boot_time": psutil.boot_time(),
            }
            import json
            return json.dumps(info, indent=2, default=str)
        except Exception as e:
            return f"Error getting system info: {e}"

    def get_process_list(self, limit: int = 20) -> str:
        """Get list of running processes."""
        try:
            processes = []
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent', 'status']):
                try:
                    processes.append(proc.info)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            # Sort by CPU usage
            processes.sort(key=lambda x: x['cpu_percent'] or 0, reverse=True)
            processes = processes[:limit]

            import json
            return json.dumps(processes, indent=2)
        except Exception as e:
            return f"Error getting process list: {e}"

    def kill_process(self, pid: int) -> str:
        """Kill a process by PID."""
        try:
            proc = psutil.Process(pid)
            proc.terminate()
            return f"Process {pid} terminated successfully"
        except psutil.NoSuchProcess:
            return f"Process {pid} not found"
        except psutil.AccessDenied:
            return f"Access denied when trying to kill process {pid}"
        except Exception as e:
            return f"Error killing process {pid}: {e}"

    def get_disk_usage(self) -> str:
        """Get disk usage information."""
        try:
            disk_info = []
            for partition in psutil.disk_partitions():
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    disk_info.append({
                        "device": partition.device,
                        "mountpoint": partition.mountpoint,
                        "fstype": partition.fstype,
                        "total": f"{usage.total / (1024**3):.2f} GB",
                        "used": f"{usage.used / (1024**3):.2f} GB",
                        "free": f"{usage.free / (1024**3):.2f} GB",
                        "percent": f"{(usage.used / usage.total) * 100:.1f}%"
                    })
                except PermissionError:
                    continue

            import json
            return json.dumps(disk_info, indent=2)
        except Exception as e:
            return f"Error getting disk usage: {e}"

    def get_network_info(self) -> str:
        """Get network interface information."""
        try:
            network_info = {}

            # Network interfaces
            interfaces = psutil.net_if_addrs()
            network_info["interfaces"] = {}
            for name, addresses in interfaces.items():
                network_info["interfaces"][name] = [
                    {
                        "family": str(addr.family),
                        "address": addr.address,
                        "netmask": addr.netmask,
                        "broadcast": addr.broadcast
                    } for addr in addresses
                ]

            # Network stats
            stats = psutil.net_io_counters()
            network_info["io_stats"] = {
                "bytes_sent": stats.bytes_sent,
                "bytes_recv": stats.bytes_recv,
                "packets_sent": stats.packets_sent,
                "packets_recv": stats.packets_recv,
                "errin": stats.errin,
                "errout": stats.errout,
                "dropin": stats.dropin,
                "dropout": stats.dropout
            }

            import json
            return json.dumps(network_info, indent=2, default=str)
        except Exception as e:
            return f"Error getting network info: {e}"

    def get_battery_info(self) -> str:
        """Get battery information."""
        try:
            if not hasattr(psutil, "sensors_battery"):
                return "Battery information not available on this platform"

            battery = psutil.sensors_battery()
            if battery is None:
                return "No battery detected"

            info = {
                "percent": battery.percent,
                "plugged": battery.power_plugged,
                "time_left": f"{battery.secsleft // 3600:.0f}h {(battery.secsleft % 3600) // 60:.0f}m" if battery.secsleft != psutil.POWER_TIME_UNLIMITED else "Unlimited"
            }

            import json
            return json.dumps(info, indent=2)
        except Exception as e:
            return f"Error getting battery info: {e}"

    def get_environment_vars(self, pattern: str = None) -> str:
        """Get environment variables."""
        try:
            env_vars = dict(os.environ)

            if pattern:
                filtered_vars = {k: v for k, v in env_vars.items() if pattern.lower() in k.lower()}
                env_vars = filtered_vars

            # Limit output for security
            limited_vars = {}
            for key, value in list(env_vars.items())[:50]:  # Limit to 50 variables
                # Truncate long values
                if len(value) > 200:
                    value = value[:200] + "..."
                limited_vars[key] = value

            import json
            return json.dumps(limited_vars, indent=2)
        except Exception as e:
            return f"Error getting environment variables: {e}"

    def get_platform_info(self) -> str:
        """Get detailed platform information."""
        try:
            info = {
                "system": platform.system(),
                "node": platform.node(),
                "release": platform.release(),
                "version": platform.version(),
                "machine": platform.machine(),
                "processor": platform.processor(),
                "python_version": platform.python_version(),
                "python_implementation": platform.python_implementation(),
                "architecture": platform.architecture(),
                "platform": platform.platform(),
                "uname": platform.uname()._asdict(),
            }

            import json
            return json.dumps(info, indent=2, default=str)
        except Exception as e:
            return f"Error getting platform info: {e}"