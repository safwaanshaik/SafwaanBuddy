"""
Utility modules for Safwaan Buddy
"""

from .logger import get_logger, get_logger_manager, setup_logging
from .helpers import (
    SafeDict, validate_email, validate_url, validate_coordinates,
    sanitize_filename, safe_file_operation, read_file_safe, write_file_safe,
    create_backup, calculate_file_hash, get_file_info, run_command_safely,
    is_admin, request_admin_privileges, format_duration, format_bytes,
    parse_time_string, get_available_memory, retry_on_failure,
    temporary_directory, debounce, truncate_string, extract_numbers,
    clean_json_text, merge_dicts
)
from .system_monitor import SystemMonitor, get_system_monitor, start_system_monitoring, stop_system_monitoring

__all__ = [
    # Logger utilities
    "get_logger",
    "get_logger_manager",
    "setup_logging",

    # Helper utilities
    "SafeDict",
    "validate_email",
    "validate_url",
    "validate_coordinates",
    "sanitize_filename",
    "safe_file_operation",
    "read_file_safe",
    "write_file_safe",
    "create_backup",
    "calculate_file_hash",
    "get_file_info",
    "run_command_safely",
    "is_admin",
    "request_admin_privileges",
    "format_duration",
    "format_bytes",
    "parse_time_string",
    "get_available_memory",
    "retry_on_failure",
    "temporary_directory",
    "debounce",
    "truncate_string",
    "extract_numbers",
    "clean_json_text",
    "merge_dicts",

    # System monitoring
    "SystemMonitor",
    "get_system_monitor",
    "start_system_monitoring",
    "stop_system_monitoring"
]