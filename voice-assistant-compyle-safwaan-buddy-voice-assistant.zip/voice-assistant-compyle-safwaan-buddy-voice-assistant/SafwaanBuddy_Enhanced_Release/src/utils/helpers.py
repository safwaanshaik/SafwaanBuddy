#!/usr/bin/env python3
"""
Common Utility Functions for Safwaan Buddy
Provides helper functions for file operations, validation, error handling, and common tasks.
"""

import os
import sys
import json
import re
import hashlib
import subprocess
import tempfile
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional, Union, Callable
from functools import wraps
from contextlib import contextmanager

from .logger import get_logger

logger = get_logger("helpers")


class SafeDict(dict):
    """Dictionary that returns None for missing keys instead of raising KeyError."""

    def __missing__(self, key):
        return None


def validate_email(email: str) -> bool:
    """Validate email address format."""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None


def validate_url(url: str) -> bool:
    """Validate URL format."""
    pattern = r'^https?://(?:[-\w.])+(?:\:[0-9]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:\#(?:[\w.])*)?)?$'
    return re.match(pattern, url) is not None


def validate_coordinates(x: int, y: int, screen_bounds: tuple = None) -> bool:
    """Validate screen coordinates."""
    if not isinstance(x, int) or not isinstance(y, int):
        return False

    if x < 0 or y < 0:
        return False

    if screen_bounds:
        width, height = screen_bounds
        if x >= width or y >= height:
            return False

    return True


def sanitize_filename(filename: str) -> str:
    """Sanitize filename by removing invalid characters."""
    # Remove invalid characters
    invalid_chars = r'[<>:"/\\|?*]'
    filename = re.sub(invalid_chars, '', filename)

    # Replace spaces with underscores
    filename = filename.replace(' ', '_')

    # Remove leading/trailing dots and spaces
    filename = filename.strip('. ')

    # Limit length
    if len(filename) > 255:
        name, ext = os.path.splitext(filename)
        filename = name[:255-len(ext)] + ext

    return filename


def safe_file_operation(operation: str, max_retries: int = 3, delay: float = 0.1):
    """Decorator for safe file operations with retry logic."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None

            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except (IOError, OSError) as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        time.sleep(delay * (2 ** attempt))  # Exponential backoff
                        continue
                    else:
                        logger.error(f"File operation failed after {max_retries} attempts: {operation}")
                        raise
                except Exception as e:
                    logger.error(f"Unexpected error in file operation {operation}: {e}")
                    raise

            if last_exception:
                raise last_exception
        return wrapper
    return decorator


@safe_file_operation("read_file")
def read_file_safe(file_path: Union[str, Path], encoding: str = 'utf-8') -> Optional[str]:
    """Safely read file contents."""
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            return f.read()
    except Exception as e:
        logger.error(f"Failed to read file {file_path}: {e}")
        return None


@safe_file_operation("write_file")
def write_file_safe(file_path: Union[str, Path], content: str, encoding: str = 'utf-8') -> bool:
    """Safely write content to file."""
    try:
        # Ensure directory exists
        file_path = Path(file_path)
        file_path.parent.mkdir(parents=True, exist_ok=True)

        # Write to temporary file first, then move
        with tempfile.NamedTemporaryFile(
            mode='w',
            encoding=encoding,
            dir=file_path.parent,
            delete=False,
            suffix='.tmp'
        ) as tmp_file:
            tmp_file.write(content)
            tmp_file.flush()
            os.fsync(tmp_file.fileno())  # Force write to disk

        # Move temporary file to target
        os.replace(tmp_file.name, file_path)
        return True
    except Exception as e:
        logger.error(f"Failed to write file {file_path}: {e}")
        return False


def create_backup(file_path: Union[str, Path], backup_dir: Union[str, Path] = None) -> Optional[Path]:
    """Create a backup of a file."""
    try:
        file_path = Path(file_path)
        if not file_path.exists():
            return None

        if backup_dir is None:
            backup_dir = file_path.parent / "backups"
        else:
            backup_dir = Path(backup_dir)

        backup_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{file_path.stem}_{timestamp}{file_path.suffix}"
        backup_path = backup_dir / backup_name

        import shutil
        shutil.copy2(file_path, backup_path)

        logger.info(f"Created backup: {backup_path}")
        return backup_path
    except Exception as e:
        logger.error(f"Failed to create backup of {file_path}: {e}")
        return None


def calculate_file_hash(file_path: Union[str, Path], algorithm: str = 'sha256') -> Optional[str]:
    """Calculate hash of a file."""
    try:
        hash_func = getattr(hashlib, algorithm)()

        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b''):
                hash_func.update(chunk)

        return hash_func.hexdigest()
    except Exception as e:
        logger.error(f"Failed to calculate hash for {file_path}: {e}")
        return None


def get_file_info(file_path: Union[str, Path]) -> Dict[str, Any]:
    """Get detailed information about a file."""
    try:
        file_path = Path(file_path)
        if not file_path.exists():
            return {"error": "File not found"}

        stat = file_path.stat()

        info = {
            "name": file_path.name,
            "path": str(file_path.resolve()),
            "size_bytes": stat.st_size,
            "size_mb": round(stat.st_size / (1024 * 1024), 2),
            "created": datetime.fromtimestamp(stat.st_ctime).isoformat(),
            "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
            "accessed": datetime.fromtimestamp(stat.st_atime).isoformat(),
            "is_file": file_path.is_file(),
            "is_directory": file_path.is_dir(),
            "extension": file_path.suffix.lower(),
            "hash_sha256": calculate_file_hash(file_path) if file_path.is_file() else None
        }

        return info
    except Exception as e:
        logger.error(f"Failed to get file info for {file_path}: {e}")
        return {"error": str(e)}


def run_command_safely(command: Union[str, List[str]], timeout: int = 30,
                      capture_output: bool = True, shell: bool = None) -> Dict[str, Any]:
    """Safely run a system command."""
    if shell is None:
        shell = isinstance(command, str)

    try:
        result = subprocess.run(
            command,
            shell=shell,
            timeout=timeout,
            capture_output=capture_output,
            text=True,
            check=False
        )

        return {
            "success": result.returncode == 0,
            "returncode": result.returncode,
            "stdout": result.stdout if capture_output else "",
            "stderr": result.stderr if capture_output else "",
            "command": command,
            "timeout": timeout
        }
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "error": "Command timed out",
            "command": command,
            "timeout": timeout
        }
    except Exception as e:
        logger.error(f"Failed to run command {command}: {e}")
        return {
            "success": False,
            "error": str(e),
            "command": command
        }


def is_admin() -> bool:
    """Check if the current process has administrative privileges."""
    try:
        import ctypes
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except:
        return False


def request_admin_privileges():
    """Request administrative privileges by restarting the script."""
    try:
        import ctypes

        if is_admin():
            return True

        # Restart script with admin privileges
        executable = sys.executable
        script_path = os.path.abspath(sys.argv[0])

        ctypes.windll.shell32.ShellExecuteW(
            None, "runas", executable, f'"{script_path}"', None, 1
        )

        # Exit current process
        sys.exit(0)
    except Exception as e:
        logger.error(f"Failed to request admin privileges: {e}")
        return False


def format_duration(seconds: float) -> str:
    """Format duration in seconds to human readable string."""
    if seconds < 1:
        return f"{seconds * 1000:.0f}ms"
    elif seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        minutes = seconds / 60
        return f"{minutes:.1f}min"
    else:
        hours = seconds / 3600
        return f"{hours:.1f}h"


def format_bytes(size_bytes: int) -> str:
    """Format bytes in human readable format."""
    if size_bytes == 0:
        return "0B"

    size_names = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    size = float(size_bytes)

    while size >= 1024.0 and i < len(size_names) - 1:
        size /= 1024.0
        i += 1

    return f"{size:.1f}{size_names[i]}"


def parse_time_string(time_str: str) -> Optional[datetime]:
    """Parse various time string formats into datetime object."""
    formats = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%d",
        "%H:%M:%S",
        "%H:%M"
    ]

    for fmt in formats:
        try:
            if ":" in time_str and "-" not in time_str:
                # Only time, use today's date
                parsed_time = datetime.strptime(time_str, fmt)
                return datetime.combine(datetime.now().date(), parsed_time.time())
            else:
                return datetime.strptime(time_str, fmt)
        except ValueError:
            continue

    return None


def get_available_memory() -> Dict[str, Any]:
    """Get system memory information."""
    try:
        import psutil

        memory = psutil.virtual_memory()

        return {
            "total": memory.total,
            "available": memory.available,
            "used": memory.used,
            "free": memory.free,
            "percent": memory.percent,
            "total_gb": round(memory.total / (1024**3), 2),
            "available_gb": round(memory.available / (1024**3), 2),
            "used_gb": round(memory.used / (1024**3), 2)
        }
    except Exception as e:
        logger.error(f"Failed to get memory info: {e}")
        return {"error": str(e)}


def retry_on_failure(max_retries: int = 3, delay: float = 1.0, backoff: float = 2.0):
    """Decorator to retry function on failure."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            current_delay = delay

            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        logger.warning(f"Attempt {attempt + 1} failed for {func.__name__}: {e}")
                        time.sleep(current_delay)
                        current_delay *= backoff
                    else:
                        logger.error(f"All {max_retries} attempts failed for {func.__name__}")

            if last_exception:
                raise last_exception

        return wrapper
    return decorator


@contextmanager
def temporary_directory():
    """Context manager for temporary directory."""
    temp_dir = tempfile.mkdtemp()
    try:
        yield Path(temp_dir)
    finally:
        import shutil
        shutil.rmtree(temp_dir, ignore_errors=True)


def debounce(wait_time: float):
    """Decorator to debounce function calls."""
    def decorator(func):
        last_called = [0]
        timer = [None]

        @wraps(func)
        def wrapper(*args, **kwargs):
            now = time.time()

            if timer[0] is not None:
                timer[0].cancel()

            if now - last_called[0] >= wait_time:
                last_called[0] = now
                return func(*args, **kwargs)
            else:
                timer[0] = threading.Timer(
                    wait_time - (now - last_called[0]),
                    func, args, kwargs
                )
                timer[0].start()

        return wrapper
    return decorator


def truncate_string(text: str, max_length: int = 50, suffix: str = "...") -> str:
    """Truncate string to maximum length."""
    if len(text) <= max_length:
        return text

    return text[:max_length - len(suffix)] + suffix


def extract_numbers(text: str) -> List[float]:
    """Extract all numbers from a string."""
    numbers = []
    for match in re.finditer(r'-?\d+\.?\d*', text):
        try:
            if '.' in match.group():
                numbers.append(float(match.group()))
            else:
                numbers.append(int(match.group()))
        except ValueError:
            continue

    return numbers


def clean_json_text(text: str) -> str:
    """Clean text for safe JSON serialization."""
    # Remove control characters except newlines and tabs
    text = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', text)
    return text.strip()


def merge_dicts(dict1: Dict, dict2: Dict) -> Dict:
    """Deep merge two dictionaries."""
    result = dict1.copy()

    for key, value in dict2.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge_dicts(result[key], value)
        else:
            result[key] = value

    return result