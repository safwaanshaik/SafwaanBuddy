#!/usr/bin/env python3
"""
Logging Configuration and Utilities for Safwaan Buddy
Provides centralized logging with rotation, structured output, and component-specific loggers.
"""

import logging
import logging.handlers
import json
import sys
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional
from contextlib import contextmanager


class JSONFormatter(logging.Formatter):
    """Custom JSON formatter for structured logging."""

    def format(self, record):
        log_entry = {
            "timestamp": datetime.fromtimestamp(record.created).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }

        # Add exception info if present
        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)

        # Add extra fields
        for key, value in record.__dict__.items():
            if key not in ["name", "msg", "args", "levelname", "levelno", "pathname",
                          "filename", "module", "lineno", "funcName", "created", "msecs",
                          "relativeCreated", "thread", "threadName", "processName",
                          "process", "getMessage", "exc_info", "exc_text", "stack_info"]:
                log_entry[key] = value

        return json.dumps(log_entry, ensure_ascii=False)


class ColoredFormatter(logging.Formatter):
    """Colored formatter for console output."""

    COLORS = {
        'DEBUG': '\033[36m',      # Cyan
        'INFO': '\033[32m',       # Green
        'WARNING': '\033[33m',    # Yellow
        'ERROR': '\033[31m',      # Red
        'CRITICAL': '\033[35m',   # Magenta
        'RESET': '\033[0m'        # Reset
    }

    def format(self, record):
        color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
        reset = self.COLORS['RESET']

        # Create colored format
        formatter = logging.Formatter(
            f"{color}%(asctime)s - %(name)s - %(levelname)s - %(message)s{reset}"
        )
        return formatter.format(record)


class LoggerManager:
    """Centralized logger management for Safwaan Buddy."""

    def __init__(self, log_dir: Optional[Path] = None, log_level: str = "INFO"):
        self.log_dir = log_dir or Path("data/logs")
        self.log_level = getattr(logging, log_level.upper(), logging.INFO)
        self.loggers = {}

        # Ensure log directory exists
        self.log_dir.mkdir(parents=True, exist_ok=True)

        # Configure root logger
        self._configure_root_logger()

        # Setup component-specific loggers
        self._setup_component_loggers()

    def _configure_root_logger(self):
        """Configure the root logger with handlers."""
        root_logger = logging.getLogger()
        root_logger.setLevel(self.log_level)

        # Clear existing handlers
        root_logger.handlers.clear()

        # Console handler with colored output
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(self.log_level)
        console_formatter = ColoredFormatter()
        console_handler.setFormatter(console_formatter)
        root_logger.addHandler(console_handler)

        # File handler with rotation for main application log
        main_log_file = self.log_dir / "buddy.log"
        file_handler = logging.handlers.RotatingFileHandler(
            main_log_file,
            maxBytes=10 * 1024 * 1024,  # 10MB
            backupCount=5,
            encoding='utf-8'
        )
        file_handler.setLevel(self.log_level)
        json_formatter = JSONFormatter()
        file_handler.setFormatter(json_formatter)
        root_logger.addHandler(file_handler)

    def _setup_component_loggers(self):
        """Setup specific loggers for different components."""
        components = [
            "voice", "gui", "ai", "memory", "plugins",
            "automation", "system", "network", "security"
        ]

        for component in components:
            self.get_component_logger(component)

    def get_component_logger(self, component: str) -> logging.Logger:
        """Get or create a logger for a specific component."""
        if component not in self.loggers:
            # Create component-specific logger
            logger = logging.getLogger(f"buddy.{component}")
            logger.setLevel(self.log_level)

            # Add component-specific file handler
            component_log_file = self.log_dir / f"{component}.log"
            file_handler = logging.handlers.RotatingFileHandler(
                component_log_file,
                maxBytes=5 * 1024 * 1024,  # 5MB
                backupCount=3,
                encoding='utf-8'
            )
            file_handler.setLevel(self.log_level)
            json_formatter = JSONFormatter()
            file_handler.setFormatter(json_formatter)
            logger.addHandler(file_handler)

            # Don't propagate to root to avoid duplicate logs
            logger.propagate = False

            self.loggers[component] = logger

        return self.loggers[component]

    def set_level(self, level: str):
        """Set logging level for all loggers."""
        log_level = getattr(logging, level.upper(), logging.INFO)
        self.log_level = log_level

        # Update root logger
        logging.getLogger().setLevel(log_level)

        # Update all handlers
        for logger in logging.getLogger().handlers:
            logger.setLevel(log_level)

        # Update component loggers
        for logger in self.loggers.values():
            logger.setLevel(log_level)
            for handler in logger.handlers:
                handler.setLevel(log_level)

    def log_system_info(self):
        """Log system information at startup."""
        import platform
        import psutil

        system_logger = self.get_component_logger("system")
        system_logger.info("=== Safwaan Buddy Starting ===")
        system_logger.info(f"Python Version: {platform.python_version()}")
        system_logger.info(f"Platform: {platform.platform()}")
        system_logger.info(f"Architecture: {platform.architecture()[0]}")
        system_logger.info(f"CPU Count: {psutil.cpu_count()}")
        system_logger.info(f"Memory Total: {psutil.virtual_memory().total / (1024**3):.1f} GB")
        system_logger.info(f"Disk Free: {psutil.disk_usage('/').free / (1024**3):.1f} GB")

    def log_exception(self, component: str, exception: Exception, context: Dict[str, Any] = None):
        """Log an exception with context."""
        logger = self.get_component_logger(component)

        extra = {
            "exception_type": type(exception).__name__,
            "exception_message": str(exception),
            "context": context or {}
        }

        logger.error(
            f"Exception in {component}: {exception}",
            exc_info=True,
            extra=extra
        )

    def log_performance(self, component: str, operation: str, duration: float,
                       metadata: Dict[str, Any] = None):
        """Log performance metrics."""
        logger = self.get_component_logger(component)

        extra = {
            "operation": operation,
            "duration_seconds": duration,
            "metadata": metadata or {}
        }

        logger.info(
            f"Performance: {operation} took {duration:.3f}s",
            extra=extra
        )

    @contextmanager
    def log_execution_time(self, component: str, operation: str, metadata: Dict[str, Any] = None):
        """Context manager to log execution time."""
        start_time = datetime.now()
        try:
            yield
        finally:
            duration = (datetime.now() - start_time).total_seconds()
            self.log_performance(component, operation, duration, metadata)

    def create_audit_log(self, event_type: str, user_input: str,
                        agent_response: str, metadata: Dict[str, Any] = None):
        """Create an audit log entry for security and compliance."""
        audit_logger = logging.getLogger("buddy.audit")

        # Ensure audit logger exists
        if not audit_logger.handlers:
            audit_log_file = self.log_dir / "audit.log"
            file_handler = logging.handlers.RotatingFileHandler(
                audit_log_file,
                maxBytes=20 * 1024 * 1024,  # 20MB
                backupCount=10,
                encoding='utf-8'
            )
            file_handler.setLevel(logging.INFO)
            json_formatter = JSONFormatter()
            file_handler.setFormatter(json_formatter)
            audit_logger.addHandler(file_handler)
            audit_logger.setLevel(logging.INFO)
            audit_logger.propagate = False

        extra = {
            "event_type": event_type,
            "user_input": user_input,
            "agent_response": agent_response,
            "metadata": metadata or {}
        }

        audit_logger.info(
            f"Audit: {event_type}",
            extra=extra
        )

    def get_log_stats(self) -> Dict[str, Any]:
        """Get statistics about log files."""
        stats = {}

        for log_file in self.log_dir.glob("*.log"):
            try:
                file_stat = log_file.stat()
                stats[log_file.name] = {
                    "size_bytes": file_stat.st_size,
                    "size_mb": file_stat.st_size / (1024 * 1024),
                    "modified": datetime.fromtimestamp(file_stat.st_mtime).isoformat(),
                    "line_count": sum(1 for _ in log_file.open(encoding='utf-8', errors='ignore'))
                }
            except Exception as e:
                stats[log_file.name] = {"error": str(e)}

        return stats


# Global logger manager instance
_logger_manager = None


def get_logger_manager() -> LoggerManager:
    """Get the global logger manager instance."""
    global _logger_manager
    if _logger_manager is None:
        from config import get_config
        config = get_config()
        log_dir = Path(config.get("data_dir", "data")) / "logs"
        log_level = config.get("log_level", "INFO")
        _logger_manager = LoggerManager(log_dir, log_level)
    return _logger_manager


def get_logger(component: str) -> logging.Logger:
    """Get a logger for a specific component."""
    return get_logger_manager().get_component_logger(component)


def setup_logging(log_level: str = None):
    """Setup logging with optional custom log level."""
    manager = get_logger_manager()
    if log_level:
        manager.set_level(log_level)

    # Log system information
    manager.log_system_info()


# Convenience functions for common logging operations
def log_exception(component: str, exception: Exception, context: Dict[str, Any] = None):
    """Log an exception with context."""
    get_logger_manager().log_exception(component, exception, context)


def log_performance(component: str, operation: str, duration: float,
                   metadata: Dict[str, Any] = None):
    """Log performance metrics."""
    get_logger_manager().log_performance(component, operation, duration, metadata)


def log_execution_time(component: str, operation: str, metadata: Dict[str, Any] = None):
    """Context manager to log execution time."""
    return get_logger_manager().log_execution_time(component, operation, metadata)


def create_audit_log(event_type: str, user_input: str,
                    agent_response: str, metadata: Dict[str, Any] = None):
    """Create an audit log entry."""
    get_logger_manager().create_audit_log(event_type, user_input, agent_response, metadata)


# Module-level logger for this module
logger = get_logger("logger")