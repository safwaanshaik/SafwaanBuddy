#!/usr/bin/env python3
"""
System Monitoring Utilities for Safwaan Buddy
Provides real-time system resource monitoring and alerts.
"""

import psutil
import threading
import time
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Callable
from pathlib import Path
from dataclasses import dataclass
from collections import deque

from .logger import get_logger
from .helpers import format_bytes, format_duration

logger = get_logger("system_monitor")


@dataclass
class SystemMetrics:
    """Data class for system metrics."""
    timestamp: datetime
    cpu_percent: float
    cpu_count: int
    memory_percent: float
    memory_total: int
    memory_used: int
    memory_available: int
    disk_percent: float
    disk_total: int
    disk_used: int
    disk_free: int
    network_bytes_sent: int
    network_bytes_recv: int
    boot_time: datetime
    uptime: timedelta


@dataclass
class ProcessInfo:
    """Data class for process information."""
    pid: int
    name: str
    cpu_percent: float
    memory_percent: float
    memory_mb: float
    status: str
    create_time: datetime
    cmdline: List[str]


class SystemMonitor:
    """Real-time system resource monitor."""

    def __init__(self, update_interval: float = 2.0, history_size: int = 100):
        self.update_interval = update_interval
        self.history_size = history_size

        # Metrics storage
        self.current_metrics: Optional[SystemMetrics] = None
        self.metrics_history: deque = deque(maxlen=history_size)
        self.processes_cache: Dict[int, ProcessInfo] = {}
        self.last_network_stats = None

        # Monitoring state
        self.monitoring = False
        self.monitor_thread: Optional[threading.Thread] = None
        self.callbacks: List[Callable[[SystemMetrics], None]] = []

        # Alert thresholds
        self.cpu_threshold = 80.0
        self.memory_threshold = 85.0
        self.disk_threshold = 90.0

        # Alert cooldowns
        self.alert_cooldown = timedelta(minutes=5)
        self.last_alerts: Dict[str, datetime] = {}

        logger.info("System monitor initialized")

    def start_monitoring(self):
        """Start system monitoring in background thread."""
        if self.monitoring:
            logger.warning("System monitoring already running")
            return

        self.monitoring = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()

        logger.info(f"System monitoring started (interval: {self.update_interval}s)")

    def stop_monitoring(self):
        """Stop system monitoring."""
        if not self.monitoring:
            return

        self.monitoring = False

        if self.monitor_thread and self.monitor_thread.is_alive():
            self.monitor_thread.join(timeout=5.0)

        logger.info("System monitoring stopped")

    def _monitor_loop(self):
        """Main monitoring loop."""
        logger.info("System monitor thread started")

        while self.monitoring:
            try:
                metrics = self._collect_metrics()
                self.current_metrics = metrics
                self.metrics_history.append(metrics)

                # Update processes cache
                self._update_processes_cache()

                # Check for alerts
                self._check_alerts(metrics)

                # Notify callbacks
                for callback in self.callbacks:
                    try:
                        callback(metrics)
                    except Exception as e:
                        logger.error(f"Error in monitoring callback: {e}")

                time.sleep(self.update_interval)

            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                time.sleep(self.update_interval)

        logger.info("System monitor thread stopped")

    def _collect_metrics(self) -> SystemMetrics:
        """Collect current system metrics."""
        try:
            # CPU metrics
            cpu_percent = psutil.cpu_percent(interval=0.1)
            cpu_count = psutil.cpu_count()

            # Memory metrics
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            memory_total = memory.total
            memory_used = memory.used
            memory_available = memory.available

            # Disk metrics (for main partition)
            disk = psutil.disk_usage('/')
            disk_percent = (disk.used / disk.total) * 100
            disk_total = disk.total
            disk_used = disk.used
            disk_free = disk.free

            # Network metrics
            network = psutil.net_io_counters()
            network_bytes_sent = network.bytes_sent
            network_bytes_recv = network.bytes_recv

            # System uptime
            boot_time = datetime.fromtimestamp(psutil.boot_time())
            uptime = datetime.now() - boot_time

            return SystemMetrics(
                timestamp=datetime.now(),
                cpu_percent=cpu_percent,
                cpu_count=cpu_count,
                memory_percent=memory_percent,
                memory_total=memory_total,
                memory_used=memory_used,
                memory_available=memory_available,
                disk_percent=disk_percent,
                disk_total=disk_total,
                disk_used=disk_used,
                disk_free=disk_free,
                network_bytes_sent=network_bytes_sent,
                network_bytes_recv=network_bytes_recv,
                boot_time=boot_time,
                uptime=uptime
            )

        except Exception as e:
            logger.error(f"Failed to collect system metrics: {e}")
            raise

    def _update_processes_cache(self):
        """Update cached process information."""
        try:
            self.processes_cache.clear()

            # Get top processes by CPU and memory usage
            processes = []

            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent',
                                           'memory_info', 'status', 'create_time', 'cmdline']):
                try:
                    pinfo = proc.info
                    if pinfo['cpu_percent'] is None:
                        pinfo['cpu_percent'] = 0.0

                    processes.append(pinfo)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            # Sort by CPU usage and keep top 20
            processes.sort(key=lambda x: x['cpu_percent'], reverse=True)
            top_cpu = processes[:20]

            # Sort by memory usage and keep top 20
            processes.sort(key=lambda x: x['memory_percent'], reverse=True)
            top_memory = processes[:20]

            # Cache unique processes
            seen_pids = set()
            for proc in top_cpu + top_memory:
                pid = proc['pid']
                if pid not in seen_pids:
                    self.processes_cache[pid] = ProcessInfo(
                        pid=proc['pid'],
                        name=proc['name'] or 'Unknown',
                        cpu_percent=proc['cpu_percent'],
                        memory_percent=proc['memory_percent'],
                        memory_mb=(proc['memory_info'].rss / (1024 * 1024)) if proc['memory_info'] else 0,
                        status=proc['status'] or 'Unknown',
                        create_time=datetime.fromtimestamp(proc['create_time']) if proc['create_time'] else datetime.now(),
                        cmdline=proc['cmdline'] or []
                    )
                    seen_pids.add(pid)

        except Exception as e:
            logger.error(f"Failed to update processes cache: {e}")

    def _check_alerts(self, metrics: SystemMetrics):
        """Check for system alerts and trigger notifications."""
        now = datetime.now()

        # CPU alert
        if metrics.cpu_percent > self.cpu_threshold:
            if self._should_send_alert("cpu", now):
                self._send_alert(
                    "High CPU Usage",
                    f"CPU usage is {metrics.cpu_percent:.1f}% (threshold: {self.cpu_threshold}%)"
                )

        # Memory alert
        if metrics.memory_percent > self.memory_threshold:
            if self._should_send_alert("memory", now):
                self._send_alert(
                    "High Memory Usage",
                    f"Memory usage is {metrics.memory_percent:.1f}% ({format_bytes(metrics.memory_used)} used)"
                )

        # Disk alert
        if metrics.disk_percent > self.disk_threshold:
            if self._should_send_alert("disk", now):
                self._send_alert(
                    "Low Disk Space",
                    f"Disk usage is {metrics.disk_percent:.1f}% ({format_bytes(metrics.disk_free)} free)"
                )

    def _should_send_alert(self, alert_type: str, now: datetime) -> bool:
        """Check if alert should be sent based on cooldown."""
        last_alert = self.last_alerts.get(alert_type)
        if last_alert is None or (now - last_alert) >= self.alert_cooldown:
            self.last_alerts[alert_type] = now
            return True
        return False

    def _send_alert(self, title: str, message: str):
        """Send system alert (can be extended with notifications)."""
        logger.warning(f"System Alert - {title}: {message}")

        # Could integrate with Windows notifications, email, etc.
        try:
            import win10toast
            toaster = win10toast.ToastNotifier()
            toaster.show_toast(
                title,
                message,
                duration=10,
                threaded=True
            )
        except ImportError:
            logger.debug("win10toast not available, skipping notification")

    def get_current_metrics(self) -> Optional[SystemMetrics]:
        """Get current system metrics."""
        return self.current_metrics

    def get_metrics_history(self, minutes: int = 10) -> List[SystemMetrics]:
        """Get metrics history for the specified time period."""
        cutoff_time = datetime.now() - timedelta(minutes=minutes)
        return [m for m in self.metrics_history if m.timestamp >= cutoff_time]

    def get_processes_by_cpu(self, limit: int = 10) -> List[ProcessInfo]:
        """Get top processes by CPU usage."""
        return sorted(self.processes_cache.values(), key=lambda p: p.cpu_percent, reverse=True)[:limit]

    def get_processes_by_memory(self, limit: int = 10) -> List[ProcessInfo]:
        """Get top processes by memory usage."""
        return sorted(self.processes_cache.values(), key=lambda p: p.memory_percent, reverse=True)[:limit]

    def find_process_by_name(self, name: str) -> List[ProcessInfo]:
        """Find processes by name."""
        name_lower = name.lower()
        return [p for p in self.processes_cache.values() if name_lower in p.name.lower()]

    def get_network_stats(self) -> Dict[str, Any]:
        """Get network statistics and usage."""
        try:
            current_stats = psutil.net_io_counters()
            current_time = datetime.now()

            stats = {
                "bytes_sent": current_stats.bytes_sent,
                "bytes_recv": current_stats.bytes_recv,
                "packets_sent": current_stats.packets_sent,
                "packets_recv": current_stats.packets_recv,
                "errin": current_stats.errin,
                "errout": current_stats.errout,
                "dropin": current_stats.dropin,
                "dropout": current_stats.dropout
            }

            # Calculate rates if we have previous data
            if self.last_network_stats:
                time_diff = (current_time - self.last_network_stats['time']).total_seconds()
                if time_diff > 0:
                    bytes_sent_diff = current_stats.bytes_sent - self.last_network_stats['bytes_sent']
                    bytes_recv_diff = current_stats.bytes_recv - self.last_network_stats['bytes_recv']

                    stats['upload_speed_bps'] = bytes_sent_diff / time_diff
                    stats['download_speed_bps'] = bytes_recv_diff / time_diff
                    stats['upload_speed'] = format_bytes(bytes_sent_diff / time_diff) + "/s"
                    stats['download_speed'] = format_bytes(bytes_recv_diff / time_diff) + "/s"

            self.last_network_stats = {
                'time': current_time,
                'bytes_sent': current_stats.bytes_sent,
                'bytes_recv': current_stats.bytes_recv
            }

            return stats

        except Exception as e:
            logger.error(f"Failed to get network stats: {e}")
            return {"error": str(e)}

    def get_system_info(self) -> Dict[str, Any]:
        """Get comprehensive system information."""
        try:
            info = {
                "platform": psutil.PLATFORM,
                "architecture": psutil.ARCH,
                "processor": psutil.cpu_freq().current if psutil.cpu_freq() else None,
                "cpu_count": psutil.cpu_count(),
                "cpu_count_logical": psutil.cpu_count(logical=True),
                "memory_total": psutil.virtual_memory().total,
                "boot_time": datetime.fromtimestamp(psutil.boot_time()).isoformat(),
                "disk_partitions": []
            }

            # Disk partitions
            for part in psutil.disk_partitions():
                try:
                    usage = psutil.disk_usage(part.mountpoint)
                    info["disk_partitions"].append({
                        "device": part.device,
                        "mountpoint": part.mountpoint,
                        "fstype": part.fstype,
                        "total": usage.total,
                        "used": usage.used,
                        "free": usage.free,
                        "percent": (usage.used / usage.total) * 100
                    })
                except PermissionError:
                    continue

            # Network interfaces
            info["network_interfaces"] = psutil.net_if_addrs()
            info["network_stats"] = psutil.net_if_stats()

            return info

        except Exception as e:
            logger.error(f"Failed to get system info: {e}")
            return {"error": str(e)}

    def set_alert_thresholds(self, cpu: float = None, memory: float = None, disk: float = None):
        """Set alert thresholds."""
        if cpu is not None:
            self.cpu_threshold = max(0.0, min(100.0, cpu))
        if memory is not None:
            self.memory_threshold = max(0.0, min(100.0, memory))
        if disk is not None:
            self.disk_threshold = max(0.0, min(100.0, disk))

        logger.info(f"Alert thresholds updated - CPU: {self.cpu_threshold}%, "
                   f"Memory: {self.memory_threshold}%, Disk: {self.disk_threshold}%")

    def add_callback(self, callback: Callable[[SystemMetrics], None]):
        """Add callback function for metric updates."""
        self.callbacks.append(callback)
        logger.debug(f"Added monitoring callback: {callback.__name__}")

    def remove_callback(self, callback: Callable[[SystemMetrics], None]):
        """Remove callback function."""
        if callback in self.callbacks:
            self.callbacks.remove(callback)
            logger.debug(f"Removed monitoring callback: {callback.__name__}")

    def get_summary(self) -> Dict[str, Any]:
        """Get current system summary."""
        if not self.current_metrics:
            return {"error": "No metrics available"}

        metrics = self.current_metrics
        network_stats = self.get_network_stats()

        return {
            "timestamp": metrics.timestamp.isoformat(),
            "cpu": {
                "percent": metrics.cpu_percent,
                "count": metrics.cpu_count
            },
            "memory": {
                "percent": metrics.memory_percent,
                "total": format_bytes(metrics.memory_total),
                "used": format_bytes(metrics.memory_used),
                "available": format_bytes(metrics.memory_available)
            },
            "disk": {
                "percent": metrics.disk_percent,
                "total": format_bytes(metrics.disk_total),
                "used": format_bytes(metrics.disk_used),
                "free": format_bytes(metrics.disk_free)
            },
            "uptime": format_duration(metrics.uptime.total_seconds()),
            "network": {
                "upload_speed": network_stats.get('upload_speed', 'N/A'),
                "download_speed": network_stats.get('download_speed', 'N/A')
            },
            "process_count": len(self.processes_cache)
        }


# Global system monitor instance
_system_monitor = None


def get_system_monitor() -> SystemMonitor:
    """Get the global system monitor instance."""
    global _system_monitor
    if _system_monitor is None:
        from config import get_config
        config = get_config()
        interval = config.get("system_monitor_interval", 2.0)
        _system_monitor = SystemMonitor(update_interval=interval)
    return _system_monitor


def start_system_monitoring():
    """Start the global system monitor."""
    monitor = get_system_monitor()
    monitor.start_monitoring()


def stop_system_monitoring():
    """Stop the global system monitor."""
    global _system_monitor
    if _system_monitor:
        _system_monitor.stop_monitoring()