#!/usr/bin/env python3
"""
Safwaan Buddy Enhanced Auto-Installer
Automatically installs dependencies, creates desktop shortcuts, and sets up the assistant
"""

import sys
import os
import platform
import subprocess
import requests
import tempfile
import shutil
import json
import time
from pathlib import Path
from typing import Dict, List, Optional
import webbrowser

class SafwaanBuddyInstaller:
    """Advanced auto-installer for Safwaan Buddy Enhanced"""

    def __init__(self):
        self.system_platform = platform.system().lower()
        self.python_version = sys.version_info
        self.install_dir = Path.home() / "SafwaanBuddy_Enhanced"
        self.temp_dir = Path(tempfile.gettempdir()) / "safwaan_install"
        self.temp_dir.mkdir(exist_ok=True)

        # Installation status
        self.install_status = {
            "python": False,
            "dependencies": False,
            "gui": False,
            "screen_capture": False,
            "ocr": False,
            "browser": False,
            "desktop_shortcut": False,
            "startup_entry": False,
            "config": False
        }

        print("🚀 Safwaan Buddy Enhanced Auto-Installer")
        print("=" * 60)

    def check_system_requirements(self) -> bool:
        """Check if system meets requirements"""
        print("🔍 Checking system requirements...")

        # Check Python version
        if self.python_version < (3, 8):
            print(f"❌ Python 3.8+ required. Found: {self.python_version}")
            return False
        else:
            print(f"✅ Python {self.python_version.major}.{self.python_version.minor}.{self.python_version.micro}")

        # Check operating system
        if self.system_platform in ["windows", "darwin", "linux"]:
            print(f"✅ {platform.system()} detected")
        else:
            print(f"⚠️ Unsupported platform: {self.system_platform}")

        # Check available memory (basic check)
        try:
            if self.system_platform == "windows":
                import psutil
                memory_gb = psutil.virtual_memory().total / (1024**3)
                if memory_gb >= 4:
                    print(f"✅ {memory_gb:.1f} GB RAM available")
                else:
                    print(f"⚠️ Only {memory_gb:.1f} GB RAM available (4GB+ recommended)")
        except:
            print("⚠️ Could not check available memory")

        # Check disk space
        try:
            disk_usage = shutil.disk_usage(Path.home())
            available_gb = disk_usage.free / (1024**3)
            if available_gb >= 1:
                print(f"✅ {available_gb:.1f} GB disk space available")
            else:
                print(f"❌ Only {available_gb:.1f} GB disk space available (1GB+ required)")
                return False
        except:
            print("⚠️ Could not check disk space")

        return True

    def install_python_dependencies(self) -> bool:
        """Install all required Python packages"""
        print("\n📦 Installing Python dependencies...")

        # Essential packages for basic functionality
        essential_packages = [
            "pyqt6>=6.5.0",
            "pyttsx3>=2.90",
            "speechrecognition>=3.10.0",
            "psutil>=5.9.0",
            "cryptography>=41.0.0",
            "requests>=2.31.0",
            "pillow>=10.0.0",
            "numpy>=1.24.0",
            "pyautogui>=0.9.54"
        ]

        # Advanced features packages
        advanced_packages = [
            "opencv-python>=4.8.0",
            "pytesseract>=0.3.10",
            "easyocr>=1.7.0",
            "beautifulsoup4>=4.12.0",
            "selenium>=4.15.0",
            "webdriver-manager>=4.0.0",
            "wget>=3.2",
            "scipy>=1.11.0",
            "scikit-learn>=1.3.0"
        ]

        # Installation commands
        commands = [
            # Upgrade pip first
            [sys.executable, "-m", "pip", "install", "--upgrade", "pip"],
        ]

        # Add essential packages
        for package in essential_packages:
            commands.append([sys.executable, "-m", "pip", "install", package])

        # Add advanced packages
        for package in advanced_packages:
            commands.append([sys.executable, "-m", "pip", "install", package])

        # Install system-specific packages
        if self.system_platform == "windows":
            commands.extend([
                [sys.executable, "-m", "pip", "install", "pywin32>=306"],
                [sys.executable, "-m", "pip", "install", "wmi>=1.5.1"],
            ])
        elif self.system_platform == "linux":
            commands.append([sys.executable, "-m", "pip", "install", "python3-xlib"])
        elif self.system_platform == "darwin":
            commands.append([sys.executable, "-m", "pip", "install", "pyobjc-framework-Cocoa"])

        # Execute installation commands
        for i, cmd in enumerate(commands, 1):
            try:
                print(f"  [{i}/{len(commands)}] Installing {' '.join(cmd[3:])}...")
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)

                if result.returncode == 0:
                    print(f"    ✅ Success")
                else:
                    print(f"    ⚠️ Warning: {result.stderr}")
                    # Continue with other packages

            except subprocess.TimeoutExpired:
                print(f"    ⏰ Timeout - continuing...")
            except Exception as e:
                print(f"    ❌ Error: {e}")

        self.install_status["dependencies"] = True
        print("✅ Python dependencies installation completed")
        return True

    def install_tesseract_ocr(self) -> bool:
        """Install Tesseract OCR for text recognition"""
        print("\n🔤 Installing Tesseract OCR...")

        try:
            if self.system_platform == "windows":
                # Download Tesseract for Windows
                tesseract_url = "https://github.com/UB-Mannheim/tesseract/wiki/download"
                print(f"🌐 Downloading Tesseract from: {tesseract_url}")
                webbrowser.open(tesseract_url)
                print("📝 Please download and install Tesseract OCR manually")
                print("   1. Visit the URL above")
                print("   2. Download the 64-bit installer")
                print("   3. Run the installer with default settings")
                input("Press Enter when Tesseract installation is complete...")

            elif self.system_platform == "linux":
                # Install using package manager
                try:
                    subprocess.run(["sudo", "apt-get", "update"], check=True)
                    subprocess.run(["sudo", "apt-get", "install", "-y", "tesseract-ocr"], check=True)
                    subprocess.run(["sudo", "apt-get", "install", "-y", "libtesseract-dev"], check=True)
                    print("✅ Tesseract OCR installed via apt-get")
                except:
                    try:
                        subprocess.run(["sudo", "yum", "install", "-y", "tesseract"], check=True)
                        print("✅ Tesseract OCR installed via yum")
                    except:
                        print("⚠️ Could not install Tesseract OCR automatically")
                        print("📝 Please install manually: sudo apt-get install tesseract-ocr")

            elif self.system_platform == "darwin":
                try:
                    subprocess.run(["brew", "install", "tesseract"], check=True)
                    print("✅ Tesseract OCR installed via Homebrew")
                except:
                    print("⚠️ Could not install Tesseract OCR automatically")
                    print("📝 Please install manually: brew install tesseract")

            # Test Tesseract installation
            import pytesseract
            pytesseract.get_tesseract_version()
            print("✅ Tesseract OCR is working correctly")
            self.install_status["ocr"] = True
            return True

        except Exception as e:
            print(f"⚠️ Tesseract OCR installation issue: {e}")
            print("💡 OCR features will be limited, but other features will work")
            return False

    def install_browser_drivers(self) -> bool:
        """Install browser drivers for web automation"""
        print("\n🌐 Installing browser drivers...")

        try:
            from selenium import webdriver
            from selenium.webdriver.chrome.service import Service
            from webdriver_manager.chrome import ChromeDriverManager

            # Install ChromeDriver
            driver_path = ChromeDriverManager().install()
            print(f"✅ ChromeDriver installed: {driver_path}")

            # Test the driver
            options = webdriver.ChromeOptions()
            options.add_argument('--headless')
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')

            driver = webdriver.Chrome(options=options)
            driver.get("https://www.google.com")
            driver.quit()
            print("✅ Browser automation is working correctly")

            self.install_status["browser"] = True
            return True

        except Exception as e:
            print(f"⚠️ Browser driver installation issue: {e}")
            print("💡 Web automation features will be limited")
            return False

    def create_application_directory(self) -> bool:
        """Create application directory and copy files"""
        print("\n📁 Creating application directory...")

        try:
            # Remove existing directory if it exists
            if self.install_dir.exists():
                shutil.rmtree(self.install_dir)

            # Create new directory
            self.install_dir.mkdir(parents=True, exist_ok=True)

            # Copy current application files
            current_dir = Path(__file__).parent
            for item in current_dir.iterdir():
                if item.is_file() and item.suffix in ['.py', '.md', '.txt', '.json'] or item.name == 'src':
                    dest = self.install_dir / item.name
                    if item.is_file():
                        shutil.copy2(item, dest)
                    else:
                        shutil.copytree(item, dest)

            print(f"✅ Application files copied to: {self.install_dir}")
            return True

        except Exception as e:
            print(f"❌ Failed to create application directory: {e}")
            return False

    def create_desktop_shortcut(self) -> bool:
        """Create desktop shortcut"""
        print("\n🖥️ Creating desktop shortcut...")

        try:
            desktop = Path.home() / "Desktop"
            if not desktop.exists():
                desktop = Path.home()  # Fallback to home directory

            if self.system_platform == "windows":
                shortcut_path = desktop / "Safwaan Buddy Enhanced.bat"
                shortcut_content = f'''@echo off
cd /d "{self.install_dir}"
title Safwaan Buddy Enhanced
echo.
echo 🚀 Safwaan Buddy Enhanced - Advanced AI Assistant
echo ==============================================
echo.
echo Features:
echo 🧠 Natural speech with emotional intelligence
echo 💻 Complete laptop system control
echo 🌍 Multilingual support (16+ languages)
echo ⚙️ Advanced AI personality and learning
echo.
echo Starting application...
echo.

python run_safwaan_buddy.py

if %errorLevel% neq 0 (
    echo.
    echo ❌ Application encountered an error
    echo 📝 Make sure all dependencies are installed
    echo.
)

pause
'''
                with open(shortcut_path, 'w') as f:
                    f.write(shortcut_content)

            elif self.system_platform == "linux":
                shortcut_path = desktop / "safwaan-buddy.desktop"
                shortcut_content = f'''[Desktop Entry]
Version=1.0
Type=Application
Name=Safwaan Buddy Enhanced
Comment=Advanced AI Voice Assistant
Exec=python3 {self.install_dir}/run_safwaan_buddy.py
Icon={self.install_dir}/static/icons/buddy.png
Terminal=false
Categories=Utility;AudioVideo;Audio;
'''
                with open(shortcut_path, 'w') as f:
                    f.write(shortcut_content)

                # Make executable
                os.chmod(shortcut_path, 0o755)

            elif self.system_platform == "darwin":
                # Create macOS app bundle
                app_dir = desktop / "Safwaan Buddy Enhanced.app"
                app_contents = app_dir / "Contents"
                app_macos = app_contents / "MacOS"
                app_resources = app_contents / "Resources"

                app_dir.mkdir(parents=True, exist_ok=True)
                app_contents.mkdir(exist_ok=True)
                app_macos.mkdir(exist_ok=True)
                app_resources.mkdir(exist_ok=True)

                # Create Info.plist
                info_plist = f'''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key>
    <string>safwaan_buddy</string>
    <key>CFBundleIdentifier</key>
    <string>com.safwaan.buddy</string>
    <key>CFBundleName</key>
    <string>Safwaan Buddy Enhanced</string>
    <key>CFBundleVersion</key>
    <string>1.0</string>
</dict>
</plist>
'''

                with open(app_contents / "Info.plist", 'w') as f:
                    f.write(info_plist)

                # Create executable script
                executable_path = app_macos / "safwaan_buddy"
                executable_content = f'''#!/bin/bash
cd "{self.install_dir}"
python3 run_safwaan_buddy.py
'''

                with open(executable_path, 'w') as f:
                    f.write(executable_content)

                os.chmod(executable_path, 0o755)

            print(f"✅ Desktop shortcut created: {shortcut_path if self.system_platform != 'darwin' else app_dir}")
            self.install_status["desktop_shortcut"] = True
            return True

        except Exception as e:
            print(f"❌ Failed to create desktop shortcut: {e}")
            return False

    def create_startup_entry(self) -> bool:
        """Create startup entry for automatic launch"""
        print("\n⚡ Creating startup entry...")

        try:
            if self.system_platform == "windows":
                # Add to Windows startup folder
                startup_folder = Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
                startup_folder.mkdir(parents=True, exist_ok=True)

                startup_script = startup_folder / "Safwaan Buddy Enhanced.bat"
                startup_content = f'''@echo off
cd /d "{self.install_dir}"
start /B python run_safwaan_buddy.py
'''

                with open(startup_script, 'w') as f:
                    f.write(startup_content)

            elif self.system_platform == "linux":
                # Create systemd service
                service_content = f'''[Unit]
Description=Safwaan Buddy Enhanced AI Assistant
After=graphical-session.target

[Service]
Type=simple
User={os.getenv('USER')}
WorkingDirectory={self.install_dir}
ExecStart=/usr/bin/python3 {self.install_dir}/run_safwaan_buddy.py
Restart=on-failure
RestartSec=5

[Install]
WantedBy=default.target
'''

                service_path = Path.home() / ".config" / "systemd" / "user"
                service_path.mkdir(parents=True, exist_ok=True)

                with open(service_path / "safwaan-buddy.service", 'w') as f:
                    f.write(service_content)

                # Enable the service
                subprocess.run(["systemctl", "--user", "daemon-reload"], check=False)
                subprocess.run(["systemctl", "--user", "enable", "safwaan-buddy"], check=False)

            print("✅ Startup entry created")
            self.install_status["startup_entry"] = True
            return True

        except Exception as e:
            print(f"⚠️ Could not create startup entry: {e}")
            print("💡 You can manually add Safwaan Buddy to startup")
            return False

    def create_configuration(self) -> bool:
        """Create default configuration files"""
        print("\n⚙️ Creating configuration...")

        try:
            config_dir = self.install_dir / "config"
            config_dir.mkdir(exist_ok=True)

            # Enhanced configuration
            enhanced_config = {
                "agent_name": "Safwaan Buddy",
                "wake_words": ["buddy", "safwaan buddy", "hey buddy", "assistant"],
                "voice_rate": 150,
                "voice_volume": 1.0,
                "enable_wake_word_detection": True,
                "enable_voice_input": True,
                "enable_system_monitoring": True,
                "gui_theme": "dark",
                "window_width": 1400,
                "window_height": 900,
                "enable_ai_personality": True,
                "enable_natural_speech": True,
                "enable_system_control": True,
                "enable_screen_interaction": True,
                "enable_web_automation": True,
                "enable_multilingual": True,
                "default_language": "english",
                "emotional_intelligence": True,
                "adaptive_learning": True,
                "creativity_engine": True,
                "reasoning_engine": True,
                "personality_formality": 0.3,
                "personality_enthusiasm": 0.7,
                "personality_empathy": 0.8,
                "conversation_context_limit": 20,
                "knowledge_base_path": str(self.install_dir / "data" / "knowledge_base.json"),
                "admin_privileges_required": False,
                "allow_file_operations": True,
                "allow_system_commands": True,
                "allow_network_operations": True,
                "allow_app_control": True,
                "screen_capture_sensitivity": 0.8,
                "ocr_confidence_threshold": 0.7,
                "web_search_timeout": 30,
                "download_directory": str(Path.home() / "Downloads" / "SafwaanDownloads"),
                "auto_install_trusted_sources": True,
                "security_level": "medium"
            }

            with open(config_dir / "enhanced.json", 'w') as f:
                json.dump(enhanced_config, f, indent=4)

            # Create directories
            (self.install_dir / "data").mkdir(exist_ok=True)
            (self.install_dir / "logs").mkdir(exist_ok=True)
            (self.install_dir / "static" / "icons").mkdir(parents=True, exist_ok=True)
            (self.install_dir / "static" / "sounds").mkdir(parents=True, exist_ok=True)

            print("✅ Configuration files created")
            self.install_status["config"] = True
            return True

        except Exception as e:
            print(f"❌ Failed to create configuration: {e}")
            return False

    def test_installation(self) -> bool:
        """Test the installation"""
        print("\n🧪 Testing installation...")

        try:
            # Test imports
            import PyQt6
            print("✅ PyQt6 imported successfully")

            import speech_recognition
            print("✅ Speech recognition imported successfully")

            import pytesseract
            print("✅ Tesseract OCR imported successfully")

            import cv2
            print("✅ OpenCV imported successfully")

            # Test screen capture
            import pyautogui
            screenshot = pyautogui.screenshot()
            screenshot.save(self.temp_dir / "test_screenshot.png")
            print("✅ Screen capture test successful")

            print("✅ All core components working correctly")
            return True

        except ImportError as e:
            print(f"❌ Import error: {e}")
            return False
        except Exception as e:
            print(f"❌ Test error: {e}")
            return False

    def launch_application(self) -> bool:
        """Launch the installed application"""
        print("\n🚀 Launching Safwaan Buddy Enhanced...")

        try:
            # Change to installation directory
            os.chdir(self.install_dir)

            # Launch the application
            if self.system_platform == "windows":
                subprocess.Popen(["python", "run_safwaan_buddy.py"], shell=True)
            else:
                subprocess.Popen([sys.executable, "run_safwaan_buddy.py"])

            print("✅ Safwaan Buddy Enhanced launched successfully!")
            return True

        except Exception as e:
            print(f"❌ Failed to launch application: {e}")
            return False

    def print_installation_summary(self):
        """Print installation summary"""
        print("\n" + "=" * 60)
        print("🎉 INSTALLATION COMPLETE!")
        print("=" * 60)

        print(f"📁 Installation Directory: {self.install_dir}")
        print(f"🖥️ Desktop Shortcut: {'✅ Created' if self.install_status['desktop_shortcut'] else '❌ Failed'}")
        print(f"⚡ Startup Entry: {'✅ Created' if self.install_status['startup_entry'] else '❌ Failed'}")

        print("\n📋 Installation Status:")
        for component, status in self.install_status.items():
            status_icon = "✅" if status else "⚠️"
            print(f"  {status_icon} {component.replace('_', ' ').title()}")

        print("\n🚀 How to Use:")
        print("1. Double-click 'Safwaan Buddy Enhanced' on your desktop")
        print("2. Or run: python run_safwaan_buddy.py")
        print("3. Say 'Hey Buddy' to activate voice commands")
        print("4. Grant administrator permissions for full features")

        print("\n✨ Advanced Features:")
        print("🧠 Natural speech with emotional intelligence")
        print("💻 Complete laptop system control")
        print("🌍 Multilingual support (16+ languages)")
        print("🖥️ Screen interaction and form filling")
        print("🌐 Web automation and auto-installation")
        print("⚙️ Advanced AI personality and learning")

        print("\n🎯 Voice Commands to Try:")
        print('• "Hey Buddy, what can you do?"')
        print('• "Take a screenshot"')
        print('• "Fill out this form"')
        print('• "Search for and install VS Code"')
        print('• "Show me system information"')
        print('• "Tell me a joke in Spanish"')

        print("\n💡 For help and documentation:")
        print(f"• Read: {self.install_dir}/README_Enhanced.md")
        print("• Check the logs in the logs/ directory")
        print("• Visit: https://github.com/safwaan/voice-assistant")

        print("\n⚠️ Important Notes:")
        print("• Run as administrator for full system control")
        print("• Ensure microphone permissions are granted")
        print("• Some features may require additional setup")
        print("• Check the installation guide if you encounter issues")

    def run_installation(self):
        """Run the complete installation process"""
        try:
            # Check system requirements
            if not self.check_system_requirements():
                print("\n❌ System requirements not met. Please upgrade your system.")
                return False

            # Install dependencies
            if not self.install_python_dependencies():
                print("\n⚠️ Some dependencies failed to install. Basic features may still work.")

            # Create application directory
            if not self.create_application_directory():
                print("\n❌ Failed to create application directory.")
                return False

            # Install optional components
            self.install_tesseract_ocr()
            self.install_browser_drivers()

            # Create shortcuts and configuration
            self.create_desktop_shortcut()
            self.create_startup_entry()
            self.create_configuration()

            # Test installation
            if self.test_installation():
                print("\n✅ Installation test passed!")
            else:
                print("\n⚠️ Installation test failed, but basic functionality should work.")

            # Print summary
            self.print_installation_summary()

            # Ask if user wants to launch
            try:
                launch = input("\n🚀 Launch Safwaan Buddy Enhanced now? (y/n): ").lower().strip()
                if launch in ['y', 'yes', '']:
                    self.launch_application()
            except KeyboardInterrupt:
                print("\n👋 Installation completed. You can launch the application anytime from the desktop shortcut.")

            return True

        except KeyboardInterrupt:
            print("\n\n❌ Installation cancelled by user")
            return False
        except Exception as e:
            print(f"\n❌ Installation failed: {e}")
            return False

def main():
    """Main installation function"""
    installer = SafwaanBuddyInstaller()
    success = installer.run_installation()

    if success:
        print("\n🎊 Thank you for installing Safwaan Buddy Enhanced!")
        print("Your advanced AI assistant is ready to serve you! 🤖✨")
    else:
        print("\n💡 Installation encountered issues. Please check the error messages above.")
        print("For manual installation help, visit: https://github.com/safwaan/voice-assistant")

    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()