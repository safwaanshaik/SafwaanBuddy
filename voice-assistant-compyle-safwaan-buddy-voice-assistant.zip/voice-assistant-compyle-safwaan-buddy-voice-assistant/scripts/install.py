#!/usr/bin/env python3
"""
Automated Installation Script for Safwaan Buddy
Sets up dependencies, configuration, and environment for the voice assistant.
"""

import os
import sys
import subprocess
import platform
from pathlib import Path
from typing import Tuple, Optional

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

try:
    from config import ConfigManager
    from utils.logger import get_logger
except ImportError:
    print("Error: Cannot import required modules. Please ensure you're running this from the project root.")
    sys.exit(1)

logger = get_logger("install")


class Installer:
    """Handles the complete installation process."""

    def __init__(self):
        """Initialize installer."""
        self.project_root = Path(__file__).parent.parent
        self.python_version = sys.version_info
        self.platform = platform.system()
        self.config_manager = ConfigManager()

    def run(self):
        """Run the complete installation process."""
        print("🤖 Safwaan Buddy - Automated Installation")
        print("=" * 50)

        try:
            # Check system requirements
            if not self.check_requirements():
                print("❌ System requirements not met. Installation aborted.")
                return False

            # Install dependencies
            if not self.install_dependencies():
                print("❌ Failed to install dependencies. Installation aborted.")
                return False

            # Setup configuration
            if not self.setup_configuration():
                print("❌ Failed to setup configuration. Installation aborted.")
                return False

            # Initialize database
            if not self.initialize_database():
                print("❌ Failed to initialize database. Installation aborted.")
                return False

            # Test installation
            if not self.test_installation():
                print("❌ Installation test failed. Please check the logs.")
                return False

            # Create desktop shortcut
            self.create_desktop_shortcut()

            # Setup autocomplete (optional)
            self.setup_autocomplete()

            print("\n✅ Installation completed successfully!")
            print("\nNext steps:")
            print("1. Edit your .env file with your API keys")
            print("2. Run: python src/main.py")
            print("3. Say 'Hey Buddy!' to start using Safwaan Buddy")

            return True

        except Exception as e:
            print(f"\n❌ Installation failed: {e}")
            logger.error(f"Installation failed: {e}")
            return False

    def check_requirements(self) -> bool:
        """Check system requirements."""
        print("🔍 Checking system requirements...")

        # Check Python version
        if self.python_version < (3, 9):
            print(f"❌ Python 3.9+ required, found {self.python_version.major}.{self.python_version.minor}")
            return False
        print(f"✅ Python version: {self.python_version.major}.{self.python_version.minor}")

        # Check platform
        if self.platform != "Windows":
            print(f"⚠️  Warning: Safwaan Buddy is optimized for Windows. Detected: {self.platform}")

        # Check for audio device (basic check)
        try:
            import speech_recognition as sr
            mic = sr.Microphone()
            print("✅ Audio device found")
        except Exception as e:
            print(f"⚠️  Warning: Could not detect audio device: {e}")

        # Check for administrative privileges (for UI automation)
        try:
            import ctypes
            is_admin = ctypes.windll.shell32.IsUserAnAdmin() != 0
            if is_admin:
                print("✅ Running with administrative privileges")
            else:
                print("⚠️  Warning: Not running as administrator (UI automation limited)")
        except:
            print("⚠️  Could not check administrative privileges")

        return True

    def install_dependencies(self) -> bool:
        """Install Python dependencies."""
        print("\n📦 Installing dependencies...")

        requirements_file = self.project_root / "requirements.txt"
        if not requirements_file.exists():
            print("❌ requirements.txt not found")
            return False

        try:
            # Upgrade pip
            subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pip"],
                         check=True, capture_output=True)

            # Install requirements
            result = subprocess.run([sys.executable, "-m", "pip", "install", "-r", str(requirements_file)],
                                  capture_output=True, text=True)

            if result.returncode == 0:
                print("✅ Dependencies installed successfully")
                return True
            else:
                print(f"❌ Failed to install dependencies: {result.stderr}")
                return False

        except subprocess.CalledProcessError as e:
            print(f"❌ Failed to install dependencies: {e}")
            return False

    def setup_configuration(self) -> bool:
        """Setup configuration files."""
        print("\n⚙️ Setting up configuration...")

        try:
            # Create .env file if it doesn't exist
            env_file = self.project_root / ".env"
            env_example = self.project_root / ".env.example"

            if not env_file.exists() and env_example.exists():
                import shutil
                shutil.copy(env_example, env_file)
                print("✅ Created .env file from template")

            # Create default configuration files
            config_dir = self.project_root / "config"
            config_dir.mkdir(exist_ok=True)

            # Create themes directory
            themes_dir = config_dir / "themes"
            themes_dir.mkdir(exist_ok=True)

            # Create default theme
            default_theme = themes_dir / "dark.json"
            if not default_theme.exists():
                import json
                theme_data = {
                    "name": "dark",
                    "background_color": "#0a0e27",
                    "primary_color": "#00d9ff",
                    "secondary_color": "#00ff88",
                    "accent_color": "#0f3460",
                    "text_color": "#ffffff",
                    "border_color": "#1a5f7f",
                    "error_color": "#ff4444",
                    "warning_color": "#ffaa00",
                    "success_color": "#00ff88"
                }
                with open(default_theme, 'w') as f:
                    json.dump(theme_data, f, indent=2)
                print("✅ Created default dark theme")

            # Create default configurations
            self.config_manager.create_default_configs()
            print("✅ Created default configuration files")

            return True

        except Exception as e:
            print(f"❌ Failed to setup configuration: {e}")
            return False

    def initialize_database(self) -> bool:
        """Initialize the memory database."""
        print("\n🗄️ Initializing database...")

        try:
            # Import and initialize memory manager
            from core.memory import MemoryManager

            # Initialize database (this creates tables)
            memory_manager = MemoryManager()
            memory_manager.close()

            print("✅ Database initialized successfully")
            return True

        except Exception as e:
            print(f"❌ Failed to initialize database: {e}")
            return False

    def test_installation(self) -> bool:
        """Test the installation."""
        print("\n🧪 Testing installation...")

        try:
            # Test imports
            print("  Testing imports...")
            from core.memory import MemoryManager
            from core.voice_processor import VoiceProcessor
            from core.command_parser import AICommandParser
            from core.plugin_manager import PluginManager
            from utils.logger import get_logger
            print("  ✅ All imports successful")

            # Test configuration
            print("  Testing configuration...")
            config = self.config_manager.get_all()
            if "agent_name" in config:
                print("  ✅ Configuration loaded successfully")

            # Test basic functionality
            print("  Testing basic functionality...")
            parser = AICommandParser()
            intent = parser.parse_intent("What time is it?")
            if intent.intent.value == "time":
                print("  ✅ Command parsing working")

            print("✅ All tests passed")
            return True

        except Exception as e:
            print(f"❌ Installation test failed: {e}")
            return False

    def create_desktop_shortcut(self):
        """Create desktop shortcut."""
        print("\n🖥️ Creating desktop shortcut...")

        try:
            if self.platform == "Windows":
                import winshell
                from win32com.client import Dispatch

                desktop = winshell.desktop()
                path = os.path.join(desktop, "Safwaan Buddy.lnk")
                target = str(self.project_root / "src" / "main.py")
                wDir = str(self.project_root)
                icon = str(self.project_root / "icon.ico")  # Optional icon file

                shell = Dispatch('WScript.Shell')
                shortcut = shell.CreateShortCut(path)
                shortcut.Targetpath = sys.executable
                shortcut.Arguments = target
                shortcut.WorkingDirectory = wDir
                if Path(icon).exists():
                    shortcut.IconLocation = icon
                shortcut.save()

                print("✅ Desktop shortcut created")
            else:
                print("⚠️  Desktop shortcuts only supported on Windows")

        except ImportError:
            print("⚠️  Could not create desktop shortcut (missing pywin32)")
        except Exception as e:
            print(f"⚠️  Could not create desktop shortcut: {e}")

    def setup_autocomplete(self):
        """Setup command line autocomplete (optional)."""
        try:
            # This is a placeholder for future autocomplete setup
            pass
        except Exception:
            pass


def main():
    """Main installation function."""
    installer = Installer()
    success = installer.run()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()