#!/usr/bin/env python3
"""
Microphone Setup and Testing Script for Safwaan Buddy
Tests audio devices and provides feedback for microphone configuration.
"""

import os
import sys
import time
import threading
from pathlib import Path
from typing import List, Optional, Dict, Any

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

try:
    import speech_recognition as sr
    import pyttsx3
    from utils.logger import get_logger
except ImportError as e:
    print(f"Error: Missing dependencies - {e}")
    print("Please run: python scripts/install.py")
    sys.exit(1)

logger = get_logger("mic_setup")


class MicrophoneSetup:
    """Handles microphone detection, testing, and configuration."""

    def __init__(self):
        """Initialize microphone setup."""
        self.recognizer = sr.Recognizer()
        self.microphones = self.get_available_microphones()
        self.tts_engine = pyttsx3.init()

    def get_available_microphones(self) -> List[Dict[str, Any]]:
        """Get list of available microphones."""
        microphones = []

        for i, microphone_name in enumerate(sr.Microphone.list_microphone_names()):
            try:
                # Test if microphone is working
                mic = sr.Microphone(device_index=i)
                microphones.append({
                    "index": i,
                    "name": microphone_name,
                    "device": mic,
                    "working": True
                })
            except Exception as e:
                logger.warning(f"Microphone {i} ({microphone_name}) not accessible: {e}")
                microphones.append({
                    "index": i,
                    "name": microphone_name,
                    "device": None,
                    "working": False
                })

        return microphones

    def test_microphone(self, microphone_index: int, duration: float = 3.0) -> bool:
        """Test a specific microphone."""
        try:
            mic = sr.Microphone(device_index=microphone_index)

            with mic as source:
                print(f"\n🎤 Testing microphone: {mic.list_microphone_names()[microphone_index]}")
                print("Speak into the microphone now...")
                print("(Listening for 3 seconds...)")

                # Adjust for ambient noise
                self.recognizer.adjust_for_ambient_noise(source, duration=1.0)

                # Listen for audio
                audio = self.recognizer.listen(source, timeout=duration, phrase_time_limit=duration)

            print("🔊 Processing audio...")

            # Try to recognize speech
            try:
                text = self.recognizer.recognize_google(audio)
                print(f"✅ Successfully detected speech: '{text}'")

                # Speak confirmation
                self.tts_engine.say(f"Microphone test successful. You said: {text}")
                self.tts_engine.runAndWait()

                return True

            except sr.UnknownValueError:
                print("❌ Could not understand audio (speech not recognized)")
                self.tts_engine.say("Microphone test failed. Could not understand speech.")
                self.tts_engine.runAndWait()
                return False

            except sr.RequestError as e:
                print(f"❌ Speech recognition service error: {e}")
                self.tts_engine.say("Microphone test failed. Speech recognition service unavailable.")
                self.tts_engine.runAndWait()
                return False

        except Exception as e:
            print(f"❌ Microphone test failed: {e}")
            self.tts_engine.say("Microphone test failed. Please check your microphone connection.")
            self.tts_engine.runAndWait()
            return False

    def interactive_setup(self):
        """Interactive microphone setup process."""
        print("🎤 Safwaan Buddy - Microphone Setup")
        print("=" * 50)

        if not self.microphones:
            print("❌ No microphones found!")
            print("Please check your microphone connection and try again.")
            return False

        print(f"\n📋 Found {len(self.microphones)} microphone(s):")

        for i, mic in enumerate(self.microphones):
            status = "✅" if mic["working"] else "❌"
            print(f"  {status} [{mic['index']}] {mic['name']}")

        working_microphones = [mic for mic in self.microphones if mic["working"]]
        if not working_microphones:
            print("\n❌ No working microphones found!")
            return False

        # Test default microphone first
        print(f"\n🧪 Testing default microphone...")
        default_mic = working_microphones[0]

        if self.test_microphone(default_mic["index"]):
            print(f"\n✅ Default microphone working: {default_mic['name']}")

            # Ask if user wants to test other microphones
            if len(working_microphones) > 1:
                response = input("\nWould you like to test other microphones? (y/n): ").lower()
                if response in ['y', 'yes']:
                    self.test_additional_microphones(working_microphones[1:])

            # Save configuration
            self.save_microphone_config(default_mic["index"])
            return True
        else:
            print(f"\n❌ Default microphone failed: {default_mic['name']}")

            if len(working_microphones) > 1:
                print("Testing other microphones...")
                return self.test_additional_microphones(working_microphones)

        return False

    def test_additional_microphones(self, microphones: List[Dict[str, Any]]) -> bool:
        """Test additional microphones."""
        for mic in microphones:
            response = input(f"\nTest microphone: {mic['name']}? (y/n): ").lower()
            if response in ['y', 'yes']:
                if self.test_microphone(mic["index"]):
                    print(f"✅ Microphone working: {mic['name']}")
                    self.save_microphone_config(mic["index"])
                    return True
                else:
                    print(f"❌ Microphone failed: {mic['name']}")
        return False

    def save_microphone_config(self, microphone_index: int):
        """Save microphone configuration to .env file."""
        try:
            env_file = Path(__file__).parent.parent / ".env"

            # Read existing .env file
            lines = []
            if env_file.exists():
                with open(env_file, 'r') as f:
                    lines = f.readlines()

            # Update or add microphone setting
            mic_name = self.microphones[microphone_index]["name"]
            found = False

            for i, line in enumerate(lines):
                if line.startswith("MICROPHONE_INDEX="):
                    lines[i] = f"MICROPHONE_INDEX={microphone_index}\n"
                    found = True
                elif line.startswith("MICROPHONE_NAME="):
                    lines[i] = f"MICROPHONE_NAME={mic_name}\n"
                    found = True

            if not found:
                lines.append(f"\n# Microphone Configuration\n")
                lines.append(f"MICROPHONE_INDEX={microphone_index}\n")
                lines.append(f"MICROPHONE_NAME={mic_name}\n")

            # Write back to file
            with open(env_file, 'w') as f:
                f.writelines(lines)

            print(f"✅ Microphone configuration saved to .env")

        except Exception as e:
            print(f"⚠️  Could not save microphone configuration: {e}")

    def test_speakers(self):
        """Test speaker/audio output."""
        print("\n🔊 Testing speakers...")

        try:
            # Test different voices if available
            voices = self.tts_engine.getProperty('voices')

            if voices:
                print(f"Found {len(voices)} voice(s)")

                # Test first voice
                self.tts_engine.setProperty('voice', voices[0].id)
                self.tts_engine.say("Speaker test successful. Safwaan Buddy is ready to use.")
                self.tts_engine.runAndWait()
                print("✅ Speaker test completed")
            else:
                print("⚠️  No voices found")

        except Exception as e:
            print(f"❌ Speaker test failed: {e}")

    def audio_quality_check(self, microphone_index: int) -> Dict[str, Any]:
        """Perform audio quality checks."""
        print("\n📊 Performing audio quality check...")

        results = {
            "background_noise": 0,
            "signal_quality": "unknown",
            "recommendations": []
        }

        try:
            mic = sr.Microphone(device_index=microphone_index)

            with mic as source:
                # Measure ambient noise
                print("Measuring ambient noise...")
                self.recognizer.adjust_for_ambient_noise(source, duration=2.0)
                ambient_threshold = self.recognizer.energy_threshold
                results["background_noise"] = ambient_threshold

                # Provide recommendations based on noise level
                if ambient_threshold < 200:
                    results["recommendations"].append("Low background noise detected - Good!")
                elif ambient_threshold < 400:
                    results["recommendations"].append("Moderate background noise - Find a quieter environment if possible")
                else:
                    results["recommendations"].append("High background noise - Please find a quieter environment")

                # Test speech detection
                print("Testing speech detection...")
                audio = self.recognizer.listen(source, timeout=5.0, phrase_time_limit=3.0)

                try:
                    text = self.recognizer.recognize_google(audio)
                    if len(text) > 0:
                        results["signal_quality"] = "good"
                        results["recommendations"].append("Speech detection working well")
                    else:
                        results["signal_quality"] = "poor"
                        results["recommendations"].append("Speech not detected clearly")
                except sr.UnknownValueError:
                    results["signal_quality"] = "poor"
                    results["recommendations"].append("Could not detect speech clearly")

        except Exception as e:
            results["signal_quality"] = "error"
            results["recommendations"].append(f"Audio quality check failed: {e}")

        return results


def main():
    """Main microphone setup function."""
    setup = MicrophoneSetup()

    try:
        # Interactive setup
        if setup.interactive_setup():
            # Test speakers
            setup.test_speakers()

            # Perform audio quality check
            print("\n" + "=" * 50)
            results = setup.audio_quality_check(setup.microphones[0]["index"])

            print("\n📊 Audio Quality Results:")
            print(f"Background Noise Level: {results['background_noise']}")
            print(f"Signal Quality: {results['signal_quality']}")

            if results["recommendations"]:
                print("\n💡 Recommendations:")
                for rec in results["recommendations"]:
                    print(f"  • {rec}")

            print("\n✅ Microphone setup completed successfully!")
            print("You can now start using Safwaan Buddy.")
            print("Run: python src/main.py")
        else:
            print("\n❌ Microphone setup failed!")
            print("Please check your audio devices and try again.")

    except KeyboardInterrupt:
        print("\n\n⚠️  Setup cancelled by user")
    except Exception as e:
        print(f"\n❌ Setup failed: {e}")
        logger.error(f"Microphone setup failed: {e}")


if __name__ == "__main__":
    main()