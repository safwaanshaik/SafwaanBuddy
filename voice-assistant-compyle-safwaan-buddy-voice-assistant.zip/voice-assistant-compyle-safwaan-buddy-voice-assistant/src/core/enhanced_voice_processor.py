#!/usr/bin/env python3
"""
Enhanced Voice Processor with Ultra-Natural Voices
Integrates with regional voices and emotional effects
"""

import sys
import time
import threading
from typing import Optional, Dict, Any, List, Callable
from pathlib import Path
from enum import Enum

# Add current directory to path
current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir))

from voice_processor import VoiceProcessor, VoiceEvent, IntentType
from ultra_natural_voices import UltraNaturalVoiceSystem, VoiceStyle

class SpeechMode(Enum):
    """Different speech modes"""
    CONVERSATIONAL = "conversational"
    PROFESSIONAL = "professional"
    FRIENDLY = "friendly"
    EMOTIONAL = "emotional"
    REGIONAL = "regional"

class EnhancedVoiceProcessor(VoiceProcessor):
    """Enhanced voice processor with ultra-natural capabilities"""

    def __init__(self):
        super().__init__()

        # Initialize ultra-natural voice system
        self.ultra_voices = UltraNaturalVoiceSystem()

        # Enhanced speech settings
        self.current_mode = SpeechMode.CONVERSATIONAL
        self.current_style = VoiceStyle.ENGLISH_EMOTIONAL
        self.emotion_mapping = {
            "happy": "excited",
            "sad": "sad",
            "angry": "angry",
            "surprised": "surprise",
            "confused": "confusion",
            "thinking": "thinking",
            "understanding": "understanding",
            "concern": "concern"
        }

        # Regional language detection
        self.language_keywords = {
            "hindi": ["namaste", "dhanyawad", "kaise hain", "aap", "ji", "sahab"],
            "urdu": ["assalamualaikum", "shukriya", "aap", "jaan", "khuda", "dil"],
            "hyderabadi": ["bhai", "nakko", "poy", "key", "baigan", "pilla", "mir"],
            "punjabi": ["sat sri akal", "waheguru", "bhai", "ji", "puttar"],
            "bengali": ["namaskar", "dhonnobad", "tumi", "apni", "bhalo"]
        }

        # Emotional response patterns
        self.emotional_responses = {
            "greeting": {
                "default": "Hello there!",
                "excited": "OH! HEY THERE!",
                "hindi": "Namaste!",
                "hyderabadi": "Assalamualaikum bhai!"
            },
            "goodbye": {
                "default": "Goodbye!",
                "warm": "Take care now!",
                "hindi": "Namaste!",
                "hyderabadi": "Allah Hafiz bhai!"
            },
            "thanks": {
                "default": "You're welcome!",
                "hindi": "Koi baat nahi!",
                "hyderabadi": "Meherbani bhai!",
                "warm": "Awwwee, so sweet!"
            },
            "agreement": {
                "default": "Yes, I agree!",
                "enthusiastic": "Absolutely! YES!",
                "hindi": "Haan bilkul!",
                "hyderabadi": "Pakka bhai!"
            },
            "disagreement": {
                "default": "I don't think so.",
                "polite": "I respectfully disagree.",
                "hindi": "Mujhe nahi lagta.",
                "hyderabadi": "Nakko bhai!"
            }
        }

        # Natural pause patterns
        self.pause_patterns = {
            "short": [0.2, 0.3, 0.4],
            "medium": [0.5, 0.6, 0.7, 0.8],
            "long": [1.0, 1.2, 1.5],
            "thinking": [0.8, 1.0, 1.2, 1.5]
        }

        # Initialize voice settings
        self._initialize_enhanced_settings()

        print("🎙️ Enhanced Voice Processor with Ultra-Natural Voices Initialized")
        print(f"🌍 Available Styles: {len(self.ultra_voices.get_available_voices())}")
        print(f"💫 Emotional Effects: {len(self.ultra_voices.emotional_effects)}")

    def _initialize_enhanced_settings(self):
        """Initialize enhanced voice settings"""
        # Install voice packages if needed
        try:
            self.ultra_voices.install_voice_packages()
        except Exception as e:
            print(f"⚠️ Voice package installation issue: {e}")

        # Set default voice style
        try:
            self.ultra_voices.set_voice_personality(self.current_style)
        except Exception as e:
            print(f"⚠️ Voice style setting issue: {e}")

    def detect_language_and_style(self, text: str) -> tuple:
        """Detect language and appropriate speaking style"""
        text_lower = text.lower()

        # Check for regional keywords
        detected_language = "english"
        detected_style = None

        for language, keywords in self.language_keywords.items():
            if any(keyword in text_lower for keyword in keywords):
                detected_language = language
                break

        # Map language to voice style
        if detected_language == "hindi":
            detected_style = VoiceStyle.HINDI_FRIENDLY
        elif detected_language == "urdu":
            detected_style = VoiceStyle.URDU_FRIENDLY
        elif detected_language == "hyderabadi":
            detected_style = VoiceStyle.HYDERABADI_CASUAL
        elif detected_language == "punjabi":
            detected_style = VoiceStyle.HINDI_FRIENDLY  # Closest available
        elif detected_language == "bengali":
            detected_style = VoiceStyle.HINDI_FRIENDLY  # Closest available
        else:
            # Use default style for English
            detected_style = self.current_style

        return detected_language, detected_style

    def add_emotional_effects(self, text: str, context: str = "neutral") -> str:
        """Add emotional effects and natural fillers"""
        enhanced_text = text

        # Add emotional interjections based on context
        if context == "greeting":
            greetings = ["Hello there!", "Hi there!", "Hey!"]
            if random.random() < 0.3:  # 30% chance to add greeting
                enhanced_text = f"{random.choice(greetings)} {enhanced_text}"

        elif context == "surprise":
            surprises = ["OH!", "WOW!", "AMAZING!", "UNBELIEVABLE!"]
            if random.random() < 0.5:
                enhanced_text = f"{random.choice(surprises)} {enhanced_text}"

        elif context == "thinking":
            thinking = ["hmmm...", "let me think...", "socho toh...", "woh..."]
            if random.random() < 0.4:
                enhanced_text = f"{random.choice(thinking)} {enhanced_text}"

        elif context == "understanding":
            understanding = ["ahhannn", "haan ji", "samjh gaya", "got it!", "ohhh i see"]
            if random.random() < 0.4:
                enhanced_text = f"{random.choice(understanding)} {enhanced_text}"

        elif context == "agreement":
            agreements = ["bilkul!", "definitely!", "absolutely!", "pakkah!"]
            if random.random() < 0.3:
                enhanced_text = f"{random.choice(agreements)} {enhanced_text}"

        # Add natural pauses (represented in text)
        enhanced_text = enhanced_text.replace(" and ", ", and ")
        enhanced_text = enhanced_text.replace(" but ", ", but ")

        return enhanced_text

    def speak_with_regional_adaptation(self, text: str, emotion: str = "neutral",
                                      language: Optional[str] = None) -> bool:
        """Speak with regional language adaptation"""
        try:
            # Detect language if not specified
            if not language:
                language, style = self.detect_language_and_style(text)
            else:
                # Map language to style
                style_map = {
                    "hindi": VoiceStyle.HINDI_FRIENDLY,
                    "urdu": VoiceStyle.URDU_FRIENDLY,
                    "hyderabadi": VoiceStyle.HYDERABADI_CASUAL
                }
                style = style_map.get(language, self.current_style)

            # Add emotional effects
            enhanced_text = self.add_emotional_effects(text, emotion)

            # Speak with the ultra-natural voice system
            success = self.ultra_voices.speak_with_emotion(enhanced_text, emotion, style)

            return success

        except Exception as e:
            print(f"❌ Regional speech failed: {e}")
            # Fallback to regular speech
            return self.speak(text)

    def set_speech_mode(self, mode: SpeechMode, style: Optional[VoiceStyle] = None):
        """Set speech mode and optional style"""
        self.current_mode = mode

        if style:
            self.current_style = style
        else:
            # Map mode to default style
            mode_styles = {
                SpeechMode.CONVERSATIONAL: VoiceStyle.ENGLISH_EMOTIONAL,
                SpeechMode.PROFESSIONAL: VoiceStyle.ENGLISH_PROFESSIONAL,
                SpeechMode.FRIENDLY: VoiceStyle.ENGLISH_FUN,
                SpeechMode.EMOTIONAL: VoiceStyle.ENGLISH_EMOTIONAL,
                SpeechMode.REGIONAL: VoiceStyle.HYDERABADI_CASUAL
            }
            self.current_style = mode_styles.get(mode, VoiceStyle.ENGLISH_EMOTIONAL)

        # Apply the style
        self.ultra_voices.set_voice_personality(self.current_style)

        print(f"🎭 Speech mode set: {mode.value} ({self.current_style.value})")

    def create_natural_response(self, user_input: str, response_text: str,
                                context: Dict[str, Any] = None) -> str:
        """Create a natural response with emotional and regional adaptation"""
        try:
            # Detect user's language and style
            user_language, user_style = self.detect_language_and_style(user_input)

            # Add emotional context
            emotion = context.get("emotion", "neutral") if context else "neutral"

            # Enhance response with natural effects
            enhanced_response = self.add_emotional_effects(response_text, emotion)

            # Adapt to detected language if different from default
            if user_language != "english" and self.current_mode == SpeechMode.CONVERSATIONAL:
                # Try to match user's language
                if user_language == "hyderabadi":
                    enhanced_response = self.ultra_voices.translate_to_regional_style(
                        enhanced_response, self.ultra_voices.voice_personalities[VoiceStyle.HYDERABADI_CASUAL.value]
                    )
                elif user_language == "hindi":
                    enhanced_response = self.ultra_voices.translate_to_regional_style(
                        enhanced_response, self.ultra_voices.voice_personalities[VoiceStyle.HINDI_FRIENDLY.value]
                    )
                elif user_language == "urdu":
                    enhanced_response = self.ultra_voices.translate_to_regional_style(
                        enhanced_response, self.ultra_voices.voice_personalities[VoiceStyle.URDU_FRIENDLY.value]
                    )

            return enhanced_response

        except Exception as e:
            print(f"❌ Response enhancement failed: {e}")
            return response_text

    def speak_with_natural_pauses(self, text: str, pause_pattern: str = "medium"):
        """Speak with natural pauses"""
        try:
            # Split text into natural chunks
            words = text.split()
            if not words:
                return

            current_chunk = []

            for word in words:
                current_chunk.append(word)

                # Add pause at natural points
                if word.endswith(('.', '!', '?')) or len(current_chunk) >= 8:
                    # Speak current chunk
                    chunk_text = " ".join(current_chunk)

                    # Add emotional effect
                    if self.ultra_voices.current_voice:
                        chunk_text = self.ultra_voices.add_natural_effects(chunk_text, "neutral")

                    # Speak chunk
                    self.speak_with_regional_adaptation(chunk_text, "neutral")

                    # Add pause
                    if pause_pattern in self.pause_patterns:
                        pause_time = random.choice(self.pause_patterns[pause_pattern])
                        time.sleep(pause_time)

                    current_chunk = []

            # Speak remaining chunk
            if current_chunk:
                chunk_text = " ".join(current_chunk)
                self.speak_with_regional_adaptation(chunk_text, "neutral")

        except Exception as e:
            print(f"❌ Natural pause speech failed: {e}")
            # Fallback
            self.speak(text)

    def emotional_conversation(self, messages: List[Dict[str, str]]):
        """Create an emotional conversation with multiple messages"""
        try:
            for message in messages:
                text = message.get("text", "")
                emotion = message.get("emotion", "neutral")
                language = message.get("language", "english")
                pause_after = message.get("pause", 0.5)

                if text:
                    self.speak_with_regional_adaptation(text, emotion, language)
                    if pause_after > 0:
                        time.sleep(pause_after)

        except Exception as e:
            print(f"❌ Emotional conversation failed: {e}")

    def demonstrate_voices(self) -> bool:
        """Demonstrate all available voices"""
        try:
            print("🎭 Demonstrating Ultra-Natural Voices...")

            demonstrations = [
                {
                    "style": VoiceStyle.HYDERABADI_CASUAL,
                    "text": "Assalamualaikum bhai! Kya haal hai pilla? Main aapka dost Safwaan bol raha hun!",
                    "emotion": "friendly"
                },
                {
                    "style": VoiceStyle.HINDI_FRIENDLY,
                    "text": "Namaste doston! Main aapki help karne ke liye hoon. Kya kaam hai?",
                    "emotion": "excited"
                },
                {
                    "style": VoiceStyle.URDU_ELEGANT,
                    "text": "Assalamualaikum! Main aapki seva ke liye hun. Kya farma rahe hain?",
                    "emotion": "gentle"
                },
                {
                    "style": VoiceStyle.ENGLISH_EMOTIONAL,
                    "text": "Hello there! I'm so excited to help you today! Ohh this is going to be amazing!",
                    "emotion": "excited"
                },
                {
                    "style": VoiceStyle.ENGLISH_FUN,
                    "text": "Brilliant! Absolutely fantastic! I'm ready to rock and roll, mate!",
                    "emotion": "fun"
                }
            ]

            for demo in demonstrations:
                print(f"\n🎤 {demo['style'].value}:")
                self.ultra_voices.set_voice_personality(demo['style'])
                self.speak_with_regional_adaptation(demo['text'], demo['emotion'])
                time.sleep(1)

            return True

        except Exception as e:
            print(f"❌ Voice demonstration failed: {e}")
            return False

    def get_language_preference(self, user_input: str) -> str:
        """Get user's language preference from input"""
        text_lower = user_input.lower()

        language_scores = {}

        for language, keywords in self.language_keywords.items():
            score = sum(1 for keyword in keywords if keyword in text_lower)
            if score > 0:
                language_scores[language] = score

        if language_scores:
            return max(language_scores, key=language_scores.get)

        return "english"

    def switch_to_user_language(self, user_input: str):
        """Automatically switch to user's detected language"""
        user_language = self.get_language_preference(user_input)

        if user_language == "hindi":
            self.set_speech_mode(SpeechMode.REGIONAL, VoiceStyle.HINDI_FRIENDLY)
        elif user_language == "urdu":
            self.set_speech_mode(SpeechMode.REGIONAL, VoiceStyle.URDU_FRIENDLY)
        elif user_language == "hyderabadi":
            self.set_speech_mode(SpeechMode.REGIONAL, VoiceStyle.HYDERABADI_CASUAL)
        else:
            self.set_speech_mode(SpeechMode.CONVERSATIONAL)

        return user_language

    def add_cultural_markers(self, text: str, language: str) -> str:
        """Add appropriate cultural markers based on language"""
        if language == "hindi":
            markers = ["ji", "sahab", "mahoday"]
            return f"{text} {random.choice(markers) if random.random() < 0.3 else ''}"
        elif language == "urdu":
            markers = ["ji", "sahib", "khuda hafiz"]
            return f"{text} {random.choice(markers) if random.random() < 0.3 else ''}"
        elif language == "hyderabadi":
            markers = ["bhai", "ji", "pilla"]
            return f"{text} {random.choice(markers) if random.random() < 0.4 else ''}"
        else:
            return text

    def speak_with_context(self, text: str, context: Dict[str, Any]) -> bool:
        """Speak with full contextual adaptation"""
        try:
            # Extract context information
            user_language = context.get("user_language", "english")
            emotion = context.get("emotion", "neutral")
            conversation_style = context.get("style", "conversational")

            # Adapt to user language
            if user_language != "english":
                adapted_text = self.add_cultural_markers(text, user_language)
            else:
                adapted_text = text

            # Add emotional effects
            enhanced_text = self.add_emotional_effects(adapted_text, emotion)

            # Choose appropriate speaking mode
            if conversation_style == "professional":
                mode = SpeechMode.PROFESSIONAL
            elif conversation_style == "friendly":
                mode = SpeechMode.FRIENDLY
            elif conversation_style == "emotional":
                mode = SpeechMode.EMOTIONAL
            else:
                mode = SpeechMode.CONVERSATIONAL

            # Set mode and speak
            self.set_speech_mode(mode)
            return self.speak_with_regional_adaptation(enhanced_text, emotion, user_language)

        except Exception as e:
            print(f"❌ Contextual speech failed: {e}")
            return self.speak(text)