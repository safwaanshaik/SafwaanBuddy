#!/usr/bin/env python3
"""
Advanced Screen Interaction System
OCR, form filling, clicking, typing, and visual element detection
"""

import cv2
import numpy as np
import pyautogui
import pytesseract
import easyocr
import time
import re
from typing import List, Dict, Tuple, Optional, Any
from dataclasses import dataclass
from pathlib import Path
import tempfile
import os

@dataclass
class ScreenElement:
    """Represents an interactive element on screen"""
    element_type: str  # 'button', 'input', 'link', 'image', 'text'
    text: str
    bbox: Tuple[int, int, int, int]  # x, y, width, height
    center: Tuple[int, int]
    confidence: float
    properties: Dict[str, Any]

@dataclass
class FormField:
    """Represents a form field"""
    field_type: str  # 'text', 'email', 'password', 'dropdown', 'checkbox', 'radio'
    label: str
    bbox: Tuple[int, int, int, int]
    center: Tuple[int, int]
    placeholder: Optional[str] = None
    options: Optional[List[str]] = None

class AdvancedScreenInteraction:
    """Advanced screen interaction with OCR and AI detection"""

    def __init__(self):
        # Initialize OCR readers
        self.ocr_reader = easyocr.Reader(['en'])  # Add more languages as needed
        self.pytesseract_config = r'--oem 3 --psm 6'

        # Computer vision setup
        self.screen_width, self.screen_height = pyautogui.size()

        # AI model for element detection (placeholder for future integration)
        self.element_detector = None

        # Form filling patterns
        self.field_patterns = {
            'email': ['email', 'e-mail', 'mail', '@'],
            'password': ['password', 'pass', 'pwd'],
            'name': ['name', 'full name', 'first name', 'last name'],
            'phone': ['phone', 'mobile', 'cell', 'tel'],
            'address': ['address', 'street', 'city', 'zip'],
            'username': ['username', 'user', 'login', 'id'],
        }

    def capture_screen(self, region: Optional[Tuple[int, int, int, int]] = None) -> np.ndarray:
        """Capture screen or specific region"""
        if region:
            screenshot = pyautogui.screenshot(region=region)
        else:
            screenshot = pyautogui.screenshot()

        # Convert to numpy array
        screen_array = np.array(screenshot)
        return cv2.cvtColor(screen_array, cv2.COLOR_RGB2BGR)

    def detect_ui_elements(self, image: np.ndarray) -> List[ScreenElement]:
        """Detect UI elements using computer vision"""
        elements = []

        # Detect buttons and interactive elements
        elements.extend(self._detect_buttons(image))
        elements.extend(self._detect_input_fields(image))
        elements.extend(self._detect_links(image))
        elements.extend(self._detect_text_blocks(image))

        return elements

    def _detect_buttons(self, image: np.ndarray) -> List[ScreenElement]:
        """Detect button-like elements"""
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Use edge detection and contour analysis
        edges = cv2.Canny(gray, 50, 150)
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        buttons = []
        for contour in contours:
            area = cv2.contourArea(contour)
            if area < 1000:  # Skip small contours
                continue

            # Get bounding box
            x, y, w, h = cv2.boundingRect(contour)

            # Check aspect ratio (buttons are usually wider than tall)
            aspect_ratio = w / h
            if aspect_ratio < 1.5 or aspect_ratio > 6:
                continue

            # Extract text from button
            roi = image[y:y+h, x:x+w]
            text = self._extract_text_from_image(roi)

            if text.strip():
                elements = ScreenElement(
                    element_type='button',
                    text=text.strip(),
                    bbox=(x, y, w, h),
                    center=(x + w // 2, y + h // 2),
                    confidence=0.8,
                    properties={'aspect_ratio': aspect_ratio}
                )
                buttons.append(elements)

        return buttons

    def _detect_input_fields(self, image: np.ndarray) -> List[ScreenElement]:
        """Detect input fields and form elements"""
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Detect rectangular shapes that look like input fields
        edges = cv2.Canny(gray, 50, 150)
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        input_fields = []
        for contour in contours:
            area = cv2.contourArea(contour)
            if area < 500 or area > 50000:  # Size filter
                continue

            x, y, w, h = cv2.boundingRect(contour)

            # Input fields are typically wider than tall but not too wide
            aspect_ratio = w / h
            if aspect_ratio < 2 or aspect_ratio > 10:
                continue

            # Check if it's likely an input field (hollow rectangle)
            roi = gray[y:y+h, x:x+w]
            mean_intensity = np.mean(roi)

            # Input fields are usually lighter (white/light gray)
            if mean_intensity < 200:
                continue

            # Extract any placeholder text
            text = self._extract_text_from_image(image[y:y+h, x:x+w])

            field_type = self._classify_input_field(text)

            element = ScreenElement(
                element_type='input',
                text=text.strip(),
                bbox=(x, y, w, h),
                center=(x + w // 2, y + h // 2),
                confidence=0.7,
                properties={
                    'field_type': field_type,
                    'mean_intensity': mean_intensity
                }
            )
            input_fields.append(element)

        return input_fields

    def _detect_links(self, image: np.ndarray) -> List[ScreenElement]:
        """Detect clickable text links"""
        # Use color detection for blue underlined text
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

        # Blue color range for links
        lower_blue = np.array([100, 150, 50])
        upper_blue = np.array([130, 255, 255])

        blue_mask = cv2.inRange(hsv, lower_blue, upper_blue)
        blue_text = cv2.bitwise_and(image, image, mask=blue_mask)

        # Extract text from blue regions
        text = self._extract_text_from_image(blue_text)

        links = []
        if text.strip():
            # Find bounding boxes for blue text regions
            contours, _ = cv2.findContours(blue_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            for contour in contours:
                x, y, w, h = cv2.boundingRect(contour)
                if w > 20 and h > 10:  # Filter small artifacts
                    element = ScreenElement(
                        element_type='link',
                        text=text.strip(),
                        bbox=(x, y, w, h),
                        center=(x + w // 2, y + h // 2),
                        confidence=0.6,
                        properties={'color': 'blue'}
                    )
                    links.append(element)

        return links

    def _detect_text_blocks(self, image: np.ndarray) -> List[ScreenElement]:
        """Detect text blocks and labels"""
        text = self._extract_text_from_image(image)

        # Use EasyOCR for better text detection
        try:
            result = self.ocr_reader.readtext(image)
            text_blocks = []

            for (bbox, text, confidence) in result:
                if confidence > 0.5 and len(text.strip()) > 2:
                    # Convert bbox from 4 points to rectangle
                    x1 = min([point[0] for point in bbox])
                    y1 = min([point[1] for point in bbox])
                    x2 = max([point[0] for point in bbox])
                    y2 = max([point[1] for point in bbox])

                    x = int(x1)
                    y = int(y1)
                    w = int(x2 - x1)
                    h = int(y2 - y1)

                    element = ScreenElement(
                        element_type='text',
                        text=text.strip(),
                        bbox=(x, y, w, h),
                        center=(x + w // 2, y + h // 2),
                        confidence=confidence,
                        properties={'ocr_confidence': confidence}
                    )
                    text_blocks.append(element)

            return text_blocks
        except:
            return []

    def _extract_text_from_image(self, image: np.ndarray) -> str:
        """Extract text using multiple OCR methods"""
        text_results = []

        # Method 1: EasyOCR
        try:
            result = self.ocr_reader.readtext(image)
            easyocr_text = ' '.join([text for (_, text, _) in result if len(text) > 1])
            text_results.append(easyocr_text)
        except:
            pass

        # Method 2: Tesseract OCR
        try:
            tesseract_text = pytesseract.image_to_string(
                image, config=self.pytesseract_config
            )
            text_results.append(tesseract_text)
        except:
            pass

        # Combine results
        combined_text = ' '.join(text_results).strip()
        return combined_text

    def _classify_input_field(self, text: str) -> str:
        """Classify the type of input field based on text/placeholder"""
        text_lower = text.lower()

        for field_type, patterns in self.field_patterns.items():
            for pattern in patterns:
                if pattern in text_lower:
                    return field_type

        return 'text'

    def find_elements_by_text(self, search_text: str, element_type: Optional[str] = None) -> List[ScreenElement]:
        """Find elements by text content"""
        screen_image = self.capture_screen()
        elements = self.detect_ui_elements(screen_image)

        matching_elements = []
        search_text_lower = search_text.lower()

        for element in elements:
            if element_type and element.element_type != element_type:
                continue

            # Fuzzy text matching
            if (search_text_lower in element.text.lower() or
                element.text.lower() in search_text_lower or
                self._fuzzy_match(search_text_lower, element.text.lower())):
                matching_elements.append(element)

        return matching_elements

    def find_form_fields(self) -> List[FormField]:
        """Find all form fields on screen"""
        screen_image = self.capture_screen()
        input_elements = self._detect_input_fields(screen_image)

        form_fields = []

        for element in input_elements:
            # Look for nearby labels
            label = self._find_field_label(element, screen_image)

            form_field = FormField(
                field_type=element.properties.get('field_type', 'text'),
                label=label,
                bbox=element.bbox,
                center=element.center,
                placeholder=element.text if element.text else None
            )

            form_fields.append(form_field)

        return form_fields

    def _find_field_label(self, field_element: ScreenElement, image: np.ndarray) -> str:
        """Find label for a form field"""
        x, y, w, h = field_element.bbox

        # Look above the field for labels
        label_region = image[max(0, y-50):y, x:x+w]
        label_text = self._extract_text_from_image(label_region)

        if label_text.strip():
            return label_text.strip()

        # Look to the left of the field
        if x > 100:
            left_region = image[y:y+h, max(0, x-100):x]
            left_text = self._extract_text_from_image(left_region)
            if left_text.strip():
                return left_text.strip()

        return "Unnamed Field"

    def click_element(self, element: ScreenElement) -> bool:
        """Click on a detected element"""
        try:
            x, y = element.center
            pyautogui.moveTo(x, y, duration=0.5)
            time.sleep(0.1)
            pyautogui.click()
            return True
        except:
            return False

    def click_text(self, text: str, element_type: Optional[str] = None) -> bool:
        """Click on element containing specified text"""
        elements = self.find_elements_by_text(text, element_type)
        if elements:
            return self.click_element(elements[0])
        return False

    def type_text(self, text: str, field: Optional[FormField] = None, clear_first: bool = True) -> bool:
        """Type text into a field or at current cursor position"""
        try:
            if field:
                x, y = field.center
                pyautogui.moveTo(x, y, duration=0.5)
                pyautogui.click()
                time.sleep(0.2)

                if clear_first:
                    pyautogui.hotkey('ctrl', 'a')
                    time.sleep(0.1)

            pyautogui.typewrite(text, interval=0.05)
            return True
        except:
            return False

    def fill_form(self, form_data: Dict[str, str]) -> Dict[str, bool]:
        """Fill a form with provided data"""
        results = {}
        form_fields = self.find_form_fields()

        for field in form_fields:
            field_name_lower = field.label.lower()

            # Find matching data
            for data_key, data_value in form_data.items():
                if (data_key.lower() in field_name_lower or
                    field_name_lower in data_key.lower() or
                    self._fuzzy_match(data_key.lower(), field_name_lower)):

                    success = self.type_text(data_value, field)
                    results[field.label] = success
                    break
            else:
                # No match found
                results[field.label] = False

        return results

    def _fuzzy_match(self, text1: str, text2: str, threshold: float = 0.8) -> bool:
        """Simple fuzzy string matching"""
        # Calculate Levenshtein distance ratio
        if len(text1) == 0 or len(text2) == 0:
            return False

        # Simple similarity check
        common_chars = set(text1) & set(text2)
        total_chars = set(text1) | set(text2)

        if not total_chars:
            return False

        similarity = len(common_chars) / len(total_chars)
        return similarity >= threshold

    def scroll_to_element(self, element: ScreenElement) -> bool:
        """Scroll screen to make element visible"""
        x, y, w, h = element.bbox
        center_y = y + h // 2

        # Check if element is already visible
        if 100 < center_y < self.screen_height - 100:
            return True

        # Scroll to bring element into view
        if center_y <= 100:
            # Scroll up
            pyautogui.scroll(200, x=x + w // 2, y=y)
        else:
            # Scroll down
            pyautogui.scroll(-200, x=x + w // 2, y=y)

        time.sleep(0.5)
        return True

    def wait_for_element(self, search_text: str, timeout: int = 10) -> Optional[ScreenElement]:
        """Wait for an element to appear"""
        start_time = time.time()

        while time.time() - start_time < timeout:
            elements = self.find_elements_by_text(search_text)
            if elements:
                return elements[0]

            time.sleep(0.5)

        return None

    def drag_and_drop(self, source_element: ScreenElement, target_element: ScreenElement) -> bool:
        """Perform drag and drop operation"""
        try:
            # Move to source
            pyautogui.moveTo(*source_element.center, duration=0.5)
            pyautogui.mouseDown()
            time.sleep(0.2)

            # Move to target
            pyautogui.moveTo(*target_element.center, duration=0.5)
            pyautogui.mouseUp()
            return True
        except:
            return False

    def take_screenshot(self, region: Optional[Tuple[int, int, int, int]] = None) -> str:
        """Take screenshot and save to temporary file"""
        timestamp = int(time.time())
        filename = f"screen_{timestamp}.png"

        if region:
            screenshot = pyautogui.screenshot(region=region)
        else:
            screenshot = pyautogui.screenshot()

        temp_path = os.path.join(tempfile.gettempdir(), filename)
        screenshot.save(temp_path)

        return temp_path

    def get_screen_summary(self) -> Dict[str, Any]:
        """Get summary of current screen state"""
        screen_image = self.capture_screen()
        elements = self.detect_ui_elements(screen_image)

        element_counts = {}
        for element in elements:
            element_counts[element.element_type] = element_counts.get(element.element_type, 0) + 1

        return {
            'screen_resolution': f"{self.screen_width}x{self.screen_height}",
            'total_elements': len(elements),
            'element_types': element_counts,
            'timestamp': time.time()
        }