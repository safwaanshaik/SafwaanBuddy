#!/usr/bin/env python3
"""
Ultra-Natural Voice System with Hindi, Urdu, Hyderabadi & Emotional English
Human-like voices with all natural effects: ahhhannn, hmmmm, ohhh, etc.
"""

import os
import sys
import time
import random
import json
import threading
import subprocess
from typing import Dict, List, Optional, Tuple, Any
from pathlib import Path
from dataclasses import dataclass
from enum import Enum
import pyttsx3
import requests

try:
    import edge_tts
    EDGE_TTS_AVAILABLE = True
except ImportError:
    EDGE_TTS_AVAILABLE = False
    print("⚠️ Edge TTS not available, installing...")

try:
    import gTTS
    from pydub import AudioSegment
    from pydub.playback import play
    GTTS_AVAILABLE = True
except ImportError:
    GTTS_AVAILABLE = False
    print("⚠️ Google TTS not available, will install...")

class VoiceStyle(Enum):
    """Voice styles and personalities"""
    HINDI_FORMAL = "hindi_formal"
    HINDI_FRIENDLY = "hindi_friendly"
    URDU_ELEGANT = "urdu_elegant"
    URDU_FRIENDLY = "urdu_friendly"
    HYDERABADI_CASUAL = "hyderabadi_casual"
    HYDERABADI_BUSINESS = "hyderabadi_business"
    ENGLISH_EMOTIONAL = "english_emotional"
    ENGLISH_FUN = "english_fun"
    ENGLISH_PROFESSIONAL = "english_professional"

@dataclass
class VoicePersonality:
    """Voice personality configuration"""
    name: str
    language: str
    accent: str
    gender: str
    age_group: str
    speaking_rate: float
    pitch_variation: float
    emotionality: float
    cultural_markers: List[str]
    filler_words: List[str]
    interjections: List[str]

class UltraNaturalVoiceSystem:
    """Ultra-natural voice system with regional and emotional capabilities"""

    def __init__(self):
        self.voices_configured = False
        self.current_voice = None
        self.tts_engines = {}
        self.voice_personalities = self._create_voice_personalities()
        self.emotion_cache = {}
        self.audio_cache = {}

        # Initialize TTS engines
        self._initialize_tts_engines()

        # Cultural and linguistic patterns
        self.hyderabadi_patterns = self._load_hyderabadi_patterns()
        self.hindi_patterns = self._load_hindi_patterns()
        self.urdu_patterns = self._load_urdu_patterns()
        self.emotional_effects = self._load_emotional_effects()

        # Voice modulation
        self.current_emotion = "neutral"
        self.speaking_style = "conversational"

        print("🎙️ Ultra-Natural Voice System Initialized")
        print(f"🌍 Available Languages: Hindi, Urdu, Hyderabadi, English")
        print(f"💫 Emotional Effects: {len(self.emotional_effects)} loaded")

    def _create_voice_personalities(self) -> Dict[str, VoicePersonality]:
        """Create diverse voice personalities"""
        personalities = {
            VoiceStyle.HINDI_FORMAL.value: VoicePersonality(
                name="Priya Sharma",
                language="hi-IN",
                accent="standard_hindi",
                gender="female",
                age_group="adult",
                speaking_rate=0.9,
                pitch_variation=0.7,
                emotionality=0.6,
                cultural_markers=["ji", "sahab", "mahoday"],
                filler_words=["matlab", "woh toh", "aisa hi"],
                interjections=["achha", "haan", "theek hai"]
            ),

            VoiceStyle.HINDI_FRIENDLY.value: VoicePersonality(
                name="Rohit Kumar",
                language="hi-IN",
                accent="north_indian",
                gender="male",
                age_group="young_adult",
                speaking_rate=1.0,
                pitch_variation=0.8,
                emotionality=0.8,
                cultural_markers=["bhai", "yaar", "arre"],
                filler_words=["woh toh", "bas", "matlab"],
                interjections=["arey", "wah", "bilkul"]
            ),

            VoiceStyle.URDU_ELEGANT.value: VoicePersonality(
                name="Fatima Khan",
                language="ur-PK",
                accent="karachi",
                gender="female",
                age_group="adult",
                speaking_rate=0.85,
                pitch_variation=0.6,
                emotionality=0.7,
                cultural_markers=["ji", "sahiba", "khudaya"],
                filler_words=["yaani", "woh toh", "aise hi"],
                interjections=["achha", "haan ji", "theek hai"]
            ),

            VoiceStyle.URDU_FRIENDLY.value: VoicePersonality(
                name="Ahmed Raza",
                language="ur-PK",
                accent="lahori",
                gender="male",
                age_group="young_adult",
                speaking_rate=1.0,
                pitch_variation=0.7,
                emotionality=0.8,
                cultural_markers=["bhai", "yaar", "janab"],
                filler_words=["woh toh", "bas", "yaani"],
                interjections=["arey", "wah", "bilkul"]
            ),

            VoiceStyle.HYDERABADI_CASUAL.value: VoicePersonality(
                name="Salman Bhai",
                language="hi-IN",
                accent="hyderabadi",
                gender="male",
                age_group="adult",
                speaking_rate=1.1,
                pitch_variation=0.9,
                emotionality=0.9,
                cultural_markers=["bhai", "nakko", "poy", "baigan"],
                filler_words=["woh toh", "bas", "matlab", "key"],
                interjections=["arey", "wah", "baigan", "pilla"]
            ),

            VoiceStyle.HYDERABADI_BUSINESS.value: VoicePersonality(
                name="Ayesha Begum",
                language="hi-IN",
                accent="hyderabadi_polite",
                gender="female",
                age_group="adult",
                speaking_rate=0.95,
                pitch_variation=0.7,
                emotionality=0.7,
                cultural_markers=["ji", "sahib", "mir"],
                filler_words=["woh toh", "aise hi", "key"],
                interjections=["achha", "theek hai", "haan ji"]
            ),

            VoiceStyle.ENGLISH_EMOTIONAL.value: VoicePersonality(
                name="Emma Watson",
                language="en-US",
                accent="american",
                gender="female",
                age_group="young_adult",
                speaking_rate=0.9,
                pitch_variation=0.8,
                emotionality=0.9,
                cultural_markers=["honey", "sweetie", "dear"],
                filler_words=["like", "you know", "I mean"],
                interjections=["omg", "wow", "ahhh", "hmmm"]
            ),

            VoiceStyle.ENGLISH_FUN.value: VoicePersonality(
                name="Jack Miller",
                language="en-GB",
                accent="british_casual",
                gender="male",
                age_group="young_adult",
                speaking_rate=1.0,
                pitch_variation=0.8,
                emotionality=0.9,
                cultural_markers=["mate", "bloke", "chap"],
                filler_words=["like", "sort of", "you know"],
                interjections=["brilliant", "awesome", "ace", "ohhh"]
            )
        }

        return personalities

    def _initialize_tts_engines(self):
        """Initialize multiple TTS engines"""
        print("🔧 Initializing TTS engines...")

        # 1. pyttsx3 (default)
        try:
            self.tts_engines['pyttsx3'] = pyttsx3.init()
            print("✅ pyttsx3 initialized")
        except Exception as e:
            print(f"❌ pyttsx3 failed: {e}")

        # 2. Edge TTS (if available)
        if EDGE_TTS_AVAILABLE:
            try:
                self.tts_engines['edge_tts'] = edge_tts
                print("✅ Edge TTS initialized")
            except Exception as e:
                print(f"❌ Edge TTS failed: {e}")

        # 3. Google TTS (if available)
        if GTTS_AVAILABLE:
            try:
                self.tts_engines['gtts'] = gTTS
                print("✅ Google TTS initialized")
            except Exception as e:
                print(f"❌ Google TTS failed: {e}")

    def _load_hyderabadi_patterns(self) -> Dict[str, Any]:
        """Load Hyderabadi Urdu-Hindi mix patterns"""
        return {
            "greetings": ["Assalamualaikum bhai!", "Kya haal hai?", "Aayiye na!"],
            "farewells": ["Allah Hafiz", "Phir milenge", "Take care bhai"],
            "agreements": ["Haan bilkul!", "Theek hai!", "Pakka bhai!"],
            "disagreements": ["Nakko bhai!", "Nahi re!", "Woh baat nahi!"],
            "exclamations": ["Arrey baigan!", "Wah pilla!", "Masallah!"],
            "fillers": ["woh toh", "key", "matlab", "aise hi"],
            "questions": ["Key baat hai?", "Kya keh rahe ho?", "Sahi hai?"],
            "affection": ["Mere dost", "Jaanaeman", "Piyare bhai"],
            "food_related": ["Biryani baigan", "Haleem pilla", "Chai lenge?"],
            "time_expressions": ["Abhi", "Der se", "Jaldi"]
        }

    def _load_hindi_patterns(self) -> Dict[str, Any]:
        """Load Hindi linguistic patterns"""
        return {
            "greetings": ["Namaste!", "Pranam!", "Aap kaise hain?"],
            "respect": ["ji", "sahab/madam", "mahoday/mahod"],
            "fillers": ["matlab", "woh toh", "aise hi", "dusra"],
            "emotions": ["Waah!", "Kya baat!", "Lajawab!", "Zabardast!"],
            "family": ["papa/mummy", "bhai/behen", "uncle/aunty"],
            "food": ["khana", "chai-pani", "nashta", "dinner"],
            "time": ["subah", "dopahar", "shaam", "raat"]
        }

    def _load_urdu_patterns(self) -> Dict[str, Any]:
        """Load Urdu linguistic patterns"""
        return {
            "greetings": ["Assalamualaikum!", "Adaab!", "Kya haal hai?"],
            "respect": ["ji", "sahib/sahiba", "janab"],
            "poetry": ["sher", "shayari", "ghazal", "nazm"],
            "literature": ["kitaab", "adab", "fun", "tanqeed"],
            "culture": ["tehzeeb", "tamaddun", "riwayat"],
            "emotions": ["Dil khush", "Roshan", "Ghamgeen", "Mushtamil"],
            "exclamations": ["SubhanAllah!", "Mashallah!", "Aajub!"]
        }

    def _load_emotional_effects(self) -> Dict[str, List[str]]:
        """Load emotional vocal effects"""
        return {
            "thinking": ["hmmm...", "let me think...", "socho toh...", "woh..."],
            "understanding": ["ahhannn", "haan ji", "samjh gaya", "theek hai"],
            "surprise": ["OH MY GOD!", "Arey baigan!", "Wah!", "Masallah!"],
            "confusion": ["kya?", "matlab?", "aaisa?", "keh rahe ho?"],
            "agreement": ["haan!", "bilkul!", "theek hai!", "pakkah!"],
            "excitement": ["YAYYYY!", "BRILLIANT!", "WAH!", "ZABARDAST!"],
            "concern": ["ohh no...", "kya hua?", "theek hai na?", "pareshan"],
            "affection": ["awwwee", "jaaneman", "piyare", "mere dost"],
            "frustration": ["arrey!", "yaar!", "not again!", "paleeese!"],
            "delight": ["ahhhannn", "perfect!", "lovely!", "beautiful!"],
            "curiosity": ["hmmm?", "interesting!", "achha?", "batao na!"],
            "realization": ["OH! Achha!", "samjh gaya!", "got it!", "haan!"],
            "appreciation": ["beautiful!", "amazing!", "superb!", "lajawab!"],
            "empathy": ["ohh dear...", "i understand...", "i feel you...", "pareshan ho"]
        }

    def install_voice_packages(self) -> bool:
        """Install all required voice packages"""
        print("🎙️ Installing Natural Voice Packages...")

        packages = [
            "edge-tts>=6.1.0",
            "gTTS>=2.3.0",
            "pydub>=0.25.0",
            "audiosegment>=0.0.0",
            "pyaudio>=0.2.11"
        ]

        success_count = 0

        for package in packages:
            try:
                print(f"📦 Installing {package}...")
                result = subprocess.run([
                    sys.executable, "-m", "pip", "install", package
                ], capture_output=True, text=True)

                if result.returncode == 0:
                    print(f"✅ {package} installed successfully")
                    success_count += 1
                else:
                    print(f"⚠️ {package} installation issue: {result.stderr}")

            except Exception as e:
                print(f"❌ Failed to install {package}: {e}")

        print(f"🎉 Voice packages installation complete: {success_count}/{len(packages)}")
        return success_count >= 3

    def set_voice_personality(self, style: VoiceStyle) -> bool:
        """Set the voice personality"""
        try:
            personality = self.voice_personalities.get(style.value)
            if not personality:
                print(f"❌ Voice personality not found: {style}")
                return False

            self.current_voice = personality
            self._configure_tts_engine()

            print(f"🎭 Voice personality set: {personality.name} ({style.value})")
            return True

        except Exception as e:
            print(f"❌ Failed to set voice personality: {e}")
            return False

    def _configure_tts_engine(self):
        """Configure TTS engine with current voice settings"""
        if 'pyttsx3' in self.tts_engines and self.current_voice:
            engine = self.tts_engines['pyttsx3']

            # Set voice rate
            engine.setProperty('rate', int(200 * self.current_voice.speaking_rate))

            # Try to find appropriate voice
            voices = engine.getProperty('voices')
            for voice in voices:
                if (self.current_voice.language in voice.languages and
                    self.current_voice.gender.lower() in voice.gender.lower()):
                    engine.setProperty('voice', voice.id)
                    break

    def add_natural_effects(self, text: str, emotion: str = "neutral") -> str:
        """Add natural human effects to text"""
        if not text.strip():
            return text

        enhanced_text = text

        # Add emotional interjections
        if emotion in self.emotional_effects:
            effects = self.emotional_effects[emotion]
            if effects and random.random() < 0.6:  # 60% chance to add effect
                effect = random.choice(effects)
                # Add at beginning or end
                if random.random() < 0.5:
                    enhanced_text = f"{effect} {enhanced_text}"
                else:
                    enhanced_text = f"{enhanced_text} {effect}"

        # Add personality-specific fillers
        if self.current_voice and self.current_voice.filler_words:
            if random.random() < 0.3:  # 30% chance to add filler
                filler = random.choice(self.current_voice.filler_words)
                # Insert in middle of text
                words = enhanced_text.split()
                if len(words) > 3:
                    insert_pos = len(words) // 2
                    words.insert(insert_pos, filler)
                    enhanced_text = " ".join(words)

        # Add natural pauses with commas
        enhanced_text = enhanced_text.replace(" and ", ", and ")
        enhanced_text = enhanced_text.replace(" but ", ", but ")

        return enhanced_text

    def translate_to_regional_style(self, text: str, personality: VoicePersonality) -> str:
        """Translate text to regional speaking style"""
        if not text.strip():
            return text

        translated = text

        # Add regional markers and cultural elements
        if personality.accent == "hyderabadi":
            # Add Hyderabadi mix
            translated = self._add_hyderabadi_style(translated)
        elif personality.language.startswith("hi"):
            # Add Hindi style
            translated = self._add_hindi_style(translated)
        elif personality.language.startswith("ur"):
            # Add Urdu style
            translated = self._add_urdu_style(translated)

        return translated

    def _add_hyderabadi_style(self, text: str) -> str:
        """Add Hyderabadi Urdu-Hindi mix"""
        hyderabadi_replacements = {
            "hello": "Assalamualaikum bhai!",
            "how are you": "kya haal hai?",
            "yes": "haan pakka",
            "no": "nakko bhai",
            "thank you": "shukriya",
            "my friend": "mere dost",
            "please": "meherbani",
            "what": "key",
            "why": "keyo",
            "where": "kidhar",
            "come": "ao",
            "go": "jao",
            "eat": "khao",
            "drink": "piyo",
            "good": "badiya",
            "bad": "kharab",
            "ok": "theek hai",
            "bye": "Allah Hafiz"
        }

        translated = text.lower()
        for eng, hyd in hyderabadi_replacements.items():
            translated = translated.replace(eng, hyd)

        # Add characteristic Hyderabadi endings
        if random.random() < 0.4:
            if not translated.endswith(("bhai", "ji", "na", "re")):
                endings = [" bhai", " na", " ji", " re", " pilla"]
                translated += random.choice(endings)

        return translated

    def _add_hindi_style(self, text: str) -> str:
        """Add Hindi speaking style"""
        hindi_replacements = {
            "hello": "Namaste!",
            "how are you": "Aap kaise hain?",
            "yes": "haan ji",
            "no": "nahi",
            "thank you": "dhanyawad",
            "my friend": "mere dost",
            "please": "kripya",
            "good": "achha",
            "bad": "bura",
            "ok": "theek hai",
            "bye": "Namaste"
        }

        translated = text.lower()
        for eng, hindi in hindi_replacements.items():
            translated = translated.replace(eng, hindi)

        return translated

    def _add_urdu_style(self, text: str) -> str:
        """Add Urdu speaking style"""
        urdu_replacements = {
            "hello": "Assalamualaikum!",
            "how are you": "Kya haal hai?",
            "yes": "han ji",
            "no": "nahi",
            "thank you": "shukriya",
            "my friend": "mere dost",
            "please": "meherbani farma",
            "good": "achha",
            "bad": "bura",
            "ok": "theek hai",
            "beautiful": "khoobsurat",
            "excellent": "behtareen"
        }

        translated = text.lower()
        for eng, urdu in urdu_replacements.items():
            translated = translated.replace(eng, urdu)

        return translated

    def speak_with_emotion(self, text: str, emotion: str = "neutral",
                          style: Optional[VoiceStyle] = None) -> bool:
        """Speak text with emotion and style"""
        try:
            # Set voice style if provided
            if style:
                self.set_voice_personality(style)

            # Add natural effects
            enhanced_text = self.add_natural_effects(text, emotion)

            # Translate to regional style
            if self.current_voice:
                enhanced_text = self.translate_to_regional_style(enhanced_text, self.current_voice)

            print(f"🎙️ Speaking: {enhanced_text}")

            # Try different TTS engines in order of preference
            tts_engines_order = ['edge_tts', 'gtts', 'pyttsx3']

            for engine_name in tts_engines_order:
                if engine_name in self.tts_engines:
                    try:
                        success = self._speak_with_engine(enhanced_text, engine_name, emotion)
                        if success:
                            return True
                    except Exception as e:
                        print(f"⚠️ {engine_name} failed: {e}")
                        continue

            print("❌ All TTS engines failed")
            return False

        except Exception as e:
            print(f"❌ Speech failed: {e}")
            return False

    def _speak_with_engine(self, text: str, engine_name: str, emotion: str) -> bool:
        """Speak with specific TTS engine"""
        if engine_name == 'edge_tts':
            return self._speak_with_edge_tts(text, emotion)
        elif engine_name == 'gtts':
            return self._speak_with_gtts(text, emotion)
        elif engine_name == 'pyttsx3':
            return self._speak_with_pyttsx3(text, emotion)
        else:
            return False

    def _speak_with_edge_tts(self, text: str, emotion: str) -> bool:
        """Speak using Edge TTS with natural voices"""
        try:
            if not self.current_voice:
                return False

            # Select appropriate voice
            voice_map = {
                ("hi-IN", "female"): "hi-IN-SwaraNeural",
                ("hi-IN", "male"): "hi-IN-MadhurNeural",
                ("ur-PK", "female"): "ur-PK-UzmaNeural",
                ("ur-PK", "male"): "ur-PK-GulNeural",
                ("en-US", "female"): "en-US-AriaNeural",
                ("en-US", "male"): "en-US-GuyNeural",
                ("en-GB", "female"): "en-GB-SoniaNeural",
                ("en-GB", "male"): "en-GB-RyanNeural"
            }

            voice_key = (self.current_voice.language, self.current_voice.gender)
            voice_name = voice_map.get(voice_key, "en-US-AriaNeural")

            # Adjust speaking rate for emotion
            rate = f"+{int((self.current_voice.speaking_rate - 1) * 50)}%" if self.current_voice.speaking_rate != 1 else "+0%"

            # Create communication
            communicate = edge_tts.Communicate(text, voice_name)

            # Add prosody for emotion
            if emotion != "neutral":
                emotion_styles = {
                    "excited": "style='cheerful'",
                    "sad": "style='sad'",
                    "angry": "style='angry'",
                    "gentle": "style='gentle'",
                    "calm": "style='calm'"
                }
                if emotion in emotion_styles:
                    communicate = edge_tts.Communicate(text, voice_name, prosody=emotion_styles[emotion])

            # Save and play
            temp_audio = "temp_speech.mp3"
            communicate.save(temp_audio)

            # Play the audio
            import pygame
            pygame.mixer.init()
            pygame.mixer.music.load(temp_audio)
            pygame.mixer.music.play()

            # Wait for playback to finish
            while pygame.mixer.music.get_busy():
                time.sleep(0.1)

            # Clean up
            os.remove(temp_audio)
            return True

        except Exception as e:
            print(f"Edge TTS error: {e}")
            return False

    def _speak_with_gtts(self, text: str, emotion: str) -> bool:
        """Speak using Google TTS"""
        try:
            if not self.current_voice:
                return False

            # Language mapping
            lang_map = {
                "hi-IN": "hi",
                "ur-PK": "ur",
                "en-US": "en",
                "en-GB": "en"
            }

            lang = lang_map.get(self.current_voice.language, "en")

            # Create TTS
            tts = gTTS(text=text, lang=lang, slow=False)
            temp_audio = "temp_gtts.mp3"
            tts.save(temp_audio)

            # Speed adjustment for emotion
            audio = AudioSegment.from_mp3(temp_audio)

            if emotion == "excited":
                audio = audio.speedup(playback_speed=1.1)
            elif emotion == "calm":
                audio = audio.speedup(playback_speed=0.9)

            # Export and play
            audio.export(temp_audio, format="mp3")
            play(audio)

            # Clean up
            os.remove(temp_audio)
            return True

        except Exception as e:
            print(f"Google TTS error: {e}")
            return False

    def _speak_with_pyttsx3(self, text: str, emotion: str) -> bool:
        """Speak using pyttsx3"""
        try:
            engine = self.tts_engines['pyttsx3']

            # Adjust voice properties for emotion
            if emotion == "excited":
                engine.setProperty('rate', 250)
                engine.setProperty('volume', 1.0)
            elif emotion == "sad":
                engine.setProperty('rate', 120)
                engine.setProperty('volume', 0.7)
            elif emotion == "angry":
                engine.setProperty('rate', 200)
                engine.setProperty('volume', 0.9)
            else:
                engine.setProperty('rate', int(200 * self.current_voice.speaking_rate))
                engine.setProperty('volume', 0.9)

            engine.say(text)
            engine.runAndWait()
            return True

        except Exception as e:
            print(f"pyttsx3 error: {e}")
            return False

    def create_conversation(self, messages: List[Tuple[str, str]],
                           style: VoiceStyle = VoiceStyle.HYDERABADI_CASUAL) -> bool:
        """Create a natural conversation with multiple messages"""
        try:
            self.set_voice_personality(style)

            for emotion, text in messages:
                time.sleep(0.5)  # Natural pause
                self.speak_with_emotion(text, emotion, style)

            return True

        except Exception as e:
            print(f"Conversation failed: {e}")
            return False

    def test_all_voices(self) -> Dict[str, bool]:
        """Test all voice personalities"""
        test_messages = {
            VoiceStyle.HINDI_FORMAL: ("neutral", "Namaste! Main Priya Sharma bol rahi hun."),
            VoiceStyle.HINDI_FRIENDLY: ("excited", "Arey bhai! Kya baat hai!"),
            VoiceStyle.URDU_ELEGANT: ("calm", "Assalamualaikum! Main Fatima hun."),
            VoiceStyle.URDU_FRIENDLY: ("friendly", "Yaar! Kya scene hai?"),
            VoiceStyle.HYDERABADI_CASUAL: ("excited", "Arrey baigan! Kya haal hai pilla!"),
            VoiceStyle.HYDERABADI_BUSINESS: ("professional", "Namaste ji! Kya kaam hai?"),
            VoiceStyle.ENGLISH_EMOTIONAL: ("excited", "Oh my god! That's amazing!"),
            VoiceStyle.ENGLISH_FUN: ("fun", "Brilliant mate! Absolutely fantastic!")
        }

        results = {}

        for style, (emotion, text) in test_messages.items():
            print(f"\n🎭 Testing {style.value}:")
            try:
                success = self.speak_with_emotion(text, emotion, style)
                results[style.value] = success
                print(f"{'✅' if success else '❌'} {style.value}: {'Success' if success else 'Failed'}")
                time.sleep(2)  # Pause between tests
            except Exception as e:
                results[style.value] = False
                print(f"❌ {style.value}: Failed - {e}")

        return results

    def get_available_voices(self) -> List[Dict[str, Any]]:
        """Get list of available voice personalities"""
        voices = []

        for style, personality in self.voice_personalities.items():
            voices.append({
                "style": style,
                "name": personality.name,
                "language": personality.language,
                "gender": personality.gender,
                "accent": personality.accent,
                "description": f"{personality.name} - {personality.accent} {personality.gender}"
            })

        return voices