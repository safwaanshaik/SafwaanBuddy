#!/usr/bin/env python3
"""
Advanced Web Automation System
Web search, auto-download, installation, and online capabilities
"""

import requests
import os
import re
import time
import tempfile
import subprocess
import platform
from typing import Dict, List, Optional, Tuple, Any
from urllib.parse import urlparse, quote
from pathlib import Path
from bs4 import BeautifulSoup
import selenium
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import wget
import zipfile
import tarfile

class AdvancedWebAutomation:
    """Advanced web automation with search, download, and installation capabilities"""

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })

        self.download_dir = Path(tempfile.gettempdir()) / "safwaan_downloads"
        self.download_dir.mkdir(exist_ok=True)

        self.driver = None
        self.init_selenium_driver()

        # Trusted download sources
        self.trusted_domains = [
            'github.com', 'sourceforge.net', 'filehippo.com',
            'microsoft.com', 'google.com', 'adobe.com',
            'python.org', 'nodejs.org', 'java.com'
        ]

    def init_selenium_driver(self):
        """Initialize Selenium WebDriver"""
        try:
            options = Options()
            options.add_argument('--headless')
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            options.add_argument('--disable-gpu')
            options.add_argument('--window-size=1920,1080')

            # Disable notifications
            options.add_argument('--disable-notifications')
            options.add_argument('--disable-popup-blocking')

            self.driver = webdriver.Chrome(options=options)
            print("✅ Selenium WebDriver initialized successfully")
        except Exception as e:
            print(f"⚠️ Selenium WebDriver not available: {e}")
            self.driver = None

    def search_web(self, query: str, num_results: int = 5) -> List[Dict[str, Any]]:
        """Search web for information"""
        search_results = []

        # Method 1: Try DuckDuckGo (no API key required)
        try:
            duckduckgo_url = f"https://duckduckgo.com/html/?q={quote(query)}"
            response = self.session.get(duckduckgo_url, timeout=10)
            soup = BeautifulSoup(response.content, 'html.parser')

            results = soup.find_all('div', class_='result')
            for result in results[:num_results]:
                title_elem = result.find('a', class_='result__a')
                snippet_elem = result.find('a', class_='result__snippet')

                if title_elem:
                    title = title_elem.get_text(strip=True)
                    link = title_elem.get('href')
                    snippet = snippet_elem.get_text(strip=True) if snippet_elem else ""

                    search_results.append({
                        'title': title,
                        'link': link,
                        'snippet': snippet,
                        'source': 'DuckDuckGo'
                    })

        except Exception as e:
            print(f"DuckDuckGo search failed: {e}")

        # Method 2: Try Google (limited)
        if len(search_results) < num_results:
            try:
                google_url = f"https://www.google.com/search?q={quote(query)}"
                response = self.session.get(google_url, timeout=10)
                soup = BeautifulSoup(response.content, 'html.parser')

                results = soup.find_all('div', class_='g')
                for result in results[:num_results - len(search_results)]:
                    title_elem = result.find('h3')
                    link_elem = result.find('a')
                    snippet_elem = result.find('span', class_='aCOpRe')

                    if title_elem and link_elem:
                        title = title_elem.get_text(strip=True)
                        link = link_elem.get('href')
                        snippet = snippet_elem.get_text(strip=True) if snippet_elem else ""

                        if link.startswith('/url?q='):
                            link = link.split('/url?q=')[1].split('&')[0]

                        search_results.append({
                            'title': title,
                            'link': link,
                            'snippet': snippet,
                            'source': 'Google'
                        })

            except Exception as e:
                print(f"Google search failed: {e}")

        return search_results

    def find_download_links(self, query: str, file_types: List[str] = None) -> List[Dict[str, Any]]:
        """Find download links for software or files"""
        if file_types is None:
            file_types = ['exe', 'msi', 'dmg', 'pkg', 'deb', 'rpm', 'zip', 'tar.gz']

        search_query = f"{query} download"
        search_results = self.search_web(search_query, num_results=10)

        download_links = []
        for result in search_results:
            link = result['link']
            title = result['title']

            # Check if link contains download indicators
            download_indicators = [
                'download', 'install', 'setup', '.exe', '.msi', '.dmg',
                '.pkg', '.deb', '.rpm', '.zip', '.tar.gz', 'get', 'free'
            ]

            if any(indicator in link.lower() or indicator in title.lower() for indicator in download_indicators):
                # Check if domain is trusted
                domain = urlparse(link).netloc
                is_trusted = any(trusted in domain for trusted in self.trusted_domains)

                download_links.append({
                    'title': title,
                    'link': link,
                    'domain': domain,
                    'is_trusted': is_trusted,
                    'file_types': [ft for ft in file_types if ft in link.lower() or ft in title.lower()]
                })

        return download_links

    def download_file(self, url: str, filename: Optional[str] = None) -> Optional[str]:
        """Download file from URL"""
        try:
            if not filename:
                # Extract filename from URL
                parsed_url = urlparse(url)
                filename = os.path.basename(parsed_url.path)
                if not filename:
                    filename = f"download_{int(time.time())}"

            # Clean filename
            filename = re.sub(r'[^\w\-_\.]', '_', filename)
            filepath = self.download_dir / filename

            print(f"📥 Downloading: {url}")
            print(f"📁 Saving to: {filepath}")

            # Use wget for large files
            if url.endswith(('.zip', '.tar.gz', '.exe', '.msi', '.dmg')):
                wget.download(url, str(filepath))
            else:
                # Use requests for smaller files
                response = self.session.get(url, stream=True, timeout=30)
                response.raise_for_status()

                with open(filepath, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)

            print(f"✅ Download completed: {filepath}")
            return str(filepath)

        except Exception as e:
            print(f"❌ Download failed: {e}")
            return None

    def install_software(self, file_path: str, silent: bool = True) -> bool:
        """Install downloaded software"""
        try:
            file_path = Path(file_path)
            platform_name = platform.system().lower()

            if platform_name == 'windows':
                return self._install_windows(file_path, silent)
            elif platform_name == 'darwin':
                return self._install_macos(file_path, silent)
            elif platform_name == 'linux':
                return self._install_linux(file_path, silent)
            else:
                print(f"❌ Unsupported platform: {platform_name}")
                return False

        except Exception as e:
            print(f"❌ Installation failed: {e}")
            return False

    def _install_windows(self, file_path: Path, silent: bool) -> bool:
        """Install software on Windows"""
        try:
            if file_path.suffix.lower() == '.exe':
                cmd = [str(file_path)]
                if silent:
                    cmd.append('/S')  # Silent installation

                subprocess.run(cmd, check=True)
                return True

            elif file_path.suffix.lower() == '.msi':
                cmd = ['msiexec', '/i', str(file_path)]
                if silent:
                    cmd.extend(['/quiet', '/norestart'])

                subprocess.run(cmd, check=True)
                return True

            else:
                print(f"❌ Unsupported Windows installer format: {file_path.suffix}")
                return False

        except subprocess.CalledProcessError as e:
            print(f"❌ Windows installation failed: {e}")
            return False

    def _install_macos(self, file_path: Path, silent: bool) -> bool:
        """Install software on macOS"""
        try:
            if file_path.suffix.lower() == '.dmg':
                # Mount DMG
                subprocess.run(['hdiutil', 'attach', str(file_path)], check=True)

                # Find and run installer
                # Note: This is simplified - actual implementation would need to mount and find pkg files
                return True

            elif file_path.suffix.lower() == '.pkg':
                cmd = ['sudo', 'installer', '-pkg', str(file_path), '-target', '/']
                subprocess.run(cmd, check=True)
                return True

            else:
                print(f"❌ Unsupported macOS installer format: {file_path.suffix}")
                return False

        except subprocess.CalledProcessError as e:
            print(f"❌ macOS installation failed: {e}")
            return False

    def _install_linux(self, file_path: Path, silent: bool) -> bool:
        """Install software on Linux"""
        try:
            if file_path.suffix.lower() in ['.deb']:
                cmd = ['sudo', 'dpkg', '-i', str(file_path)]
                subprocess.run(cmd, check=True)
                return True

            elif file_path.suffix.lower() in ['.rpm']:
                cmd = ['sudo', 'rpm', '-i', str(file_path)]
                subprocess.run(cmd, check=True)
                return True

            elif file_path.suffix.lower() in ['.tar.gz', '.tar.bz2']:
                # Extract and install
                with tarfile.open(file_path, 'r:*') as tar:
                    tar.extractall(self.download_dir)

                # Look for install script
                for extracted_file in self.download_dir.rglob('install*'):
                    if extracted_file.is_file() and os.access(extracted_file, os.X_OK):
                        subprocess.run([str(extracted_file)], check=True)
                        return True

            else:
                print(f"❌ Unsupported Linux installer format: {file_path.suffix}")
                return False

        except subprocess.CalledProcessError as e:
            print(f"❌ Linux installation failed: {e}")
            return False

    def search_and_install(self, software_name: str, auto_install: bool = False) -> Dict[str, Any]:
        """Search for software and optionally install it"""
        print(f"🔍 Searching for: {software_name}")

        # Find download links
        download_links = self.find_download_links(software_name)

        if not download_links:
            return {
                'success': False,
                'message': f"No download links found for {software_name}"
            }

        # Filter trusted sources first
        trusted_links = [link for link in download_links if link['is_trusted']]
        if trusted_links:
            download_links = trusted_links

        best_link = download_links[0]
        print(f"🎯 Found: {best_link['title']}")
        print(f"📎 Link: {best_link['link']}")
        print(f"🏷️  Domain: {best_link['domain']} {'✅ Trusted' if best_link['is_trusted'] else '⚠️ Unknown'}")

        if not auto_install:
            return {
                'success': True,
                'message': f"Found download link for {software_name}",
                'download_link': best_link,
                'auto_install': False
            }

        # Download and install
        downloaded_file = self.download_file(best_link['link'])
        if not downloaded_file:
            return {
                'success': False,
                'message': f"Failed to download {software_name}"
            }

        if auto_install:
            install_success = self.install_software(downloaded_file)
            return {
                'success': install_success,
                'message': f"{'✅' if install_success else '❌'} {software_name} {'installed' if install_success else 'installation failed'}",
                'downloaded_file': downloaded_file,
                'auto_install': True
            }

        return {
            'success': True,
            'message': f"Downloaded {software_name} to {downloaded_file}",
            'downloaded_file': downloaded_file,
            'auto_install': False
        }

    def extract_archive(self, archive_path: str, extract_to: Optional[str] = None) -> Optional[str]:
        """Extract archive file"""
        try:
            archive_path = Path(archive_path)

            if extract_to is None:
                extract_to = archive_path.parent / archive_path.stem

            extract_path = Path(extract_to)
            extract_path.mkdir(exist_ok=True)

            print(f"📦 Extracting {archive_path.name} to {extract_path}")

            if archive_path.suffix.lower() == '.zip':
                with zipfile.ZipFile(archive_path, 'r') as zip_ref:
                    zip_ref.extractall(extract_path)

            elif archive_path.suffix.lower() in ['.tar', '.gz', '.bz2', '.xz']:
                with tarfile.open(archive_path, 'r:*') as tar_ref:
                    tar_ref.extractall(extract_path)

            else:
                print(f"❌ Unsupported archive format: {archive_path.suffix}")
                return None

            print(f"✅ Extracted successfully to: {extract_path}")
            return str(extract_path)

        except Exception as e:
            print(f"❌ Extraction failed: {e}")
            return None

    def get_webpage_content(self, url: str) -> Optional[str]:
        """Get text content from webpage"""
        try:
            response = self.session.get(url, timeout=15)
            response.raise_for_status()

            soup = BeautifulSoup(response.content, 'html.parser')

            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.decompose()

            text = soup.get_text()

            # Clean up text
            lines = (line.strip() for line in text.splitlines())
            chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
            text = ' '.join(chunk for chunk in chunks if chunk)

            return text[:5000]  # Limit to first 5000 characters

        except Exception as e:
            print(f"❌ Failed to get webpage content: {e}")
            return None

    def monitor_download_progress(self, url: str) -> Dict[str, Any]:
        """Monitor download progress"""
        # This would require implementing progress tracking
        # For now, return basic info
        return {
            'url': url,
            'status': 'downloading',
            'progress': 0
        }

    def search_programming_tutorials(self, topic: str) -> List[Dict[str, Any]]:
        """Search for programming tutorials and resources"""
        search_queries = [
            f"{topic} tutorial",
            f"{topic} documentation",
            f"{topic} examples",
            f"how to {topic}"
        ]

        all_results = []
        for query in search_queries:
            results = self.search_web(query, num_results=3)
            all_results.extend(results)

        # Remove duplicates and sort by relevance
        unique_results = []
        seen_urls = set()

        for result in all_results:
            if result['link'] not in seen_urls:
                seen_urls.add(result['link'])
                unique_results.append(result)

        return unique_results[:10]  # Return top 10 results

    def get_software_info(self, software_name: str) -> Dict[str, Any]:
        """Get information about software"""
        search_query = f"{software_name} official website"
        results = self.search_web(search_query, num_results=5)

        if not results:
            return {'error': f'No information found for {software_name}'}

        # Try to get official website info
        official_result = None
        for result in results:
            if software_name.lower() in result['link'].lower():
                official_result = result
                break

        if not official_result:
            official_result = results[0]

        return {
            'software': software_name,
            'official_website': official_result['link'],
            'description': official_result['snippet'][:200],
            'title': official_result['title']
        }

    def cleanup_downloads(self, older_than_days: int = 7) -> int:
        """Clean up old download files"""
        deleted_count = 0
        current_time = time.time()

        for file_path in self.download_dir.iterdir():
            if file_path.is_file():
                file_age = current_time - file_path.stat().st_mtime
                if file_age > (older_than_days * 24 * 3600):  # Convert days to seconds
                    try:
                        file_path.unlink()
                        deleted_count += 1
                        print(f"🗑️ Deleted old file: {file_path.name}")
                    except Exception as e:
                        print(f"⚠️ Could not delete {file_path.name}: {e}")

        return deleted_count

    def get_download_history(self) -> List[Dict[str, Any]]:
        """Get history of downloaded files"""
        history = []
        for file_path in self.download_dir.iterdir():
            if file_path.is_file():
                stat = file_path.stat()
                history.append({
                    'filename': file_path.name,
                    'path': str(file_path),
                    'size': stat.st_size,
                    'modified': stat.st_mtime,
                    'size_mb': round(stat.st_size / (1024 * 1024), 2)
                })

        return sorted(history, key=lambda x: x['modified'], reverse=True)