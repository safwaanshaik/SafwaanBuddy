#!/usr/bin/env python3
"""
Enhanced Main Window with Jarvis Interface
Integrates advanced visual interface with screen interaction and automation
"""

import sys
import json
import time
from datetime import datetime
from typing import Optional, Dict, Any, List
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QTextEdit, QGroupBox, QStatusBar,
    QApplication, QMessageBox, QDialog, QFrame, QSplitter,
    QScrollArea, QProgressBar, QTabWidget, QSizePolicy
)
from PyQt6.QtCore import (
    Qt, QTimer, QThread, pyqtSignal, QSize, QPoint, QRect,
    QPropertyAnimation, QEasingCurve, QParallelAnimationGroup
)
from PyQt6.QtGui import (
    QFont, QIcon, QPixmap, QPainter, QColor, QBrush, QPen,
    QLinearGradient, QRadialGradient
)

from .jarvis_interface import VisualAssistant, AssistantState
from utils.logger import get_logger
from core.screen_interaction import AdvancedScreenInteraction, FormField
from core.web_automation import AdvancedWebAutomation

class ScreenInteractionWidget(QWidget):
    """Widget for displaying screen interaction information"""

    def __init__(self):
        super().__init__()
        self.screen_interaction = AdvancedScreenInteraction()
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout()

        # Screen interaction controls
        control_group = QGroupBox("Screen Control")
        control_layout = QGridLayout()

        self.screenshot_btn = QPushButton("📸 Take Screenshot")
        self.screenshot_btn.clicked.connect(self.take_screenshot)
        control_layout.addWidget(self.screenshot_btn, 0, 0)

        self.detect_elements_btn = QPushButton("🔍 Detect Elements")
        self.detect_elements_btn.clicked.connect(self.detect_elements)
        control_layout.addWidget(self.detect_elements_btn, 0, 1)

        self.find_forms_btn = QPushButton("📋 Find Forms")
        self.find_forms_btn.clicked.connect(self.find_forms)
        control_layout.addWidget(self.find_forms_btn, 0, 2)

        control_group.setLayout(control_layout)
        layout.addWidget(control_group)

        # Detected elements display
        self.elements_text = QTextEdit()
        self.elements_text.setMaximumHeight(150)
        self.elements_text.setPlaceholderText("Detected elements will appear here...")
        layout.addWidget(QLabel("Detected Elements:"))
        layout.addWidget(self.elements_text)

        # Quick actions
        quick_group = QGroupBox("Quick Actions")
        quick_layout = QGridLayout()

        self.click_by_text_btn = QPushButton("👆 Click by Text")
        self.click_by_text_btn.clicked.connect(self.click_by_text)
        quick_layout.addWidget(self.click_by_text_btn, 0, 0)

        self.fill_form_btn = QPushButton("📝 Fill Form")
        self.fill_form_btn.clicked.connect(self.fill_form)
        quick_layout.addWidget(self.fill_form_btn, 0, 1)

        self.scroll_btn = QPushButton("📜 Scroll")
        self.scroll_btn.clicked.connect(self.scroll_screen)
        quick_layout.addWidget(self.scroll_btn, 0, 2)

        quick_group.setLayout(quick_layout)
        layout.addWidget(quick_group)

        self.setLayout(layout)

    def take_screenshot(self):
        """Take a screenshot"""
        screenshot_path = self.screen_interaction.take_screenshot()
        self.elements_text.append(f"📸 Screenshot saved: {screenshot_path}")

    def detect_elements(self):
        """Detect UI elements on screen"""
        elements = self.screen_interaction.detect_ui_elements(
            self.screen_interaction.capture_screen()
        )

        self.elements_text.clear()
        self.elements_text.append(f"🔍 Found {len(elements)} elements:\n")

        for i, element in enumerate(elements, 1):
            self.elements_text.append(
                f"{i}. {element.element_type.upper()}: '{element.text}' "
                f"at ({element.center[0]}, {element.center[1]}) "
                f"[confidence: {element.confidence:.2f}]"
            )

    def find_forms(self):
        """Find form fields"""
        form_fields = self.screen_interaction.find_form_fields()

        self.elements_text.clear()
        self.elements_text.append(f"📋 Found {len(form_fields)} form fields:\n")

        for i, field in enumerate(form_fields, 1):
            self.elements_text.append(
                f"{i}. {field.field_type}: '{field.label}' "
                f"at ({field.center[0]}, {field.center[1]})"
            )

    def click_by_text(self):
        """Click element by text"""
        text = "Submit"  # This could be made configurable
        success = self.screen_interaction.click_text(text)
        self.elements_text.append(f"👆 Clicked '{text}': {'✅ Success' if success else '❌ Failed'}")

    def fill_form(self):
        """Fill a sample form"""
        sample_data = {
            "name": "John Doe",
            "email": "john.doe@example.com",
            "phone": "123-456-7890"
        }

        results = self.screen_interaction.fill_form(sample_data)
        self.elements_text.append("📝 Form filling results:")
        for field, success in results.items():
            self.elements_text.append(f"  {field}: {'✅' if success else '❌'}")

    def scroll_screen(self):
        """Scroll the screen"""
        from pyautogui import scroll
        scroll(-200)  # Scroll down
        self.elements_text.append("📜 Scrolled down")

class WebAutomationWidget(QWidget):
    """Widget for web automation tasks"""

    def __init__(self):
        super().__init__()
        self.web_automation = AdvancedWebAutomation()
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout()

        # Search controls
        search_group = QGroupBox("Web Search")
        search_layout = QVBoxLayout()

        self.search_input = QTextEdit()
        self.search_input.setMaximumHeight(50)
        self.search_input.setPlaceholderText("Enter search query...")
        search_layout.addWidget(self.search_input)

        self.search_btn = QPushButton("🔍 Search Web")
        self.search_btn.clicked.connect(self.search_web)
        search_layout.addWidget(self.search_btn)

        self.software_search_btn = QPushButton("💾 Find Software")
        self.software_search_btn.clicked.connect(self.find_software)
        search_layout.addWidget(self.software_search_btn)

        search_group.setLayout(search_layout)
        layout.addWidget(search_group)

        # Download controls
        download_group = QGroupBox("Downloads & Installation")
        download_layout = QGridLayout()

        self.download_url_input = QTextEdit()
        self.download_url_input.setMaximumHeight(50)
        self.download_url_input.setPlaceholderText("Enter URL to download...")
        download_layout.addWidget(self.download_url_input, 0, 0, 1, 2)

        self.download_btn = QPushButton("📥 Download")
        self.download_btn.clicked.connect(self.download_file)
        download_layout.addWidget(self.download_btn, 1, 0)

        self.install_btn = QPushButton("⚙️ Install")
        self.install_btn.clicked.connect(self.install_software)
        download_layout.addWidget(self.install_btn, 1, 1)

        download_group.setLayout(download_layout)
        layout.addWidget(download_group)

        # Results display
        self.results_text = QTextEdit()
        self.results_text.setPlaceholderText("Search results and download information will appear here...")
        layout.addWidget(QLabel("Results:"))
        layout.addWidget(self.results_text)

        self.setLayout(layout)

    def search_web(self):
        """Search the web"""
        query = self.search_input.toPlainText().strip()
        if not query:
            return

        self.results_text.append(f"🔍 Searching for: {query}")
        results = self.web_automation.search_web(query)

        self.results_text.append(f"Found {len(results)} results:\n")
        for i, result in enumerate(results, 1):
            self.results_text.append(
                f"{i}. {result['title']}\n   {result['link']}\n   {result['snippet']}\n"
            )

    def find_software(self):
        """Find software to download"""
        query = self.search_input.toPlainText().strip()
        if not query:
            return

        self.results_text.append(f"💾 Searching for software: {query}")
        result = self.web_automation.search_and_install(query, auto_install=False)

        if result['success']:
            self.results_text.append(f"✅ Found: {result['download_link']['title']}")
            self.results_text.append(f"📎 {result['download_link']['link']}")
            self.download_url_input.setPlainText(result['download_link']['link'])
        else:
            self.results_text.append(f"❌ {result['message']}")

    def download_file(self):
        """Download file from URL"""
        url = self.download_url_input.toPlainText().strip()
        if not url:
            return

        self.results_text.append(f"📥 Downloading from: {url}")
        downloaded_file = self.web_automation.download_file(url)

        if downloaded_file:
            self.results_text.append(f"✅ Downloaded to: {downloaded_file}")
        else:
            self.results_text.append("❌ Download failed")

    def install_software(self):
        """Install downloaded software"""
        # For now, just get download history
        history = self.web_automation.get_download_history()
        self.results_text.append("📋 Download history:")
        for item in history[:5]:  # Show last 5 downloads
            self.results_text.append(
                f"  • {item['filename']} ({item['size_mb']} MB)"
            )

class EnhancedSafwaanBuddyGUI(QMainWindow):
    """Enhanced GUI with Jarvis interface and advanced capabilities"""

    def __init__(self, memory_manager=None, voice_processor=None,
                 command_parser=None, plugin_manager=None, ui_automation=None,
                 natural_speech=None, system_control=None, ai_personality=None):
        """Initialize enhanced main window."""
        super().__init__()

        # Core components
        self.memory_manager = memory_manager
        self.voice_processor = voice_processor
        self.command_parser = command_parser
        self.plugin_manager = plugin_manager
        self.ui_automation = ui_automation
        self.natural_speech = natural_speech
        self.system_control = system_control
        self.ai_personality = ai_personality

        # Enhanced components
        self.logger = get_logger("enhanced_gui")

        # Visual assistant
        self.visual_assistant = VisualAssistant()

        # Advanced capabilities
        self.screen_widget = ScreenInteractionWidget()
        self.web_widget = WebAutomationWidget()

        self.setup_ui()
        self.setup_connections()

        # Position visual assistant
        self.visual_assistant.show()

        self.logger.info("Enhanced Safwaan Buddy GUI initialized")

    def setup_ui(self):
        """Setup the enhanced user interface"""
        self.setWindowTitle("Safwaan Buddy Enhanced - Advanced AI Assistant")
        self.setGeometry(100, 100, 1400, 900)

        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Main layout
        main_layout = QHBoxLayout()

        # Create tab widget for different features
        self.tab_widget = QTabWidget()

        # Chat tab
        self.chat_widget = self.create_chat_widget()
        self.tab_widget.addTab(self.chat_widget, "💬 Chat")

        # Screen interaction tab
        self.tab_widget.addTab(self.screen_widget, "🖥️ Screen Control")

        # Web automation tab
        self.tab_widget.addTab(self.web_widget, "🌐 Web Automation")

        # System control tab
        self.system_widget = self.create_system_widget()
        self.tab_widget.addTab(self.system_widget, "⚙️ System Control")

        main_layout.addWidget(self.tab_widget, 3)

        # Status panel
        status_panel = self.create_status_panel()
        main_layout.addWidget(status_panel, 1)

        central_widget.setLayout(main_layout)

        # Status bar
        self.statusBar().showMessage("Safwaan Buddy Enhanced - Ready")

    def create_chat_widget(self) -> QWidget:
        """Create chat interface widget"""
        widget = QWidget()
        layout = QVBoxLayout()

        # Conversation display
        self.conversation_display = QTextEdit()
        self.conversation_display.setReadOnly(True)
        self.conversation_display.setFont(QFont("Arial", 12))
        layout.addWidget(QLabel("Conversation:"))
        layout.addWidget(self.conversation_display)

        # Input area
        input_layout = QHBoxLayout()
        self.input_field = QTextEdit()
        self.input_field.setMaximumHeight(100)
        self.input_field.setPlaceholderText("Type your message or say 'Hey Buddy'...")
        input_layout.addWidget(self.input_field)

        self.send_btn = QPushButton("📤 Send")
        self.send_btn.clicked.connect(self.send_message)
        input_layout.addWidget(self.send_btn)

        self.voice_btn = QPushButton("🎤 Voice")
        self.voice_btn.clicked.connect(self.toggle_voice_input)
        input_layout.addWidget(self.voice_btn)

        layout.addLayout(input_layout)

        widget.setLayout(layout)
        return widget

    def create_system_widget(self) -> QWidget:
        """Create system control widget"""
        widget = QWidget()
        layout = QVBoxLayout()

        # System info
        self.system_info_label = QLabel("System Information")
        self.system_info_label.setFont(QFont("Arial", 14, QFont.Weight.Bold))
        layout.addWidget(self.system_info_label)

        self.system_status = QTextEdit()
        self.system_status.setReadOnly(True)
        layout.addWidget(self.system_status)

        # Quick actions
        actions_layout = QGridLayout()

        self.refresh_btn = QPushButton("🔄 Refresh")
        self.refresh_btn.clicked.connect(self.refresh_system_info)
        actions_layout.addWidget(self.refresh_btn, 0, 0)

        self.cleanup_btn = QPushButton("🧹 Cleanup")
        self.cleanup_btn.clicked.connect(self.cleanup_system)
        actions_layout.addWidget(self.cleanup_btn, 0, 1)

        layout.addLayout(actions_layout)

        # Add some initial system info
        self.refresh_system_info()

        widget.setLayout(layout)
        return widget

    def create_status_panel(self) -> QWidget:
        """Create status panel"""
        widget = QWidget()
        layout = QVBoxLayout()

        # Assistant status
        status_group = QGroupBox("Assistant Status")
        status_layout = QVBoxLayout()

        self.assistant_state_label = QLabel("State: Idle")
        self.assistant_state_label.setStyleSheet("font-weight: bold;")
        status_layout.addWidget(self.assistant_state_label)

        self.emotion_label = QLabel("Emotion: Neutral")
        status_layout.addWidget(self.emotion_label)

        self.confidence_label = QLabel("Confidence: 0%")
        status_layout.addWidget(self.confidence_label)

        status_group.setLayout(status_layout)
        layout.addWidget(status_group)

        # Performance metrics
        metrics_group = QGroupBox("Performance")
        metrics_layout = QVBoxLayout()

        self.cpu_label = QLabel("CPU: 0%")
        metrics_layout.addWidget(self.cpu_label)

        self.memory_label = QLabel("Memory: 0%")
        metrics_layout.addWidget(self.memory_label)

        self.response_time_label = QLabel("Response Time: 0ms")
        metrics_layout.addWidget(self.response_time_label)

        metrics_group.setLayout(metrics_layout)
        layout.addWidget(metrics_group)

        widget.setLayout(layout)

        # Update timer
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update_status)
        self.update_timer.start(2000)  # Update every 2 seconds

        return widget

    def setup_connections(self):
        """Setup signal connections"""
        # Voice state updates
        if self.voice_processor:
            self.voice_processor.add_callback(self.on_voice_event)

    def on_voice_event(self, event):
        """Handle voice events and update visual assistant"""
        if event.event_type == "wake_word_detected":
            self.visual_assistant.set_state(AssistantState.LISTENING)
            self.assistant_state_label.setText("State: Listening")
        elif event.event_type == "command_recognized":
            self.visual_assistant.set_state(AssistantState.THINKING)
            self.assistant_state_label.setText("State: Thinking")
        elif event.event_type == "response_ready":
            self.visual_assistant.set_state(AssistantState.SPEAKING)
            self.assistant_state_label.setText("State: Speaking")

    def send_message(self):
        """Send a message to the AI"""
        message = self.input_field.toPlainText().strip()
        if not message:
            return

        # Add to conversation
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.conversation_display.append(f"<b>You [{timestamp}]:</b> {message}")

        # Clear input
        self.input_field.clear()

        # Process message
        self.process_message(message)

    def process_message(self, message: str):
        """Process user message"""
        start_time = time.time()

        # Set visual state to thinking
        self.visual_assistant.set_state(AssistantState.THINKING)

        try:
            if self.command_parser:
                # Try to parse as command
                parsed = self.command_parser.parse_command(message)
                if parsed.intent_type != "general_query":
                    response = self.handle_command(parsed)
                else:
                    response = self.handle_general_query(message)
            else:
                response = "Command parser not available."

        except Exception as e:
            response = f"I apologize, but I encountered an error: {e}"

        # Calculate response time
        response_time = (time.time() - start_time) * 1000
        self.response_time_label.setText(f"Response Time: {response_time:.0f}ms")

        # Add response to conversation
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.conversation_display.append(f"<b>Buddy [{timestamp}]:</b> {response}")
        self.conversation_display.append("")  # Add spacing

        # Set visual state to speaking
        self.visual_assistant.set_state(AssistantState.SPEAKING)

        # Use text-to-speech if available
        if self.voice_processor and self.natural_speech:
            try:
                # Enhance response with natural speech
                enhanced_response = self.natural_speech.enhance_response_naturally(response)
                self.voice_processor.speak(enhanced_response)
            except Exception as e:
                self.logger.error(f"TTS error: {e}")

        # Return to idle after speaking
        QTimer.singleShot(3000, lambda: self.visual_assistant.set_state(AssistantState.IDLE))

    def handle_command(self, parsed_command) -> str:
        """Handle parsed commands"""
        # Enhanced command handling with screen and web capabilities
        if parsed_command.intent_type == "SCREENSHOT":
            screenshot_path = self.screen_widget.screen_interaction.take_screenshot()
            return f"📸 Screenshot saved to {screenshot_path}"

        elif parsed_command.intent_type == "FILL_FORM":
            # Extract form data from command
            # This would need more sophisticated parsing in practice
            sample_data = {"name": "Sample Name", "email": "sample@example.com"}
            results = self.screen_widget.screen_interaction.fill_form(sample_data)
            return f"📝 Form filling completed with {sum(results.values())} successful fields"

        elif parsed_command.intent_type == "DOWNLOAD":
            if self.web_widget.web_automation:
                software_name = parsed_command.parameters.get("software_name", "Unknown")
                result = self.web_widget.web_automation.search_and_install(software_name)
                return result['message']
            else:
                return "Web automation not available"

        elif "system_control" in str(type(self.system_control)):
            # Try to handle with system control
            command_handler = getattr(self, f"_handle_{parsed_command.intent_type}", None)
            if command_handler:
                return command_handler(parsed_command)

        return f"I'll help you with: {parsed_command.original_text}"

    def handle_general_query(self, message: str) -> str:
        """Handle general AI queries"""
        if self.ai_personality:
            try:
                # Get context from memory
                context = []
                if self.memory_manager:
                    recent_conversations = self.memory_manager.get_recent_conversations(5)
                    context = [
                        {"user": conv['user'], "assistant": conv['agent']}
                        for conv in recent_conversations
                    ]

                # Get AI response
                ai_response = self.ai_personality.analyze_and_respond(
                    message, context, "english"
                )

                if ai_response["success"]:
                    return ai_response["response"]
                else:
                    return f"I apologize, but I encountered an issue: {ai_response.get('error', 'Unknown error')}"

            except Exception as e:
                self.logger.error(f"AI personality error: {e}")
                return f"I'm having trouble processing that right now. Could you try again?"

        return f"I understand you're asking about: {message}. Let me help you with that."

    def toggle_voice_input(self):
        """Toggle voice input"""
        if self.voice_processor:
            if self.voice_processor.is_listening:
                self.voice_processor.stop_listening()
                self.voice_btn.setText("🎤 Voice")
            else:
                self.voice_processor.start_listening()
                self.voice_btn.setText("⏹️ Stop")
        else:
            QMessageBox.information(self, "Voice Input", "Voice processor not available")

    def update_status(self):
        """Update status panel"""
        # Update assistant state
        current_state = self.visual_assistant.get_state()
        self.assistant_state_label.setText(f"State: {current_state.value.title()}")

        # Update system metrics (if available)
        try:
            import psutil
            cpu_percent = psutil.cpu_percent()
            memory_percent = psutil.virtual_memory().percent
            self.cpu_label.setText(f"CPU: {cpu_percent:.1f}%")
            self.memory_label.setText(f"Memory: {memory_percent:.1f}%")
        except:
            pass

    def refresh_system_info(self):
        """Refresh system information"""
        if self.system_control:
            try:
                overview = self.system_control.get_system_overview()
                if overview["success"]:
                    self.system_status.setText(overview["message"])
                else:
                    self.system_status.setText("Failed to get system information")
            except Exception as e:
                self.system_status.setText(f"Error: {e}")

    def cleanup_system(self):
        """Perform system cleanup"""
        if self.web_widget.web_automation:
            deleted = self.web_widget.web_automation.cleanup_downloads()
            QMessageBox.information(self, "Cleanup", f"Deleted {deleted} old download files")

    def closeEvent(self, event):
        """Handle window close event"""
        self.visual_assistant.close()

        # Cleanup web automation
        if self.web_widget.web_automation.driver:
            self.web_widget.web_automation.driver.quit()

        # Save conversation to memory if available
        if self.memory_manager and self.conversation_display:
            conversation_text = self.conversation_display.toPlainText()
            if conversation_text:
                self.memory_manager.store_conversation(
                    "User", conversation_text, {"type": "chat_session"}
                )

        event.accept()