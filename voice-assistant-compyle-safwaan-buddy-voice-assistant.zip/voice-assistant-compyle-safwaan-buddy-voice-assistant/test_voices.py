#!/usr/bin/env python3
"""
Ultra-Natural Voice Test Script
Test the ultra-natural voice system
"""

# Test command
test_commands = [
    # Test Hindi voice
    "python -c "from core.enhanced_voice_processor import EnhancedVoiceProcessor; v = EnhancedVoiceProcessor(); v.set_speech_mode('regional'); v.speak_with_regional_adaptation('Namaste dost! Kya haal hai?', 'hindi')"",

    # Test Hyderabadi voice
    "python -c "from core.enhanced_voice_processor import EnhancedVoiceProcessor; v = EnhancedVoiceProcessor(); v.set_speech_mode('regional'); v.speak_with_regional_adaptation('Assalamualaikum bhai! Key scene hai?', 'hyderabadi')"",

    # Test Emotional English
    "python -c "from core.enhanced_voice_processor import EnhancedVoiceProcessor; v = EnhancedVoiceProcessor(); v.speak_with_emotional_effects('OH MY GOD! This is amazing!', 'excited')"",

    # Test Conversation
    "python -c "from core.enhanced_voice_processor import EnhancedVoiceProcessor; v = EnhancedVoiceProcessor(); v.emotional_conversation([{'text': 'Hello there!', 'emotion': 'excited'}, {'text': 'How are you doing today?', 'emotion': 'friendly'}])""
]

print("🎙️ Voice Test Commands:")
for i, cmd in enumerate(test_commands, 1):
    print(f"{i}. {cmd}")
    print()
